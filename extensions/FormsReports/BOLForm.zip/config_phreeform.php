<?php 
// +-----------------------------------------------------------------+
// |                   PhreeBooks Open Source ERP                    |
// +-----------------------------------------------------------------+
// | Copyright (c) 2008, 2009, 2010, 2011, 2012 PhreeSoft, LLC       |
// | http://www.PhreeSoft.com                                        |
// +-----------------------------------------------------------------+
// | This program is free software: you can redistribute it and/or   |
// | modify it under the terms of the GNU General Public License as  |
// | published by the Free Software Foundation, either version 3 of  |
// | the License, or any later version.                              |
// |                                                                 |
// | This program is distributed in the hope that it will be useful, |
// | but WITHOUT ANY WARRANTY; without even the implied warranty of  |
// | MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the   |
// | GNU General Public License for more details.                    |
// +-----------------------------------------------------------------+
//  Path: /modules/inventory/config_phreeform.php
// 
$myTotalWeight = 0;

$FormProcessing['myNMFC']        = 'NMFC# from SKU';
$FormProcessing['myClass']       = 'Class from SKU';
$FormProcessing['myLineWeight']  = 'Weight from Qty';
$FormProcessing['myTotalWeight'] = 'Total Order Weight';
// Extra form processing operations
function pf_process_inventory($strData, $Process) {
	global $myTotalWeight;
	switch ($Process) {
	case "myNMFC":        return get_my_NMFC($strData);
	case "myClass":       return get_my_class($strData);
	case "myLineWeight":  return get_my_line_weight($strData);
	case "myTotalWeight": return $myTotalWeight;
	default: // Do nothing
  }
  return $strData; // No Process recognized, return original value
}

function get_my_NMFC($sku) {
  global $db, $myWeight, $currencies;
  if (!$sku) return '';
  $result = $db->Execute("select item_weight, NMFC, class from ".TABLE_INVENTORY." where sku = '$sku'");
  if ($result->RecordCount()==0) {
    $myWeight = 20;
  	$code     = '99';
  } else {
  	$myWeight = $currencies->clean_value($result->fields['item_weight']);
  	$code     = $result->fields['NMFC'];
  }
  return $code;
}

function get_my_class($sku) {
  global $db, $myWeight, $currencies;
  if (!$sku) return '';
  $result = $db->Execute("select item_weight, NMFC, class from ".TABLE_INVENTORY." where sku = '$sku'");
  if ($result->RecordCount()==0) {
	$myWeight = 10;
	$class    = '60';
  } else {
	$myWeight = $currencies->clean_value($result->fields['item_weight']);
	$class    = $result->fields['class'];
  }
  return $class;
}

function get_my_line_weight($qty) {
	global $myWeight, $myTotalWeight;
	$lineWeight     = number_format($qty * $myWeight, 0, '.', '');
	$myTotalWeight += $lineWeight;
	return $lineWeight;
}

?>