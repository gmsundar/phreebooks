Installation Instructions:

1. Copy 2 files (gnumicr.php and gnumicr.z) to the directory /includes/addons/tcpdf/fonts

2. Replace line 37 of file: /modules/reportwriter/language/en_us/language.php with
FROM:
  $Fonts['freeserif'] = RW_FONT_SERIF;
TO:
  $Fonts['freeserif'] = RW_FONT_SERIF;
  $Fonts['gnumicr']   = 'GNU MICR';

3. Import the report (Check-MICR.rpt.txt) with reportwriter.

Notes:
- You must be using TCPDF as the rendering application.
- The report needs to be editted for value and location of the routing number, account. 
- Other edits of the report may be needed.
- The new font should show up as available when choosing the font to display the entry with.