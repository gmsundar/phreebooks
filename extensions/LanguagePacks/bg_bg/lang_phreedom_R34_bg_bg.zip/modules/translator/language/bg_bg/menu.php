<?php
// +-----------------------------------------------------------------+
// Phreedom Language Translation File
// Generated: 2012-08-05 03:42:01
// Module/Method: translator
// ISO Language: bg_bg
// Version: 3.3
// +-----------------------------------------------------------------+
// Path: /modules/translator/language/bg_bg/menu.php

define('MENU_HEADING_TRANSLATOR','Language Translator Tool');
define('BOX_TRANSLATOR_MODULE','Translator Assistant');

?>
