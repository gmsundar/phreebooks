<?php
// +-----------------------------------------------------------------+
// Phreedom Language Translation File
// Generated: 2012-08-05 03:42:01
// Module/Method: translator
// ISO Language: bg_bg
// Version: 3.3
// +-----------------------------------------------------------------+
// Path: /modules/translator/language/bg_bg/admin.php

define('MODULE_TRANSLATOR_TITLE','Translator Module');
define('MODULE_TRANSLATOR_DESCRIPTION','The Translator module provides a convenient interface to translate language files from one language ot another. This module handles version updates as well as full initial translation support.');

?>
