<?php
// +-----------------------------------------------------------------+
// Phreedom Language Translation File
// Generated: 2012-08-05 03:41:59
// Module/Method: phreebooks-open_inv
// ISO Language: bg_bg
// Version: 3.3
// +-----------------------------------------------------------------+
// Path: /modules/phreebooks/dashboards/open_inv/language/bg_bg/language.php

define('CP_OPEN_INV_TITLE','Open Invoices');
define('CP_OPEN_INV_DESCRIPTION','Lists open sales/invoices. Links to reveiw the invoice are also provided.');
define('CP_OPEN_INV_NO_RESULTS','No results found!');

?>
