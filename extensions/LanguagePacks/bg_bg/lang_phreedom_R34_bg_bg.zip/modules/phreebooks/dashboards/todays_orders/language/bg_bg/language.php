<?php
// +-----------------------------------------------------------------+
// Phreedom Language Translation File
// Generated: 2012-08-05 03:41:59
// Module/Method: phreebooks-todays_orders
// ISO Language: bg_bg
// Version: 3.2
// +-----------------------------------------------------------------+
// Path: /modules/phreebooks/dashboards/todays_orders/language/bg_bg/language.php

define('CP_TODAYS_ORDERS_TITLE','Today\\\'s Sales Orders');
define('CP_TODAYS_ORDERS_DESCRIPTION','Lists today\\\'s sales orders. Links to reveiw the sales orders are also provided.');
define('CP_TODAYS_ORDERS_NO_RESULTS','No results found!');

?>
