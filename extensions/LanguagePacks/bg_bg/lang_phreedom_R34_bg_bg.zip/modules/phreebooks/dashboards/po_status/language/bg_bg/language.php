<?php
// +-----------------------------------------------------------------+
// Phreedom Language Translation File
// Generated: 2012-08-05 03:41:59
// Module/Method: phreebooks-po_status
// ISO Language: bg_bg
// Version: 3.2
// +-----------------------------------------------------------------+
// Path: /modules/phreebooks/dashboards/po_status/language/bg_bg/language.php

define('CP_PO_STATUS_TITLE','Open Purchase Orders');
define('CP_PO_STATUS_DESCRIPTION','Lists purchase orders with current open status. Links to reveiw the purchase order are also provided.');
define('CP_PO_STATUS_SORT_ORDER','Sort Order by Post Date');
define('CP_PO_STATUS_HIDE_FUTURE','Restrict to Today and Earlier');

?>
