<?php
// +-----------------------------------------------------------------+
// Phreedom Language Translation File
// Generated: 2012-08-05 03:41:59
// Module/Method: phreebooks-open_inv_branch
// ISO Language: bg_bg
// Version: 1.0
// +-----------------------------------------------------------------+
// Path: /modules/phreebooks/dashboards/open_inv_branch/language/bg_bg/language.php

define('CP_OPEN_INV_BRANCH_TITLE','Open Invoices by Branch');
define('CP_OPEN_INV_BRANCH_DESCRIPTION','Lists open sales/invoices by the users default branch. Links to reveiw the invoice are also provided.');
define('CP_OPEN_INV_BRANCH_NO_RESULTS','No results found!');

?>
