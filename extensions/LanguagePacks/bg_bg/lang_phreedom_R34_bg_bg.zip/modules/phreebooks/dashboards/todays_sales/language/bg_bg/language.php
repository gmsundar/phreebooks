<?php
// +-----------------------------------------------------------------+
// Phreedom Language Translation File
// Generated: 2012-08-05 03:41:59
// Module/Method: phreebooks-todays_sales
// ISO Language: bg_bg
// Version: 3.2
// +-----------------------------------------------------------------+
// Path: /modules/phreebooks/dashboards/todays_sales/language/bg_bg/language.php

define('CP_TODAYS_SALES_TITLE','Today\\\'s Sales');
define('CP_TODAYS_SALES_DESCRIPTION','Lists today\\\'s sales/invoices. Links to reveiw the invoice are also provided.');
define('CP_TODAYS_SALES_NO_RESULTS','No results found!');

?>
