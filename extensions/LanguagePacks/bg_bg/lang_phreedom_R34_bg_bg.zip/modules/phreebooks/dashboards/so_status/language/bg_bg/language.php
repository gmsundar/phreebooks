<?php
// +-----------------------------------------------------------------+
// Phreedom Language Translation File
// Generated: 2012-08-05 03:41:59
// Module/Method: phreebooks-so_status
// ISO Language: bg_bg
// Version: 3.2
// +-----------------------------------------------------------------+
// Path: /modules/phreebooks/dashboards/so_status/language/bg_bg/language.php

define('CP_SO_STATUS_TITLE','Open Sales Orders');
define('CP_SO_STATUS_DESCRIPTION','Lists sales orders with current open status. Links to reveiw the sales order are also provided.');
define('CP_SO_STATUS_SORT_ORDER','Sort Order by Post Date');
define('CP_SO_STATUS_HIDE_FUTURE','Restrict to Today and Earlier');

?>
