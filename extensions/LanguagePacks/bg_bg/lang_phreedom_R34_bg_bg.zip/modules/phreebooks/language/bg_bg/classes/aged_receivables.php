<?php
// +-----------------------------------------------------------------+
// Phreedom Language Translation File
// Generated: 2012-08-05 03:42:00
// Module/Method: phreebooks
// ISO Language: bg_bg
// Version: 3.4
// +-----------------------------------------------------------------+
// Path: /modules/phreebooks/language/bg_bg/classes/aged_receivables.php

define('RW_AR_JOURNAL_DESC','Описание на журнал');
define('RW_AR_STORE_ID','Склад ID');
define('RW_AR_RECORD_ID','Запис ID');
define('TEXT_AGE','Възраст');
define('RW_AR_CLOSED','Затворен');
define('RW_AR_FRT_TOTAL','Навло сума');
define('RW_AR_FRT_CARRIER','Превозвач');
define('RW_AR_FRT_SERVICE','Навло услуга');
define('RW_AR_TERMS','Срокове');
define('RW_AR_SALES_TAX','Данък продажби');
define('RW_AR_TAX_AUTH','Вид данък');
define('RW_AR_INV_TOTAL','Сума по фактура');
define('RW_AR_BALANCE_DUE','Дължимо салдо');
define('RW_AR_CUR_CODE','Код на валута');
define('RW_AR_CUR_EXC_RATE','Обменен курс на валута');
define('RW_AR_SO_NUM','Номер на поръчка за продажба');
define('RW_AR_INV_NUM','Номер на фактура');
define('RW_AR_PO_NUM','Номер на поръчка за покупка');
define('RW_AR_SALES_REP','Справка продажби');
define('RW_AR_AR_ACCT','Сметка клиенти');
define('RW_AR_BILL_ACCT_ID','Сметка за фактуриране ID');
define('RW_AR_BILL_ADD_ID','Адрес на фактуриране ID');
define('RW_AR_BILL_PRIMARY_NAME','Основно име на фактуриране');
define('RW_AR_BILL_CONTACT','Контакт за фактуриране');
define('RW_AR_BILL_ADDRESS1','Адрес 1 за фактуриране');
define('RW_AR_BILL_ADDRESS2','Адрес 2 за фактуриране');
define('RW_AR_BILL_CITY','Град за фактуриране');
define('RW_AR_BILL_STATE','Щат/област за фактуриране');
define('RW_AR_BILL_ZIP','Пощенски код за фактуриране');
define('RW_AR_BILL_COUNTRY','Страна за фактуриране');
define('RW_AR_BILL_TELE1','Телефон 1 за фактуриране');
define('RW_AR_BILL_TELE2','Телефон 2 за фактуриране');
define('RW_AR_BILL_FAX','Факс за фактуриране');
define('RW_AR_BILL_EMAIL','Имейл за фактуриране');
define('RW_AR_BILL_WEBSITE','Уебсайт за фактуриране');
define('RW_AR_SHIP_ACCT_ID','Сметка за превозване ID');
define('RW_AR_SHIP_ADD_ID','Адрес за превозване ID');
define('RW_AR_SHIP_PRIMARY_NAME','Основно име на превозване');
define('RW_AR_SHIP_CONTACT','Контакт за превозване');
define('RW_AR_SHIP_ADDRESS1','Адрес 1 за превозване');
define('RW_AR_SHIP_ADDRESS2','Адрес 2 за превозване');
define('RW_AR_SHIP_CITY','Град за превозване');
define('RW_AR_SHIP_STATE','Щат/област за превозване');
define('RW_AR_SHIP_ZIP','Пощенски код за превозване');
define('RW_AR_SHIP_COUNTRY','Страна за превозване');
define('RW_AR_SHIP_TELE1','Телефон 1 за превозване');
define('RW_AR_SHIP_TELE2','Телефон 2 за превозване');
define('RW_AR_SHIP_FAX','Факс за превозване');
define('RW_AR_SHIP_EMAIL','Имейл за превозване');
define('RW_AR_SHIP_WEBSITE','Уебсайт за превозване');
define('RW_AR_CUSTOMER_ID','Клиент ID');
define('RW_AR_ACCOUNT_NUMBER','Сметка номер');
define('RW_AR_SHIP_DATE','Дата на превозване');
define('RW_AR_JOURNAL_ID','Journal ID');

?>
