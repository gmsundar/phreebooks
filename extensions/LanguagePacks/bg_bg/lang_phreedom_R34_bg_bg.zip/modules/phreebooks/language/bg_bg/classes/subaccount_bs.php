<?php
// +-----------------------------------------------------------------+
// Phreedom Language Translation File
// Generated: 2012-08-05 03:42:00
// Module/Method: phreebooks
// ISO Language: bg_bg
// Version: 3.4
// +-----------------------------------------------------------------+
// Path: /modules/phreebooks/language/bg_bg/classes/subaccount_bs.php

define('RW_SUB_ACT_BAL_SHT_IS_ACCT','0');
define('RW_RECORD_ID','Плейсхолдър за колона');

?>
