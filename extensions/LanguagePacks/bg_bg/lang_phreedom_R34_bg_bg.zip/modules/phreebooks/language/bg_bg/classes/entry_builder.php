<?php
// +-----------------------------------------------------------------+
// Phreedom Language Translation File
// Generated: 2012-08-05 03:42:00
// Module/Method: phreebooks
// ISO Language: bg_bg
// Version: 3.4
// +-----------------------------------------------------------------+
// Path: /modules/phreebooks/language/bg_bg/classes/entry_builder.php

define('TEXT_SO_POST_DATE','Дата на публикуване на поръчка за продажба');
define('RW_EB_PAYMENT_DETAIL','Подробна информация за плащане');
define('RW_EB_RECORD_ID','Запис ID');
define('RW_EB_JOURNAL_ID','Журнал ID');
define('RW_EB_STORE_ID','Склад ID');
define('RW_EB_JOURNAL_DESC','Описание на журнал');
define('RW_EB_CLOSED','Затворен');
define('RW_EB_FRT_TOTAL','Сума на навло');
define('RW_EB_FRT_CARRIER','Навло превозвач');
define('RW_EB_FRT_SERVICE','Навло услуга');
define('RW_EB_FRT_TRACKING','Номер за проследяване');
define('RW_EB_TERMS','Срокове');
define('RW_EB_INV_DISCOUNT','Отстъпка за фактура');
define('RW_EB_SALES_TAX','Данък продажби');
define('RW_EB_TAX_AUTH','Вид данък');
define('RW_EB_TAX_DETAILS','Подробности за данък');
define('RW_EB_INV_SUBTOTAL','Междинна сума по фактура');
define('RW_EB_INV_SUB_W_TAX','Междинна сума по фактура без данък');
define('RW_EB_INV_TOTAL','Сума по фактура');
define('RW_EB_CUR_CODE','Код на валута');
define('RW_EB_CUR_EXC_RATE','Обменен курс на валута');
define('RW_EB_SO_NUM','Номер на поръчка за продажба');
define('RW_EB_INV_NUM','Номер на фактура');
define('RW_EB_PO_NUM','Номер на поръчка за покупка');
define('RW_EB_SALES_REP','Справка продажби');
define('RW_EB_AR_ACCT','Сметка клиенти');
define('RW_EB_BILL_ACCT_ID','Сметка за фактуриране ID');
define('RW_EB_BILL_ADD_ID','Адрес за фактуриране ID');
define('RW_EB_BILL_PRIMARY_NAME','Основно име за фактуриране');
define('RW_EB_BILL_CONTACT','Контакт за фактуриране');
define('RW_EB_BILL_ADDRESS1','Адрес 1 за фактуриране');
define('RW_EB_BILL_ADDRESS2','Адрес 2 за фактуриране');
define('RW_EB_BILL_CITY','Град за фактуриране');
define('RW_EB_BILL_STATE','Щат/област за фактуриране');
define('RW_EB_BILL_ZIP','Пощенски код за фактуриране');
define('RW_EB_BILL_COUNTRY','Страна за фактуриране');
define('RW_EB_BILL_TELE1','Телефон 1 за фактуриране');
define('RW_EB_BILL_TELE2','Телефон 2 за фактуриране');
define('RW_EB_BILL_FAX','Факс за фактуриране');
define('RW_EB_BILL_TELE4','Мобилен телефон за фактуриране');
define('RW_EB_BILL_EMAIL','Имейл за фактуриране');
define('RW_EB_BILL_WEBSITE','Уебсайт за фактуриране');
define('RW_EB_SHIP_ACCT_ID','Сметка за превоз ID');
define('RW_EB_SHIP_ADD_ID','Адрес за превоз ID');
define('RW_EB_SHIP_PRIMARY_NAME','Основно име на превоз');
define('RW_EB_SHIP_CONTACT','Контакт за превоз');
define('RW_EB_SHIP_ADDRESS1','Адрес 1 за превоз');
define('RW_EB_SHIP_ADDRESS2','Адрес 2 за превоз');
define('RW_EB_SHIP_CITY','Град за превоз');
define('RW_EB_SHIP_STATE','Щат/област за превоз');
define('RW_EB_SHIP_ZIP','Пощенски код за превоз');
define('RW_EB_SHIP_COUNTRY','Страна за превоз');
define('RW_EB_SHIP_TELE1','Телефон 1 за превоз');
define('RW_EB_SHIP_TELE2','Телефон 2 за превоз');
define('RW_EB_SHIP_FAX','Факс за превоз');
define('RW_EB_SHIP_TELE4','Мобилен телефон за превоз');
define('RW_EB_SHIP_EMAIL','Имейл за превоз');
define('RW_EB_SHIP_WEBSITE','Уебсайт за превоз');
define('RW_EB_CUSTOMER_ID','Клиент ID');
define('RW_EB_ACCOUNT_NUMBER','Сметка номер');
define('RW_EB_GOV_ID_NUMBER','Gov ID Number');
define('RW_EB_SHIP_DATE','Дата на превоз');
define('RW_EB_TOTAL_PAID','Сумата е платена');
define('RW_EB_PAYMENT_DATE','Дата на плащане');
define('RW_EB_PAYMENT_DUE_DATE','Дата на задължение за плащане');
define('RW_EB_PAYMENT_METHOD','Метод на плащане');
define('RW_EB_PAYMENT_REF','Референция на плащане');
define('RW_EB_PAYMENT_DEP_ID','Плащане на депозит ID');
define('RW_EB_BALANCE_DUE','Дължимо салдо');
define('RW_EB_SO_DESC','order_description');
define('RW_EB_SO_QTY','order_qty');
define('RW_EB_SO_TOTAL_PRICE','order_price');
define('RW_EB_SO_UNIT_PRICE','order_unit_price');
define('RW_EB_SO_SKU','order_sku');
define('RW_EB_SO_SERIAL_NUM','order_serial_num');
define('RW_EB_SHIPPED_PRIOR','qty_shipped_prior');
define('RW_EB_BACKORDER_QTY','qty_on_backorder');
define('RW_EB_INV_DESC','invoice_description');
define('RW_EB_INV_QTY','invoice_qty');
define('RW_EB_INV_TOTAL_PRICE','invoice_full_price');
define('RW_EB_INV_UNIT_PRICE','invoice_unit_price');
define('RW_EB_INV_PRICE','invoice_price');
define('RW_EB_INV_PRICE_W_TAX','invoice_price_w_tax');
define('RW_EB_INV_SKU','invoice_sku');
define('RW_EB_INV_SERIAL_NUM','invoice_serial_num');
define('RW_EB_INV_LINE_TAX','invoice_line_tax');

?>
