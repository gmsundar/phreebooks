<?php
// +-----------------------------------------------------------------+
// Phreedom Language Translation File
// Generated: 2012-08-05 03:42:00
// Module/Method: phreebooks
// ISO Language: bg_bg
// Version: 3.4
// +-----------------------------------------------------------------+
// Path: /modules/phreebooks/language/bg_bg/menu.php

define('BOX_STATUS_MGR','%s Мениджър');
define('BOX_GL_UTILITIES','Инструменти на главния журнал');
define('BOX_BANKING_BANK_ACCOUNT_REGISTER','Регистър на банкова сметка');
define('BOX_BANKING_SELECT_FOR_PAYMENT','Изберете за плащане');
define('ORD_TEXT_20_V_WINDOW_TITLE','Платежни сметки');
define('ORD_TEXT_20_C_WINDOW_TITLE','Връщания към клиент');
define('ORD_TEXT_18_C_WINDOW_TITLE','Бележки за клиенти');
define('ORD_TEXT_20_WINDOW_TITLE','Разпределения на кеша');
define('ORD_TEXT_18_WINDOW_TITLE','Касови бележки');
define('ORD_TEXT_12_WINDOW_TITLE','Поръчки/Фактури');
define('ORD_TEXT_10_WINDOW_TITLE','Поръчки за продажби');
define('ORD_TEXT_9_WINDOW_TITLE','Оферти за продажби');
define('ORD_TEXT_7_WINDOW_TITLE','Кредитно известие от доставчик');
define('ORD_TEXT_6_WINDOW_TITLE','Купуване/получаване на инвентар');
define('ORD_TEXT_4_WINDOW_TITLE','Поръчки за покупка');
define('ORD_TEXT_3_WINDOW_TITLE','Искане за оферта');
define('ORD_TEXT_2_WINDOW_TITLE','Главен журнал');
define('MENU_HEADING_BANKING','Банкиране');
define('BOX_PHREEBOOKS_MODULE_ADM','PhreeBooks администратор');
define('BOX_GL_BUDGET','Бюджетиране');
define('BOX_BANKING_VOID_CHECKS','Празни чекове');
define('BOX_BANKING_ACCOUNT_RECONCILIATION','Приравняване на сметка');
define('ORD_TEXT_18_V_WINDOW_TITLE','Връщания от доставчик');
define('ORD_TEXT_13_WINDOW_TITLE','Кредитни известия към клиент');
define('ORD_TEXT_0_WINDOW_TITLE','Начални салда');
define('MENU_HEADING_GL','Главна счетоводна книга');

?>
