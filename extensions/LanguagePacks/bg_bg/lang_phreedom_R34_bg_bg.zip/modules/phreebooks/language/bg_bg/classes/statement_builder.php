<?php
// +-----------------------------------------------------------------+
// Phreedom Language Translation File
// Generated: 2012-08-05 03:42:00
// Module/Method: phreebooks
// ISO Language: bg_bg
// Version: 3.4
// +-----------------------------------------------------------------+
// Path: /modules/phreebooks/language/bg_bg/classes/statement_builder.php

define('RW_SB_RECORD_ID','Запис ID');
define('RW_SB_POST_DATE','Дата на публикуване');
define('RW_SB_JOURNAL_ID','Журнал ID');
define('RW_SB_CUSTOMER_ID','Клиент ID');
define('RW_SB_ACCOUNT_NUMBER','Сметка номер');
define('RW_SB_SALES_REP','Справка продажби');
define('RW_SB_TERMS','Срокове');
define('RW_SB_CUSTOMER_RECORD','Запис на фактуриране ID');
define('RW_SB_BILL_PRIMARY_NAME','Основно име на фактуриране');
define('RW_SB_BILL_CONTACT','Контакт за фактуриране');
define('RW_SB_BILL_ADDRESS1','Адрес за фактуриране');
define('RW_SB_BILL_ADDRESS2','Адрес 2 за фактуриране');
define('RW_SB_BILL_CITY','Град за фактуриране');
define('RW_SB_BILL_STATE','Щат/област за фактуриране');
define('RW_SB_BILL_ZIP','Пощенски код за фактуриране');
define('RW_SB_BILL_COUNTRY','Страна за фактуриране');
define('RW_SB_BILL_TELE1','Телефон 1 за фактуриране');
define('RW_SB_BILL_TELE2','Телефон 2 за фактуриране');
define('RW_SB_BILL_FAX','Факс за фактуриране');
define('RW_SB_BILL_EMAIL','Имейл за фактуриране');
define('RW_SB_BILL_WEBSITE','Уебсайт за фактуриране');
define('RW_SB_PRIOR_BALANCE','По-ранно салдо');
define('RW_SB_BALANCE_DUE','Дължимо салдо');
define('RW_SB_JOURNAL_DESC','Описание на журнал');
define('RW_SB_INV_NUM','Фактура номер');
define('RW_SB_PO_NUM','Поръчка за покупка номер');
define('RW_SB_DUE_DATE','Дата на задлъжението');
define('RW_SB_PMT_RCVD','Плащането получено');
define('RW_SB_INV_TOTAL','Сума по фактура');

?>
