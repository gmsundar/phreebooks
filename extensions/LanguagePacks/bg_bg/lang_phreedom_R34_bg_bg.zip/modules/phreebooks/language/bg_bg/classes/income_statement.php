<?php
// +-----------------------------------------------------------------+
// Phreedom Language Translation File
// Generated: 2012-08-05 03:42:00
// Module/Method: phreebooks
// ISO Language: bg_bg
// Version: 3.4
// +-----------------------------------------------------------------+
// Path: /modules/phreebooks/language/bg_bg/classes/income_statement.php

define('RW_FIN_REVENUES','Постъпления');
define('RW_FIN_COST_OF_SALES','Себестойност на продажбите');
define('RW_FIN_GROSS_PROFIT','Брутна печалба');
define('RW_FIN_EXPENSES','Разходи');

?>
