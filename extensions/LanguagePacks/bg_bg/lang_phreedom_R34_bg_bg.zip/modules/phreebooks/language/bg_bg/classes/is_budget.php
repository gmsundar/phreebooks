<?php
// +-----------------------------------------------------------------+
// Phreedom Language Translation File
// Generated: 2012-08-05 03:42:00
// Module/Method: phreebooks
// ISO Language: bg_bg
// Version: 3.4
// +-----------------------------------------------------------------+
// Path: /modules/phreebooks/language/bg_bg/classes/is_budget.php

define('IS_BUDGET_ACCOUNT','Сметка');
define('IS_BUDGET_CUR_MONTH','Текущ месец');
define('IS_BUDGET_YTD','Година към днешна дата');
define('IS_BUDGET_LY_CUR','LY Curernt');
define('IS_BUDGET_LAST_YTD','Last YTD');
define('IS_BUDGET_CUR_BUDGET','Текущ бюджет');
define('IS_BUDGET_YTD_BUDGET','Budget YTD');

?>
