<?php
// +-----------------------------------------------------------------+
// Phreedom Language Translation File
// Generated: 2012-08-05 03:42:00
// Module/Method: phreebooks
// ISO Language: bg_bg
// Version: 3.4
// +-----------------------------------------------------------------+
// Path: /modules/phreebooks/language/bg_bg/classes/backorders_report.php

define('RW_BO_RECORD_ID','Запис ID');
define('RW_BO_STORE_ID','Склад ID');
define('RW_BO_FRT_TOTAL','Сума на навлото');
define('RW_BO_FRT_CARRIER','Навло превозвач');
define('RW_BO_FRT_SERVICE','Навло услуга');
define('RW_BO_SALES_TAX','Данък продажби');
define('RW_BO_TAX_AUTH','Вид данък');
define('RW_BO_INV_TOTAL','Сума по фактура');
define('RW_BO_BALANCE_DUE','Дължимо салдо');
define('RW_BO_CUR_CODE','Код на валута');
define('RW_BO_CUR_EXC_RATE','Обменен курс на валута');
define('RW_BO_INV_NUM','Поръчка за продажба номер');
define('RW_BO_PO_NUM','Поръчка за покупка номер');
define('RW_BO_SALES_REP','Справка продажби');
define('RW_BO_AR_ACCT','Сметка клиенти');
define('RW_BO_BILL_ACCT_ID','Сметка за фактуриране ID');
define('RW_BO_BILL_ADD_ID','Адрес за фактуриране ID');
define('RW_BO_BILL_PRIMARY_NAME','Основно име на фактуриране');
define('RW_BO_BILL_CONTACT','Контакт за фактуриране');
define('RW_BO_BILL_ADDRESS1','Адрес 1 за фактуриране');
define('RW_BO_BILL_ADDRESS2','Адрес 2 за фактуриране');
define('RW_BO_BILL_CITY','Град за фактуриране');
define('RW_BO_BILL_STATE','Щат/област за фактуриране');
define('RW_BO_BILL_ZIP','Пощенски код за фактуриране');
define('RW_BO_BILL_COUNTRY','Страна за фактуриране');
define('RW_BO_BILL_TELE1','Телефон 1 за фактуриране');
define('RW_BO_QTY_ORDERED','Поръчан');
define('RW_QTY_IN_STOCK','На склад');
define('RW_BO_QTY_BACKORDER','Неизпълнена поръчка');

?>
