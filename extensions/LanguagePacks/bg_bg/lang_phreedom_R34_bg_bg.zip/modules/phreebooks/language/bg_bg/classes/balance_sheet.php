<?php
// +-----------------------------------------------------------------+
// Phreedom Language Translation File
// Generated: 2012-08-05 03:42:00
// Module/Method: phreebooks
// ISO Language: bg_bg
// Version: 3.4
// +-----------------------------------------------------------------+
// Path: /modules/phreebooks/language/bg_bg/classes/balance_sheet.php

define('RW_FIN_CURRENT_ASSETS','Текущи активи');
define('RW_FIN_TOTAL_CURRENT_ASSETS','Общо текущи активи');
define('RW_FIN_PROP_EQUIP','Нетекущи активи');
define('RW_FIN_TOTAL_PROP_EQUIP','Общо нетекущи активи');
define('RW_FIN_TOTAL_ASSETS','Общо активи');
define('RW_FIN_CUR_LIABILITIES','Текущи задължения');
define('RW_FIN_TOTAL_CUR_LIABILITIES','Общо текущи задължения');
define('RW_FIN_LONG_TERM_LIABILITIES','Нетекущи задължения');
define('RW_FIN_TOTAL_LT_LIABILITIES','Общо нетекущи задължения');
define('RW_FIN_TOTAL_LIABILITIES','Общо задължения');
define('RW_FIN_CAPITAL','Капитал');
define('RW_FIN_NET_INCOME','Нетна печалба');
define('RW_FIN_TOTAL_CAPITAL','Общ капитал');
define('RW_FIN_TOTAL_LIABILITIES_CAPITAL','Общо пасиви и капитал');

?>
