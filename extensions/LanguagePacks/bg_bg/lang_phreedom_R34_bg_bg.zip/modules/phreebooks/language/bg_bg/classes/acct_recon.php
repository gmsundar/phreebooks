<?php
// +-----------------------------------------------------------------+
// Phreedom Language Translation File
// Generated: 2012-08-05 03:42:00
// Module/Method: phreebooks
// ISO Language: bg_bg
// Version: 3.4
// +-----------------------------------------------------------------+
// Path: /modules/phreebooks/language/bg_bg/classes/acct_recon.php

define('RW_RECON_TDC','Общо изчистени депозити');
define('RW_RECON_PCLEARED','Изчистени плащания');
define('RW_RECON_DCLEARED','Изчистени депозити');
define('RW_RECON_TBD','Плейсхолдър за колона');
define('RW_RECON_TOP','Общо дължими плащания');
define('RW_RECON_LOP','Less Outstanding Payments');
define('RW_RECON_ADD_BACK','Добави обратно депозит в транзит');
define('RW_RECON_EB','Краен ГСК баланс');
define('RW_RECON_BB','Начален ГСК баланс');
define('RW_RECON_NCLEARED','Net Cleared');
define('RW_RECON_TPC','Total Payments Cleared');
define('RW_RECON_CLEARED','Изчистени транзакции');
define('RW_RECON_DIFF','Неприравнена разлика');
define('RW_RECON_DIT','Общо депозити в транзит');
define('RW_RECON_CD','Парични получени кредити и депозити (Cash Disbursements)?');
define('RW_RECON_CR','Касови бележки');

?>
