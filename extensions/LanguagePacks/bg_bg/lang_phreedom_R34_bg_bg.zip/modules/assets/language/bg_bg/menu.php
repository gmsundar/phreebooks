<?php
// +-----------------------------------------------------------------+
// Phreedom Language Translation File
// Generated: 2012-08-05 03:41:58
// Module/Method: assets
// ISO Language: bg_bg
// Version: 3.3
// +-----------------------------------------------------------------+
// Path: /modules/assets/language/bg_bg/menu.php

define('MENU_HEADING_ASSETS','Активи');
define('BOX_ASSET_MODULE','Управление на активи');

?>
