<?php
// +-----------------------------------------------------------------+
// Phreedom Language Translation File
// Generated: 2012-08-05 03:41:58
// Module/Method: assets
// ISO Language: bg_bg
// Version: 3.3
// +-----------------------------------------------------------------+
// Path: /modules/assets/language/bg_bg/language.php

define('ASSETS_MSG_DELETE_ASSET','Сигурни ли сте, че искате да изтриете този актив?');
define('ASSETS_MSG_COPY_INTRO','Въведете актив ID за новия актив.');
define('ASSETS_MSG_RENAME_INTRO','Въведете новия ID за да преименувате този актив.');
define('ASSETS_ENTRY_IMAGE_PATH','Относителен път до изображението');
define('ASSETS_PURCHASE_CONDITION','Състояние на покупката');
define('ASSETS_DATE_LAST_JOURNAL_DATE','Дата на излизане от употреба');
define('ASSETS_DATE_LAST_UPDATE','Дата на последна поддръжка');
define('ASSETS_DATE_ACCOUNT_CREATION','Дата на закупуване на актива');
define('ASSETS_ENTRY_ASSETS_SERIALIZE','Производство/модел/рег. №');
define('ASSETS_ENTRY_ACCT_COS','ГСК сметка за поддръжка');
define('ASSETS_ENTRY_ACCT_INV','ГСК сметка за амортизации');
define('ASSETS_ENTRY_ACCT_SALES','ГСК сметка за активи');
define('ASSETS_ENTRY_FULL_PRICE','Оригинална цена');
define('ASSETS_ENTRY_ASSETS_TYPE','Тип на актива');
define('ASSETS_ENTRY_ASSET_TYPE','Enter the Asset Type');
define('ASSETS_ENTER_ASSET_ID','Въведете тип на актива');
define('ASSETS_HEADING_NEW_ITEM','Нов Актив');
define('TEXT_VEHICLE','Превозно средство');
define('TEXT_USED','Използвани');
define('TEXT_TABS','Табове');
define('TEXT_SOFTWARE','Софтуер');
define('TEXT_RETIRE_DATE','Дата на излизане от употреба');
define('TEXT_LAND','Земя');
define('TEXT_IMAGE','Изображение');
define('TEXT_FURNITURE','Мебели');
define('TEXT_EQUIP','Инструменти и оборудване');
define('TEXT_DETAIL_DESCRIPTION','Подробно описание');
define('TEXT_DESCRIPTION_SHORT','Кратко описание');
define('TEXT_CONDITION','Условие');
define('TEXT_COMPUTER','Компютър');
define('TEXT_BUILDING','Строителство');
define('TEXT_ASSETS','активи');
define('TEXT_ASSET_ID','Актив ID');
define('TEXT_ACQ_DATE','Дата на придобиване');

?>
