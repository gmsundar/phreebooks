<?php
// +-----------------------------------------------------------------+
// Phreedom Language Translation File
// Generated: 2012-08-05 03:41:58
// Module/Method: assets
// ISO Language: bg_bg
// Version: 3.3
// +-----------------------------------------------------------------+
// Path: /modules/assets/language/bg_bg/admin.php

define('TEXT_EDIT_FIELD','Редакция на поле за актив');
define('TEXT_NEW_FIELD','Ново поле');
define('TEXT_EDIT_TAB','Редакция на таб за актив');
define('TEXT_NEW_TAB','Нов таб за актив');
define('TEXT_NEW_USED','Нови/използвани');
define('BOX_ASSETS_ADMIN','Администрация на модул активи');
define('MODULE_ASSETS_DESCRIPTION','Модул активи обслужва данните за имуществото на фирмата. Модулът разрешава създаването на допълнителни табове и полета за настройка според нуждите на потребителя.');
define('MODULE_ASSETS_TITLE','Модул активи');

?>
