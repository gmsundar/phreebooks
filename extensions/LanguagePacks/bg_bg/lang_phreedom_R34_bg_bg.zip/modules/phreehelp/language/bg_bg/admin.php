<?php
// +-----------------------------------------------------------------+
// Phreedom Language Translation File
// Generated: 2012-08-05 03:42:00
// Module/Method: phreehelp
// ISO Language: bg_bg
// Version: 3.4
// +-----------------------------------------------------------------+
// Path: /modules/phreehelp/language/bg_bg/admin.php

define('MODULE_PHREEHELP_TITLE','PhreeHelp Module');
define('MODULE_PHREEHELP_DESCRIPTION','The PhreeHelp module provides a popup context help screen to display manual entries supplied with modules. <b>NOTE: This is a core module and should not be removed!</b>');

?>
