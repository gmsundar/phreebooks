<?php
// +-----------------------------------------------------------------+
// Phreedom Language Translation File
// Generated: 2012-08-05 03:42:00
// Module/Method: phreehelp
// ISO Language: bg_bg
// Version: 3.4
// +-----------------------------------------------------------------+
// Path: /modules/phreehelp/language/bg_bg/language.php

define('HEADING_TITLE','PhreeBooks логин');
define('HEADING_CONTENTS','Contents');
define('HEADING_INDEX','Index');
define('TEXT_DOCUMENT','Document');
define('TEXT_EXIT','Exit');
define('TEXT_FOLDER','Folder');
define('TEXT_FORWARD','Forward');
define('TEXT_SUPPORT','PhreeSoft Online Support');
define('TEXT_KEYWORD','Type in the keyword to find:');
define('TEXT_SEARCH_RESULTS','Your search results:');
define('TEXT_UNTITLED','Untitled Document');
define('TEXT_MANUAL','Manual');
define('TEXT_NO_RESULTS','No results were found. The search word must be at least four letters and not a common word.');

?>
