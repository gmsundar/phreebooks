<?php
// +-----------------------------------------------------------------+
// Phreedom Language Translation File
// Generated: 2012-08-05 03:42:01
// Module/Method: shipping-endicia
// ISO Language: bg_bg
// Version: 1.0
// +-----------------------------------------------------------------+
// Path: /modules/shipping/methods/endicia/language/bg_bg/language.php

define('MODULE_SHIPPING_ENDICIA_TEXT_TITLE','US Postal Service');
define('MODULE_SHIPPING_ENDICIA_TITLE_SHORT','USPS');
define('MODULE_SHIPPING_ENDICIA_TEXT_DESCRIPTION','US Postal Service (powered by Endicia)');
define('MODULE_SHIPPING_ENDICIA_TITLE_DESC','Title to use for display purposes when shipping with USPS');
define('MODULE_SHIPPING_ENDICIA_ACCOUNT_NUMBER_DESC','Enter the Endicia account number to use');
define('MODULE_SHIPPING_ENDICIA_PASS_PHRASE_DESC','Enter your Endicia account pass phrase');
define('MODULE_SHIPPING_ENDICIA_TEST_MODE_DESC','Test/Production mode used for testing shipping labels');
define('MODULE_SHIPPING_ENDICIA_PRINTER_TYPE_DESC','Type of printer to use for printing labels. PDF for plain paper, Thermal for Eltron/Zebra Label Printer');
define('MODULE_SHIPPING_ENDICIA_PRINTER_NAME_DESC','Sets then name of the printer to use for printing labels as defined in the printer preferences for the local workstation');
define('MODULE_SHIPPING_ENDICIA_TYPES_DESC','Select the USPS services to be offered by default');
define('MODULE_SHIPPING_ENDICIA_SORT_ORDER_DESC','Sort order of display. Lowest is displayed first');
define('MODULE_SHIPPING_ENDICIA_GND','Parcel Post');
define('MODULE_SHIPPING_ENDICIA_GDR','Parcel Select');
define('MODULE_SHIPPING_ENDICIA_1DM','Priority');
define('MODULE_SHIPPING_ENDICIA_1DA','Express');
define('MODULE_SHIPPING_ENDICIA_1DP','First Class');
define('MODULE_SHIPPING_ENDICIA_2DA','Critical Mail');
define('MODULE_SHIPPING_ENDICIA_2DP','Library Mail');
define('MODULE_SHIPPING_ENDICIA_3DA','Standard Mail');
define('MODULE_SHIPPING_ENDICIA_3DS','Media Mail');
define('MODULE_SHIPPING_ENDICIA_XDM','Express Mail Int');
define('MODULE_SHIPPING_ENDICIA_XPR','Priority Mail Int');
define('MODULE_SHIPPING_ENDICIA_X3D','First Class Mail Int');
define('TEXT_PASSPHRASE_NOW','Enter Current Passphrase');
define('TEXT_PASSPHRASE','Enter New Passphrase');
define('TEXT_PASSPHRASE_DUP','Re-enter Passphrase');
define('TEXT_PARTNER_ID','Partner ID');
define('SHIPPING_ENDICIA_LABEL_STATUS','Successfully retrieved the USPS label, tracking # %s. Your postage balance is: %s');
define('SHIPPING_ENDICIA_ERROR_TOO_HEAVY','The package weight exceeds the maximum supported by this carrier!');
define('SHIPPING_ENDICIA_PURCHASE_SUCCESS_MSG','Your purchase was successful, your balance is now %s (transaction reference %s)');
define('SHIPPING_ENDICIA_PASSPHRASE_CHANGE_DESC','Pass Phrase must be at least 5 characters long with a maximum of 64 characters. For added security, the Pass Phrase should be at least 10 characters long and include more than one word, use at least one uppercase and lowercase letter, one number and one non-text character (for example, punctuation). A Pass Phrase which has been used previously will be rejected.');
define('SHIPPING_ENDICIA_PASSPHRASE_OLD_NOT_MATCH','Your current Pass Phrase does not match what is stored in the system!');
define('SHIPPING_ENDICIA_PASSPHRASE_NEW_NOT_MATCH','Your new Pass Phrase does not match the confirmed Pass Phrase!');
define('SHIPPING_ENDICIA_PASSPHRASE_SUCCESS_MSG','Your passphrase was successfully changed!');
define('SHIPPING_ENDICIA_REFUND_MSG','Endicia tracking # %s refund approved: %s - %s');
define('SHIPPING_ENDICIA_ERROR_POSTAL_CODE','Postal Code is required to use the Endicia module!');
define('SHIPPING_ENDICIA_TRACK_STATUS','Tracking results from USPS for shipment id %s, tracking # %s is: %s');
define('SHIPPING_ENDICIA_SIGNUP_STATUS','Signup confirmation from Endicia servers: %s. You will receive an email shortly to complete your activation.');
define('SHIPPING_ENDICIA_ADD_VAL_ERROR','Dial-A-Zip error (%s) %s. The address must be corrected before a label can be generated.');
define('ENDICIA_CHANGE_PASSPHRASE','Change Pass Phrase');
define('ENDICIA_BUY_POSTAGE','Buy Postage');
define('TEXT_0010_DOLLARS','$10.00');
define('TEXT_0025_DOLLARS','$25.00');
define('TEXT_0100_DOLLARS','$100.00');
define('TEXT_0250_DOLLARS','$250.00');
define('TEXT_0500_DOLLARS','$500.00');
define('TEXT_1000_DOLLARS','$1000.00');
define('MPS_01','Card');
define('MPS_02','Letter');
define('MPS_03','Flat');
define('MPS_04','Parcel');
define('MPS_05','Large Parcel');
define('MPS_06','Irregular Parcel');
define('MPS_07','Oversized Parcel');
define('MPS_08','Flat Rate Envelope');
define('MPS_09','Flat Rate Legal Envelope');
define('MPS_10','Flat Rate Padded Envelope');
define('MPS_11','Flat Rate Gift Card Envelope');
define('MPS_12','Flat Rate Window Envelope');
define('MPS_13','Flat Rate Cardboard Envelope');
define('MPS_14','Small Flat Rate Envelope');
define('MPS_15','Small Flat Rate Box');
define('MPS_16','Medium Flat Rate Box');
define('MPS_17','Large Flat Rate Box');
define('MPS_18','DVD Flat Rate Box');
define('MPS_19','Large Video Flat Rate Box');
define('MPS_20','Regional Rate Box A');
define('MPS_21','Regional Rate Box B');

?>
