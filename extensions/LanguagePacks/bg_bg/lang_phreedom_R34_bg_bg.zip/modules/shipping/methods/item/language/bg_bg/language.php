<?php
// +-----------------------------------------------------------------+
// Phreedom Language Translation File
// Generated: 2012-08-05 03:42:01
// Module/Method: shipping-item
// ISO Language: bg_bg
// Version: 3.2
// +-----------------------------------------------------------------+
// Path: /modules/shipping/methods/item/language/bg_bg/language.php

define('MODULE_SHIPPING_ITEM_TEXT_TITLE','Per Item');
define('MODULE_SHIPPING_ITEM_TITLE_SHORT','Per Item');
define('MODULE_SHIPPING_ITEM_TEXT_DESCRIPTION','Per Item Charge based on the number of items shipped.');
define('MODULE_SHIPPING_ITEM_TITLE_DESC','Title to use for display purposes on shipping rate estimator');
define('MODULE_SHIPPING_ITEM_COST_DESC','The shipping cost will be multiplied by the number of items in an order that uses this shipping method.');
define('MODULE_SHIPPING_ITEM_HANDLING_DESC','Handling fee for this shipping method.');
define('MODULE_SHIPPING_ITEM_SORT_ORDER_DESC','Sort order of display. Determines the order which this method appears on all generted lists.');
define('item_GND','Per Item');
define('SHIPPING_ITEM_SHIPMENTS_ON','Per Item Shipments on ');

?>
