<?php
// +-----------------------------------------------------------------+
// Phreedom Language Translation File
// Generated: 2012-08-05 03:42:01
// Module/Method: shipping-table
// ISO Language: bg_bg
// Version: 3.2
// +-----------------------------------------------------------------+
// Path: /modules/shipping/methods/table/language/bg_bg/language.php

define('MODULE_SHIPPING_TABLE_TEXT_TITLE','Table Rate');
define('MODULE_SHIPPING_TABLE_TITLE_SHORT','Table Rate');
define('MODULE_SHIPPING_TABLE_TEXT_DESCRIPTION','Table Rate');
define('MODULE_SHIPPING_TABLE_TITLE_DESC','Title to use for display purposes on shipping rate estimator');
define('MODULE_SHIPPING_TABLE_COST_DESC','The shipping cost is based on the total cost or weight of items. Example: 25:8.50,50:5.50,etc.. Up to 25 charge 8.50, from there to 50 charge 5.50, etc');
define('MODULE_SHIPPING_TABLE_MODE_DESC','The shipping cost is based on the order total or the total weight of the items ordered.');
define('MODULE_SHIPPING_TABLE_HANDLING_DESC','Handling fee for this shipping method.');
define('MODULE_SHIPPING_TABLE_SORT_ORDER_DESC','Sort order of display. Determines the order which this method appears on all generted lists.');
define('table_GND','Table Rate');
define('SHIPPING_TABLE_SHIPMENTS_ON','Table Rate Shipments on ');

?>
