<?php
// +-----------------------------------------------------------------+
// Phreedom Language Translation File
// Generated: 2012-08-05 03:42:01
// Module/Method: shipping
// ISO Language: bg_bg
// Version: 3.4
// +-----------------------------------------------------------------+
// Path: /modules/shipping/language/bg_bg/menu.php

define('BOX_SHIPPING_MANAGER','Shipping Manager');

?>
