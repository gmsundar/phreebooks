<?php
// +-----------------------------------------------------------------+
// Phreedom Language Translation File
// Generated: 2012-08-05 03:42:00
// Module/Method: phreeform-favorite_reports
// ISO Language: bg_bg
// Version: 3.2
// +-----------------------------------------------------------------+
// Path: /modules/phreeform/dashboards/favorite_reports/language/bg_bg/language.php

define('CP_FAVORITE_REPORTS_NO_RESULTS','No results found!');
define('CP_FAVORITE_REPORTS_DESCRIPTION','Lists favorite reports for quick display.');
define('CP_FAVORITE_REPORTS_TITLE','Favorite Reports');

?>
