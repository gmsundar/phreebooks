<?php
// +-----------------------------------------------------------------+
// Phreedom Language Translation File
// Generated: 2012-08-05 03:41:59
// Module/Method: payment
// ISO Language: bg_bg
// Version: 3.4
// +-----------------------------------------------------------------+
// Path: /modules/payment/language/bg_bg/language.php

define('TEXT_MORE_INFO','More Info');
define('MODULE_PAYMENT_CC_TEXT_CATALOG_TITLE','Credit Card');
define('MODULE_PAYMENT_CC_TEXT_CREDIT_CARD_OWNER','Credit Card Owner:');
define('MODULE_PAYMENT_CC_TEXT_CREDIT_CARD_NUMBER','Credit Card Number:');
define('MODULE_PAYMENT_CC_TEXT_CREDIT_CARD_EXPIRES','Credit Card Expiry Date:');
define('MODULE_PAYMENT_CC_TEXT_CVV','CVV Number');
define('MODULE_PAYMENT_CC_TEXT_JS_CC_OWNER','* The owner\\\'s name of the credit card must be at least %s characters.');
define('MODULE_PAYMENT_CC_TEXT_JS_CC_NUMBER','* The credit card number must be at least %s characters.');
define('MODULE_PAYMENT_CC_TEXT_JS_CC_CVV','* The 3 or 4 digit CVV number must be entered from the back of the credit card.');
define('MODULE_PAYMENT_CC_TEXT_DECLINED_MESSAGE','The credit card transaction did not process correctly. If no reason is given, the card was declined by the bank.');
define('MODULE_PAYMENT_CC_NO_DUPS','The credit card was not processed because it has already been processed. To recharge a credit card, the credit card must be valid and not contain any * characters.');
define('MODULE_PAYMENT_CC_TEXT_ERROR','Credit Card Error!');

?>
