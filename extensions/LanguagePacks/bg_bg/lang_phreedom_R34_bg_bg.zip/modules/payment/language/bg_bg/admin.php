<?php
// +-----------------------------------------------------------------+
// Phreedom Language Translation File
// Generated: 2012-08-05 03:41:59
// Module/Method: payment
// ISO Language: bg_bg
// Version: 3.4
// +-----------------------------------------------------------------+
// Path: /modules/payment/language/bg_bg/admin.php

define('MODULE_PAYMENT_TITLE','Payment Module');
define('MODULE_PAYMENT_DESCRIPTION','The payment module is a wrapper for user configurable payment methods. Some methods are included with the core package and others are available for download from the PhreeSoft website. <b>NOTE: This is a core module and should not be removed!</b>');
define('TEXT_PAYMENT_MODULES_AVAILABLE','Payment Methods Available');
define('TEXT_PRODUCTION','Production');
define('TEXT_AUTHORIZE','Authorize');
define('TEXT_CAPTURE','Capture');
define('TEXT_REMOVE_MESSAGE','Are you sure you want to remove this module and all the data associated with it?');

?>
