<?php
// +-----------------------------------------------------------------+
// Phreedom Language Translation File
// Generated: 2012-08-05 03:41:59
// Module/Method: payment
// ISO Language: bg_bg
// Version: 3.4
// +-----------------------------------------------------------------+
// Path: /modules/payment/language/bg_bg/menu.php

define('MENU_HEADING_PHREEPAY','Payment Module');

?>
