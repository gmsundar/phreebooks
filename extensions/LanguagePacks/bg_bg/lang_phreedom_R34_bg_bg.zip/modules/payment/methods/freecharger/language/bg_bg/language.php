<?php
// +-----------------------------------------------------------------+
// Phreedom Language Translation File
// Generated: 2012-08-05 03:41:59
// Module/Method: payment-freecharger
// ISO Language: bg_bg
// Version: 3.2
// +-----------------------------------------------------------------+
// Path: /modules/payment/methods/freecharger/language/bg_bg/language.php

define('MODULE_PAYMENT_FREECHARGER_TEXT_TITLE','Free Payment');
define('MODULE_PAYMENT_FREECHARGER_TEXT_DESCRIPTION','Free payment method for use with purchases requiring no payment.');
define('MODULE_PAYMENT_FREECHARGER_SORT_ORDER_DESC','Sort order of display. Lowest is displayed first.');

?>
