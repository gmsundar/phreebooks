<?php
// +-----------------------------------------------------------------+
// Phreedom Language Translation File
// Generated: 2012-08-05 03:41:59
// Module/Method: payment-cod
// ISO Language: bg_bg
// Version: 3.2
// +-----------------------------------------------------------------+
// Path: /modules/payment/methods/cod/language/bg_bg/language.php

define('MODULE_PAYMENT_COD_TEXT_TITLE','Cash on Delivery');
define('MODULE_PAYMENT_COD_TEXT_DESCRIPTION','Cash on Delivery');
define('MODULE_PAYMENT_COD_SORT_ORDER_DESC','Sort order of display. Lowest is displayed first.');

?>
