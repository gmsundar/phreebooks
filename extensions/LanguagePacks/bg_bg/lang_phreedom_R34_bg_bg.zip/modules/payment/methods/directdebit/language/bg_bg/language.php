<?php
// +-----------------------------------------------------------------+
// Phreedom Language Translation File
// Generated: 2012-08-05 03:41:59
// Module/Method: payment-directdebit
// ISO Language: bg_bg
// Version: 3.2
// +-----------------------------------------------------------------+
// Path: /modules/payment/methods/directdebit/language/bg_bg/language.php

define('MODULE_PAYMENT_DIRECTDEBIT_TEXT_TITLE','Direct Debits');
define('MODULE_PAYMENT_DIRECTDEBIT_TEXT_DESCRIPTION','Direct Debit and Electronic Funds Transfer (EFT) Payments.');
define('MODULE_PAYMENT_DIRECTDEBIT_TEXT_REF_NUM','Reference Number');
define('MODULE_PAYMENT_DIRECTDEBIT_SORT_ORDER_DESC','Sort order of display. Lowest is displayed first.');

?>
