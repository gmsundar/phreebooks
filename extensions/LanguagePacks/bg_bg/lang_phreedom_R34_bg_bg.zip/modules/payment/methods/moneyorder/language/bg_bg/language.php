<?php
// +-----------------------------------------------------------------+
// Phreedom Language Translation File
// Generated: 2012-08-05 03:41:59
// Module/Method: payment-moneyorder
// ISO Language: bg_bg
// Version: 3.2
// +-----------------------------------------------------------------+
// Path: /modules/payment/methods/moneyorder/language/bg_bg/language.php

define('MODULE_PAYMENT_MONEYORDER_TEXT_TITLE','Check/Money Order');
define('MODULE_PAYMENT_MONEYORDER_TEXT_DESCRIPTION','Payments via check, money order, EFT and other direct forms of payment not requiring a payment gateway.');
define('MODULE_PAYMENT_MONEYORDER_TEXT_REF_NUM','Reference Number');
define('MODULE_PAYMENT_MONEYORDER_PAYTO_DESC','Make Payments To:');
define('MODULE_PAYMENT_MONEYORDER_SORT_ORDER_DESC','Sort order of display. Lowest is displayed first.');

?>
