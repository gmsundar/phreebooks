<?php
// +-----------------------------------------------------------------+
// Phreedom Language Translation File
// Generated: 2012-08-05 03:41:58
// Module/Method: inventory
// ISO Language: bg_bg
// Version: 3.4
// +-----------------------------------------------------------------+
// Path: /modules/inventory/language/bg_bg/menu.php

define('MENU_HEADING_INVENTORY','Инвентар');
define('BOX_INV_MAINTAIN','Инвентарен мениджър');
define('BOX_INV_NEW','Нов инвентар');
define('BOX_INV_TRANSFER','Трансфер на инвентар');
define('ORD_TEXT_14_WINDOW_TITLE','Асемблита');
define('ORD_TEXT_16_WINDOW_TITLE','Корекции');
define('BOX_PRICE_SHEET_MANAGER','Мениджър на ценова листа');
define('BOX_SALES_PRICE_SHEETS','Ценови листи на клиенти');
define('BOX_PURCHASE_PRICE_SHEETS','Ценови листи на доставчици');

?>
