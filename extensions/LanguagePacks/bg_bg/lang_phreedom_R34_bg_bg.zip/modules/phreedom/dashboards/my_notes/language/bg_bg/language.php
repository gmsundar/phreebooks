<?php
// +-----------------------------------------------------------------+
// Phreedom Language Translation File
// Generated: 2012-08-05 03:42:00
// Module/Method: phreedom-my_notes
// ISO Language: bg_bg
// Version: 3.2
// +-----------------------------------------------------------------+
// Path: /modules/phreedom/dashboards/my_notes/language/bg_bg/language.php

define('CP_MY_NOTES_NO_RESULTS','No results found!');
define('CP_MY_NOTES_DESCRIPTION','Allows posting notes and reminders.');
define('CP_MY_NOTES_TITLE','My Notes');

?>
