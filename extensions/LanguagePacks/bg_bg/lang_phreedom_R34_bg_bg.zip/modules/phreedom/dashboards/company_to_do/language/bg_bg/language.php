<?php
// +-----------------------------------------------------------------+
// Phreedom Language Translation File
// Generated: 2012-08-05 03:42:00
// Module/Method: phreedom-company_to_do
// ISO Language: bg_bg
// Version: 1.0
// +-----------------------------------------------------------------+
// Path: /modules/phreedom/dashboards/company_to_do/language/bg_bg/language.php

define('CP_COMPANY_TO_DO_NO_RESULTS','No results found!');
define('CP_COMPANY_TO_DO_DESCRIPTION','Creates a list of activities and things to do viewable throughout the company.');
define('CP_COMPANY_TO_DO_TITLE','Company ToDo List');

?>
