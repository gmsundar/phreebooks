<?php
// +-----------------------------------------------------------------+
// Phreedom Language Translation File
// Generated: 2012-08-05 03:42:00
// Module/Method: phreedom-personal_links
// ISO Language: bg_bg
// Version: 3.2
// +-----------------------------------------------------------------+
// Path: /modules/phreedom/dashboards/personal_links/language/bg_bg/language.php

define('CP_PERSONAL_LINKS_NO_RESULTS','No results found!');
define('CP_PERSONAL_LINKS_DESCRIPTION','Lists URLs for personal use as quicklinks.');
define('CP_PERSONAL_LINKS_TITLE','My Links');

?>
