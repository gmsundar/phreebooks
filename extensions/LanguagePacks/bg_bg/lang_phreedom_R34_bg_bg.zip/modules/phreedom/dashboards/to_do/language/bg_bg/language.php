<?php
// +-----------------------------------------------------------------+
// Phreedom Language Translation File
// Generated: 2012-08-05 03:42:00
// Module/Method: phreedom-to_do
// ISO Language: bg_bg
// Version: 3.2
// +-----------------------------------------------------------------+
// Path: /modules/phreedom/dashboards/to_do/language/bg_bg/language.php

define('CP_TO_DO_DESCRIPTION','Creates a list of activities and things to do.');
define('CP_TO_DO_TITLE','My ToDo List');
define('CP_TO_DO_NO_RESULTS','No results found!');

?>
