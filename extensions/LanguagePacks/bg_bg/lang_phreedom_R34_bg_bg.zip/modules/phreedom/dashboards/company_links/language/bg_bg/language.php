<?php
// +-----------------------------------------------------------------+
// Phreedom Language Translation File
// Generated: 2012-08-05 03:42:00
// Module/Method: phreedom-company_links
// ISO Language: bg_bg
// Version: 3.2
// +-----------------------------------------------------------------+
// Path: /modules/phreedom/dashboards/company_links/language/bg_bg/language.php

define('CP_COMPANY_LINKS_NO_RESULTS','No results found!');
define('CP_COMPANY_LINKS_DESCRIPTION','Lists URLs for all users as company wide links. ');
define('CP_COMPANY_LINKS_TITLE','Company Links');

?>
