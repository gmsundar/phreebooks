<?php
// +-----------------------------------------------------------------+
// Phreedom Language Translation File
// Generated: 2012-08-05 03:42:00
// Module/Method: phreedom-company_notes
// ISO Language: bg_bg
// Version: 1.0
// +-----------------------------------------------------------------+
// Path: /modules/phreedom/dashboards/company_notes/language/bg_bg/language.php

define('CP_COMPANY_NOTES_DESCRIPTION','Allows posting notes and reminders viewable to all in company.');
define('CP_COMPANY_NOTES_TITLE','Company Notes');
define('CP_COMPANY_NOTES_NO_RESULTS','No results found!');

?>
