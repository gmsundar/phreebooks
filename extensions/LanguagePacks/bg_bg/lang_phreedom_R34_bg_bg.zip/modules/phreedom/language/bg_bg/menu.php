<?php
// +-----------------------------------------------------------------+
// Phreedom Language Translation File
// Generated: 2012-08-05 03:42:00
// Module/Method: phreedom
// ISO Language: bg_bg
// Version: 3.4
// +-----------------------------------------------------------------+
// Path: /modules/phreedom/language/bg_bg/menu.php

define('BOX_HEADING_DEBUG_DL','Изтегляне на дебъг файл');
define('BOX_HEADING_CONFIGURATION','Администрация на модул');
define('BOX_COMPANY_MANAGER','Мениджър на фирма');
define('BOX_HEADING_ENCRYPTION','Шифриране на данни');
define('BOX_HEADING_USERS','Потребители');
define('BOX_HEADING_BACKUP','Архив на фирма');
define('BOX_HEADING_ROLES','Роли');
define('MENU_HEADING_MODULES','Модули');
define('BOX_HEADING_PROFILE','Моят профил');
define('HEADING_TITLE_USERS','Потребители');
define('MENU_HEADING_COMPANY','Фирма');
define('MENU_HEADING_TOOLS','Инструменти');
define('TEXT_HOME','Начало');
define('BOX_GENERAL_ADMIN','Общи настройки');
define('BOX_HEADING_ADMIN_TOOLS','Административни инструменти');
define('BOX_IMPORT_EXPORT','Импорт/експорт');
define('TEXT_LOGOUT','Логаут');

?>
