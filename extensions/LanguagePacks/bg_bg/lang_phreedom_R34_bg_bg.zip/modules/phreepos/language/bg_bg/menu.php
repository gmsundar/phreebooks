<?php
// +-----------------------------------------------------------------+
// Phreedom Language Translation File
// Generated: 2012-08-05 03:42:00
// Module/Method: phreepos
// ISO Language: bg_bg
// Version: 1.3
// +-----------------------------------------------------------------+
// Path: /modules/phreepos/language/bg_bg/menu.php

define('MENU_HEADING_PHREEPOS','Point of Sale');
define('BOX_PHREEPOS','Point of Sale');
define('BOX_POS_MGR','POS/POP Manager');
define('BOX_CUSTOMER_DEPOSITS','Customer Deposits');
define('BOX_VENDOR_DEPOSITS','Vendor Deposits');

?>
