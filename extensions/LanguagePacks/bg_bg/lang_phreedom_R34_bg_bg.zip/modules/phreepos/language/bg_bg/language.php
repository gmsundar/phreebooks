<?php
// +-----------------------------------------------------------------+
// Phreedom Language Translation File
// Generated: 2012-08-05 03:42:00
// Module/Method: phreepos
// ISO Language: bg_bg
// Version: 1.3
// +-----------------------------------------------------------------+
// Path: /modules/phreepos/language/bg_bg/language.php

define('BOX_PHREEPOS_RETURN','Point of Sale - Return');
define('PHREEPOS_PAYMENT_TITLE','Enter Payment');
define('BNK_19_AMOUNT_PAID','Amt Rcvd');
define('BNK_21_AMOUNT_PAID','Amt Paid');
define('TEXT_ADD_UPDATE','Add/Update');
define('TEXT_SUBTOTAL','Subtotal');
define('TEXT_AMOUNT_PAID','Amount Paid');
define('TEXT_BALANCE_DUE','Balance Due');
define('TEXT_PAYMENT','Плащане');
define('TEXT_RETURN','Process Return');
define('TEXT_DISCOUNT_PERCENT','Discount Percent');
define('TEXT_REFUND','Refund');
define('TEXT_REFUND_METHOD','Refund Method');
define('TEXT_ENTRIES','Entries');
define('PHREEPOS_ITEM_NOTES','Cursor must be in the SKU box for bar code scanners to record an item.');
define('PHREEPOS_PAYMENT_NOTES','Cursor must be in the first box to record credit card information.');
define('POS_MSG_DELETE_CONFIRM','Are you sure you want to void/delete this POS entry?');
define('GENERAL_JOURNAL_19_ERROR_6','A POS sale cannot be deleted if it is closed!');

?>
