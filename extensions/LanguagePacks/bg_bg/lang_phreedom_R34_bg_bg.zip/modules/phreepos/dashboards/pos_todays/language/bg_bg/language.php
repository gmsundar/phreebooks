<?php
// +-----------------------------------------------------------------+
// Phreedom Language Translation File
// Generated: 2012-08-05 03:42:00
// Module/Method: phreepos-pos_todays
// ISO Language: bg_bg
// Version: 3.2
// +-----------------------------------------------------------------+
// Path: /modules/phreepos/dashboards/pos_todays/language/bg_bg/language.php

define('CP_POS_TODAYS_TITLE','Today\\\'s Pos Sales');
define('CP_POS_TODAYS_DESCRIPTION','Lists today\\\'s sales/invoices. Links to reveiw the invoice are also provided.');
define('CP_POS_TODAYS_NO_RESULTS','No results found!');

?>
