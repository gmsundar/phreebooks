<?php
// +-----------------------------------------------------------------+
// Phreedom Language Translation File
// Generated: 2012-08-05 03:42:00
// Module/Method: phreepos-pos_this_week
// ISO Language: bg_bg
// Version: 3.2
// +-----------------------------------------------------------------+
// Path: /modules/phreepos/dashboards/pos_this_week/language/bg_bg/language.php

define('CP_POS_THIS_WEEK_TITLE','Pos Sales This Week');
define('CP_POS_THIS_WEEK_DESCRIPTION','Lists the total of pos sales day by day from the beginning of the week. ');
define('CP_POS_THIS_WEEK_NO_RESULTS','No results found!');

?>
