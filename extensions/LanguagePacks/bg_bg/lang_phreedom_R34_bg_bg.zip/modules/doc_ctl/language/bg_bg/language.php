<?php
// +-----------------------------------------------------------------+
// Phreedom Language Translation File
// Generated: 2012-08-05 03:41:58
// Module/Method: doc_ctl
// ISO Language: bg_bg
// Version: 1.0
// +-----------------------------------------------------------------+
// Path: /modules/doc_ctl/language/bg_bg/language.php

define('TEXT_BOOKMARK_DOC','Bookmark Document');
define('TEXT_BOOKMARKED','Bookmarked');
define('TEXT_CANCEL_CHECKOUT','Cancel Check-out Flag');
define('TEXT_CHECKED_OUT','Checked Out');
define('TEXT_CHECKOUT_DOC','Check-out Document');
define('TEXT_CREATE_DATE','Creation Date');
define('TEXT_DETAILS','Детайли');
define('TEXT_DOCUMENT','Document: ');
define('TEXT_DOCUMENT_TITLE','Contents of: ');
define('TEXT_DOCUMENTS','Document List');
define('TEXT_DOWNLOAD_DOCUMENT','Download Document');
define('TEXT_FILENAME','Име на файл');
define('TEXT_IMG_NOT_AVAILABLE','Image Not Available');
define('TEXT_LAST_UPDATE','Last Update');
define('TEXT_LAST_VIEW','Last View');
define('TEXT_LOCK_DOC','Lock Document');
define('TEXT_LOCKED','Locked');
define('TEXT_MY_BOOKMARKS','My Bookmarks');
define('TEXT_MY_CHECKED_OUT','Checked Out Files');
define('TEXT_NEW_FOLDER','New Folder');
define('TEXT_NEW_DOCUMENT','New Document');
define('TEXT_NO_BOOKMARKS','No Bookmarks Have Been Set.');
define('TEXT_NO_CHECKED_OUT','No Checked Out Files Have Been Found.');
define('TEXT_NO_DOCUMENTS','Няма намерени документи!');
define('TEXT_OWNER','Owner');
define('TEXT_PATH','Path');
define('TEXT_RECENTLY_ADDED','Recently Added Documents');
define('TEXT_REMOVE_BOOKMARK','Remove Bookmark');
define('TEXT_REVISION','Revision');
define('TEXT_THUMBNAIL','Thumbnail');
define('TEXT_UNLOCK_DOC','Unlock Document');
define('TEXT_UPLOAD_FILE','Upload Revision');
define('DOC_CTL_EMPTY_FOLDER','The Folder does not contain any documents.');
define('DOC_CTL_FILE_WRITE_ERROR','There was an error writing the file. Check directory permissions of directory (%s) and try again.');
define('DOC_CTL_ITEMS','Folders and Documents');
define('DOC_CTL_DELETE_DOCUMENT','Are you sure you want to delete this document?');
define('DOC_CTL_DELETE_DIRECTORY','Are you sure you want to delete this directory?');
define('DOC_CTL_JS_DEL_BOOKMARK','Are you sure you want to delete this bookmark?');
define('DOC_CTL_JS_DIR_DELETED_ERROR','The directory is not empty, it cannot be deleted!');

?>
