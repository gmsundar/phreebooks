<?php
// +-----------------------------------------------------------------+
// Phreedom Language Translation File
// Generated: 2012-08-05 03:41:58
// Module/Method: doc_ctl
// ISO Language: bg_bg
// Version: 1.0
// +-----------------------------------------------------------------+
// Path: /modules/doc_ctl/language/bg_bg/admin.php

define('MODULE_DOC_CTL_TITLE','Document Control Module');
define('MODULE_DOC_CTL_DESCRIPTION','The document control module provides a docmuent management system to control many types of documents. The module includes functionality to check-in/check-out documents, lock for editting, security and directory structured management.');

?>
