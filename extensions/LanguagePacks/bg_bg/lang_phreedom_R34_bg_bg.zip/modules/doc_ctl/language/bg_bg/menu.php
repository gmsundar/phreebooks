<?php
// +-----------------------------------------------------------------+
// Phreedom Language Translation File
// Generated: 2012-08-05 03:41:58
// Module/Method: doc_ctl
// ISO Language: bg_bg
// Version: 1.0
// +-----------------------------------------------------------------+
// Path: /modules/doc_ctl/language/bg_bg/menu.php

define('MENU_HEADING_QUALITY','Quality');
define('BOX_DOC_CTL_MODULE','Document Control');

?>
