<?php
// +-----------------------------------------------------------------+
// Phreedom Language Translation File
// Generated: 2012-08-05 03:41:58
// Module/Method: contacts
// ISO Language: bg_bg
// Version: 3.6
// +-----------------------------------------------------------------+
// Path: /modules/contacts/language/bg_bg/menu.php

define('MENU_HEADING_CUSTOMERS','Клиенти');
define('MENU_HEADING_VENDORS','Доставчици');
define('MENU_HEADING_EMPLOYEES','Работници');
define('BOX_PHREECRM_MODULE','PhreeCRM');
define('BOX_CONTACTS_NEW_BRANCH','Нов клон');
define('BOX_CONTACTS_MAINTAIN_BRANCHES','Мениджър на клонове');
define('BOX_CONTACTS_NEW_CUSTOMER','Нов клиент');
define('BOX_CONTACTS_MAINTAIN_CUSTOMERS','Мениджър клиенти');
define('BOX_CONTACTS_NEW_EMPLOYEE','Нов работник');
define('BOX_CONTACTS_MAINTAIN_EMPLOYEES','Мениджър работници');
define('BOX_CONTACTS_NEW_PROJECT','Нов проект');
define('BOX_CONTACTS_MAINTAIN_PROJECTS','Мениджър на проекти');
define('BOX_CONTACTS_NEW_VENDOR','Нов доставчик');
define('BOX_CONTACTS_MAINTAIN_VENDORS','Мениджър доставчици');
define('BOX_CONTACTS_NEW_CONTACT','Нов контакт');
define('BOX_HR_DEPARTMENTS','Отдели');
define('BOX_PROJECTS_PHASES','Фази на проект');
define('BOX_PROJECTS_COSTS','Цени на проект');

?>
