<?php
// +-----------------------------------------------------------------+
// Phreedom Language Translation File
// Generated: 2012-08-05 03:41:58
// Module/Method: contacts
// ISO Language: bg_bg
// Version: 3.6
// +-----------------------------------------------------------------+
// Path: /modules/contacts/language/bg_bg/admin.php

define('SETUP_PROJECT_PHASESS_DELETE_ERROR','Не мога да изтрия тази фаза на проект, тъй като тя се използва в запис на журнала.');
define('SETUP_PROJECT_PHASESS_LOG','Фази на проект - ');
define('SETUP_INFO_HEADING_EDIT_PROJECT_PHASES','Редактиране фаза на проект');
define('SETUP_INFO_HEADING_NEW_PROJECT_PHASES','Нова фаза на проект');
define('SETUP_PROJECT_PHASES_DELETE_INTRO','Сигурни ли сте, че искате да изтриете тази фаза на проект?');
define('SETUP_PROJECT_PHASES_INSERT_INTRO','Моля въведете новата фаза на проект, с нейните свойства');
define('SETUP_INFO_COST_BREAKDOWN','Да се използват ли разбивки на разходите за тази фаза?');
define('TEXT_COST_BREAKDOWN','Разбивки на разходите');
define('SETUP_TITLE_PROJECTS_PHASES','Проектни фази');
define('SETUP_PROJECT_COSTS_DELETE_ERROR','Cannot delete this project cost, it is being use in a journal entry.');
define('SETUP_PROJECT_COSTS_LOG','Разходи по проект - ');
define('SETUP_INFO_COST_TYPE','Тип разход');
define('SETUP_INFO_HEADING_EDIT_PROJECT_COSTS','Редактиране на разход за проект');
define('SETUP_INFO_HEADING_NEW_PROJECT_COSTS','Нов разход за проект');
define('SETUP_PROJECT_COSTS_DELETE_INTRO','Сигурни ли сте, че искате да изтриете този разход за проект?');
define('SETUP_PROJECT_COSTS_INSERT_INTRO','Моля въведете нов разход за проект с неговите свойства');
define('SETUP_INFO_DESC_LONG','Дълго Описание (макс. 64 символа)');
define('SETUP_TITLE_PROJECTS_COSTS','Разходи за проект');
define('TEXT_SHORT_NAME','Късо наименование');
define('TEXT_COST_TYPE','Тип разход');
define('SETUP_INFO_DESC_SHORT','Кратко наименование (макс. 15 символа)');
define('SETUP_DEPT_TYPES_LOG','Типове дълг - ');
define('SETUP_INFO_HEADING_NEW_DEPT_TYPES','Нов тип отдел');
define('SETUP_INFO_HEADING_EDIT_DEPT_TYPES','Редакция на тип отдел');
define('SETUP_DEPT_TYPES_DELETE_ERROR','Не мога да изтрия този тип отдел, използва се от отдел.');
define('SETUP_INFO_DEPT_TYPES_NAME','Име на тип на отдел');
define('SETUP_DEPT_TYPES_INSERT_INTRO','Моля въведете новия тип отдел');
define('SETUP_DEPT_TYPES_DELETE_INTRO','Сигурни ли сте, че искате да изтриете този тип отдел?');
define('HR_LOG_DEPARTMENTS','Отдели - ');
define('SETUP_TITLE_DEPT_TYPES','Типове отдели');
define('HR_INFO_INSERT_INTRO','Моля въведете новия отдел с неговите свойства');
define('HR_INFO_NEW_ACCOUNT','Нов отдел');
define('HR_INFO_EDIT_ACCOUNT','Редактиране на отдел');
define('HR_INFO_DELETE_INTRO','Сигурни ли сте, че искате да изтриете този отдел?');
define('HR_DEPARTMENT_REF_ERROR','Основният отдел не може да бъде същия като този подотдел, който в момента се запазва!');
define('HR_INFO_ACCOUNT_TYPE','Тип отдел');
define('HR_INFO_ACCOUNT_INACTIVE','Отдела е неактивен');
define('HR_INFO_SUBACCOUNT','Този отдел подотдел ли е?');
define('HR_INFO_PRIMARY_ACCT_ID','Да, изберете също и основен отдел:');
define('HR_EDIT_INTRO','Моля направете необходимите промени');
define('HR_ACCOUNT_ID','Отдел ID');
define('HR_POPUP_WINDOW_TITLE','Отдели');
define('HR_HEADING_SUBACCOUNT','Подотдел');
define('CONTACT_BILL_FIELD_REQ','Дали полето да е задължително или не: %s да бъде въведен за нов главен адрес/адрес за фактуриране (за доставчици, клиенти, и работници)');
define('NEXT_VEND_ID_NUM_DESC','Следващ доставчик ID');
define('TEXT_CUSTOMER','Клиент');
define('TEXT_VENDOR','Доставчик');
define('TEXT_EMPLOYEE','Работник');
define('TEXT_CONTACT_TYPE','Тип контакт');
define('NEXT_CUST_ID_NUM_DESC','Следващ клиент ID');
define('COST_TYPE_CNT','Предприемачи');
define('COST_TYPE_EQT','Оборудване');
define('COST_TYPE_OTH','Други');
define('COST_TYPE_MAT','Материали');
define('PB_PF_TERMS_TO_LANGUAGE','Terms to Language');
define('COST_TYPE_LBR','Труд');
define('PB_PF_CONTACT_ID','Контакт ID');
define('BOX_CONTACTS_ADMIN','Администрация на контакт');
define('TEXT_BILLING_PREFS','Настройки на адресна книга за фактуриране');
define('MODULE_CONTACTS_TITLE','Модул контакти');
define('MODULE_CONTACTS_DESCRIPTION','Модул контакти управлява всички клиенти, доставчици, работници, клонове и проекти, използвани във PhreeSoft Business Toolkit. <b>NOTE: This is a core module and should not be removed!</b>');

?>
