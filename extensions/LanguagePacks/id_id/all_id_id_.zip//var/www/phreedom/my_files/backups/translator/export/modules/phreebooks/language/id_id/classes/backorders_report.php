<?php
// +-----------------------------------------------------------------+
// Berkas Terjemahan Bahasa
// Generated: 2011-06-14 11:43:13
// +-----------------------------------------------------------------+
// Path: /modules/phreebooks/language/id_id/classes/backorders_report.php

define('RW_BO_QTY_BACKORDER','Backorder');
define('RW_QTY_IN_STOCK','In Stock');
define('RW_BO_QTY_ORDERED','Ordered');
define('RW_BO_BILL_TELE1','Telepon 1 Tagihan');
define('RW_BO_BILL_COUNTRY','Negara Tagihan');
define('RW_BO_BILL_ZIP','Kode Pos Tagihan');
define('RW_BO_BILL_STATE','Propinsi Tagihan');
define('RW_BO_BILL_CITY','Kota Tagihan');
define('RW_BO_BILL_ADDRESS2','Alamat 2 Tagihan');
define('RW_BO_BILL_ADDRESS1','Alamat 1 Tagihan');
define('RW_BO_BILL_CONTACT','Kontak Tagihan');
define('RW_BO_BILL_PRIMARY_NAME','Nama Tagihan');
define('RW_BO_BILL_ADD_ID','Bill Address ID');
define('RW_BO_BILL_ACCT_ID','Bill Acct ID');
define('RW_BO_AR_ACCT','A/R Account');
define('RW_BO_SALES_REP','Sales Rep');
define('RW_BO_PO_NUM','Nomor Pesanan Pembelian');
define('RW_BO_INV_NUM','Nomor Pesanan Penjualan');
define('RW_BO_CUR_EXC_RATE','Nilai Tukar Mata Uang');
define('RW_BO_CUR_CODE','Kode Mata Uang');
define('RW_BO_BALANCE_DUE','Balance Due');
define('RW_BO_INV_TOTAL','Jumlah Faktur Penjualan');
define('RW_BO_TAX_AUTH','Tax Authorities');
define('RW_BO_SALES_TAX','Sales Tax');
define('RW_BO_FRT_SERVICE','Freight Service');
define('RW_BO_FRT_CARRIER','Freight Carrier');
define('RW_BO_FRT_TOTAL','Freight Amount');
define('RW_BO_STORE_ID','Store ID');
define('RW_BO_RECORD_ID','Record ID');

?>
