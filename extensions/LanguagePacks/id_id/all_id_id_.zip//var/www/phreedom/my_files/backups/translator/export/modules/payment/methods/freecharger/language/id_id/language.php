<?php
// +-----------------------------------------------------------------+
// Berkas Terjemahan Bahasa
// Generated: 2011-06-14 11:43:12
// +-----------------------------------------------------------------+
// Path: /modules/payment/methods/freecharger/language/id_id/language.php

define('MODULE_PAYMENT_FREECHARGER_SORT_ORDER_DESC','Urutan Tampilan, yang terkecil yang pertama');
define('MODULE_PAYMENT_FREECHARGER_TEXT_DESCRIPTION','Free payment method for use with purchases requiring no payment.');
define('MODULE_PAYMENT_FREECHARGER_TEXT_TITLE','Free Payment');

?>
