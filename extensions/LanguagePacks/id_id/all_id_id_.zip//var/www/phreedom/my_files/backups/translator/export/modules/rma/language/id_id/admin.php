<?php
// +-----------------------------------------------------------------+
// Berkas Terjemahan Bahasa
// Generated: 2011-06-14 11:43:13
// +-----------------------------------------------------------------+
// Path: /modules/rma/language/id_id/admin.php

define('MODULE_RMA_TITLE','RMA Module');
define('MODULE_RMA_DESCRIPTION','The Return Material Authorization (RMA) module manages product returns from customers.');

?>
