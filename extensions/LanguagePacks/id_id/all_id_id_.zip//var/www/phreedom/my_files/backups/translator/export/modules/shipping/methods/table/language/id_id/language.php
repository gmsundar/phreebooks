<?php
// +-----------------------------------------------------------------+
// Berkas Terjemahan Bahasa
// Generated: 2011-06-14 11:43:13
// +-----------------------------------------------------------------+
// Path: /modules/shipping/methods/table/language/id_id/language.php

define('SHIPPING_TABLE_SHIPMENTS_ON','Table Rate Shipments on ');
define('table_GDR','Customer Pickup');
define('table_GND','Local Delivery');
define('table_3Dpm','Sender Paid Economy');
define('table_2Dpm','Courier');
define('table_1Dpm','Sender Paid 1 Day');
define('table_1Dam','Sender Paid 2 Day');
define('table_1DEam','Best Way');
define('MODULE_SHIPPING_TABLE_SORT_ORDER_DESC','Sort order of display. Determines the order which this method appears on all generted lists.');
define('MODULE_SHIPPING_TABLE_HANDLING_DESC','Handling fee for this shipping method.');
define('MODULE_SHIPPING_TABLE_MODE_DESC','The shipping cost is based on the order total or the total weight of the items ordered.');
define('MODULE_SHIPPING_TABLE_COST_DESC','The shipping cost is based on the total cost or weight of items. Example: 25:8.50,50:5.50,etc.. Up to 25 charge 8.50, from there to 50 charge 5.50, etc');
define('MODULE_SHIPPING_TABLE_TITLE_DESC','Title to use for display purposes on shipping rate estimator');
define('MODULE_SHIPPING_TABLE_TEXT_DESCRIPTION','Table Rate');
define('MODULE_SHIPPING_TABLE_TITLE_SHORT','Table Rate');
define('MODULE_SHIPPING_TABLE_TEXT_TITLE','Table Rate');

?>
