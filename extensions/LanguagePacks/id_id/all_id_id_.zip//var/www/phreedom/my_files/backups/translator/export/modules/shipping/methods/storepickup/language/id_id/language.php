<?php
// +-----------------------------------------------------------------+
// Berkas Terjemahan Bahasa
// Generated: 2011-06-14 11:43:13
// +-----------------------------------------------------------------+
// Path: /modules/shipping/methods/storepickup/language/id_id/language.php

define('SHIPPING_STOREPICKUP_SHIPMENTS_ON','Store Pickup Shipments on ');
define('storepickup_GDR','Customer Pickup');
define('storepickup_GND','Local Delivery');
define('storepickup_3Dpm','Sender Paid Economy');
define('storepickup_2Dpm','Courier');
define('storepickup_1Dpm','Sender Paid 1 Day');
define('storepickup_1Dam','Sender Paid 2 Day');
define('storepickup_1DEam','Best Way');
define('MODULE_SHIPPING_STOREPICKUP_SORT_ORDER_DESC','Sort order of display. Determines the order which this method appears on all generted lists.');
define('MODULE_SHIPPING_STOREPICKUP_COST_DESC','The shipping cost for all orders using this shipping method.');
define('MODULE_SHIPPING_STOREPICKUP_TITLE_DESC','Title to use for display purposes on shipping rate estimator');
define('MODULE_SHIPPING_STOREPICKUP_STATUS_DESC','Do you want to offer In Store rate shipping?');
define('MODULE_SHIPPING_STOREPICKUP_TEXT_DESCRIPTION','Customer In Store Pick-up');
define('MODULE_SHIPPING_STOREPICKUP_TITLE_SHORT','Store Pickup');
define('MODULE_SHIPPING_STOREPICKUP_TEXT_TITLE','Store Pickup');

?>
