<?php
// +-----------------------------------------------------------------+
// Berkas Terjemahan Bahasa
// Generated: 2011-06-14 11:43:13
// +-----------------------------------------------------------------+
// Path: /modules/translator/language/id_id/admin.php

define('MODULE_TRANSLATOR_DESCRIPTION','The Translator module provides a convenient interface to translate language files from one language ot another. This module handles version updates as well as full initial translation support.');
define('MODULE_TRANSLATOR_TITLE','Modul Penterjemah');

?>
