<?php
// +-----------------------------------------------------------------+
// Berkas Terjemahan Bahasa
// Generated: 2011-06-14 11:43:12
// +-----------------------------------------------------------------+
// Path: /modules/phreebooks/dashboards/so_status/language/id_id/language.php

define('CP_SO_STATUS_NO_RESULTS','Tidak ada!');
define('CP_SO_STATUS_DESCRIPTION','Pesanan penjualan yang masih aktif.');
define('CP_SO_STATUS_TITLE','Pesanan Penjualan');

?>
