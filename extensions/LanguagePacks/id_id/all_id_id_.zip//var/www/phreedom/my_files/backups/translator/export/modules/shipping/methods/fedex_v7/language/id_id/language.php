<?php
// +-----------------------------------------------------------------+
// Berkas Terjemahan Bahasa
// Generated: 2011-06-14 11:43:13
// +-----------------------------------------------------------------+
// Path: /modules/shipping/methods/fedex_v7/language/id_id/language.php

define('SHIPPING_FEDEX_RECON_SUMMARY','Total number of records reconcilied: %s');
define('SHIPPING_FEDEX_RECON_COST_OVER','Ship Date: %s Reference %s, tracking # %s - The billed cost: (%s) quoted cost: (%s)');
define('SHIPPING_FEDEX_RECON_TOO_MANY','Ship Date: %s Reference %s, tracking # %s - Too many references were found, shipment from %s to %s');
define('SHIPPING_FEDEX_RECON_NO_RECORDS','Ship Date: %s Reference %s, tracking # %s - No records were found, shipment from %s to %s');
define('SHIPPING_FEDEX_RECON_INTRO','Invoice Number: %s dated %s');
define('SHIPPING_FEDEX_RECON_TITLE','FedEx Reconciliation Report generated: ');
define('SHIPPING_FEDEX_ERROR_POSTAL_CODE','Postal Code is required to use the FedEx module');
define('UNKNOWN','Unknown Transit Time');
define('TWENTY_DAYS','Twenty Days Transit');
define('NINETEEN_DAYS','Nineteen Days Transit');
define('EIGHTEEN_DAYS','Eighteen Days Transit');
define('SEVENTEEN_DAYS','Seventeen Days Transit');
define('SIXTEEN_DAYS','Sixteen Days Transit');
define('FIFTEEN_DAYS','Fifteen Days Transit');
define('FOURTEEN_DAYS','Fourteen Days Transit');
define('THIRTEEN_DAYS','Thirteen Days Transit');
define('TWELVE_DAYS','Twelve Days Transit');
define('ELEVEN_DAYS','Eleven Days Transit');
define('TEN_DAYS','Ten Days Transit');
define('NINE_DAYS','Nine Days Transit');
define('EIGHT_DAYS','Eight Days Transit');
define('SEVEN_DAYS','Seven Days Transit');
define('SIX_DAYS','Six Days Transit');
define('FIVE_DAYS','Five Days Transit');
define('FOUR_DAYS','Four Days Transit');
define('THREE_DAYS','Three Days Transit');
define('TWO_DAYS','Two Days Transit');
define('ONE_DAY','One Day Transit');
define('SRV_TRACK_FEDEX_V7','Track Today\\\'s FedEx Shipments');
define('SHIPPING_FEDEX_V7_CLOSE_SUCCESS','Successfully closed the FedEx shipments for today.');
define('SHIPPING_FEDEX_V7_TRACK_FAIL','The following package reference number was deliverd after the expected date/time: ');
define('SHIPPING_FEDEX_V7_TRACK_STATUS','The package reference: %s is not delivered, the status is: (Code %s) %s.');
define('SHIPPING_FEDEX_V7_TRACK_SUCCESS','Successfully Tracked Package Reference # ');
define('SHIPPING_FEDEX_V7_TRACK_ERROR','FedEx Package Tracking Error: ');
define('SHIPPING_FEDEX_V7_DEL_SUCCESS','Successfully deleted the FedEx shipping label. Tracking # ');
define('SHIPPING_FEDEX_V7_DEL_ERROR','FedEx Delete Label Error: ');
define('SHIPPING_FEDEX_V7_TNT_ERROR',' FedEx Time in Transit Error # ');
define('SHIPPING_FEDEX_V7_RATE_TRANSIT',' Day(s) Transit, arrives ');
define('SHIPPING_FEDEX_V7_RATE_CITY_MATCH','City doesn\\\'t match zip code.');
define('SHIPPING_FEDEX_V7_RATE_ERROR','FedEx rate response error: ');
define('SHIPPING_FEDEX_CURL_ERROR','There was an error communicating with the FedEx server:');
define('SHIPPING_FEDEX_V7_SHIPMENTS_ON','FedEx Shipments on ');
define('SHIPPING_FEDEX_V7_HAZMAT_REPORTS','Hazmat Report');
define('SHIPPING_FEDEX_V7_MULTIWGHT_REPORTS','Multiweight Report');
define('SHIPPING_FEDEX_V7_CLOSE_REPORTS','Closing Report');
define('SHIPPING_FEDEX_V7_VIEW_REPORTS','View Reports for ');
define('MODULE_SHIPPING_FEDEX_V7_ECF','Gnd Economy Freight');
define('MODULE_SHIPPING_FEDEX_V7_GDF','Gnd Priority Freight');
define('MODULE_SHIPPING_FEDEX_V7_3DF','3 Day Freight');
define('MODULE_SHIPPING_FEDEX_V7_2DF','2 Day Freight');
define('MODULE_SHIPPING_FEDEX_V7_1DF','1 Day Freight');
define('MODULE_SHIPPING_FEDEX_V7_XPD','Int. Economy');
define('MODULE_SHIPPING_FEDEX_V7_XPR','Int. Priority');
define('MODULE_SHIPPING_FEDEX_V7_XDM','Int. First');
define('MODULE_SHIPPING_FEDEX_V7_3DS','Express Saver');
define('MODULE_SHIPPING_FEDEX_V7_2DP','Express 2 Day');
define('MODULE_SHIPPING_FEDEX_V7_1DP','Standard Overnight');
define('MODULE_SHIPPING_FEDEX_V7_1DA','Priority Overnight');
define('MODULE_SHIPPING_FEDEX_V7_1DM','First Overnight');
define('MODULE_SHIPPING_FEDEX_V7_GDR','Home Delivery');
define('MODULE_SHIPPING_FEDEX_V7_GND','Ground');
define('MODULE_SHIPPING_FEDEX_V7_SORT_ORDER_DESC','Sort order of display. Lowest is displayed first.');
define('MODULE_SHIPPING_FEDEX_V7_TYPES_DESC','Select the FEDEX services to be offered by default.');
define('MODULE_SHIPPING_FEDEX_V7_PRINTER_NAME_DESC','Sets then name of the printer to use for printing labels as defined in the printer preferences for the local workstation.');
define('MODULE_SHIPPING_FEDEX_V7_PRINTER_TYPE_DESC','Type of printer to use for printing labels. PDF for plain paper, Thermal for FedEx 2844 Thermal Label Printer (See Help file before selecting Thermal printer)');
define('MODULE_SHIPPING_FEDEX_V7_TEST_MODE_DESC','Test/Production mode used for testing shipping labels');
define('MODULE_SHIPPING_FEDEX_V7_METER_NUMBER_DESC','Enter the meter number supplied to you from FedEx.');
define('MODULE_SHIPPING_FEDEX_V7_AUTH_PWD_DESC','Enter the FedEx developer password provided by FedEx.');
define('MODULE_SHIPPING_FEDEX_V7_AUTH_KEY_DESC','Enter the FedEx developer key provided by FedEx.');
define('MODULE_SHIPPING_FEDEX_V7_NAT_ACCOUNT_NUMBER_DESC','Enter the FedEx National LTL account number to use for rate estimates. Leave this field blank if no LTL Freight will be used.');
define('MODULE_SHIPPING_FEDEX_V7_LTL_ACCOUNT_NUMBER_DESC','Enter the FedEx Freight account number to use for rate estimates. Leave this field blank if no LTL Freight will be used.');
define('MODULE_SHIPPING_FEDEX_V7_TEXT_TITLE','Federal Express');
define('MODULE_SHIPPING_FEDEX_V7_TITLE_SHORT','FedEx');
define('MODULE_SHIPPING_FEDEX_V7_TEXT_DESCRIPTION','Federal Express');
define('MODULE_SHIPPING_FEDEX_V7_TITLE_DESC','Title to use for display purposes on shipping with FedEx.');
define('MODULE_SHIPPING_FEDEX_V7_ACCOUNT_NUMBER_DESC','Enter the FedEx account number to use for rate estimates');

?>
