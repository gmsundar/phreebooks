<?php
// +-----------------------------------------------------------------+
// Berkas Terjemahan Bahasa
// Generated: 2011-06-14 11:43:13
// +-----------------------------------------------------------------+
// Path: /modules/rma/language/id_id/menu.php

define('MENU_HEADING_RMA','Returns');
define('BOX_RMA_MODULE','RMA');

?>
