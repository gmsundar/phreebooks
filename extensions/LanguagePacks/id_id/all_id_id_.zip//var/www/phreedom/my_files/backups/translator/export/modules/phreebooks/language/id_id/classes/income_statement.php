<?php
// +-----------------------------------------------------------------+
// Berkas Terjemahan Bahasa
// Generated: 2011-06-14 11:43:13
// +-----------------------------------------------------------------+
// Path: /modules/phreebooks/language/id_id/classes/income_statement.php

define('RW_FIN_NET_INCOME','Pendapatan Bersih');
define('RW_FIN_EXPENSES','Pengeluaran');
define('RW_FIN_GROSS_PROFIT','Keuntungan Kotor');
define('RW_FIN_COST_OF_SALES','Beban Penjualan');
define('RW_FIN_REVENUES','Pembagian Hasil');

?>
