<?php
// +-----------------------------------------------------------------+
// Berkas Terjemahan Bahasa
// Generated: 2011-06-14 11:43:12
// +-----------------------------------------------------------------+
// Path: /modules/phreebooks/dashboards/mini_financial/language/id_id/language.php

define('RW_FIN_TOTAL_LIABILITIES_CAPITAL','Total kewajiban & modal');
define('RW_FIN_CAPITAL','Modal pokok');
define('RW_FIN_NET_INCOME','Pendapatan Neto');
define('RW_FIN_EXPENSES','Pengeluaran');
define('RW_FIN_GROSS_PROFIT','Keuntungan Bruto');
define('RW_FIN_COST_OF_SALES','Beban penjualan');
define('RW_FIN_TOTAL_INCOME','Total Pendapatan');
define('RW_FIN_TOTAL_LIABILITIES','Total Kewajiban');
define('RW_FIN_LT_LIABILITIES','Kewajiban Jangka Panjang');
define('RW_FIN_CUR_LIABILITIES','Kewajiban Lancar');
define('RW_FIN_INCOME','Total Pendapatan');
define('RW_FIN_ASSETS','Total Aset/Harta');
define('RW_FIN_HEAD_44','Tidak digunakan');
define('RW_FIN_HEAD_42','Tidak digunakan');
define('RW_FIN_HEAD_40','Tidak digunakan');
define('RW_FIN_HEAD_24','Tidak digunakan');
define('RW_FIN_HEAD_22','Tidak digunakan');
define('RW_FIN_HEAD_20','Tidak digunakan');
define('RW_FIN_HEAD_12','Tidak digunakan');
define('RW_FIN_HEAD_10','Tidak digunakan');
define('RW_FIN_HEAD_8','Tidak digunakan');
define('RW_FIN_HEAD_6','Aset/Harta lain-lain');
define('RW_FIN_HEAD_4','Persediaan');
define('RW_FIN_HEAD_2','Piutang');
define('RW_FIN_HEAD_0','Kas');
define('RW_FIN_PROP_EQUIP','Property & Equipment');
define('RW_FIN_CURRENT_ASSETS','Aset/Harta Lancar');
define('CP_MINI_FINANCIAL_NO_OPTIONS','There are no selectable options for this item!');
define('CP_MINI_FINANCIAL_DESCRIPTION','Ringkasan singkat kondisi keuangan anda.');
define('CP_MINI_FINANCIAL_TITLE','Ringkasan kondisi keuangan');

?>
