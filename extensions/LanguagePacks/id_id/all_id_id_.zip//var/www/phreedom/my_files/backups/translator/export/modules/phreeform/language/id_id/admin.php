<?php
// +-----------------------------------------------------------------+
// Berkas Terjemahan Bahasa
// Generated: 2011-06-14 11:43:13
// +-----------------------------------------------------------------+
// Path: /modules/phreeform/language/id_id/admin.php

define('PB_CONVERT_SAVE_ERROR','There was and error saving the converted report: %s');
define('PB_CONVERT_REPORTS','Convert .txt Reports to PhreeForm');
define('BOX_PHREEFORM_MODULE_ADM','PhreeForm Admin');
define('MODULE_PHREEFORM_DESCRIPTION','The phreeform module contains all the report and form tools needed to print reports in PDF or HTML format. <b>NOTE: This is a core module and should not be removed!</b>');
define('MODULE_PHREEFORM_TITLE','PhreeForm Module');
define('PDF_APP_TEXT','Sets the default PDF generator application. Note: TCPDF is required for UTF-8 and Bar Code generation.');
define('PF_DEFAULT_ROWSPACE_TEXT','Sets the separation between the heading rows for reports (default: 2)');
define('PF_DEFAULT_TRIM_LENGTH_TEXT','Sets the trim length of report and form names when listing in directory format (default: 25)');
define('PF_DEFAULT_ORIENTATION_TEXT','Sets the default page orientation for reports and forms (default: Portrait)');
define('PF_DEFAULT_PAPERSIZE_TEXT','Sets the default papersize to use for reports and forms (default: Letter)');
define('PF_DEFAULT_TITLE2_TEXT','Sets the default title text to print as heading 2 for reports (default: Report Generated %date%)');
define('PF_DEFAULT_TITLE1_TEXT','Sets the default title text to print as heading 1 for reports (default: %reportname%)');
define('PF_DEFAULT_COLUMN_WIDTH_TEXT','Sets the default width to use for column widths of reports in mm (default: 25)');
define('PF_DEFAULT_MARGIN_TEXT','Sets the default page margin to use for reports and forms in mm (default: 8)');
define('PB_CONVERT_SUCCESS','Successfully converted %s reports and forms. If any had errors during the conversion, they will appear in a prior message.');

?>
