<?php
// +-----------------------------------------------------------------+
// Berkas Terjemahan Bahasa
// Generated: 2011-06-14 11:43:13
// +-----------------------------------------------------------------+
// Path: /modules/phreebooks/language/id_id/classes/is_budget.php

define('IS_BUDGET_YTD_BUDGET','Budget YTD');
define('IS_BUDGET_CUR_BUDGET','Cur Budget');
define('IS_BUDGET_LY_CUR','LY Curernt');
define('IS_BUDGET_LAST_YTD','Last YTD');
define('IS_BUDGET_YTD','Year To Date');
define('IS_BUDGET_ACCOUNT','Account');
define('IS_BUDGET_CUR_MONTH','Bulan Ini');
define('RW_FIN_NET_INCOME','Pendapatan Bersih');
define('RW_FIN_EXPENSES','Pengeluaran');
define('RW_FIN_GROSS_PROFIT','Keuntungan Kotor');
define('RW_FIN_COST_OF_SALES','Beban Penjualan');
define('RW_FIN_REVENUES','Pembagian Hasil');

?>
