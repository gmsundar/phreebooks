<?php
// +-----------------------------------------------------------------+
// Berkas Terjemahan Bahasa
// Generated: 2011-06-14 11:43:12
// +-----------------------------------------------------------------+
// Path: /modules/contacts/language/id_id/menu.php

define('BOX_PROJECTS_COSTS','Biaya Proyek');
define('BOX_HR_DEPARTMENTS','Bagian');
define('BOX_PROJECTS_PHASES','Tahap Proyek');
define('BOX_CONTACTS_NEW_CONTACT','Kontak Baru');
define('BOX_CONTACTS_MAINTAIN_VENDORS','Daftar Pemasok');
define('BOX_CONTACTS_NEW_VENDOR','Pemasok Baru');
define('BOX_CONTACTS_NEW_PROJECT','Proyek Baru');
define('BOX_CONTACTS_MAINTAIN_PROJECTS','Daftar Proyek');
define('BOX_CONTACTS_MAINTAIN_EMPLOYEES','Daftar Karyawan');
define('BOX_CONTACTS_NEW_EMPLOYEE','Karyawan Baru');
define('BOX_CONTACTS_NEW_CUSTOMER','Pelanggan Baru');
define('BOX_CONTACTS_MAINTAIN_CUSTOMERS','Daftar Pelanggan');
define('BOX_CONTACTS_MAINTAIN_BRANCHES','Daftar Cabang');
define('BOX_CONTACTS_NEW_BRANCH','Cabang Baru');
define('BOX_PHREECRM_MODULE','PhreeCRM');
define('MENU_HEADING_VENDORS','Pemasok');
define('MENU_HEADING_EMPLOYEES','Karyawan');
define('MENU_HEADING_CUSTOMERS','Pelanggan');

?>
