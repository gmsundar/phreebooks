<?php
// +-----------------------------------------------------------------+
// Berkas Terjemahan Bahasa
// Generated: 2011-06-14 11:43:12
// +-----------------------------------------------------------------+
// Path: /modules/phreebooks/dashboards/todays_s_quotes/language/id_id/language.php

define('CP_TODAYS_S_QUOTES_NO_RESULTS','Tidak ada!');
define('CP_TODAYS_S_QUOTES_DESCRIPTION','Daftar Penawaran penjualan hari ini.');
define('CP_TODAYS_S_QUOTES_TITLE','Penawaran Penjualan hari ini');

?>
