<?php
// +-----------------------------------------------------------------+
// Berkas Terjemahan Bahasa
// Generated: 2011-06-14 11:43:12
// +-----------------------------------------------------------------+
// Path: /modules/assets/language/id_id/admin.php

define('TEXT_EDIT_FIELD','Edit Asset Field');
define('TEXT_NEW_FIELD','New Asset Field');
define('TEXT_EDIT_TAB','Ubah Tab Aset');
define('TEXT_NEW_TAB','Tab Aset Baru');
define('TEXT_NEW_USED','Baru/Bekas');
define('BOX_ASSETS_ADMIN','Pengaturan Modul Aset');
define('MODULE_ASSETS_DESCRIPTION','Modul aset digunakan untuk mendaftar harta perusahaan. Modul ini memungkinkan kita untuk menambah atau menyesuaikan dengan kebutuhan kita.');
define('MODULE_ASSETS_TITLE','Modul Aset');

?>
