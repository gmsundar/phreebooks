<?php
// +-----------------------------------------------------------------+
// Berkas Terjemahan Bahasa
// Generated: 2011-06-14 11:43:13
// +-----------------------------------------------------------------+
// Path: /modules/phreedom/dashboards/to_do/language/id_id/language.php

define('CP_TO_DO_NO_RESULTS','Tidak ada!');
define('CP_TO_DO_DESCRIPTION','Creates a list of activities and things to do.');
define('CP_TO_DO_TITLE','My ToDo List');

?>
