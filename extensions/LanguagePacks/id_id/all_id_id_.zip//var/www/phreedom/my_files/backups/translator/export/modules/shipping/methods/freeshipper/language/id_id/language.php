<?php
// +-----------------------------------------------------------------+
// Berkas Terjemahan Bahasa
// Generated: 2011-06-14 11:43:13
// +-----------------------------------------------------------------+
// Path: /modules/shipping/methods/freeshipper/language/id_id/language.php

define('SHIPPING_FREESHIPPER_SHIPMENTS_ON','Free Shipping Shipments on ');
define('freeshipper_GDR','Customer Pickup');
define('freeshipper_GND','Local Delivery');
define('freeshipper_3Dpm','Sender Paid Economy');
define('freeshipper_2Dpm','Courier');
define('freeshipper_1Dpm','Sender Paid 1 Day');
define('freeshipper_1Dam','Sender Paid 2 Day');
define('freeshipper_1DEam','Best Way');
define('MODULE_SHIPPING_FREESHIPPER_COST_DESC','What is the Shipping cost?');
define('MODULE_SHIPPING_FREESHIPPER_HANDLING_DESC','Handling fee for this shipping method.');
define('MODULE_SHIPPING_FREESHIPPER_SORT_ORDER_DESC','Sort order of display. Determines the order which this method appears on all generted lists.');
define('MODULE_SHIPPING_FREESHIPPER_TITLE_DESC','Title to use for display purposes on shipping rate estimator');
define('MODULE_SHIPPING_FREESHIPPER_TEXT_DESCRIPTION','FREE SHIPPING');
define('MODULE_SHIPPING_FREESHIPPER_TITLE_SHORT','Free Shipping');
define('MODULE_SHIPPING_FREESHIPPER_TEXT_TITLE','FREE SHIPPING!');

?>
