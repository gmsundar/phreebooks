<?php
// +-----------------------------------------------------------------+
// Berkas Terjemahan Bahasa
// Generated: 2011-06-14 11:43:12
// +-----------------------------------------------------------------+
// Path: /modules/phreebooks/dashboards/open_inv/language/id_id/language.php

define('CP_OPEN_INV_NO_RESULTS','Tidak ada!');
define('CP_OPEN_INV_DESCRIPTION','Perincian Faktur Penjualan.');
define('CP_OPEN_INV_TITLE','Faktur Penjualan');

?>
