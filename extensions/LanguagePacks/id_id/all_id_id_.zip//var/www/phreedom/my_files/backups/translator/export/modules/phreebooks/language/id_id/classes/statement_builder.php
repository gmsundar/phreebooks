<?php
// +-----------------------------------------------------------------+
// Berkas Terjemahan Bahasa
// Generated: 2011-06-14 11:43:13
// +-----------------------------------------------------------------+
// Path: /modules/phreebooks/language/id_id/classes/statement_builder.php

define('RW_SB_INV_TOTAL','Jumlah Faktur Penjualan');
define('RW_SB_PMT_RCVD','Pembayaran Diterima');
define('RW_SB_DUE_DATE','Jatuh Tempo Tanggal');
define('RW_SB_PO_NUM','Nomor Pesanan Pembelian');
define('RW_SB_INV_NUM','Nomor Faktur Penjualan');
define('RW_SB_JOURNAL_DESC','Journal Description');
define('RW_SB_BALANCE_DUE','Balance Due');
define('RW_SB_PRIOR_BALANCE','Prior Balance');
define('RW_SB_BILL_WEBSITE','Website Tagihan');
define('RW_SB_BILL_EMAIL','E-mail Tagihan');
define('RW_SB_BILL_FAX','Fax Tagihan');
define('RW_SB_BILL_TELE2','Telepon 2 Tagihan');
define('RW_SB_BILL_TELE1','Telepon 1 Tagihan');
define('RW_SB_BILL_COUNTRY','Negara Tagihan');
define('RW_SB_BILL_ZIP','Kode Pos Tagihan');
define('RW_SB_BILL_STATE','Propinsi Tagihan');
define('RW_SB_BILL_CITY','Kota Tagihan');
define('RW_SB_BILL_ADDRESS2','Alamat 2 Tagihan');
define('RW_SB_BILL_ADDRESS1','Alamat 1 Tagihan');
define('RW_SB_BILL_CONTACT','Kontak Tagihan');
define('RW_SB_BILL_PRIMARY_NAME','Nama Tagihan');
define('RW_SB_CUSTOMER_RECORD','ID Tagihan');
define('RW_SB_TERMS','Syarat-syarat');
define('RW_SB_SALES_REP','Sales Rep');
define('RW_SB_ACCOUNT_NUMBER','Account Number');
define('RW_SB_CUSTOMER_ID','ID Pelanggan');
define('RW_SB_JOURNAL_ID','ID Jurnal');
define('RW_SB_POST_DATE','Post Date');
define('RW_SB_RECORD_ID','Record ID');

?>
