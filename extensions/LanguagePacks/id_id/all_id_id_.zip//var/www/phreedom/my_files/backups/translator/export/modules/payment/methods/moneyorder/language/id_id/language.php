<?php
// +-----------------------------------------------------------------+
// Berkas Terjemahan Bahasa
// Generated: 2011-06-14 11:43:12
// +-----------------------------------------------------------------+
// Path: /modules/payment/methods/moneyorder/language/id_id/language.php

define('MODULE_PAYMENT_MONEYORDER_SORT_ORDER_DESC','Urutan Tampilan, yang terkecil yang pertama');
define('MODULE_PAYMENT_MONEYORDER_PAYTO_DESC','Di bayarkan Kepada:');
define('MODULE_PAYMENT_MONEYORDER_TEXT_REF_NUM','Nomor Referensi');
define('MODULE_PAYMENT_MONEYORDER_TEXT_DESCRIPTION','Payments via check, money order, EFT and other direct forms of payment not requiring a payment gateway.');
define('MODULE_PAYMENT_MONEYORDER_TEXT_TITLE','Check/Money Order');

?>
