<?php
// +-----------------------------------------------------------------+
// Berkas Terjemahan Bahasa
// Generated: 2011-06-14 11:43:13
// +-----------------------------------------------------------------+
// Path: /modules/phreedom/dashboards/my_notes/language/id_id/language.php

define('CP_MY_NOTES_NO_RESULTS','Tidak ada!');
define('CP_MY_NOTES_DESCRIPTION','Untuk Menampilkan Catatan dan pengingat.');
define('CP_MY_NOTES_TITLE','Catatan');

?>
