<?php
// +-----------------------------------------------------------------+
// Berkas Terjemahan Bahasa
// Generated: 2011-06-14 11:43:12
// +-----------------------------------------------------------------+
// Path: /modules/payment/methods/cod/language/id_id/language.php

define('MODULE_PAYMENT_COD_SORT_ORDER_DESC','Urutan Tampilan, yang terkecil yang pertama');
define('MODULE_PAYMENT_COD_TEXT_DESCRIPTION','Tunai setelah barang diterima');
define('MODULE_PAYMENT_COD_TEXT_TITLE','Tunai setelah barang diterima');

?>
