<?php
// +-----------------------------------------------------------------+
// Berkas Terjemahan Bahasa
// Generated: 2011-06-14 11:43:13
// +-----------------------------------------------------------------+
// Path: /modules/shipping/methods/item/language/id_id/language.php

define('item_3Dpm','Sender Paid Economy');
define('item_1Dpm','Sender Paid 1 Day');
define('item_2Dpm','Courier');
define('item_1Dam','Sender Paid 2 Day');
define('item_1DEam','Best Way');
define('MODULE_SHIPPING_ITEM_SORT_ORDER_DESC','Sort order of display. Determines the order which this method appears on all generted lists.');
define('MODULE_SHIPPING_ITEM_HANDLING_DESC','Handling fee for this shipping method.');
define('MODULE_SHIPPING_ITEM_COST_DESC','The shipping cost will be multiplied by the number of items in an order that uses this shipping method.');
define('MODULE_SHIPPING_ITEM_TITLE_DESC','Title to use for display purposes on shipping rate estimator');
define('MODULE_SHIPPING_ITEM_TEXT_DESCRIPTION','Per Item Charge based on the number of items shipped.');
define('MODULE_SHIPPING_ITEM_TITLE_SHORT','Per Item');
define('MODULE_SHIPPING_ITEM_TEXT_TITLE','Per Item');
define('SHIPPING_ITEM_SHIPMENTS_ON','Per Item Shipments on ');
define('item_GDR','Customer Pickup');
define('item_GND','Local Delivery');

?>
