<?php
// +-----------------------------------------------------------------+
// Berkas Terjemahan Bahasa
// Generated: 2011-06-14 11:43:12
// +-----------------------------------------------------------------+
// Path: /modules/phreebooks/dashboards/todays_orders/language/id_id/language.php

define('CP_TODAYS_ORDERS_NO_RESULTS','Tidak ada!');
define('CP_TODAYS_ORDERS_DESCRIPTION','Perincian pesanan penjualan hari ini.');
define('CP_TODAYS_ORDERS_TITLE','Pesanan Penjualan hari ini');

?>
