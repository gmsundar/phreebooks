<?php
// +-----------------------------------------------------------------+
// Berkas Terjemahan Bahasa
// Generated: 2011-06-14 11:43:12
// +-----------------------------------------------------------------+
// Path: /modules/payment/methods/directdebit/language/id_id/language.php

define('MODULE_PAYMENT_DIRECTDEBIT_SORT_ORDER_DESC','Urutan Tampilan, yang terkecil yang pertama');
define('MODULE_PAYMENT_DIRECTDEBIT_TEXT_REF_NUM','Nomor Referensi');
define('MODULE_PAYMENT_DIRECTDEBIT_TEXT_DESCRIPTION','Direct Debit and Electronic Funds Transfer (EFT) Payments.');
define('MODULE_PAYMENT_DIRECTDEBIT_TEXT_TITLE','Direct Debits');

?>
