<?php
// +-----------------------------------------------------------------+
// Berkas Terjemahan Bahasa
// Generated: 2011-06-14 11:43:13
// +-----------------------------------------------------------------+
// Path: /modules/phreebooks/language/id_id/menu.php

define('BOX_STATUS_MGR','Daftar %s');
define('BOX_PHREEBOOKS_MODULE_ADM','Pengaturan PhreeBooks');
define('BOX_PRICE_SHEET_MANAGER','Price Sheet Manager');
define('BOX_GL_UTILITIES','General Journal Utilities');
define('BOX_GL_BUDGET','Anggaran');
define('BOX_BANKING_VOID_CHECKS','Void Checks');
define('BOX_BANKING_ACCOUNT_RECONCILIATION','Account Reconciliation');
define('BOX_BANKING_BANK_ACCOUNT_REGISTER','Bank Account Register');
define('BOX_BANKING_SELECT_FOR_PAYMENT','Select for Payment');
define('ORD_TEXT_20_V_WINDOW_TITLE','Bayar Tagihan');
define('ORD_TEXT_20_C_WINDOW_TITLE','Customer Refunds');
define('ORD_TEXT_20_WINDOW_TITLE','Cash Distributions');
define('ORD_TEXT_18_V_WINDOW_TITLE','Vendor Refunds');
define('ORD_TEXT_18_C_WINDOW_TITLE','Pelunasan Piutang');
define('ORD_TEXT_18_WINDOW_TITLE','Cash Receipts');
define('ORD_TEXT_20_WINDOW_TITLE','Cash Distributions');
define('ORD_TEXT_13_WINDOW_TITLE','Customer Credit Memos');
define('ORD_TEXT_18_WINDOW_TITLE','Cash Receipts');
define('ORD_TEXT_12_WINDOW_TITLE','Penjualan/Faktur Penjualan');
define('ORD_TEXT_10_WINDOW_TITLE','Pesanan Penjualan');
define('ORD_TEXT_7_WINDOW_TITLE','Vendor Credit Memos');
define('ORD_TEXT_9_WINDOW_TITLE','Penawaran Penjualan');
define('ORD_TEXT_6_WINDOW_TITLE','Pembelian/Penerimaan Persediaan');
define('ORD_TEXT_4_WINDOW_TITLE','Pesanan Pembelian');
define('ORD_TEXT_3_WINDOW_TITLE','Penawaran Pembelian');
define('ORD_TEXT_2_WINDOW_TITLE','Jurnal Umum');
define('ORD_TEXT_0_WINDOW_TITLE','Saldo Awal');
define('MENU_HEADING_BANKING','Perbankan');
define('MENU_HEADING_GL','Buku Besar');

?>
