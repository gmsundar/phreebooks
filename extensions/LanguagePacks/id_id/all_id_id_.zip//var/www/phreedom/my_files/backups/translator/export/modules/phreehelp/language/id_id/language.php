<?php
// +-----------------------------------------------------------------+
// Berkas Terjemahan Bahasa
// Generated: 2011-06-14 11:43:13
// +-----------------------------------------------------------------+
// Path: /modules/phreehelp/language/id_id/language.php

define('TEXT_NO_RESULTS','No results were found. The search word must be at least four letters and not a common word.');
define('TEXT_MANUAL','Manual');
define('TEXT_UNTITLED','Untitled Document');
define('TEXT_SEARCH_RESULTS','Your search results:');
define('TEXT_KEYWORD','Type in the keyword to find:');
define('TEXT_SUPPORT','PhreeSoft Online Support');
define('TEXT_FORWARD','Forward');
define('TEXT_FOLDER','Folder');
define('TEXT_EXIT','Exit');
define('TEXT_DOCUMENT','Document');
define('HEADING_INDEX','Index');
define('HEADING_CONTENTS','Contents');
define('HEADING_TITLE','Phreedom Help - Powered by PhreeHelp');

?>
