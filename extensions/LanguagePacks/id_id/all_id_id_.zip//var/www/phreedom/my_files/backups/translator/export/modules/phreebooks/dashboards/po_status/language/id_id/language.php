<?php
// +-----------------------------------------------------------------+
// Berkas Terjemahan Bahasa
// Generated: 2011-06-14 11:43:12
// +-----------------------------------------------------------------+
// Path: /modules/phreebooks/dashboards/po_status/language/id_id/language.php

define('CP_PO_STATUS_NO_RESULTS','Tidak ada!');
define('CP_PO_STATUS_DESCRIPTION','Daftar pesanan pembelian yang belum selesai.');
define('CP_PO_STATUS_TITLE','Pesanan Pembelian');

?>
