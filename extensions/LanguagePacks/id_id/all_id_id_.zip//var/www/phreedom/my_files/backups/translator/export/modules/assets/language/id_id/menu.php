<?php
// +-----------------------------------------------------------------+
// Berkas Terjemahan Bahasa
// Generated: 2011-06-14 11:43:12
// +-----------------------------------------------------------------+
// Path: /modules/assets/language/id_id/menu.php

define('BOX_ASSET_MODULE','Daftar Aset');
define('MENU_HEADING_ASSETS','Aset');

?>
