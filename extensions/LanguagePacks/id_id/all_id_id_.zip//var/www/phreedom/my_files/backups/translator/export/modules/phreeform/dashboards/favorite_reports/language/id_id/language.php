<?php
// +-----------------------------------------------------------------+
// Berkas Terjemahan Bahasa
// Generated: 2011-06-14 11:43:13
// +-----------------------------------------------------------------+
// Path: /modules/phreeform/dashboards/favorite_reports/language/id_id/language.php

define('CP_FAVORITE_REPORTS_NO_RESULTS','Tidak Ada!');
define('CP_FAVORITE_REPORTS_DESCRIPTION','Lists favorite reports for quick display.');
define('CP_FAVORITE_REPORTS_TITLE','Favorite Reports');

?>
