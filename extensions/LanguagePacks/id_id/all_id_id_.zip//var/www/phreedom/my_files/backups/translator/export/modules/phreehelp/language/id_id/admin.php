<?php
// +-----------------------------------------------------------------+
// Berkas Terjemahan Bahasa
// Generated: 2011-06-14 11:43:13
// +-----------------------------------------------------------------+
// Path: /modules/phreehelp/language/id_id/admin.php

define('MODULE_PHREEHELP_DESCRIPTION','The PhreeHelp module provides a popup context help screen to display manual entries supplied with modules. <b>NOTE: This is a core module and should not be removed!</b>');
define('MODULE_PHREEHELP_TITLE','PhreeHelp Module');

?>
