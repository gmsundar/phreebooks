<?php
// +-----------------------------------------------------------------+
// Berkas Terjemahan Bahasa
// Generated: 2011-06-14 11:43:13
// +-----------------------------------------------------------------+
// Path: /modules/phreebooks/language/id_id/classes/subaccount_is.php

define('RW_RECORD_ID','Column Placeholder');
define('RW_FIN_NET_INCOME','Pendapatan Neto');
define('RW_SUB_ACT_BAL_SHT_IS_ACCT','RW_SUB_ACT_BAL_SHT_IS_ACCT');

?>
