<?php
// +-----------------------------------------------------------------+
// Berkas Terjemahan Bahasa
// Generated: 2011-06-14 11:43:13
// +-----------------------------------------------------------------+
// Path: /modules/phreedom/dashboards/company_links/language/id_id/language.php

define('CP_COMPANY_LINKS_NO_RESULTS','Tidak ada!');
define('CP_COMPANY_LINKS_DESCRIPTION','Lists URLs for all users as company wide links. ');
define('CP_COMPANY_LINKS_TITLE','Company Links');

?>
