<?php
// +-----------------------------------------------------------------+
// Berkas Terjemahan Bahasa
// Generated: 2011-06-14 11:43:13
// +-----------------------------------------------------------------+
// Path: /modules/phreedom/language/id_id/menu.php

define('BOX_HEADING_DEBUG_DL','Download Debug File');
define('BOX_GENERAL_ADMIN','Pengaturan Umum');
define('BOX_HEADING_CONFIGURATION','Pengaturan Modul');
define('BOX_HEADING_ADMIN_TOOLS','Perangkat Pengaturan');
define('BOX_COMPANY_MANAGER','Pengaturan Perusahaan');
define('BOX_IMPORT_EXPORT','Import/Export');
define('BOX_HEADING_ENCRYPTION','Pengacak Data');
define('BOX_HEADING_BACKUP','Cadangan Perusahaan');
define('MENU_HEADING_MODULES','Modul');
define('BOX_HEADING_USERS','Pengguna');
define('MENU_HEADING_TOOLS','Peralatan');
define('HEADING_TITLE_USERS','Pengguna');
define('MENU_HEADING_COMPANY','Perusahaan');
define('HEADER_TITLE_LOGOFF','Keluar');
define('HEADER_TITLE_TOP','Beranda');

?>
