<?php
// +-----------------------------------------------------------------+
// Berkas Terjemahan Bahasa
// Generated: 2011-06-14 11:43:13
// +-----------------------------------------------------------------+
// Path: /modules/phreebooks/language/id_id/classes/aged_receivables.php

define('RW_AR_SHIP_DATE','Tanggal Kirim');
define('RW_AR_ACCOUNT_NUMBER','Nomor Rekening');
define('RW_AR_CUSTOMER_ID','ID Pelanggan');
define('RW_AR_SHIP_WEBSITE','Situs Pengiriman');
define('RW_AR_SHIP_EMAIL','E-mail Pengiriman');
define('RW_AR_SHIP_FAX','Fax Pengiriman');
define('RW_AR_SHIP_TELE1','Telephon 1 Pengiriman');
define('RW_AR_SHIP_TELE2','Telephon 2 Pengiriman');
define('RW_AR_SHIP_COUNTRY','Negara Pengiriman');
define('RW_AR_SHIP_STATE','Propinsi Pengiriman');
define('RW_AR_SHIP_ZIP','Kode Pos Pengiriman');
define('RW_AR_SHIP_CITY','Kota Pengiriman');
define('RW_AR_SHIP_ADDRESS2','Alamat 2 Pengiriman');
define('RW_AR_SHIP_ADDRESS1','Alamat 1 Pengiriman');
define('RW_AR_SHIP_CONTACT','Kontak Pengiriman');
define('RW_AR_SHIP_PRIMARY_NAME','Nama Pengiriman');
define('RW_AR_SHIP_ACCT_ID','Ship Acct ID');
define('RW_AR_SHIP_ADD_ID','Ship Address ID');
define('RW_AR_BILL_WEBSITE','Situs Penagihan');
define('RW_AR_BILL_EMAIL','E-Mail Penagihan');
define('RW_AR_BILL_TELE2','Telepon 2 Penagihan');
define('RW_AR_BILL_FAX','Fax Penagihan');
define('RW_AR_FRT_SERVICE','Jasa Penerbangan');
define('RW_AR_TERMS','Syarat-syarat');
define('RW_AR_SALES_TAX','Pajak Penjualan');
define('RW_AR_TAX_AUTH','Instansi Pajak');
define('RW_AR_INV_TOTAL','Jumlah Faktur Penjualan');
define('RW_AR_BALANCE_DUE','Kekurangan');
define('RW_AR_CUR_CODE','Kode Mata Uang');
define('RW_AR_CUR_EXC_RATE','Nilai Tukar');
define('RW_AR_SO_NUM','Nomor Pesanan Penjualan');
define('RW_AR_INV_NUM','Nomor Faktur Penjualan');
define('RW_AR_PO_NUM','Nomor Pesanan Pembelian');
define('RW_AR_SALES_REP','Sales');
define('RW_AR_AR_ACCT','Piutang');
define('RW_AR_BILL_ACCT_ID','Bill Acct ID');
define('RW_AR_BILL_ADD_ID','Bill Address ID');
define('RW_AR_BILL_PRIMARY_NAME','Bill Primary Name');
define('RW_AR_BILL_CONTACT','Nama Penagihan');
define('RW_AR_BILL_ADDRESS1','Alamat 1 Penagihan');
define('RW_AR_BILL_ADDRESS2','Alamat 2 Penagihan');
define('RW_AR_BILL_CITY','Kota Penagihan');
define('RW_AR_BILL_STATE','Propinsi Penagihan');
define('RW_AR_BILL_ZIP','Kode Pos Penagihan');
define('RW_AR_BILL_COUNTRY','Negara Penagihan');
define('RW_AR_BILL_TELE1','Telepon 1 Penagihan');
define('RW_AR_FRT_CARRIER','Freight Carrier');
define('RW_AR_FRT_TOTAL','Freight Amount');
define('RW_AR_CLOSED','Selesai');
define('RW_AR_JOURNAL_DESC','Journal Description');
define('RW_AR_STORE_ID','ID Toko');
define('RW_AR_JOURNAL_ID','Journal ID');
define('RW_AR_RECORD_ID','Record ID');

?>
