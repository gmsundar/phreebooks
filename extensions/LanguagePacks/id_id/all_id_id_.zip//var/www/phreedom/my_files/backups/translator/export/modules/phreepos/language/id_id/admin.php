<?php
// +-----------------------------------------------------------------+
// Berkas Terjemahan Bahasa
// Generated: 2011-06-14 11:43:13
// +-----------------------------------------------------------------+
// Path: /modules/phreepos/language/id_id/admin.php

define('PHREEPOS_RECEIPT_PRINTER_NAME_DESC','Sets then name of the printer to use for printing receipts as defined in the printer preferences for the local workstation.');
define('PHREEPOS_REQUIRE_ADDRESS_DESC','Require address information for every POS/POP Sale?');
define('BOX_PHREEPOS_ADMIN','Point of Sale Administration');
define('MODULE_PHREEPOS_DESCRIPTION','The PhreePOS module provides a Point of Sale interface. This module is a supplement to the phreebooks module and is not a replacement for it.');
define('MODULE_PHREEPOS_TITLE','PhreePOS Module');

?>
