<?php
// +-----------------------------------------------------------------+
// Berkas Terjemahan Bahasa
// Generated: 2011-06-14 11:43:13
// +-----------------------------------------------------------------+
// Path: /modules/phreepos/language/id_id/menu.php

define('MENU_HEADING_PHREEPOS','Point of Sale');
define('BOX_PHREEPOS','Point of Sale');
define('BOX_POS_MGR','POS/POP Manager');
define('BOX_CUSTOMER_DEPOSITS','Customer Deposits');
define('BOX_VENDOR_DEPOSITS','Vendor Deposits');

?>
