<?php
// +-----------------------------------------------------------------+
// Berkas Terjemahan Bahasa
// Generated: 2011-06-14 11:43:12
// +-----------------------------------------------------------------+
// Path: /modules/inventory/language/id_id/menu.php

define('ORD_TEXT_16_WINDOW_TITLE','Penyesuaian');
define('ORD_TEXT_14_WINDOW_TITLE','Perakitan');
define('BOX_INV_TRANSFER','Transfer Persediaan');
define('BOX_INV_NEW','Tambah Persediaan');
define('BOX_INV_MAINTAIN','Daftar Persediaan');
define('MENU_HEADING_INVENTORY','Persediaan');

?>
