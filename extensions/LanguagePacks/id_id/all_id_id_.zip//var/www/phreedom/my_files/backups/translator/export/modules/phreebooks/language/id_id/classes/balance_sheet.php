<?php
// +-----------------------------------------------------------------+
// Berkas Terjemahan Bahasa
// Generated: 2011-06-14 11:43:13
// +-----------------------------------------------------------------+
// Path: /modules/phreebooks/language/id_id/classes/balance_sheet.php

define('RW_FIN_TOTAL_LIABILITIES_CAPITAL','Total Liabilities & Capital');
define('RW_FIN_NET_INCOME','Pendapatan Neto');
define('RW_FIN_TOTAL_CAPITAL','Total Capital');
define('RW_FIN_CAPITAL','Capital');
define('RW_FIN_TOTAL_LIABILITIES','Total Hutang');
define('RW_FIN_TOTAL_LT_LIABILITIES','Total Hutang Jangka Panjang');
define('RW_FIN_LONG_TERM_LIABILITIES','Hutang Jangka Panjang');
define('RW_FIN_CUR_LIABILITIES','Hutang Lancar');
define('RW_FIN_TOTAL_CUR_LIABILITIES','Total Hutang Lancar');
define('RW_FIN_TOTAL_ASSETS','Total Harta');
define('RW_FIN_TOTAL_PROP_EQUIP','Total Prop and Equipment');
define('RW_FIN_TOTAL_CURRENT_ASSETS','Total Harta Lancar');
define('RW_FIN_PROP_EQUIP','Prop and Equipment');
define('RW_FIN_CURRENT_ASSETS','Harta Lancar');

?>
