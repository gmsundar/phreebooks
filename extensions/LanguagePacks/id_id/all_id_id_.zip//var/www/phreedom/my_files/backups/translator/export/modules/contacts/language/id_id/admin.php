<?php
// +-----------------------------------------------------------------+
// Berkas Terjemahan Bahasa
// Generated: 2011-06-14 11:43:12
// +-----------------------------------------------------------------+
// Path: /modules/contacts/language/id_id/admin.php

define('SETUP_PROJECT_PHASESS_DELETE_ERROR','Cannot delete this project phase, it is being use in a journal entry.');
define('SETUP_PROJECT_PHASESS_LOG','Tahapan Proyek - ');
define('SETUP_INFO_HEADING_EDIT_PROJECT_PHASES','Edit Tahapan Proyek');
define('SETUP_INFO_HEADING_NEW_PROJECT_PHASES','Tahapan Proyek Baru');
define('SETUP_PROJECT_PHASES_DELETE_INTRO','Anda yakin ingin menghapus tahapan proyek ini?');
define('SETUP_PROJECT_PHASES_INSERT_INTRO','Please enter the new project phase with its properties');
define('SETUP_INFO_COST_BREAKDOWN','Use Cost Breakdowns for this phase?');
define('TEXT_COST_BREAKDOWN','Cost Breakdown');
define('SETUP_TITLE_PROJECTS_PHASES','Tahapan Proyek');
define('SETUP_PROJECT_COSTS_DELETE_ERROR','Cannot delete this project cost, it is being use in a journal entry.');
define('SETUP_PROJECT_COSTS_LOG','Biaya Proyek - ');
define('SETUP_INFO_COST_TYPE','Jenis Biaya');
define('SETUP_INFO_HEADING_EDIT_PROJECT_COSTS','Edit Biaya Proyek');
define('SETUP_INFO_HEADING_NEW_PROJECT_COSTS','Biaya Proyek Baru');
define('SETUP_PROJECT_COSTS_DELETE_INTRO','Are you sure you want to delete this project cost?');
define('SETUP_PROJECT_COSTS_INSERT_INTRO','Please enter the new project cost with its properties');
define('SETUP_INFO_DESC_LONG','Long Description (64 chars max)');
define('SETUP_INFO_DESC_SHORT','Short Name (16 chars max)');
define('TEXT_COST_TYPE','Cost Type');
define('TEXT_SHORT_NAME','Nama Pendek');
define('SETUP_TITLE_PROJECTS_COSTS','Project Costs');
define('SETUP_DEPT_TYPES_LOG','Dept Types - ');
define('SETUP_INFO_HEADING_EDIT_DEPT_TYPES','Edit Department Type');
define('SETUP_INFO_HEADING_NEW_DEPT_TYPES','New Department Type');
define('SETUP_DEPT_TYPES_DELETE_ERROR','Cannot delete this department type, it is being use by a department.');
define('SETUP_DEPT_TYPES_DELETE_INTRO','Are you sure you want to delete this department type?');
define('SETUP_DEPT_TYPES_INSERT_INTRO','Please enter the new department type');
define('SETUP_INFO_DEPT_TYPES_NAME','Department Type Name');
define('SETUP_TITLE_DEPT_TYPES','Department Types');
define('HR_LOG_DEPARTMENTS','Departments - ');
define('HR_DEPARTMENT_REF_ERROR','The primary department cannot be the same as this subdepartment being saved!');
define('HR_INFO_DELETE_INTRO','Are you sure you want to delete this department?');
define('HR_INFO_EDIT_ACCOUNT','Edit Department');
define('HR_INFO_NEW_ACCOUNT','New Department');
define('HR_INFO_INSERT_INTRO','Please enter the new department with its properties');
define('HR_INFO_ACCOUNT_INACTIVE','Department inactive');
define('HR_INFO_ACCOUNT_TYPE','Department type');
define('HR_INFO_PRIMARY_ACCT_ID','Yes, also select primary department:');
define('HR_INFO_SUBACCOUNT','Is this department a subdepartment?');
define('HR_ACCOUNT_ID','Department ID');
define('HR_EDIT_INTRO','Please make any necessary changes');
define('HR_HEADING_SUBACCOUNT','Subdepartment');
define('HR_POPUP_WINDOW_TITLE','Departments');
define('CONTACT_BILL_FIELD_REQ','Whether or not to require field: %s to be entered for a new main/billing address (for vendors, customers, and employees)');
define('NEXT_VEND_ID_NUM_DESC','ID Pemasok Berikutnya');
define('NEXT_CUST_ID_NUM_DESC','ID Pelanggan Berikutnya');
define('TEXT_CONTACT_TYPE','Jenis Kontak');
define('TEXT_EMPLOYEE','Karyawan');
define('TEXT_VENDOR','Pemasok');
define('TEXT_CUSTOMER','Pelanggan');
define('COST_TYPE_OTH','Lainnya');
define('COST_TYPE_EQT','Peralatan');
define('COST_TYPE_CNT','Kontraktor');
define('COST_TYPE_MAT','Material');
define('COST_TYPE_LBR','Upah');
define('PB_PF_TERMS_TO_LANGUAGE','Terms to Language');
define('PB_PF_CONTACT_ID','ID Kontak');
define('TEXT_BILLING_PREFS','Billing Address Book Settings');
define('BOX_CONTACTS_ADMIN','Pengaturan Kontak');
define('MODULE_CONTACTS_DESCRIPTION','The contacts module manages all customer, vendors, employees, branches and projects used in the PhreeSoft Business Toolkit. <b>NOTE: This is a core module and should not be removed!</b>');
define('MODULE_CONTACTS_TITLE','Modul Kontak');

?>
