<?php
// +-----------------------------------------------------------------+
// Berkas Terjemahan Bahasa
// Generated: 2011-06-14 11:43:13
// +-----------------------------------------------------------------+
// Path: /modules/translator/language/id_id/language.php

define('TRANS_ERROR_DUPLICATE','Error importing module: %s, language: %s, version: %s, the language file already exists. Import skipped!');
define('TRANSLATION_HEADER','Berkas Terjemahan Bahasa');
define('TEXT_TRANSLATIONS_SAVED','Terjemahan telah di simpan.');
define('TEXT_DEFAULT_TRANSLATION','Terjemahan saat ini');
define('TEXT_STATS_VALUES','%s dari %s telah diterjahkan (%s persen)');
define('TEXT_CONSTANT','Defined Constant');
define('MESSAGE_DELETE_TRANSLATION','Anda yakin ingin menghapus terjemahan ini?');
define('TRANSLATOR_UPLOAD_ZIPFILE','Pilih berkas yang telah di zip untuk di unggah dan di masukan ke dalam basis data penterjemah:');
define('TRANSLATOR_MODULE_CREATE','Module to assign translation to:');
define('TRANSLATOR_RELEASE_CREATE','Release number to create:');
define('TRANSLATOR_ISO_CREATE','ISO language to create (form xx_xx):');
define('TRANSLATOR_UPLOAD_DESC','This form will upload a zipped language file and import all defines into the database. It should be used for assisting in upconverting older versions to new or modifying translations to new languages.');
define('TRANSLATOR_INSTALL_IMPORT','Directory name of install directory (if moved after install):');
define('TRANSLATOR_MODULE_IMPORT','Module name to import:');
define('TRANSLATOR_ISO_EXPORT','ISO language to export:');
define('TEXT_LANGUAGE','Bahasa');
define('TEXT_FILTERS','Saring:');
define('TEXT_APPLY','Terapkan Saringan');
define('TEXT_UPLOAD_LANGUAGE_FILE','Unggah dari Berkas yang telah di Zip');
define('TEXT_EDIT_TRANSLATION','Modul Penterjemah');
define('TEXT_EXPORT_CURRENT_LANGUAGE','Export All for a language and version');
define('TEXT_UPLOAD_TRANSLATION','Unggah Terjemahan');
define('TEXT_IMPORT_CURRENT_LANGUAGE','Import from Current Installation');
define('TEXT_EXPORT_TRANSLATION','Export Terjemahan');
define('TEXT_NEW_TRANSLATION','Terjemahan Baru');
define('TEXT_IMPORT_TRANSLATION','Import Terjemahan');
define('BOX_TRANSLATOR_MAINTAIN','Panduan Penterjemah');
define('TRANS_ERROR_NO_SOURCE','No available versions of the source language were found! Please import the source language.');
define('TRANSLATOR_ISO_IMPORT','ISO language to import (form xx_xx):');
define('TRANSLATOR_EXPORT_DESC','This page exports all modules from a given translated language and version to a single .zip file.');
define('TRANSLATOR_IMPORT_DESC','This page imports loaded languages from the currently installed module or modules into the translator database. If the install module is selected and the directory has been renamed, the new directory needs to be entered into the form below.');
define('TRANSLATOR_NEW_OVERRIDE','Then overwrite (if available) from installed language:');
define('TRANSLATOR_NEW_SOURCE','Source Module:');
define('TEXT_SOURCE_LANGUAGE','Source Language:');
define('TRANSLATOR_NEW_DESC','This form creates a new translation release. If you want translation guesses from prior releases to override the source language check the Overwrite box and enter an ISO language to use. Note that this language must be loaded into the translator database. The source module and language must also be in the translator database. (Release # will be created automatically)');
define('TEXT_CREATE_NEW_TRANSLATION','Buat Terjemahan Baru');
define('TEXT_TRANSLATED','Telah di Terjemahkan');
define('TEXT_TRANSLATIONS','Terjemahan');
define('TEXT_TRANSLATION','Terjemahan');
define('TEXT_LANGUAGE_CODE','ISO Language Code');
define('TEXT_UPLOAD','Unggah');

?>
