<?php
// +-----------------------------------------------------------------+
// Berkas Terjemahan Bahasa
// Generated: 2011-06-14 11:43:13
// +-----------------------------------------------------------------+
// Path: /modules/phreebooks/language/id_id/classes/entry_builder.php

define('RW_EB_INV_SERIAL_NUM','invoice_serial_num');
define('RW_EB_INV_DISCOUNT','invoice_discount');
define('RW_EB_INV_PRICE','invoice_price');
define('RW_EB_INV_SKU','invoice_sku');
define('RW_EB_INV_QTY','invoice_qty');
define('RW_EB_INV_TOTAL_PRICE','invoice_full_price');
define('RW_EB_INV_UNIT_PRICE','invoice_unit_price');
define('RW_EB_INV_DESC','invoice_description');
define('RW_EB_BACKORDER_QTY','qty_on_backorder');
define('RW_EB_SO_SERIAL_NUM','order_serial_num');
define('RW_EB_SHIPPED_PRIOR','qty_shipped_prior');
define('RW_EB_SO_SKU','order_sku');
define('RW_EB_SO_UNIT_PRICE','order_unit_price');
define('RW_EB_SO_QTY','order_qty');
define('RW_EB_SO_TOTAL_PRICE','order_price');
define('RW_EB_BALANCE_DUE','Kekurangan');
define('RW_EB_SO_DESC','order_description');
define('RW_EB_PAYMENT_DEP_ID','Payment Deposit ID');
define('RW_EB_PAYMENT_METHOD','Cara Pembayaran');
define('RW_EB_PAYMENT_REF','Payment Reference');
define('RW_EB_PAYMENT_DATE','Tanggal Pembayaran');
define('RW_EB_PAYMENT_DUE_DATE','Tanggal jatuh tempo Pembayaran');
define('RW_EB_TOTAL_PAID','Jumlah yang Telah Dibayar');
define('RW_EB_SHIP_DATE','Dikirim Tanggal');
define('RW_EB_GOV_ID_NUMBER','Gov ID Number');
define('RW_EB_ACCOUNT_NUMBER','Account Number');
define('RW_EB_SHIP_WEBSITE','Ship Website');
define('RW_EB_CUSTOMER_ID','Customer ID');
define('RW_EB_SHIP_TELE4','Ship Mobile');
define('RW_EB_SHIP_EMAIL','E-mail Pengirim');
define('RW_EB_SHIP_FAX','Fax Pengirim');
define('RW_EB_SHIP_TELE2','Telepon 2 Pengirim');
define('RW_EB_SHIP_TELE1','Telepon 1 Pengirim');
define('RW_EB_SHIP_COUNTRY','Negara Pengirim');
define('RW_EB_SHIP_ZIP','Kode Pos Pengirim');
define('RW_EB_SHIP_STATE','Propinsi Pengirim');
define('RW_EB_SHIP_CITY','Kota Pengirim');
define('RW_EB_SHIP_ADDRESS2','Alamat 2 Pengirim');
define('RW_EB_SHIP_ADDRESS1','Alamat 1 Pengirim');
define('RW_EB_SHIP_CONTACT','Kontak Pengirim');
define('RW_EB_SHIP_PRIMARY_NAME','Nama Pengirim');
define('RW_EB_BILL_WEBSITE','Situs Penagihan');
define('RW_EB_SHIP_ACCT_ID','Ship Acct ID');
define('RW_EB_SHIP_ADD_ID','Ship Address ID');
define('RW_EB_BILL_TELE4','Bill Mobile');
define('RW_EB_BILL_EMAIL','E-mail Penagihan');
define('RW_EB_BILL_FAX','Fax Penagihan');
define('RW_EB_BILL_TELE2','Telepon 1 Penagihan');
define('RW_EB_BILL_TELE1','Telepon 2 Penagihan');
define('RW_EB_BILL_ZIP','Kode Pos Penagihan');
define('RW_EB_BILL_COUNTRY','Negara Penagihan');
define('RW_EB_BILL_STATE','Propinsi Penagihan');
define('RW_EB_BILL_ADDRESS2','Alamat 2 Penagihan');
define('RW_EB_BILL_CITY','Kota Penagihan');
define('RW_EB_BILL_ADDRESS1','Alamat 1 Penagihan');
define('RW_EB_BILL_CONTACT','Kontak Penagihan');
define('RW_EB_BILL_PRIMARY_NAME','Nama Penagihan');
define('RW_EB_BILL_ADD_ID','Bill Address ID');
define('RW_EB_BILL_ACCT_ID','Bill Acct ID');
define('RW_EB_SALES_REP','Sales Rep');
define('RW_EB_AR_ACCT','Piutang');
define('RW_EB_PO_NUM','Nomor Pesanan Pembelian');
define('RW_EB_INV_NUM','Nomor Faktur Penjualan');
define('RW_EB_SO_NUM','Nomor Pesanan Penjualan');
define('RW_EB_CUR_CODE','Kode Mata Uang');
define('RW_EB_CUR_EXC_RATE','Currency Exc. Rate');
define('RW_EB_INV_TOTAL','Total Faktur Penjualan');
define('RW_EB_INV_SUBTOTAL','Subtotal Faktur Penjualan');
define('RW_EB_TAX_DETAILS','Tax Details');
define('RW_EB_SALES_TAX','Sales Tax');
define('RW_EB_TAX_AUTH','Tax Authorities');
define('RW_EB_INV_DISCOUNT','Diskon Faktur Penjualan');
define('RW_EB_TERMS','Syarat-syarat');
define('RW_EB_FRT_TRACKING','Tracking Number');
define('RW_EB_FRT_SERVICE','Freight Service');
define('RW_EB_FRT_CARRIER','Freight Carrier');
define('RW_EB_CLOSED','Selesai');
define('RW_EB_FRT_TOTAL','Freight Amount');
define('RW_EB_JOURNAL_DESC','Journal Description');
define('RW_EB_JOURNAL_ID','Journal ID');
define('RW_EB_STORE_ID','Store ID');
define('RW_EB_RECORD_ID','Record ID');
define('RW_EB_PAYMENT_DETAIL','Payment Detail');
define('TEXT_SO_POST_DATE','Sales Order Post Date');

?>
