<?php
// +-----------------------------------------------------------------+
// Berkas Terjemahan Bahasa
// Generated: 2011-06-14 11:43:13
// +-----------------------------------------------------------------+
// Path: /modules/phreedom/dashboards/personal_links/language/id_id/language.php

define('CP_PERSONAL_LINKS_NO_RESULTS','Tidak ada!');
define('CP_PERSONAL_LINKS_DESCRIPTION','Lists URLs for personal use as quicklinks.');
define('CP_PERSONAL_LINKS_TITLE','My Links');

?>
