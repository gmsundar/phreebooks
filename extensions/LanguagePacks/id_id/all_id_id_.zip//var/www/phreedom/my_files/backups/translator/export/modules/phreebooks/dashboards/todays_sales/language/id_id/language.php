<?php
// +-----------------------------------------------------------------+
// Berkas Terjemahan Bahasa
// Generated: 2011-06-14 11:43:12
// +-----------------------------------------------------------------+
// Path: /modules/phreebooks/dashboards/todays_sales/language/id_id/language.php

define('CP_TODAYS_SALES_NO_RESULTS','Tidak ada!');
define('CP_TODAYS_SALES_DESCRIPTION','Perincian penjualan hari ini.');
define('CP_TODAYS_SALES_TITLE','Penjualan hari ini');

?>
