<?php
// +-----------------------------------------------------------------+
// Berkas Terjemahan Bahasa
// Generated: 2011-06-14 11:43:12
// +-----------------------------------------------------------------+
// Path: /modules/assets/language/id_id/language.php

define('ASSETS_MSG_DELETE_ASSET','Anda yakin ingin menghapus aset ini?');
define('ASSETS_MSG_RENAME_INTRO','Masukan ID Aset untuk mengganti nama aset ini.');
define('ASSETS_MSG_COPY_INTRO','Masukan ID Aset untuk membuat aset baru.');
define('ASSETS_ENTRY_IMAGE_PATH','Image Relative Path');
define('ASSETS_PURCHASE_CONDITION','Kondisi pada saat pembelian');
define('ASSETS_DATE_LAST_JOURNAL_DATE','Asset Retire Date');
define('ASSETS_DATE_LAST_UPDATE','Perawatan Terakhir');
define('ASSETS_DATE_ACCOUNT_CREATION','Tanggal Pembelian Aset');
define('ASSETS_ENTRY_ASSETS_SERIALIZE','Make/Model/VIN');
define('ASSETS_ENTRY_ACCT_COS','Jurnal Umum Perawatan');
define('ASSETS_ENTRY_ACCT_INV','Jurnal Umum Penyusutan');
define('ASSETS_ENTRY_ACCT_SALES','Jurnal Umum Aset');
define('ASSETS_ENTRY_FULL_PRICE','Harga Sesungguhnya');
define('ASSETS_ENTRY_ASSETS_TYPE','Jenis Aset');
define('ASSETS_ENTRY_ASSET_TYPE','Masukan Jenis Aset');
define('ASSETS_ENTER_ASSET_ID','Membuat Aset Baru');
define('ASSETS_HEADING_NEW_ITEM','Aset Baru');
define('TEXT_VEHICLE','Kendaraan');
define('TEXT_USED','Bekas');
define('TEXT_TABS','Tab');
define('TEXT_SOFTWARE','Perangkat Lunak');
define('TEXT_RETIRE_DATE','Retire Date');
define('TEXT_LAND','Tanah');
define('TEXT_IMAGE','Gambar');
define('TEXT_FURNITURE','Mebel/Perabotan');
define('TEXT_EQUIP','Peralatan');
define('TEXT_DETAIL_DESCRIPTION','Uraian lebih lengkap');
define('TEXT_DESCRIPTION_SHORT','Uraian singkat');
define('TEXT_CONDITION','Kondisi');
define('TEXT_COMPUTER','Komputer');
define('TEXT_BUILDING','Bangunan');
define('TEXT_ASSETS','aset');
define('TEXT_ASSET_ID','ID Aset');
define('TEXT_ACQ_DATE','Acq Date');

?>
