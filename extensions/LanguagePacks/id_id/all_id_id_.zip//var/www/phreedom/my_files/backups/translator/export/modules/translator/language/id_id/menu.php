<?php
// +-----------------------------------------------------------------+
// Berkas Terjemahan Bahasa
// Generated: 2011-06-14 11:43:13
// +-----------------------------------------------------------------+
// Path: /modules/translator/language/id_id/menu.php

define('BOX_TRANSLATOR_MODULE','Panduan Penterjemah');
define('MENU_HEADING_TRANSLATOR','Alat Bantu Penterjemah Bahasa');

?>
