<?php
// +-----------------------------------------------------------------+
// Berkas Terjemahan Bahasa
// Generated: 2011-06-14 11:43:12
// +-----------------------------------------------------------------+
// Path: /modules/payment/language/id_id/admin.php

define('TEXT_REMOVE_MESSAGE','Are you sure you want to remove this module and all the data associated with it?');
define('TEXT_CAPTURE','Capture');
define('TEXT_AUTHORIZE','Authorize');
define('TEXT_PRODUCTION','Production');
define('TEXT_PAYMENT_MODULES_AVAILABLE','Tersedia Modul Pembayaran');
define('MODULE_PAYMENT_DESCRIPTION','The payment module is a wrapper for user configurable payment methods. Some methods are included with the core package and others are available for download from the PhreeSoft website. <b>NOTE: This is a core module and should not be removed!</b>');
define('MODULE_PAYMENT_TITLE','Modul Pembayaran');

?>
