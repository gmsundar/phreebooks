<?php
// +-----------------------------------------------------------------+
// Berkas Terjemahan Bahasa
// Generated: 2011-06-14 11:43:12
// +-----------------------------------------------------------------+
// Path: /modules/payment/language/id_id/menu.php

define('MENU_HEADING_PHREEPAY','PhreePay Payment Module');

?>
