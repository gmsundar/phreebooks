<?php
// +-----------------------------------------------------------------+
// |                   PhreeBooks Open Source ERP                    |
// +-----------------------------------------------------------------+
// | Copyright (c) 2008, 2009, 2010 PhreeSoft, LLC                   |
// | http://www.PhreeSoft.com                                        |
// +-----------------------------------------------------------------+
// | This program is free software: you can redistribute it and/or   |
// | modify it under the terms of the GNU General Public License as  |
// | published by the Free Software Foundation, either version 3 of  |
// | the License, or any later version.                              |
// |                                                                 |
// | This program is distributed in the hope that it will be useful, |
// | but WITHOUT ANY WARRANTY; without even the implied warranty of  |
// | MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the   |
// | GNU General Public License for more details.                    |
// |                                                                 |
// | The license that is bundled with this package is located in the |
// | file: /doc/manual/ch01-Introduction/license.html.               |
// | If not, see http://www.gnu.org/licenses/                        |
// +-----------------------------------------------------------------+
//  Path: /modules/accounts/language/en_us/language.php
//

// *************  Release 2.1 changes  *********************
define('RECORD_NUM_REF_ONLY','record ID (Reference only) = ');

// *************  Release 2.0 changes  *********************
define('TEXT_NEW_CONTACT','Новый контакт');
define('TEXT_COPY_ADDRESS','Transfer Address');
define('TEXT_CONTACTS','Контакты');
define('TEXT_TITLE','Заголовок');
define('TEXT_LINK_TO','Link To:');
define('ACT_CATEGORY_I_ADDRESS','Добавить/Редактировать контакт');
define('ACT_CONTACT_HISTORY','История контакта');
define('ACT_I_SHORT_NAME','Контакт');
define('ACT_I_HEADING_TITLE','PhreeCRM');
define('ACT_I_TYPE_NAME','Контакты');
define('ACT_I_PAGE_TITLE_EDIT','Редактировать контакт');
define('ACT_SHORT_NAME','ID контакта');
define('ACT_GL_ACCOUNT_TYPE','Категория');
define('ACT_ACCOUNT_NUMBER','Facebook ID');
define('ACT_ID_NUMBER','Twitter ID');
define('ACT_REP_ID','Линк на Покупателя/Поставщика');
define('ACT_FIRST_DATE','Дата создания');
define('ACT_LAST_DATE1','Дата обновления');
define('ACT_ERROR_DUPLICATE_CONTACT','ID контакта уже существует, введите другой ID.');

// *************  Release 1.9 changes  *********************
// Text specific to Projects
define('ACT_J_TYPE_NAME','проекты');
define('ACT_J_HEADING_TITLE','Проекты');
define('ACT_J_SHORT_NAME','ID проекта');
define('ACT_J_ID_NUMBER','Референс PO');
define('ACT_J_REP_ID','Sales Rep ID');
define('ACT_J_PAGE_TITLE_EDIT','Редактировать проект');
define('ACT_J_ACCOUNT_NUMBER','Break Into Phases:');
define('ACT_ID_AUTO_FILL','(оставте пустым для авто ID)');

// *********************************************************
// Targeted defines (to differentiate wording differences for different account types)
// Text specific to Vendor accounts
define('ACT_V_TYPE_NAME','Поставщики');
define('ACT_V_HEADING_TITLE','Поставщики');
define('ACT_V_SHORT_NAME','ID Поставщика');
define('ACT_V_GL_ACCOUNT_TYPE','Purchase GL Account');
define('ACT_V_ID_NUMBER','Federal EIN');
define('ACT_V_REP_ID','Purchase Rep ID');
define('ACT_V_ACCOUNT_NUMBER','Account Number');
define('ACT_V_FIRST_DATE','Vendor Since: ');
define('ACT_V_LAST_DATE1','Last Invoice Date: ');
define('ACT_V_LAST_DATE2','Last Payment Date: ');
define('ACT_V_PAGE_TITLE_EDIT','Редактировать поставщика');
// Text specific to Employee accounts
define('ACT_E_TYPE_NAME','Сотрудники');
define('ACT_E_HEADING_TITLE','Сотрудники');
define('ACT_E_SHORT_NAME','ID Сотрудника');
define('ACT_E_GL_ACCOUNT_TYPE','Employee Type');
define('ACT_E_ID_NUMBER','Social Security Number');
define('ACT_E_REP_ID','ID департпмента');
define('ACT_E_ACCOUNT_NUMBER','Не используется');
define('ACT_E_FIRST_DATE','Hire Date: ');
define('ACT_E_LAST_DATE1','Last Raise Date: ');
define('ACT_E_LAST_DATE2','Termination Date: ');
define('ACT_E_PAGE_TITLE_EDIT','Редактировать сотрудника');
// Text specific to branch accounts
define('ACT_B_TYPE_NAME','Branches');
define('ACT_B_HEADING_TITLE','Branches');
define('ACT_B_SHORT_NAME','Branch ID');
define('ACT_B_GL_ACCOUNT_TYPE','Не используется');
define('ACT_B_ID_NUMBER','Не используется');
define('ACT_B_REP_ID','Не используется');
define('ACT_B_ACCOUNT_NUMBER','Не используется');
define('ACT_B_FIRST_DATE','Creation Date: ');
define('ACT_B_LAST_DATE1','Не используется');
define('ACT_B_LAST_DATE2','Не используется');
define('ACT_B_PAGE_TITLE_EDIT','Edit Branch');
// Text specific to Customer accounts (default)
define('ACT_C_TYPE_NAME','Customers');
define('ACT_C_HEADING_TITLE','Покупатели');
define('ACT_C_SHORT_NAME','ID покупателя');
define('ACT_C_GL_ACCOUNT_TYPE','Sales GL Account');
define('ACT_C_ID_NUMBER','Resale License Number');
define('ACT_C_REP_ID','Sales Rep ID');
define('ACT_C_ACCOUNT_NUMBER','Account Number');
define('ACT_C_FIRST_DATE','Customer Since: ');
define('ACT_C_LAST_DATE1','Last Invoice Date: ');
define('ACT_C_LAST_DATE2','Last Payment Date: ');
define('ACT_C_PAGE_TITLE_EDIT','Редактировать покупателя');

// Category headings
define('ACT_CATEGORY_CONTACT','Контактная информация');
define('ACT_CATEGORY_M_ADDRESS','Main Mailing Address');
define('ACT_CATEGORY_S_ADDRESS','Адреса доставки');
define('ACT_CATEGORY_B_ADDRESS','Платежный адрес');
define('ACT_CATEGORY_P_ADDRESS','Credit Card Payment Information');
define('ACT_CATEGORY_INFORMATION','Account Information');
define('ACT_CATEGORY_PAYMENT_TERMS','Условия оплаты');
define('TEXT_ADDRESS_BOOK','Адресная книга');
define('TEXT_EMPLOYEE_ROLES','Роли сотрудников');
define('ACT_ACT_HISTORY','Account History');
define('ACT_ORDER_HISTORY','История заказов');
define('ACT_SO_HIST','Sales Order History (Most Recent %s Results)');
define('ACT_PO_HIST','Purchase Order History (Most Recent %s Results)');
define('ACT_INV_HIST','Invoice History (Most Recent %s Results)');
define('ACT_SO_NUMBER','SO Номер');
define('ACT_PO_NUMBER','PO Номер');
define('ACT_INV_NUMBER','Номер счета');
define('ACT_NO_RESULTS','Ничего не найдено');
define('ACT_PAYMENT_MESSAGE','Enter the payment information to be stored in PhreeBooks.');
define('ACT_PAYMENT_CREDIT_CARD_NUMBER','Credit Card Number');
define('ACT_PAYMENT_CREDIT_CARD_EXPIRES','Credit Card Expiration Date');
define('ACT_PAYMENT_CREDIT_CARD_CVV2','Security Code');
define('AR_CONTACT_STATUS','Customer Status');
define('AP_CONTACT_STATUS','Vendor Status');

// Account Terms (used in several modules)
define('ACT_SPECIAL_TERMS','Special Terms');
define('ACT_TERMS_DUE','Terms (Due)');
define('ACT_TERMS_DEFAULT','Default: ');
define('ACT_TERMS_USE_DEFAULTS','Use Default Terms');
define('ACT_COD_SHORT','COD');
define('ACT_COD_LONG','Оплата при получении');
define('ACT_PREPAID','Предоплата');
define('ACT_SPECIAL_TERMS','Due in number of days');
define('ACT_END_OF_MONTH','Due end of month');
define('ACT_DAY_NEXT_MONTH','Due on specified date');
define('ACT_DUE_ON', 'Due on: ');
define('ACT_DISCOUNT', 'Discount ');
define('ACT_EARLY_DISCOUNT', ' percent. ');
define('ACT_EARLY_DISCOUNT_SHORT', '% ');
define('ACT_DUE_IN','Due in ');
define('ACT_TERMS_EARLY_DAYS', ' day(s). ');
define('ACT_TERMS_NET','Net ');
define('ACT_TERMS_STANDARD_DAYS', ' day(s). ');
define('ACT_TERMS_CREDIT_LIMIT', 'Credit limit: ');
define('ACT_AMT_PAST_DUE','Amount Past Due: ');
define('ACT_GOOD_STANDING','Account in Good Standing');
define('ACT_OVER_CREDIT_LIMIT','Account is Over Credit Limit');
define('ACT_HAS_PAST_DUE_AMOUNT','Account has Past Due Balance');

// Account table fields - common to all account types
define('ACT_POPUP_WINDOW_TITLE','Account Search');
define('ACT_POPUP_TERMS_WINDOW_TITLE','Условия оплаты');

// misc information messages
define('ACT_WARN_DELETE_ADDRESS','Точно хотите удалить этот адрес?');
define('ACT_WARN_DELETE_ACCOUNT','Точно хотите удалить этот аккаунт?');
define('ACT_WARN_DELETE_PAYMENT','Точно хотите удалить этот платеж?');
define('ACT_ERROR_CANNOT_DELETE','Cannot delete this account because a journal record contains this account');
define('ACT_ERROR_DUPLICATE_ACCOUNT','The account ID already exists in the system, please enter a new id.');
define('ACT_ERROR_NO_ACCOUNT_ID','When adding a new Customer/Vendor, the ID field is required, please enter an unique id.');
define('ACT_ERROR_ACCOUNT_NOT_FOUND','The account you are looking for could not be found!');
define('ACT_BILLING_MESSAGE','These fields are not required unless a billing address is being added.');
define('ACT_SHIPPING_MESSAGE','These fields are not required unless a shipping address is being added.');
define('ACT_NO_ENCRYPT_KEY_ENTERED','CAUTION: The encryption key has not been entered. Stored credit card information will not be displayed and values entered here will not be saved!');
define('ACT_PAYMENT_REF','Payment Ref');
define('ACT_LIST_OPEN_ORDERS','Открытые заказы');
define('ACT_LIST_OPEN_INVOICES','Открытые счета');
define('ACT_CARDHOLDER_NAME','Имя владельца карты');
define('ACT_CARD_HINT','Card Hint');
define('ACT_EXP','Exp');

define('ACT_NO_KEY_EXISTS','A payment was specified but the encryption key has not been entered. The payment address was saved but the payment information was not.');

// java script errors
define('ACT_JS_SHORT_NAME','* The \'ID\' entry cannot be blank.\n');

// Audit log messages
define('ACT_LOG_ADD_ACCOUNT','Added account - ');
define('ACT_LOG_UPDATE_ACCOUNT','Updated account - ');
define('ACT_LOG_DELETE_ACCOUNT','Deleted account - ');

?>