<?php
// +-----------------------------------------------------------------+
// |                   PhreeBooks Open Source ERP                    |
// +-----------------------------------------------------------------+
// | Copyright (c) 2008, 2009, 2010 PhreeSoft, LLC                   |
// | http://www.PhreeSoft.com                                        |
// +-----------------------------------------------------------------+
// | This program is free software: you can redistribute it and/or   |
// | modify it under the terms of the GNU General Public License as  |
// | published by the Free Software Foundation, either version 3 of  |
// | the License, or any later version.                              |
// |                                                                 |
// | This program is distributed in the hope that it will be useful, |
// | but WITHOUT ANY WARRANTY; without even the implied warranty of  |
// | MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the   |
// | GNU General Public License for more details.                    |
// |                                                                 |
// | The license that is bundled with this package is located in the |
// | file: /doc/manual/ch01-Introduction/license.html.               |
// | If not, see http://www.gnu.org/licenses/                        |
// +-----------------------------------------------------------------+
//  Path: /modules/reportwriter/language/en_us/classes/backorders_report.php
//

define('RW_BO_RECORD_ID','ID записи');
define('RW_BO_STORE_ID','ID магазина');
define('RW_BO_FRT_TOTAL','Freight Amount');
define('RW_BO_FRT_CARRIER','Доставщик');
define('RW_BO_FRT_SERVICE','Способ доставки');
define('RW_BO_SALES_TAX','Sales Tax');
//define('RW_BO_TAX_AUTH','Tax Authorities');
define('RW_BO_INV_TOTAL','Сума Счета');
define('RW_BO_BALANCE_DUE','Balance Due');
define('RW_BO_CUR_CODE','Код валюты');
define('RW_BO_CUR_EXC_RATE','Currency Exc. Rate');
define('RW_BO_INV_NUM','Sales Order Number');
define('RW_BO_PO_NUM','Purchase Order Number');
define('RW_BO_SALES_REP','Sales Rep');
define('RW_BO_AR_ACCT','Дт счет');
define('RW_BO_BILL_ACCT_ID','Bill Acct ID');
define('RW_BO_BILL_ADD_ID','Bill Address ID');
define('RW_BO_BILL_PRIMARY_NAME','Bill Primary Name');
define('RW_BO_BILL_CONTACT','Bill Contact');
define('RW_BO_BILL_ADDRESS1','Адрес плательщика 1');
define('RW_BO_BILL_ADDRESS2','Адрес плательщика 2');
define('RW_BO_BILL_CITY','Город плательщика');
define('RW_BO_BILL_STATE','Bill State/Province');
define('RW_BO_BILL_ZIP','Bill Postal Code');
define('RW_BO_BILL_COUNTRY','Bill Country');
define('RW_BO_BILL_TELE1','Bill Telephone 1');

define('RW_BO_QTY_ORDERED','Ordered');
define('RW_QTY_IN_STOCK','На руках');
define('RW_BO_QTY_BACKORDER','Backorder');

?>