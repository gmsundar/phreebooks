<?php
// +-----------------------------------------------------------------+
// |                   PhreeBooks Open Source ERP                    |
// +-----------------------------------------------------------------+
// | Copyright (c) 2008, 2009, 2010 PhreeSoft, LLC                   |
// | http://www.PhreeSoft.com                                        |
// +-----------------------------------------------------------------+
// | This program is free software: you can redistribute it and/or   |
// | modify it under the terms of the GNU General Public License as  |
// | published by the Free Software Foundation, either version 3 of  |
// | the License, or any later version.                              |
// |                                                                 |
// | This program is distributed in the hope that it will be useful, |
// | but WITHOUT ANY WARRANTY; without even the implied warranty of  |
// | MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the   |
// | GNU General Public License for more details.                    |
// |                                                                 |
// | The license that is bundled with this package is located in the |
// | file: /doc/manual/ch01-Introduction/license.html.               |
// | If not, see http://www.gnu.org/licenses/                        |
// +-----------------------------------------------------------------+
//  Path: /modules/setup/language/en_us/modules/chart_of_accounts.php
//

/************* Release 2.0 additions ***********************/
define('GL_INFO_HEADING_ONLY','This account is a heading and cannot accept posted values?');
define('GL_INFO_PRIMARY_ACCT_ID','Этот счет является под-счетом, выберите базовый счет:');
define('ERROR_ACCT_TYPE_REQ','Тип счета ГК обязателен!');
define('GL_ERROR_CANT_MAKE_HEADING','На этом счета есть средства. It cannot be converted to a header account.');
/***********************************************************/

define('GL_POPUP_WINDOW_TITLE','План счетов');
define('GL_HEADING_ACCOUNT_NAME','ID счета');
define('GL_HEADING_SUBACCOUNT','Под счет');
define('GL_EDIT_INTRO','Внесите требуемые изменения');
define('GL_INFO_ACCOUNT_TYPE','Тип счета (обязательно)');
define('GL_INFO_ACCOUNT_INACTIVE','Счет неактивен');
define('GL_INFO_INSERT_INTRO','Введите новый счет ГК и его свойства');
define('GL_INFO_NEW_ACCOUNT','Новый счет');
define('GL_INFO_EDIT_ACCOUNT','Редактировать счет');
define('GL_INFO_DELETE_ACCOUNT','Удалить счет');
define('GL_INFO_DELETE_INTRO','Точно хотите удалить этот счет?\nСчет не может быть удален если по нем есть какие либо проводки.');
define('GL_DISPLAY_NUMBER_OF_COA', TEXT_DISPLAY_NUMBER . 'accounts');
define('GL_ERROR_CANT_DELETE','Невозможно удалить, существуют зависимые записи.');
define('GL_LOG_CHART_OF_ACCOUNTS','Chart of Accounts - ');
?>