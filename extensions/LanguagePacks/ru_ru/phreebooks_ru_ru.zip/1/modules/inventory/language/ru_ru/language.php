<?php
// +-----------------------------------------------------------------+
// |                   PhreeBooks Open Source ERP                    |
// +-----------------------------------------------------------------+
// | Copyright (c) 2008, 2009, 2010 PhreeSoft, LLC                   |
// | http://www.PhreeSoft.com                                        |
// +-----------------------------------------------------------------+
// | This program is free software: you can redistribute it and/or   |
// | modify it under the terms of the GNU General Public License as  |
// | published by the Free Software Foundation, either version 3 of  |
// | the License, or any later version.                              |
// |                                                                 |
// | This program is distributed in the hope that it will be useful, |
// | but WITHOUT ANY WARRANTY; without even the implied warranty of  |
// | MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the   |
// | GNU General Public License for more details.                    |
// |                                                                 |
// | The license that is bundled with this package is located in the |
// | file: /doc/manual/ch01-Introduction/license.html.               |
// | If not, see http://www.gnu.org/licenses/                        |
// +-----------------------------------------------------------------+
//  Path: /modules/inventory/language/en_us/language.php
//

/********************* Release R2.0 additions *************************/
define('INV_TOOLS_STOCK_ROUNDING_ERROR','SKU: %s -> Stock indicates %s on hand but is less than your precision. Please repair your inventory balances, the stock on hand will be rounded to %s.');
define('INV_TOOLS_BALANCE_CORRECTED','АРТ: %s -> Количество на руках изменено на %s.');

/********************* Release R2.0 additions *************************/
define('INV_TYPES_SA','Serialized Assembly');

/********************* Release R1.9 additions *************************/
define('INV_TYPES_SI','Единица на складе');
define('INV_TYPES_SR','Serialized Item');
define('INV_TYPES_MS','Единица главного склада');
define('INV_TYPES_AS','Item Assembly');
define('INV_TYPES_NS','Нескладская единица');
define('INV_TYPES_LB','Рабочая сила');
define('INV_TYPES_SV','Сервис');
define('INV_TYPES_SF','Фиксированный тариф - Сервис');
define('INV_TYPES_CI','Charge Item');
define('INV_TYPES_AI','Activity Item');
define('INV_TYPES_DS','Описание');
define('INV_TYPES_IA','Item Assembly Part');
define('INV_TYPES_MI','Master Stock Sub Item');
define('INV_TEXT_FIFO','FIFO');
define('INV_TEXT_LIFO','LIFO');
define('INV_TEXT_AVERAGE','Средний');
define('INV_TEXT_GREATER_THAN','Более чем');
define('TEXT_CHECKED','Проверено');
define('TEXT_UNCHECKED','Непроверено');
define('TEXT_SGL_PREC','Single Precision');
define('TEXT_DBL_PREC','Double Precision');
define('TEXT_NOT_USED','Не используется');
define('TEXT_DIR_ENTRY','Прямой ввод');
define('TEXT_ITEM_COST','Себестоимость');
define('TEXT_RETAIL_PRICE','Розничная цена');
define('TEXT_PRICE_LVL_1','Цена ур. 1');	
define('TEXT_DEC_AMT','Снижение по сумме');
define('TEXT_DEC_PCNT','Decrease by Percent');
define('TEXT_INC_AMT','Increase by Amount');
define('TEXT_INC_PCNT','Increase by Percent');
define('TEXT_NEXT_WHOLE','Next Dollar');
define('TEXT_NEXT_FRACTION','Constant Cents');
define('TEXT_NEXT_INCREMENT','Next Increment');
define('INV_XFER_SUCCESS','Successfully transfered %s pieces of sku %s');
define('TEXT_INV_MANAGED','Controlled Stock');
define('TEXT_FILTERS','Фильтра:');
define('TEXT_SHOW_INACTIVE','Показать неактивные');
define('TEXT_APPLY','Применить');
define('AJAX_INV_NO_INFO','Not enough information was passed to retrieve the item details');

/********************* Release R1.8 additions *************************/
define('INV_TOOLS_VALIDATE_SO_PO','Инвентаризация: проверка количества товаров в заказах');
define('INV_TOOLS_VALIDATE_SO_PO_DESC','This operation tests to make sure your inventory quantity on Purchase Order and quantity of Sales Order match with the journal entries. The calculated values from the journal entries override the value in the inventory table.');
define('INV_TOOLS_REPAIR_SO_PO','Test and Repair Inventory Quantity on Order Values');
define('INV_TOOLS_BTN_SO_PO_FIX','Нечать проверку и восстановление');
define('INV_TOOLS_PO_ERROR','SKU: %s had a quantity on Purchase Order of %s and should be %s. The inventory table balance was fixed.');
define('INV_TOOLS_SO_ERROR','SKU: %s had a quantity on Sales Order of %s and should be %s. The inventory table balance was fixed.');
define('INV_TOOLS_SO_PO_RESULT','Finished processing Inventory order quantities. The total number of items processed was %s. The number of records with errors was %s.');
define('INV_TOOLS_AUTDIT_LOG_SO_PO','Inv Tools - Repair SO/PO Qty (%s)');
define('INV_ENTRY_PURCH_TAX','Налог с закупок');
define('INV_ENTRY_ITEM_TAXABLE','Налог с продаж');
define('TEXT_LAST_MONTH','За последний месяц');
define('TEXT_LAST_3_MONTH','3 Месяца');
define('TEXT_LAST_6_MONTH','6 Месяцев');
define('TEXT_LAST_12_MONTH','12 Месяцев');

/********************* Release R1.7 additions *************************/
define('TEXT_WHERE_USED','Where Used');
define('TEXT_CURRENT_COST','Current Assembly Cost');
define('JS_INV_TEXT_ASSY_COST','The current price to assemble this SKU is: ');
define('JS_INV_TEXT_USAGE','This SKU is used in the following assemblies: ');
define('JS_INV_TEXT_USAGE_NONE','This SKU is not used in any assemblies.');
define('INV_HEADING_UPC_CODE','UPC Код');
define('INV_SKU_ACTIVITY','SKU Activity');
define('INV_ENTRY_INVENTORY_DESC_SALES','Sales Description');
define('INV_ERROR_DELETE_HISTORY_EXISTS','Cannot delete this inventory item since there is a record in the inventory_history table.');
define('INV_ERROR_DELETE_ASSEMBLY_PART','Cannot delete this inventory item since it is part of an assembly.');

define('INV_TOOLS_VALIDATE_INVENTORY','Validate Inventory Displayed Stock');
define('INV_TOOLS_VALIDATE_INV_DESC','This operation tests to make sure your inventory quantities listed in the inventory database and displayed in the inventory screens are the same as the quantities in the inventory history database as calculated by PhreeBooks when inventory movements occur. The only items tested are the ones that are tracked in the cost of goods sold calculation. Repairing inventory balances will correct the quantity in stock and leave the inventory history data alone. ');
define('INV_TOOLS_REPAIR_TEST','Test Inventory Balances with COGS History');
define('INV_TOOLS_REPAIR_FIX','Repair Inventory Balances with COGS History');
define('INV_TOOLS_REPAIR_CONFIRM','Are you sure you want to repair the inventory stock on hand to match the PhreeBooks COGS history calculated values?');
define('INV_TOOLS_BTN_TEST','Verify Stock Balances');
define('INV_TOOLS_BTN_REPAIR','Sync Qty in Stock');
define('INV_TOOLS_OUT_OF_BALANCE','SKU: %s -> stock indicates %s on hand but COGS history list %s available');
define('INV_TOOLS_IN_BALANCE','Баланс склада в норме.');

/********************* Release R1.6 and earlier additions *************************/
define('INV_ASSY_HEADING_TITLE','Assemble/Disassemble Inventory');
define('TEXT_INVENTORY_REVALUATION','Inventory Re-valuation');
define('INV_FIELD_HEADING_TITLE','Управление полями');
define('INV_POPUP_WINDOW_TITLE','Inventory Items');
define('INV_POPUP_PRICE_MGR_WINDOW_TITLE','Управление прайсами');
define('INV_POPUP_ADJ_WINDOW_TITLE','Корректировки наличия');
define('INV_ADJUSTMENT_ACCOUNT','Корректировочный счет');
define('INV_POPUP_PRICES_WINDOW_TITLE','АРТ прайс');
define('INV_BULK_SKU_ENTRY_TITLE','Bulk SKU Pricing Entry');
define('INV_POPUP_XFER_WINDOW_TITLE','Трансфер между складами магазинов');

define('INV_HEADING_QTY_ON_HAND','Кол на Руках');
define('INV_QTY_ON_HAND','Количество на Руках');
define('INV_HEADING_SERIAL_NUMBER','Серийный номер');
define('INV_HEADING_QTY_TO_ASSY','Кол к сборке');
define('INV_HEADING_QTY_ON_ORDER','Кол в Зак. Поставки');
define('INV_HEADING_QTY_IN_STOCK','Кол на складе');
define('TEXT_QTY_THIS_STORE','Qty this Branch');
define('INV_HEADING_QTY_ON_SO','Кол в заказах');
define('INV_QTY_ON_SALES_ORDER','Количество в Заказах клиентов');
define('INV_HEADING_PREFERRED_VENDOR','Предпочитаемый поставщик');
define('INV_HEADING_LEAD_TIME','Время поставки (дн)');
define('INV_QTY_ON_ORDER','Количество в заказах на поставку');
define('INV_ASSY_PARTS_REQUIRED','Components required for this assembly');
define('INV_TEXT_REMAINING','Qty Remaining');
define('INV_TEXT_UNIT_COST','Себестоимость');
define('INV_TEXT_CURRENT_VALUE','Текущая стоимость');
define('INV_TEXT_NEW_VALUE','Новое значение');

define('INV_ADJ_QUANTITY','Количество единиц');
define('INV_REASON_FOR_ADJUSTMENT','Причина корректировки');
define('INV_ADJ_VALUE','Кол единиц');
define('INV_ROUNDING','Округление');
define('INV_RND_VALUE','Rnd. Value');
define('INV_BOM','Ведомость материалов
');
define('INV_ADJ_DELETE_ALERT','Are you sure you want to delete this Inventory Adjustment?');
define('INV_MSG_DELETE_INV_ITEM','Are you sure you want to delete this inventory item?');

define('INV_XFER_FROM_STORE','Перенести из магазина ID');
define('INV_XFER_TO_STORE','В магазин ID');
define('INV_XFER_QTY','Количество для трансфера');
define('INV_XFER_ERROR_NO_COGS_REQD','This inventory item is not tracked in the cost of goods sold. Therefore, the transfer of this item between stores does not require it to be posted!');
define('INV_XFER_ERROR_QTY_ZERO','This inventory item quantity cannot be less than zero! Re-enter the transfer the other direction with a positive quantity.');
define('INV_XFER_ERROR_SAME_STORE_ID','The source and destination store ID\'s are the same, the transfer was not performed!');
define('INV_XFER_ERROR_NOT_ENOUGH_SKU','Cannot transfer inventory, not enough available in stock to transfer!');

define('INV_HEADING_NEW_ITEM','Новая единиуа на складе'); 
define('INV_HEADING_FIELD_INFO','Inventory Field Information');
define('INV_HEADING_FIELD_PROPERTIES','Field Type and Properties (Select One)');
define('INV_ENTER_SKU','Enter the SKU, item type and cost method then press Continue<br />Maximum SKU length is ' . MAX_INVENTORY_SKU_LENGTH . ' characters (' . (MAX_INVENTORY_SKU_LENGTH - 5) . ' for Master Stock)');
define('INV_MS_ATTRIBUTES','Master Stock Attributes');
define('INV_TEXT_ATTRIBUTE_1','Атрибут 1');
define('INV_TEXT_ATTRIBUTE_2','Атрибут 2');
define('INV_TEXT_ATTRIBUTES','Атрибуты');
define('INV_MS_CREATED_SKUS','Следующие АРТиулы созданы');

define('INV_ENTRY_INVENTORY_TYPE','Тип единицы');
define('INV_ENTRY_INVENTORY_DESC_SHORT','Краткое описание');
define('INV_ENTRY_INVENTORY_DESC_PURCHASE','Purchase Description');
define('INV_ENTRY_IMAGE_PATH','Папка изображений');
define('INV_ENTRY_SELECT_IMAGE','Выберите изображение');
define('INV_ENTRY_ACCT_SALES','Счет Продаж/Доходов');
define('INV_ENTRY_ACCT_INV','Счет оборотных фондов');
define('INV_ENTRY_ACCT_COS','Себестоимость - Счет');
define('INV_ENTRY_INV_ITEM_COST','Себестоимость');
define('INV_ENTRY_FULL_PRICE','Полная цена');
define('INV_ENTRY_ITEM_WEIGHT','Вес');
define('INV_ENTRY_ITEM_MINIMUM_STOCK','Минимальное количество на складе');
define('INV_ENTRY_ITEM_REORDER_QUANTITY','Reorder Quantity');
define('INV_ENTRY_INVENTORY_COST_METHOD','Метод учета');
define('INV_ENTRY_INVENTORY_SERIALIZE','Сериализация');
define('INV_MASTER_STOCK_ATTRIB_ID','ID (макс 2 симв)');

define('INV_DATE_ACCOUNT_CREATION','Дата создание');
define('INV_DATE_LAST_UPDATE','Дата обновления');
define('INV_DATE_LAST_JOURNAL_DATE','Last Entry Date');

// Inventory History
define('INV_SKU_HISTORY','История АРТ');
define('INV_OPEN_PO','Открытые Заказы на поставку');
define('INV_OPEN_SO','Открытые Заказы на продажу');
define('INV_PURCH_BY_MONTH','Закупки по месяцам');
define('INV_SALES_BY_MONTH','Продажи по месяцам');

define('INV_NO_RESULTS','Ничего не найдено');
define('INV_PO_NUMBER','Номер поставки');
define('INV_SO_NUMBER','Номер заказа');
define('INV_PO_DATE','Дата закупки');
define('INV_SO_DATE','Дата продажи');
define('INV_PO_RCV_DATE','Дата получения');
define('INV_SO_SHIP_DATE','Дата отправки');
define('INV_PURCH_COST','Сума закупки');
define('INV_SALES_INCOME','Сума продаж');
define('TEXT_MONTH','В этом месяце');

define('INV_MSG_COPY_INTRO','Введите новый АРТ для копирования:');
define('INV_MSG_RENAME_INTRO','Please enter a new SKU ID to rename this SKU to:');
define('INV_ERROR_DUPLICATE_SKU','The new inventory item cannot be created because the sku is already in use.');
define('INV_ERROR_CANNOT_DELETE','The inventory item cannot be deleted because there are journal entries in the system matching the sku');
define('INV_ERROR_BAD_SKU','There was an error with the item assembly list, please validate sku values and check quantities. Failing sku was: ');
define('INV_ERROR_SKU_INVALID','SKU is invalid. Please check the sku value and inventory account for errors.');
define('INV_ERROR_SKU_BLANK','The SKU field was left blank. Please enter a sku value and retry.');
define('INV_ERROR_FIELD_BLANK','The field name was left blank. Please enter a field name and retry.');
define('INV_ERROR_FIELD_DUPLICATE','The field you entered is a duplicate, please change the field name and re-submit.');
define('INV_ERROR_NEGATIVE_BALANCE','Error unbuilding inventory, not enough stock on hand to unbuild the requested quantity!');
define('TEXT_DISPLAY_NUMBER_OF_ITEMS','Отображено <b>%d</b> по <b>%d</b> (из <b>%d</b> единиц)');
define('TEXT_DISPLAY_NUMBER_OF_FIELDS','Отображено <b>%d</b> по <b>%d</b> (из <b>%d</b> полей)');
define('INV_CATEGORY_MEMBER','Category Member:');
define('INV_FIELD_NAME', 'Field Name: ');
define('INV_DESCRIPTION', 'Description: ');
define('TEXT_USE_DEFAULT_PRICE_SHEET','Изпользовать настройки прайса по умолчанию');
define('INV_ERROR_ASSY_CANNOT_DELETE','Cannot delete assembly. It has been used by another journal entry!');
define('INV_POST_SUCCESS','Succesfully Posted Inventory Adjustment Ref # ');
define('INV_POST_ASSEMBLY_SUCCESS','Successfully assembled SKU: ');
define('INV_NO_PRICE_SHEETS','No price sheets have been defined!');
define('INV_DEFINED_PRICES','Defined Prices for SKU: ');

define('INV_LABEL_DEFAULT_TEXT_VALUE', 'Default Value: ');
define('INV_LABEL_MAX_NUM_CHARS','Maximum Number of Characters (Length)');
define('INV_LABEL_FIXED_255_CHARS','Fixed at 255 Characters Maximum');
define('INV_LABEL_MAX_255','(for lengths less than 256 Characters)');
define('INV_LABEL_CHOICES','Enter Selection String');
define('INV_LABEL_TEXT_FIELD','Текстовое поле');
define('INV_LABEL_HTML_TEXT_FIELD','HTML Код');
define('INV_LABEL_HYPERLINK','Ссылка');
define('INV_LABEL_IMAGE_LINK','Файл изображения');
define('INV_LABEL_INVENTORY_LINK','Inventory Link (Link pointing to another inventory item (URL))');
define('INV_LABEL_INTEGER_FIELD','Целое число');
define('INV_LABEL_INTEGER_RANGE','Диапазон целых чисел');
define('INV_LABEL_DECIMAL_FIELD','Десятичное число');
define('INV_LABEL_DECIMAL_RANGE','Диапазон десятичных');
define('INV_LABEL_DEFAULT_DISPLAY_VALUE','Формат отображения (Max,Decimal)');
define('INV_LABEL_DROP_DOWN_FIELD','Выпадающий список');
define('INV_LABEL_RADIO_FIELD','Radio Button Selection<br />Enter choices, separated by commas as:<br />value1:desc1:def1,value2:desc2:def2<br /><u>Key:</u><br />value = The value to place into the database<br />desc = Textual description of the choice<br />def = Default 0 or 1, 1 being the default choice<br />Note: Only 1 default is allowed per list');
define('INV_LABEL_DATE_TIME_FIELD','Дата и время');
define('INV_LABEL_CHECK_BOX_FIELD','Check Box (Yes or No Choice)');
define('INV_LABEL_TIME_STAMP_FIELD','Временной штамп');
define('INV_LABEL_TIME_STAMP_VALUE','System field to track the last date and time a change to a particular inventory item was made.');

define('INV_FIELD_NAME_RULES','Fieldnames cannot contain spaces or special<br />characters and must be 64 characters or less');
define('INV_DELETE_INTRO_INV_FIELDS','Are you sure you want to delete this inventory field?\nALL DATA WILL BE LOST!');
define('INV_INFO_HEADING_DELETE_INVENTORY','Delete Inventory Field');
define('INV_CATEGORY_CANNOT_DELETE','Cannot delete category. It is being used by field: ');
define('INV_CANNOT_DELETE_SYSTEM','Fields in the System category cannot be deleted!');
define('INV_IMAGE_PATH_ERROR','Error in the path specified for the upload image!');
define('INV_IMAGE_FILE_TYPE_ERROR','Error in the uploaded image file. Not an acceptable file type.');
define('INV_IMAGE_FILE_WRITE_ERROR','There was a problem writing the image file to the specified directory.');
define('INV_FIELD_RESERVED_WORD','The field name entered is a reserved word. Please choose a new field name.');

// java script errors and messages
define('JS_SKU_BLANK','* The new item needs a SKU or UPC Code\n');
define('JS_COGS_AUTO_CALC','Unit price will be calculated by the system.');
define('JS_NO_SKU_ENTERED','A SKU value is required.\n');
define('JS_ADJ_VALUE_ZERO','A non-zero adjustment quantity is required.\n');
define('JS_XFER_VALUE_ZERO','A positive transfer quantity is required.\n');
define('JS_ASSY_VALUE_ZERO','A non-zero assembly quantity is required.\n');
define('JS_NOT_ENOUGH_PARTS','Not enough inventory to assemble the desired quantities');
define('JS_MS_INVALID_ENTRY','Both ID and Description are required fields. Please enter both values and press OK.');
define('JS_INV_TEXT_ASSY_COST','The current price to assemble this SKU is: ');
define('JS_INV_TEXT_USAGE','This SKU is used in the following assemblies: ');
define('JS_INV_TEXT_USAGE_NONE','This SKU is not used in any assemblies.');

// audit log messages
define('INV_LOG_ADJ','Inventory Adjustment - ');
define('INV_LOG_ASSY','Inventory Assembly - ');
define('INV_LOG_FIELDS','Inventory Fields - ');
define('INV_LOG_INVENTORY','Inventory Item - ');
define('INV_LOG_PRICE_MGR','Inventory Price Manager - ');
define('INV_LOG_TRANSFER','Inv Transfer from %s to %s');

// the inventory type indexes should not be changed or the inventory module won't work.
// system generated types (not to be displayed are: ai - assembly item, mi - master stock with attributes)
$inventory_types = array(
  'si' => INV_TYPES_SI,
  'sr' => INV_TYPES_SR,
  'ms' => INV_TYPES_MS,
  'as' => INV_TYPES_AS,
  'sa' => INV_TYPES_SA,
  'ns' => INV_TYPES_NS,
  'lb' => INV_TYPES_LB,
  'sv' => INV_TYPES_SV,
  'sf' => INV_TYPES_SF,
  'ci' => INV_TYPES_CI,
  'ai' => INV_TYPES_AI,
  'ds' => INV_TYPES_DS,
);

// used for identifying inventory types in reports and forms that are not selectable by the user
$inventory_types_plus       = $inventory_types;
$inventory_types_plus['ia'] = INV_TYPES_IA;
$inventory_types_plus['mi'] = INV_TYPES_MI;

$cost_methods = array(
  'f' => INV_TEXT_FIFO,	   // First-in, First-out
  'l' => INV_TEXT_LIFO,	   // Last-in, First-out
  'a' => INV_TEXT_AVERAGE, // Average Costing
); 

$integer_lengths = array(
  '0' => '-127 ' . TEXT_TO . ' 127',
  '1' => '-32,768 ' . TEXT_TO . ' 32,768',
  '2' => '-8,388,608 ' . TEXT_TO . ' 8,388,607',
  '3' => '-2,147,483,648 ' . TEXT_TO . ' 2,147,483,647',
  '4' => INV_TEXT_GREATER_THAN . ' 2,147,483,648',
);

$decimal_lengths = array(
  '0' => TEXT_SGL_PREC,
  '1' => TEXT_DBL_PREC,
);

$check_box_choices = array(
  '0' => TEXT_UNCHECKED, 
  '1' => TEXT_CHECKED,
);

$price_mgr_sources = array(
  '0' => TEXT_NOT_USED,	// Do not remove this selection, leave as first entry
  '1' => TEXT_DIR_ENTRY,
  '2' => TEXT_ITEM_COST,
  '3' => TEXT_RETAIL_PRICE,
// Price Level 1 needs to always be at the end (it is pulled from the first row to avoid a circular reference)
// The index can change but must be matched with the javascript to update the price source values.
  '4' => TEXT_PRICE_LVL_1,
);	

$price_mgr_adjustments = array(
  '0' => TEXT_NONE,
  '1' => TEXT_DEC_AMT,
  '2' => TEXT_DEC_PCNT,
  '3' => TEXT_INC_AMT,
  '4' => TEXT_INC_PCNT,
);

$price_mgr_rounding = array(
  '0' => TEXT_NONE,
  '1' => TEXT_NEXT_WHOLE,
  '2' => TEXT_NEXT_FRACTION,
  '3' => TEXT_NEXT_INCREMENT,
);

?>