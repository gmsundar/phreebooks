<?php
// +-----------------------------------------------------------------+
// |                   PhreeBooks Open Source ERP                    |
// +-----------------------------------------------------------------+
// | Copyright (c) 2008, 2009, 2010 PhreeSoft, LLC                   |
// | http://www.PhreeSoft.com                                        |
// +-----------------------------------------------------------------+
// | This program is free software: you can redistribute it and/or   |
// | modify it under the terms of the GNU General Public License as  |
// | published by the Free Software Foundation, either version 3 of  |
// | the License, or any later version.                              |
// |                                                                 |
// | This program is distributed in the hope that it will be useful, |
// | but WITHOUT ANY WARRANTY; without even the implied warranty of  |
// | MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the   |
// | GNU General Public License for more details.                    |
// |                                                                 |
// | The license that is bundled with this package is located in the |
// | file: /doc/manual/ch01-Introduction/license.html.               |
// | If not, see http://www.gnu.org/licenses/                        |
// +-----------------------------------------------------------------+
//  Path: /modules/orders/language/en_us/language.php
//

/********************* Release R2.1 additions ***********************/
define('TEXT_SAVE_OPEN_PREVIOUS','Сохранить - Открыть предыдущий счет');
define('TEXT_SAVE_OPEN_NEXT','Сохранить - Открыть следующий счет');
define('ORD_WARN_FORM_MODIFIED','Данные введенные в форму уже существуют. Хотите найти существующий контакт?');

/********************* Release R2.0 additions ***********************/
define('ORD_ERROR_NOT_CUR_PERIOD','Your permissions prevent you from posting to a period other than the current period!');
define('ORD_ERROR_DEL_NOT_CUR_PERIOD','Ваши полномочия не позоляют удалять заказы за период отличный от текущего!');

/********************* Release R1.9 additions ***********************/
define('ORD_DISCOUNT_GL_ACCT','Счет учета скидок');
define('ORD_FREIGHT_GL_ACCT','Счет расходов на доставку');
define('ORD_INV_STOCK_LOW','Не хватает складских запасов этой единицы.');
define('ORD_INV_STOCK_BAL','The number of units in stock is: ');
define('ORD_INV_OPEN_POS','Есть следующие открытые заказы на закупку:');
define('ORD_INV_STOCK_STATUS','Магазин: %s PO: %s Кол: %s Due: %s');
define('ORD_JS_SKU_NOT_UNIQUE','Не найдено уникальных результатов по этому АРТ. Либо по введенному критерию не найдено ничего, либо есть несколько результатов.');
define('ORD_JS_NO_CID','The contact information must be loaded into this form before the properties can be retrieved.');

/********************* Release R1.7 additions ***********************/
define('POPUP_BAR_CODE_TITLE','Штрихкод');
define('ORD_BAR_CODE_INTRO','Введите количество и отсканируйте товар.');
define('TEXT_UPC_CODE','Штрихкод');

/********************************************************************/
// General
define('ORD_ADD_UPDATE','Добавить/Обновить');
define('ORD_AP_ACCOUNT','Кт перед поставщиками');
define('ORD_AR_ACCOUNT','Дт счет');
define('ORD_CASH_ACCOUNT','Наличный счет');
define('ORD_CLOSED','Закрыт?');
define('ORD_COPY_BILL','Копировать -->');
define('ORD_CUSTOMER_NAME','Имя покупателя');
define('ORD_DELETE_ALERT','Точно хотите удалить этот заказ?');
define('ORD_DELIVERY_DATES','Дата доставки');
define('ORD_DISCOUNT_PERCENT','Скидка (%)');
define('ORD_DROP_SHIP','Прямая поставка');
define('ORD_EXPECTED_DATES','Expected Delivery Dates - ');
define('ORD_FREIGHT','Доставка');
define('ORD_FREIGHT_ESTIMATE','Расчет доставки');
define('ORD_FREIGHT_SERVICE','Сервис');
define('ORD_INVOICE_TOTAL','Всего');
define('ORD_MANUAL_ENTRY','Ручной ввод');
define('ORD_NA','N/A');
define('ORD_NEW_DELIVERY_DATES','Новая дата доставки');
define('ORD_PAID','Оплаченный');
define('ORD_PURCHASE_TAX','Налог на покупку');
define('ORD_ROW_DELETE_ALERT','Точно хотите удалить эту строку?');
define('ORD_SALES_TAX','Налог на продажу');
define('ORD_SHIP_CARRIER','Доставщик');
define('ORD_SHIP_TO','Адрес доставки:');
define('ORD_SHIPPED','Отправленный');
define('ORD_SUBTOTAL','Подитог');
define('ORD_TAX_RATE','Налоговая ставка');
define('ORD_TAXABLE','Облагаемый');
define('ORD_VENDOR_NAME','Поставщик');
define('ORD_VOID_SHIP','Отменить отгрузку');
define('ORD_WAITING_FOR_INVOICE','Ожидает Счет');
define('ORD_WAITING','Ожидает?');
define('ORD_SO_INV_MESSAGE','Для автоматического присвоения номера, ставте номер Заказа или Счета пустым.');
define('ORD_CONVERT_TO_SO_INV','Преобразовать в Заказ/Счет');
define('ORD_CONVERT_TO_SO','Convert to SO ');
define('ORD_CONVERT_TO_INV','Convert to Invoice ');
define('ORD_PO_MESSAGE','Для автоматического присвоения номера, ставте номер Заказа на поставку пустым.');
define('ORD_CONVERT_TO_SO_INV','Конверт. в Заказ/Счет');
define('ORD_CONVERT_TO_PO','Auto Generate Purchase Order ');

// Javascript Messages
define('ORD_JS_RECUR_NO_INVOICE','For a recurring transaction, a starting invoice number needs to be entered. PhreeBooks will increment it for each recurring entry.');
define('ORD_JS_RECUR_ROLL_REQD','This is a recurring entry. Do you want to update future entries as well? (Press Cancel to update only this entry)');
define('ORD_JS_RECUR_DEL_ROLL_REQD','This is a recurring entry. Do you want to delete future entries as well? (Press Cancel to delete only this entry)');
define('ORD_JS_WAITING_FOR_PAYMENT','Either Waiting for Invoice needs to be checked or an invoice number needs to be entered.');
define('ORD_JS_SERIAL_NUM_PROMPT','Enter the serial number for this line item. NOTE: The quantiy must be 1 for serialized items.');
define('ORD_JS_NO_STOCK_A','Caution! There is not enough of item SKU ');
define('ORD_JS_NO_STOCK_B',' in stock to fill the order.\nThe number of items in stock is: ');
define('ORD_JS_NO_STOCK_C','\n\nНажмите OK чтобы продолжить, или Отменить для возвращения к заказу.');
define('ORD_JS_INACTIVE_A','Caution! SKU: ');
define('ORD_JS_INACTIVE_B',' is an inactive item.\n\nPress OK to continue or Cancel to return to the order form');
define('ORD_JS_CANNOT_CONVERT_QUOTE','An un-Posted Sales Quote cannot be converted to Sales Order or a Sales/Invoice!');
define('ORD_JS_CANNOT_CONVERT_SO','An un-Posted Sales Order cannot be converted to a Purchase Order!');

// Audit log messages
define('ORD_DELIVERY_DATES','PO/SO Delivery Dates - ');

// Recur Transactions
define('ORD_RECUR_INTRO','This transaction can be duplicated in the future by selecting the number of entries to be created and the frequency for which they are posted. The current entry is considered the first recurrence.');
define('ORD_RECUR_ENTRIES','Введите номер записи для создания
');
define('ORD_RECUR_FREQUENCY','How often to post entries');
define('ORD_TEXT_WEEKLY','Еженедельно');
define('ORD_TEXT_BIWEEKLY','Дважды в неделю');
define('ORD_TEXT_MONTHLY','Ежемесячно');
define('ORD_TEXT_QUARTERLY','Ежеквартально');
define('ORD_TEXT_YEARLY','Ежегодно');
define('ORD_PAST_LAST_PERIOD','The posted transaction cannot recur past the last period in the system!');

// Tooltips
define('ORD_TT_PURCH_INV_NUM','If you leave this field blank, Phreebooks will automatically assign a number.');

// Purchase Quote Specific
define('ORD_TEXT_3_BILL_TO','Перечислять:');
define('ORD_TEXT_3_REF_NUM','Референс #');
define('ORD_TEXT_3_WINDOW_TITLE','Запросить Квоту');
define('ORD_TEXT_3_EXPIRES','Конечный срок');
define('ORD_TEXT_3_NUMBER','Quote Number');
define('ORD_TEXT_3_TEXT_REP','Покупатель');
define('ORD_TEXT_3_ITEM_COLUMN_1','Кол');
define('ORD_TEXT_3_ITEM_COLUMN_2','Приемка');
define('ORD_TEXT_3_ERROR_NO_VENDOR','No vendor was selected! Either select a vendor from the popup menu or enter the information and select: ' . ORD_ADD_UPDATE);
define('ORD_TEXT_3_NUMBER_OF_ORDERS', TEXT_DISPLAY_NUMBER . 'vendor quotes');
define('ORD_TEXT_3_CLOSED_TEXT',TEXT_CLOSE);

// Purchase Order Specific
define('ORD_TEXT_4_BILL_TO','Плательщик:');
define('ORD_TEXT_4_REF_NUM','Референс #');
define('ORD_TEXT_4_WINDOW_TITLE','Заказ на поставку');
define('ORD_TEXT_4_EXPIRES','Конечный срок');
define('ORD_TEXT_4_NUMBER','Номер поставки');
define('ORD_TEXT_4_TEXT_REP','Покупатель');
define('ORD_TEXT_4_ITEM_COLUMN_1','Кол');
define('ORD_TEXT_4_ITEM_COLUMN_2','Приемка');
define('ORD_TEXT_4_ERROR_NO_VENDOR','No vendor was selected! Either select a vendor from the popup menu or enter the information and select: ' . ORD_ADD_UPDATE);
define('ORD_TEXT_4_NUMBER_OF_ORDERS', TEXT_DISPLAY_NUMBER . 'purchase orders');
define('ORD_TEXT_4_CLOSED_TEXT',TEXT_CLOSE);

// Purchase/Receive Specific
define('ORD_TEXT_6_BILL_TO','Плательщик:');
define('ORD_TEXT_6_REF_NUM','Референс #');
define('ORD_TEXT_6_WINDOW_TITLE','Управление Постаками/Приемками');
define('ORD_TEXT_6_ERROR_NO_VENDOR','No vendor was selected! Either select a vendor from the popup menu or enter the information and select: ' . ORD_ADD_UPDATE);
define('ORD_TEXT_6_NUMBER','Номер счета');
define('ORD_TEXT_6_TEXT_REP','Покупатель');
define('ORD_TEXT_6_ITEM_COLUMN_1','PO Bal');
define('ORD_TEXT_6_ITEM_COLUMN_2','Приемка');
define('ORD_TEXT_6_NUMBER_OF_ORDERS', TEXT_DISPLAY_NUMBER . 'item receipts');
define('ORD_TEXT_6_CLOSED_TEXT','Счет оплачен');

// Vendor Credit Memo Specific
define('ORD_TEXT_7_BILL_TO','Плательщик:');
define('ORD_TEXT_7_REF_NUM','Референс #');
define('ORD_TEXT_7_WINDOW_TITLE','Кт М.О. поставщики');
define('ORD_TEXT_7_ERROR_NO_VENDOR','No vendor was selected! Either select a vendor from the popup menu or enter the information and select: ' . ORD_ADD_UPDATE);
define('ORD_TEXT_7_NUMBER','Кт М.О №');
define('ORD_TEXT_7_TEXT_REP','Покупатель');
define('ORD_TEXT_7_ITEM_COLUMN_1','Принятый');
define('ORD_TEXT_7_ITEM_COLUMN_2','Возвращенный');
define('ORD_TEXT_7_NUMBER_OF_ORDERS', TEXT_DISPLAY_NUMBER . 'vendor invoices');
define('ORD_TEXT_7_CLOSED_TEXT','Credit Taken');

// Customer Quote Specific
define('ORD_TEXT_9_BILL_TO','Адрес плательщика:');
define('ORD_TEXT_9_REF_NUM','Заказ Закупки #');
define('ORD_TEXT_9_WINDOW_TITLE','Customer Quote');
define('ORD_TEXT_9_EXPIRES','Дата окончания срока');
define('ORD_TEXT_9_NUMBER','Quote Number');
define('ORD_TEXT_9_TEXT_REP','Sales Rep');
define('ORD_TEXT_9_ITEM_COLUMN_1','Кол');
define('ORD_TEXT_9_ITEM_COLUMN_2','Счет выставлен');
define('ORD_TEXT_9_ERROR_NO_VENDOR','No customer was selected! Either select a customer from the popup menu or enter the information and select: ' . ORD_ADD_UPDATE);
define('ORD_TEXT_9_NUMBER_OF_ORDERS', TEXT_DISPLAY_NUMBER . 'customer quotes');
define('ORD_TEXT_9_CLOSED_TEXT',TEXT_CLOSE);

// Sales Order Specific
define('ORD_TEXT_10_BILL_TO','Адрес плательщика:');
define('ORD_TEXT_10_REF_NUM','Заказы на поставку #');
define('ORD_TEXT_10_WINDOW_TITLE','Заказы покупателей');
define('ORD_TEXT_10_EXPIRES','Дата отправки');
define('ORD_TEXT_10_NUMBER','Номер заказа');
define('ORD_TEXT_10_TEXT_REP','Sales Rep');
define('ORD_TEXT_10_ITEM_COLUMN_1','Кол');
define('ORD_TEXT_10_ITEM_COLUMN_2','Счет выставлен');
define('ORD_TEXT_10_ERROR_NO_VENDOR','No customer was selected! Either select a customer from the popup menu or enter the information and select: ' . ORD_ADD_UPDATE);
define('ORD_TEXT_10_NUMBER_OF_ORDERS', TEXT_DISPLAY_NUMBER . 'sales orders');
define('ORD_TEXT_10_CLOSED_TEXT',TEXT_CLOSE);

// Sales/Invoice Specific
define('ORD_TEXT_12_BILL_TO','Адрес плательщика:');
define('ORD_TEXT_12_REF_NUM','Заказ на поставку #');
define('ORD_TEXT_12_WINDOW_TITLE','Продажи/Счета');
define('ORD_TEXT_12_EXPIRES','Отправить по дате');
define('ORD_TEXT_12_ERROR_NO_VENDOR','Не выбран покупатель!');
define('ORD_TEXT_12_NUMBER','Номер счета');
define('ORD_TEXT_12_TEXT_REP','Sales Rep');
define('ORD_TEXT_12_ITEM_COLUMN_1','SO Bal');
define('ORD_TEXT_12_ITEM_COLUMN_2','Кол');
define('ORD_TEXT_12_NUMBER_OF_ORDERS', TEXT_DISPLAY_NUMBER . 'invoices');
define('ORD_TEXT_12_CLOSED_TEXT','Полностью оплачен');

// Customer Credit Memo Specific
define('ORD_TEXT_13_BILL_TO','Плательщик:');
define('ORD_TEXT_13_REF_NUM','Референс');
define('ORD_TEXT_13_WINDOW_TITLE','Кт М.О. покупателей');
define('ORD_TEXT_13_EXPIRES','Отправить по дате');
define('ORD_TEXT_13_ERROR_NO_VENDOR','Не выбран покупупатель!');
define('ORD_TEXT_13_NUMBER','Кт М.О. №');
define('ORD_TEXT_13_TEXT_REP','Sales Rep');
define('ORD_TEXT_13_ITEM_COLUMN_1','Отправленный');
define('ORD_TEXT_13_ITEM_COLUMN_2','Возвращен');
define('ORD_TEXT_13_NUMBER_OF_ORDERS', TEXT_DISPLAY_NUMBER . 'invoices');
define('ORD_TEXT_13_CLOSED_TEXT','Credit Paid');

/*
// Cash Receipts Specific
define('ORD_TEXT_18_BILL_TO','Sale to:');
define('ORD_TEXT_18_REF_NUM','Purchase Order #');
define('ORD_TEXT_18_WINDOW_TITLE','Приемка наличных');
define('ORD_TEXT_18_EXPIRES','Отправить по дате');
define('ORD_TEXT_18_ERROR_NO_VENDOR','Не выбран покупатель!');
define('ORD_TEXT_18_NUMBER','Номер приемки');
define('ORD_TEXT_18_TEXT_REP','Sales Rep');
define('ORD_TEXT_18_ITEM_COLUMN_1','SO Bal');
define('ORD_TEXT_18_ITEM_COLUMN_2','Кол');
define('ORD_TEXT_18_NUMBER_OF_ORDERS', TEXT_DISPLAY_NUMBER . 'receipts');
*/
// Point of Sale Specific
define('ORD_TEXT_19_BILL_TO','Sale to:');
define('ORD_TEXT_19_REF_NUM','Заказ на поставку #');
define('ORD_TEXT_19_WINDOW_TITLE','Точка продажи');
define('ORD_TEXT_19_EXPIRES','Отправить по дате');
define('ORD_TEXT_19_ERROR_NO_VENDOR','Не выбран покупатель!');
define('ORD_TEXT_19_NUMBER','Номер приемки');
define('ORD_TEXT_19_TEXT_REP','Sales Rep');
define('ORD_TEXT_19_ITEM_COLUMN_1','SO Bal');
define('ORD_TEXT_19_ITEM_COLUMN_2','Кол');
define('ORD_TEXT_19_NUMBER_OF_ORDERS', TEXT_DISPLAY_NUMBER . 'sales');
define('ORD_TEXT_19_CLOSED_TEXT','Полностью оплачен');
/*
// Cash Distribution Journal
define('ORD_TEXT_20_BILL_TO','Remit to:');
define('ORD_TEXT_20_REF_NUM','Референс #');
define('ORD_TEXT_20_WINDOW_TITLE','Распределение наличных');
define('ORD_TEXT_20_ERROR_NO_VENDOR','No vendor was selected! Either select a vendor from the popup menu or enter the information and select: ' . ORD_ADD_UPDATE);
define('ORD_TEXT_20_NUMBER','Номер платежа');
define('ORD_TEXT_20_TEXT_REP','Покупатель');
define('ORD_TEXT_20_ITEM_COLUMN_1','PO Bal');
define('ORD_TEXT_20_ITEM_COLUMN_2','Приемка');
define('ORD_TEXT_20_NUMBER_OF_ORDERS', TEXT_DISPLAY_NUMBER . 'payments');
*/
// Direct Inventory Purchase/Receive (Checks)
define('ORD_TEXT_21_BILL_TO','Перечислять:');
define('ORD_TEXT_21_REF_NUM','Референс #');
define('ORD_TEXT_21_WINDOW_TITLE','Прямая покупка');
define('ORD_TEXT_21_ERROR_NO_VENDOR','No vendor was selected! Either select a vendor from the popup menu or enter the information and select: ' . ORD_ADD_UPDATE);
define('ORD_TEXT_21_NUMBER','Номер платежа');
define('ORD_TEXT_21_TEXT_REP','Покупатель');
define('ORD_TEXT_21_ITEM_COLUMN_1','PO Bal');
define('ORD_TEXT_21_ITEM_COLUMN_2','Приемка');
define('ORD_TEXT_21_NUMBER_OF_ORDERS', TEXT_DISPLAY_NUMBER . 'payments');
define('ORD_TEXT_21_CLOSED_TEXT','Полностью оплчен');

// popup specific
define('ORD_POPUP_WINDOW_TITLE_3','Vendor Quotes');
define('ORD_POPUP_WINDOW_TITLE_4','Заказы на закупку');
define('ORD_POPUP_WINDOW_TITLE_6','Заказ/Приемка единиц');
define('ORD_POPUP_WINDOW_TITLE_7','Кт М.О. поставщики');
define('ORD_POPUP_WINDOW_TITLE_9','Request for Quote');
define('ORD_POPUP_WINDOW_TITLE_10','Заказы клиентов');
define('ORD_POPUP_WINDOW_TITLE_12','Продажи/Счета');
define('ORD_POPUP_WINDOW_TITLE_13','Кт М.О.');
define('ORD_POPUP_WINDOW_TITLE_19','Точка продажи');
define('ORD_POPUP_WINDOW_TITLE_21','Прямая закупка (склад)');

// recur specific
define('ORD_RECUR_WINDOW_TITLE_2','Периодические записи в Главной книге');
define('ORD_RECUR_WINDOW_TITLE_3','Recur Vendor Quotes');
define('ORD_RECUR_WINDOW_TITLE_4','Периодические закупки');
define('ORD_RECUR_WINDOW_TITLE_6','Периодические Закупки/Приемки');
define('ORD_RECUR_WINDOW_TITLE_7','Recur Vendor Credit Memo');
define('ORD_RECUR_WINDOW_TITLE_9','Recur Request for Quote');
define('ORD_RECUR_WINDOW_TITLE_10','Периодические заказы');
define('ORD_RECUR_WINDOW_TITLE_12','Периодические Счета');
define('ORD_RECUR_WINDOW_TITLE_13','Периодический Кт М.О.');
define('ORD_RECUR_WINDOW_TITLE_19','Recur Point of Sale');
define('ORD_RECUR_WINDOW_TITLE_21','Recur Inventory Direct Purchase');

define('ORD_HEADING_NUMBER_3','Quote Number');
define('ORD_HEADING_NUMBER_4','Номер поставки');
define('ORD_HEADING_NUMBER_6','Счет #');
define('ORD_HEADING_NUMBER_7','Кт М.О. №');
define('ORD_HEADING_NUMBER_9','Quote Number');
define('ORD_HEADING_NUMBER_10','Номер заказа');
define('ORD_HEADING_NUMBER_12','Счет #');
define('ORD_HEADING_NUMBER_13','Кт М.О. №');
define('ORD_HEADING_NUMBER_19','Номер приемки');
define('ORD_HEADING_NUMBER_21','Номер платежа');

define('ORD_HEADING_STATUS_3', ORD_CLOSED);
define('ORD_HEADING_STATUS_4', ORD_CLOSED);
define('ORD_HEADING_STATUS_6', ORD_WAITING);
define('ORD_HEADING_STATUS_7', ORD_WAITING);
define('ORD_HEADING_STATUS_9', ORD_CLOSED);
define('ORD_HEADING_STATUS_10', ORD_CLOSED);
define('ORD_HEADING_STATUS_12', TEXT_PAID);
define('ORD_HEADING_STATUS_13', TEXT_PAID);
define('ORD_HEADING_STATUS_19', ORD_CLOSED);
define('ORD_HEADING_STATUS_21', ORD_CLOSED);

define('ORD_HEADING_NAME_3',ORD_VENDOR_NAME);
define('ORD_HEADING_NAME_4',ORD_VENDOR_NAME);
define('ORD_HEADING_NAME_6',ORD_VENDOR_NAME);
define('ORD_HEADING_NAME_7',ORD_VENDOR_NAME);
define('ORD_HEADING_NAME_9',ORD_CUSTOMER_NAME);
define('ORD_HEADING_NAME_10',ORD_CUSTOMER_NAME);
define('ORD_HEADING_NAME_12',ORD_CUSTOMER_NAME);
define('ORD_HEADING_NAME_13',ORD_CUSTOMER_NAME);
define('ORD_HEADING_NAME_19',ORD_CUSTOMER_NAME);
define('ORD_HEADING_NAME_21',ORD_VENDOR_NAME);
?>