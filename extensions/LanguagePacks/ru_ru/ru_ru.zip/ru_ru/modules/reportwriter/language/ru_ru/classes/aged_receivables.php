<?php
// +-----------------------------------------------------------------+
// |                   PhreeBooks Open Source ERP                    |
// +-----------------------------------------------------------------+
// | Copyright (c) 2008, 2009, 2010 PhreeSoft, LLC                   |
// | http://www.PhreeSoft.com                                        |
// +-----------------------------------------------------------------+
// | This program is free software: you can redistribute it and/or   |
// | modify it under the terms of the GNU General Public License as  |
// | published by the Free Software Foundation, either version 3 of  |
// | the License, or any later version.                              |
// |                                                                 |
// | This program is distributed in the hope that it will be useful, |
// | but WITHOUT ANY WARRANTY; without even the implied warranty of  |
// | MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the   |
// | GNU General Public License for more details.                    |
// |                                                                 |
// | The license that is bundled with this package is located in the |
// | file: /doc/manual/ch01-Introduction/license.html.               |
// | If not, see http://www.gnu.org/licenses/                        |
// +-----------------------------------------------------------------+
//  Path: /modules/reportwriter/language/en_us/classes/aged_receivables.php
//

define('RW_AR_RECORD_ID','ID записи');
define('RW_AR_JOURNAL_ID','Journal ID');
define('RW_AR_STORE_ID','ID магазина');
define('RW_AR_JOURNAL_DESC','Описание журнала');
define('RW_AR_CLOSED','Закрыт');
define('RW_AR_FRT_TOTAL','Сума доставки');
define('RW_AR_FRT_CARRIER','Доставщик');
define('RW_AR_FRT_SERVICE','Способ доставки');
define('RW_AR_TERMS','Условия');
define('RW_AR_SALES_TAX','Sales Tax');
define('RW_AR_TAX_AUTH','Tax Authorities');
define('RW_AR_INV_TOTAL','Сума Счета');
define('RW_AR_BALANCE_DUE','Balance Due');
define('RW_AR_CUR_CODE','Код валюты');
define('RW_AR_CUR_EXC_RATE','Currency Exc. Rate');
define('RW_AR_SO_NUM','Номер Заказа');
define('RW_AR_INV_NUM','Номер счета');
define('RW_AR_PO_NUM','Номер Закупки');
define('RW_AR_SALES_REP','Sales Rep');
define('RW_AR_AR_ACCT','Дт счет');
define('RW_AR_BILL_ACCT_ID','Bill Acct ID');
define('RW_AR_BILL_ADD_ID','Bill Address ID');
define('RW_AR_BILL_PRIMARY_NAME','Имя плятельщика');
define('RW_AR_BILL_CONTACT','Контакты плательщика');
define('RW_AR_BILL_ADDRESS1','Адрес плательщика 1');
define('RW_AR_BILL_ADDRESS2','Адрес плательщика 2');
define('RW_AR_BILL_CITY','Город плательщика');
define('RW_AR_BILL_STATE','Регион плательщика');
define('RW_AR_BILL_ZIP','Индекс плательщика');
define('RW_AR_BILL_COUNTRY','Страна плательщика');
define('RW_AR_BILL_TELE1','Телефон 1');
define('RW_AR_BILL_TELE2','Телефон 2');
define('RW_AR_BILL_FAX','Факс');
define('RW_AR_BILL_EMAIL','E-mail');
define('RW_AR_BILL_WEBSITE','Сайт');
define('RW_AR_SHIP_ACCT_ID','Ship Acct ID');
define('RW_AR_SHIP_ADD_ID','Ship Address ID');
define('RW_AR_SHIP_PRIMARY_NAME','Ship Primary Name');
define('RW_AR_SHIP_CONTACT','Ship Contact');
define('RW_AR_SHIP_ADDRESS1','Адрес получателя 1');
define('RW_AR_SHIP_ADDRESS2','Адрес получателя 2');
define('RW_AR_SHIP_CITY','Город получателя');
define('RW_AR_SHIP_STATE','Регион получателя');
define('RW_AR_SHIP_ZIP','Индекс получателя');
define('RW_AR_SHIP_COUNTRY','Страна получателя');
define('RW_AR_SHIP_TELE1','Телефон 1');
define('RW_AR_SHIP_TELE2','Телефон 2');
define('RW_AR_SHIP_FAX','Факс');
define('RW_AR_SHIP_EMAIL','E-mail');
define('RW_AR_SHIP_WEBSITE','Сайт');
define('RW_AR_CUSTOMER_ID','ID покупателя');
define('RW_AR_ACCOUNT_NUMBER','Account Number');
define('RW_AR_SHIP_DATE','Дата отправки');
define('RW_AR_AGE1','Age ' . AR_AGING_HEADING_1);
define('RW_AR_AGE2','Age ' . AR_AGING_HEADING_2);
define('RW_AR_AGE3','Age ' . AR_AGING_HEADING_3);
define('RW_AR_AGE4','Age ' . AR_AGING_HEADING_4);

?>