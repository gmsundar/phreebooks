<?php
// +-----------------------------------------------------------------+
// |                   PhreeBooks Open Source ERP                    |
// +-----------------------------------------------------------------+
// | Copyright (c) 2008, 2009, 2010 PhreeSoft, LLC                   |
// | http://www.PhreeSoft.com                                        |
// +-----------------------------------------------------------------+
// | This program is free software: you can redistribute it and/or   |
// | modify it under the terms of the GNU General Public License as  |
// | published by the Free Software Foundation, either version 3 of  |
// | the License, or any later version.                              |
// |                                                                 |
// | This program is distributed in the hope that it will be useful, |
// | but WITHOUT ANY WARRANTY; without even the implied warranty of  |
// | MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the   |
// | GNU General Public License for more details.                    |
// |                                                                 |
// | The license that is bundled with this package is located in the |
// | file: /doc/manual/ch01-Introduction/license.html.               |
// | If not, see http://www.gnu.org/licenses/                        |
// +-----------------------------------------------------------------+
//  Path: /modules/general/language/en_us/boxes/mini_financial.php
//

define('CP_MINI_FINANCIAL_TITLE','Мои финансовые показатели');
define('CP_MINI_FINANCIAL_DESCRIPTION','Списки сокращенных версий вашего финансового положения.');
define('CP_MINI_FINANCIAL_NO_OPTIONS','Нет опций по этому пункту!');
define('RW_FIN_CURRENT_ASSETS','Оборотные активы');
define('RW_FIN_PROP_EQUIP','Недвижимость и оборудование');
define('RW_FIN_HEAD_0','Наличные');
define('RW_FIN_HEAD_2','Дебиторская задолженность');
define('RW_FIN_HEAD_4','Склад');
define('RW_FIN_HEAD_6','Прочие активы');
define('RW_FIN_HEAD_8','Не используется');
define('RW_FIN_HEAD_10','Не используется');
define('RW_FIN_HEAD_12','Не используется');
define('RW_FIN_HEAD_20','Не используется');
define('RW_FIN_HEAD_22','Не используется');
define('RW_FIN_HEAD_24','Не используется');
define('RW_FIN_HEAD_40','Не используется');
define('RW_FIN_HEAD_42','Не используется');
define('RW_FIN_HEAD_44','Не используется');
define('RW_FIN_ASSETS','Суммарные активы');
define('RW_FIN_INCOME','Итоговая прибыль');
define('RW_FIN_CUR_LIABILITIES','Текущие обязательства');
define('RW_FIN_LT_LIABILITIES','Долгосрочные обязательства');
define('RW_FIN_TOTAL_LIABILITIES','Обязательства Всего');
define('RW_FIN_TOTAL_INCOME','Итоговая прибыль');
define('RW_FIN_COST_OF_SALES','Себестоимость реализованной продукции');
define('RW_FIN_GROSS_PROFIT','Валовая прибыль');
define('RW_FIN_EXPENSES','Затраты');
define('RW_FIN_NET_INCOME','Чистый доход');
define('RW_FIN_CAPITAL','Капитал');
define('RW_FIN_TOTAL_LIABILITIES_CAPITAL','Итого обязательства и капитал');

?>