<?php
// +-----------------------------------------------------------------+
// |                   PhreeBooks Open Source ERP                    |
// +-----------------------------------------------------------------+
// | Copyright (c) 2009 PhreeSoft, LLC                               |
// | http://www.PhreeSoft.com                                        |
// +-----------------------------------------------------------------+
// | This program is free software: you can redistribute it and/or   |
// | modify it under the terms of the GNU General Public License as  |
// | published by the Free Software Foundation, either version 3 of  |
// | the License, or any later version.                              |
// |                                                                 |
// | This program is distributed in the hope that it will be useful, |
// | but WITHOUT ANY WARRANTY; without even the implied warranty of  |
// | MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the   |
// | GNU General Public License for more details.                    |
// |                                                                 |
// | The license that is bundled with this package is located in the |
// | file: /doc/manual/ch01-Introduction/license.html.               |
// | If not, see http://www.gnu.org/licenses/                        |
// +-----------------------------------------------------------------+
//  Path: /modules/translator/language/en_us/language.php
//

// Headings
define('BOX_TRANSLATOR_MAINTAIN','Переводчик');

// General Defines


define('TEXT_ACTION','Действие');
define('TEXT_ALL','Все');
define('TEXT_CHOOSE','Выберите');
define('TEXT_CONVERSION_STATISTICS','Conversion Statisics');
define('TEXT_CURRENT_INSTALLATION','Current Installation');
define('TEXT_DELETE','Удалить');
define('TEXT_DESCRIPTION','Описание');
define('TEXT_DESTINATION_LANGUAGE','Язык назначения');
define('TEXT_EDIT','Редактировать');
define('TEXT_EDIT_RELEASE','Edit release');
define('TEXT_EXPORT','Експорт');
define('TEXT_EXPORT_AS_LANGUAGE','Експортировать язык как');
define('TEXT_EXPORT_OPTIONS','Опции експорта');
define('TEXT_EXPORT_TO','Експортировать в');
define('TEXT_EXPORT_TRANSLATED_ONLY','Експортировать только переведенные');
define('TEXT_FILENAME','Файл');
define('TEXT_INSTALL','Установить');
define('TEXT_INSTALLABLE_RELEASES','Installable releases');
define('TEXT_INSTALLED_RELEASES','Installed releases');
define('TEXT_KEY','Ключ');
define('TEXT_LANGUAGE_TO_LOAD','Language to load');
define('TEXT_LINES_PER_TRANSLATED','Lines/Translated');
define('TEXT_LOAD_CURRENT_PHREEBOOKS_INSTALLATION_LANGUAGE_FILES','Load current Phreebooks installation language files');
define('TEXT_MODULE_NAME','Module name');
define('TEXT_MODULES','Модули');
define('TEXT_NEW_RELEASE','New release');
define('TEXT_NO','Нет');
define('TEXT_ORIGINAL','Оригинал');
define('TEXT_RELEASE','Release');
define('TEXT_RELEASE_FILES','Release files');
define('TEXT_RELEASE_INFO','Release info');
define('TEXT_RELEASE_NAME','Release name');
define('TEXT_RELEASES','Releases');
define('TEXT_SELECT_MODULE','Виберите модуль');
define('TEXT_TRANSLATE','Перевести');
define('TEXT_TRANSLATABLE_STRINGS','Translatable strings');
define('TEXT_TRANSLATED','Переведено');
define('TEXT_UPDATE_FROM_ALREADY_TRANSLATED','Update from already translated');
define('TEXT_VALUE','Значение');
define('TEXT_YES','Да');
define('TEXT_ZIP','Zip');

//************ Translator admin defines *************/
define('MODULE_TRANSLATOR_GEN_INFO','Translator Module Administration tools. Please select an action below.');
define('MODULE_TRANSLATOR_INSTALL_INFO','Установить модуль Переводчика');
define('MODULE_TRANSLATOR_REMOVE_INFO','Удалить модуль Переводчика');
define('MODULE_TRANSLATOR_REMOVE_CONFIRM','Точно хотите удалить модуль Переводчика?');
define('TRANSLATOR_ERROR_DELETE_MSG','The database files have been deleted. To completely remove the module, remove all files in the directory /my_files/custom/translator and the configuration file /my_files/custom/extra_menus/translator.php. The data files are located in /my_files/translator.');

// Error Messages
define('TRANSLATOR_ERROR_INSTALL_MSG','Какаято проблема при установке!');

// Javascrpt defines


?>
