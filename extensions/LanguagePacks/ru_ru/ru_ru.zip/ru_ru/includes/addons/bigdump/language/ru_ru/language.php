<?php
// +-----------------------------------------------------------------+
// |                   PhreeBooks Open Source ERP                    |
// +-----------------------------------------------------------------+
// | Copyright (c) 2008, 2009, 2010 PhreeSoft, LLC                   |
// | http://www.PhreeSoft.com                                        |
// +-----------------------------------------------------------------+
// | This program is free software: you can redistribute it and/or   |
// | modify it under the terms of the GNU General Public License as  |
// | published by the Free Software Foundation, either version 3 of  |
// | the License, or any later version.                              |
// |                                                                 |
// | This program is distributed in the hope that it will be useful, |
// | but WITHOUT ANY WARRANTY; without even the implied warranty of  |
// | MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the   |
// | GNU General Public License for more details.                    |
// |                                                                 |
// | The license that is bundled with this package is located in the |
// | file: /doc/manual/ch01-Introduction/license.html.               |
// | If not, see http://www.gnu.org/licenses/                        |
// +-----------------------------------------------------------------+
//  Path: /includes/addons/bigdump/language/en_us/language.php
//

define('TEXT_FILENAME','Название файла');
define('TEXT_MISC','Разное');
define('TEXT_QUERY','Query: ');
define('TEXT_MYSQL','MYSQL: ');
define('TEXT_PROCESSING_FILE','Processing file: ');
define('TEXT_STARTING_LINE','Starting from line: ');
define('TEXT_TO_GO','Для перехода');
define('TEXT_DONE','Готово');
define('TEXT_SESSION','Сессия');
define('TEXT_LINES','Линии');
define('TEXT_QUERIES','Запросы');
define('TEXT_BYTES','Байт');
define('TEXT_KB','KB');
define('TEXT_MB','MB');
define('TEXT_PERCENT','%');
define('TEXT_PERCENT_BAR','% bar');
define('TEXT_STOP','СТОП');
define('TEXT_PRESS','Press ');

define('BIGDUMP_INTRO','Это модифицированный скрипт BigDump разрабатываемый <a href="mailto:alexey@ozerov.de">Алексеем Озеровым</a> - <a href="http://www.ozerov.de/bigdump.php" target="_blank">BigDump Home</a>');
define('BIGDUMP_FILE_EXISTS','Файл %s уже существует! Удалите его и попробуйте заново!');
define('BIGDUMP_UPLOAD_TYPES','Разрешены только .sql .gz or .csv файлы.');
define('BIGDUMP_ERROR_MOVE','Ошибка перемещения загруженного файла %s в %s');
define('BIGDUMP_ERROR_PERM','Проверьте права на директорию %s (должно быть 777)!');
define('BIGDUMP_FILE_SAVED','Загруженый файл сохранен как %s');
define('BIGDUMP_ERROR_UPLOAD','Error uploading file ');
define('BIGDUMP_REMOVED',' was removed successfully');
define('BIGDUMP_FAIL_REMOVE','Can not remove ');
define('BIGDUMP_START_IMP','Начать импорт');
define('BIGDUMP_START_LOC',"into %s at %s");
define('BIGDUMP_DEL_FILE','Удалить файл');
define('BIGDUMP_NO_FILES','Не найден файл в рабочей директории');
define('BIGDUMP_ERROR_DIR','Ошибка листинга директории %s');
define('BIGDUMP_FROM_LOC','от %s до %s в %s');
define('BIGDUMP_UPLOAD_A','Upload form disabled. Permissions for the working directory <i>%s</i> <b>must be set to 777</b> in order ');
define('BIGDUMP_UPLOAD_B',"to upload files from here. Alternatively you can upload your dump files via FTP to directory: ");
define('BIGDUMP_UPLOAD_C','You can now upload your dump file up to %s bytes (%s Mbytes) ');
define('BIGDUMP_UPLOAD_D',"directly from your browser to the server. Alternatively you can upload your dump files of any size via FTP to directory: ");
define('BIGDUMP_OPEN_FAIL','Не могу открыть %s для импорта');
define('BIGDUMP_BAD_NAME','Please, check that your dump file name contains only alphanumerical characters, and rename it accordingly, for example: %s.<br />Or, specify \%s in bigdump.php with the full filename. <br />Or, you have to upload the %s to the server first.');
define('BIGDUMP_NO_SEEK','I can\'t seek into %s');
define('BIGDUMP_IMPORT_MSG_1','СЮРПРАЙЗ: Non-numeric values for start and foffset');
define('BIGDUMP_IMPORT_MSG_2','Ошибка удаления значений из %s.');
define('BIGDUMP_IMPORT_MSG_3','СЮРПРАЙЗ: Can\'t set file pointer behind the end of file');
define('BIGDUMP_IMPORT_MSG_4','UNEXPECTED: Can\'t set file pointer to offset: ');
define('BIGDUMP_IMPORT_MSG_5','Остановлено на строке %s.');
define('BIGDUMP_IMPORT_MSG_6','At this place the current query is from csv file, but %s was not set.');
define('BIGDUMP_IMPORT_MSG_7','You have to tell where you want to send your data.');
define('BIGDUMP_IMPORT_MSG_8','At this place the current query includes more than %s dump lines. That can happen if your dump file was created by some tool which doesn\'t place a semicolon followed by a linebreak at the end of each query, or if your dump contains extended inserts. Please read the BigDump FAQs for more infos.');
define('BIGDUMP_IMPORT_MSG_9','Error at the line %s: ');
define('BIGDUMP_IMPORT_MSG_10','UNEXPECTED: Can\'t read the file pointer offset');
define('BIGDUMP_IMPORT_MSG_11','Сейчас ожидаем %s милисикунд</b> перед стартом новой сессии...');
define('BIGDUMP_IMPORT_MSG_12','Continue from the line %s (Enable JavaScript to do it automatically)');
define('BIGDUMP_IMPORT_MSG_13'," to abort the import <b>OR WAIT!</b>");
define('BIGDUMP_IMPORT_MSG_14','Остановлено на ошибке');
define('BIGDUMP_IMPORT_MSG_15','Начать с начала');
define('BIGDUMP_IMPORT_MSG_16',' (DROP the old tables before restarting)');

define('BIGDUMP_READ_SUCCESS','Поздравляю: Достигнут конец файла, все OK');
?>