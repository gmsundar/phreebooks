<?php
// +-----------------------------------------------------------------+
// Phreedom Language Translation File
// Generated: 2011-11-27 05:02:30
// Module/Method: soap
// ISO Language: nl_nl
// Version: 0.1
// +-----------------------------------------------------------------+
// Path: /my_files/translator/upload/test/soap/language/nl_nl/language.php

define('SOAP_NO_USER_PW','De gebruikersnaam en wachtwoord zijn niet gevonden in de XML tekst.');
define('SOAP_USER_NOT_FOUND','De gebruikersnaam is niet gelding.');
define('SOAP_PASSWORD_NOT_FOUND','Het wachtwoord is niet gelding.');
define('SOAP_UNEXPECTED_ERROR','Een onverwachte error code is geretourneerd door de server.');
define('SOAP_XML_SUBMITTED_SO','XML ingediende Verkoop Order');
define('SOAP_ACCOUNT_PROBLEM','Kan het hoofd adres van een bestaande klant niet vinden. Groot probleem in de PhreeBooks adderessen database.');
define('SOAP_MISSING_FIELDS','Order # %s mist de volgende vereiste velden: %s');
define('AUDIT_LOG_SOAP_10_ADDED','SOAP Verkoop Orders - Toevoegen');
define('AUDIT_LOG_SOAP_12_ADDED','SOAP Verkoop/factuur - Toevoegen');
define('SOAP_10_SUCCESS','Verkoop order %s is succesvol gedownload.');
define('SOAP_12_SUCCESS','Verkoop Factuur %s is succesvol gedownload.');

?>
