<?php
// +-----------------------------------------------------------------+
// Phreedom Language Translation File
// Generated: 2011-11-27 05:02:39
// Module/Method: zencart
// ISO Language: nl_nl
// Version: 3.0
// +-----------------------------------------------------------------+
// Path: /modules/zencart/language/nl_nl/menu.php

define('MENU_HEADING_ZENCART','ZenCart');
define('BOX_ZENCART_MODULE','ZenCart Interface');

?>
