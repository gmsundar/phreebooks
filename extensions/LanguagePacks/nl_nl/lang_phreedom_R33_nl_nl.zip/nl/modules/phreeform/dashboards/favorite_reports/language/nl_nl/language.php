<?php
// +-----------------------------------------------------------------+
// Phreedom Language Translation File
// Generated: 2011-11-27 05:02:35
// Module/Method: phreeform-favorite_reports
// ISO Language: nl_nl
// Version: 3.2
// +-----------------------------------------------------------------+
// Path: /modules/phreeform/dashboards/favorite_reports/language/nl_nl/language.php

define('CP_FAVORITE_REPORTS_TITLE','Favoriete Rapporten');
define('CP_FAVORITE_REPORTS_DESCRIPTION','Lijst favoriete rapporten voor snelle display.');
define('CP_FAVORITE_REPORTS_NO_RESULTS','Geen resultaten gevonden!');

?>
