<?php
// +-----------------------------------------------------------------+
// Phreedom Language Translation File
// Generated: 2011-11-27 05:02:31
// Module/Method: inventory
// ISO Language: nl_nl
// Version: 3.3
// +-----------------------------------------------------------------+
// Path: /modules/inventory/language/nl_nl/menu.php

define('MENU_HEADING_INVENTORY','Voorraad');
define('BOX_INV_MAINTAIN','Voorraad Manager');
define('BOX_INV_NEW','Voorraad Toevoegen');
define('BOX_INV_TRANSFER','Transporteer Voorraad');
define('ORD_TEXT_14_WINDOW_TITLE','Assemblage');
define('ORD_TEXT_16_WINDOW_TITLE','Wijzigingen');
define('BOX_PRICE_SHEET_MANAGER','Prijslijst Manager');
define('BOX_SALES_PRICE_SHEETS','Klant Prijslijsten');
define('BOX_PURCHASE_PRICE_SHEETS','Leverancier Prijslijsten');

?>
