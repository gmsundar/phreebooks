<?php
// +-----------------------------------------------------------------+
// Phreedom Language Translation File
// Generated: 2011-11-27 05:02:31
// Module/Method: extra_import_export
// ISO Language: nl_nl
// Version: 0.3
// +-----------------------------------------------------------------+
// Path: /modules/extra_import_export/language/nl_nl/language.php

define('HEADING_MODULE_IMPORT_BANK','Importeer bankrekening overzicht');
define('GEN_IMPORT_MESSAGE','De lijst hieronder toont de tabellen beschikbaar voor import. Selecteer een formaat, upload het bestand en klik de import knop om door te gaan.');
define('TEXT_IMPORT','Importeer');
define('SAMPLE_CSV','Voorbeeld CSV');
define('TEXT_REQUIRED','VEREIST');

?>
