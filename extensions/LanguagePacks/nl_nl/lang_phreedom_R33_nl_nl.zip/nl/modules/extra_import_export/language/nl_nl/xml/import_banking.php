<?php
// +-----------------------------------------------------------------+
// Phreedom Language Translation File
// Generated: 2011-11-27 05:02:31
// Module/Method: extra_import_export
// ISO Language: nl_nl
// Version: 0.3
// +-----------------------------------------------------------------+
// Path: /modules/extra_import_export/language/nl_nl/xml/import_banking.php

define('TEXT_BIMP_ERMSG1','Uw eigen rekeningnummer is Leeg');
define('TEXT_BIMP_ERMSG2','Er zijn twee of meer grootboekrekeningen gevonden met de omschrijving : ');
define('TEXT_BIMP_ERMSG3','Het Bankrekeningnummer naar is leeg');
define('TEXT_BIMP_ERMSG4','Er zijn twee of meer contacten met hetzelfde bankrekeningnummer : ');
define('TEXT_BIMP_ERMSG5','Er zijn geen grootboekrekeningen met de omschrijving :  ');

?>
