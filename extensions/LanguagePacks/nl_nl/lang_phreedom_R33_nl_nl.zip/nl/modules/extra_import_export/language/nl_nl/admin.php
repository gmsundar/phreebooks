<?php
// +-----------------------------------------------------------------+
// Phreedom Language Translation File
// Generated: 2011-11-27 05:02:31
// Module/Method: extra_import_export
// ISO Language: nl_nl
// Version: 0.3
// +-----------------------------------------------------------------+
// Path: /modules/extra_import_export/language/nl_nl/admin.php

define('MODULE_EXTRA_IMPORT_EXPORT_TITLE','Import bank statement');
define('MODULE_EXTRA_IMPORT_EXPORT_DESCRIPTION','Met deze kunt u .csv bank overzichten importeren er wordt dan gecontroleerd op corresponderende contacten');
define('BOX_EXTRA_IMPORT_EXPORT_ADMIN','Bank Import Settings');
define('TEXT_EXTRA_IMPORT_EXPORT_SETTINGS','Bank Import Settings');
define('MODULE_EXTRA_IMPORT_EXPORT_CONFIG_INFO','Stel uw configuratie in');
define('BANK_IMPORT_QUESTION_POSTS','Om te voorkomen dat boekingen niet geboekt worden wordt door het script wordt als laatste optie de boekingen opgeslagen op de grootboek vraag posten. <B>Dit moet ingevuld worden anders werkt het script niet</B>');
define('BANK_IMPORT_DEBIT_CREDIT','De omschrijving als er bedragen op uw rekening bijgeschreven zijn. <br><B>dit is voor het xml veld debit_credit</B>');

?>
