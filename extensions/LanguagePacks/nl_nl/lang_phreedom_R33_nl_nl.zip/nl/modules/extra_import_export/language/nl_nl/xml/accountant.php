<?php
// +-----------------------------------------------------------------+
// Phreedom Language Translation File
// Generated: 2011-11-27 05:02:31
// Module/Method: extra_import_export
// ISO Language: nl_nl
// Version: 0.3
// +-----------------------------------------------------------------+
// Path: /modules/extra_import_export/language/nl_nl/xml/accountant.php

define('MODULE_ACCOUNTANT_TITLE','Exporting for accountent');

?>
