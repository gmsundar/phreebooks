<?php
// +-----------------------------------------------------------------+
// Phreedom Language Translation File
// Generated: 2011-11-27 05:02:36
// Module/Method: phreewiki
// ISO Language: nl_nl
// Version: 1.2
// +-----------------------------------------------------------------+
// Path: /modules/phreewiki/language/nl_nl/admin.php

define('MODULE_PHREEWIKI_TITLE','Phreewiki');
define('MODULE_PHREEWIKI_DESCRIPTION','This is a wiki that your company can use');
define('TEXT_PHREEWIKI_SETTINGS','Phreewiki settings');

?>
