<?php
// +-----------------------------------------------------------------+
// Phreedom Language Translation File
// Generated: 2011-11-27 05:02:35
// Module/Method: phreedom-todays_s_quotes
// ISO Language: nl_nl
// Version: 0.1
// +-----------------------------------------------------------------+
// Path: /modules/phreedom/dashboards/todays_s_quotes/language/nl_nl/language.php

define('CP_TODAYS_S_QUOTES_NO_RESULTS','Geen resultaten!');
define('CP_TODAYS_S_QUOTES_DESCRIPTION','Lijst met verkoop offertes van vandaag. Links Om de offertes te bekijken zijn beschikbaar.');
define('CP_TODAYS_S_QUOTES_TITLE','Verkoop Offertes van Vandaag');

?>
