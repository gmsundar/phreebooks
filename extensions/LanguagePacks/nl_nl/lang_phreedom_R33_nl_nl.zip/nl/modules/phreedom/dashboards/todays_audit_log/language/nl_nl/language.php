<?php
// +-----------------------------------------------------------------+
// Phreedom Language Translation File
// Generated: 2011-11-27 05:02:35
// Module/Method: phreedom-todays_audit_log
// ISO Language: nl_nl
// Version: 0.1
// +-----------------------------------------------------------------+
// Path: /modules/phreedom/dashboards/todays_audit_log/language/nl_nl/language.php

define('CP_TODAYS_AUDIT_LOG_NO_RESULTS','Geen resultaten!');
define('CP_TODAYS_AUDIT_LOG_DESCRIPTION','Auditlog van Vandaag ');
define('CP_TODAYS_AUDIT_LOG_TITLE','Auditlog Vandaag ');

?>
