<?php
// +-----------------------------------------------------------------+
// Phreedom Language Translation File
// Generated: 2011-11-27 05:02:35
// Module/Method: phreedom-personal_links
// ISO Language: nl_nl
// Version: 3.2
// +-----------------------------------------------------------------+
// Path: /modules/phreedom/dashboards/personal_links/language/nl_nl/language.php

define('CP_PERSONAL_LINKS_TITLE','Mijn Links');
define('CP_PERSONAL_LINKS_DESCRIPTION','lijst URLs voor persoonlijk gebruik als quicklinks.');
define('CP_PERSONAL_LINKS_NO_RESULTS','Geen resultaten gevonden!');

?>
