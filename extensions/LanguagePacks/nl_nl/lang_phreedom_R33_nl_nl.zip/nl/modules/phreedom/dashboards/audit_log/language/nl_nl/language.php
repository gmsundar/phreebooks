<?php
// +-----------------------------------------------------------------+
// Phreedom Language Translation File
// Generated: 2011-11-27 05:02:34
// Module/Method: phreedom-audit_log
// ISO Language: nl_nl
// Version: 0.1
// +-----------------------------------------------------------------+
// Path: /modules/phreedom/dashboards/audit_log/language/nl_nl/language.php

define('CP_AUDIT_LOG_DISPLAY2',' dag(en) terug (Vandaag=0)');
define('CP_AUDIT_LOG_DISPLAY','Toon vermeldingen');
define('CP_AUDIT_LOG_NO_RESULTS','Geen Resultaten voor deze dag!');
define('CP_AUDIT_LOG_DESCRIPTION','Lijsten waarop de audit log voor een bepaalde dag. De module heeft de controle om een dag in te stellen om het logboek items weer te geven.');
define('CP_AUDIT_LOG_TITLE','Logboek');

?>
