<?php
// +-----------------------------------------------------------------+
// Phreedom Language Translation File
// Generated: 2011-11-27 05:02:35
// Module/Method: phreedom-company_links
// ISO Language: nl_nl
// Version: 3.2
// +-----------------------------------------------------------------+
// Path: /modules/phreedom/dashboards/company_links/language/nl_nl/language.php

define('CP_COMPANY_LINKS_TITLE','Bedrijfs Links');
define('CP_COMPANY_LINKS_DESCRIPTION','Lijst met URLs voor alle gebruikers binnen het bedrijf. ');
define('CP_COMPANY_LINKS_NO_RESULTS','Geen resultaten!');

?>
