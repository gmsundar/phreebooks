<?php
// +-----------------------------------------------------------------+
// Phreedom Language Translation File
// Generated: 2011-11-27 05:02:35
// Module/Method: phreedom-my_notes
// ISO Language: nl_nl
// Version: 3.2
// +-----------------------------------------------------------------+
// Path: /modules/phreedom/dashboards/my_notes/language/nl_nl/language.php

define('CP_MY_NOTES_TITLE','Mijn Notes');
define('CP_MY_NOTES_DESCRIPTION','Maak Notities en herinneringen.');
define('CP_MY_NOTES_NO_RESULTS','Geen resultaten!');

?>
