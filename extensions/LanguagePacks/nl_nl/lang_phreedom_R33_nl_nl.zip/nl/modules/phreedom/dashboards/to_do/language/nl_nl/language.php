<?php
// +-----------------------------------------------------------------+
// Phreedom Language Translation File
// Generated: 2011-11-27 05:02:35
// Module/Method: phreedom-to_do
// ISO Language: nl_nl
// Version: 3.2
// +-----------------------------------------------------------------+
// Path: /modules/phreedom/dashboards/to_do/language/nl_nl/language.php

define('CP_TO_DO_TITLE','Mijn Te Doen Lijst');
define('CP_TO_DO_DESCRIPTION','Maakt een lijst met uit te voeren activiteiten en taken.');
define('CP_TO_DO_NO_RESULTS','Geen restultaten gevonden');

?>
