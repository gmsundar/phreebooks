<?php
// +-----------------------------------------------------------------+
// Phreedom Language Translation File
// Generated: 2011-11-27 05:02:35
// Module/Method: phreedom
// ISO Language: nl_nl
// Version: 3.3
// +-----------------------------------------------------------------+
// Path: /modules/phreedom/language/nl_nl/menu.php

define('TEXT_HOME','Home');
define('TEXT_LOGOUT','Log Uit');
define('MENU_HEADING_COMPANY','Bedrijf');
define('MENU_HEADING_TOOLS','Tools');
define('BOX_HEADING_PROFILE','Mijn Profiel');
define('HEADING_TITLE_USERS','Gebruikers');
define('BOX_HEADING_ROLES','Rollen');
define('MENU_HEADING_MODULES','Modules');
define('BOX_HEADING_USERS','Gebruikers');
define('BOX_HEADING_BACKUP','Bedrijfs Backup');
define('BOX_HEADING_ENCRYPTION','Data Versleuteling');
define('BOX_IMPORT_EXPORT','Import/Export');
define('BOX_COMPANY_MANAGER','Bedrijfs Manager');
define('BOX_HEADING_ADMIN_TOOLS','Administratieve Tools');
define('BOX_HEADING_CONFIGURATION','Module Administratie');
define('BOX_GENERAL_ADMIN','Algemene Instellingen');
define('BOX_HEADING_DEBUG_DL','Download Debug Bestand');

?>
