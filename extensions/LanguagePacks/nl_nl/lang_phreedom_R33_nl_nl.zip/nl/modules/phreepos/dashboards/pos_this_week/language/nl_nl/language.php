<?php
// +-----------------------------------------------------------------+
// Phreedom Language Translation File
// Generated: 2011-11-27 05:02:36
// Module/Method: phreepos-pos_this_week
// ISO Language: nl_nl
// Version: 0.1
// +-----------------------------------------------------------------+
// Path: /modules/phreepos/dashboards/pos_this_week/language/nl_nl/language.php

define('CP_POS_THIS_WEEK_NO_RESULTS','Geen resultaten!');
define('CP_POS_THIS_WEEK_DESCRIPTION','Lijst met totale kassa verkopen per dag van deze week.');
define('CP_POS_THIS_WEEK_TITLE','Kassa verkopen deze week');

?>
