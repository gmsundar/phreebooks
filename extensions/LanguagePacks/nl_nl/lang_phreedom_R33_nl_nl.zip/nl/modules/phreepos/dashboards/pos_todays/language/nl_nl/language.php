<?php
// +-----------------------------------------------------------------+
// Phreedom Language Translation File
// Generated: 2011-11-27 05:02:36
// Module/Method: phreepos-pos_todays
// ISO Language: nl_nl
// Version: 0.1
// +-----------------------------------------------------------------+
// Path: /modules/phreepos/dashboards/pos_todays/language/nl_nl/language.php

define('CP_POS_TODAYS_NO_RESULTS','Geen resultaten!');
define('CP_POS_TODAYS_DESCRIPTION','Lijst met verkopen van vandaag.');
define('CP_POS_TODAYS_TITLE','Kassa verkopen vandaag');

?>
