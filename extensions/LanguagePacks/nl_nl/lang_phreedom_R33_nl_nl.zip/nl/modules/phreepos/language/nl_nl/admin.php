<?php
// +-----------------------------------------------------------------+
// Phreedom Language Translation File
// Generated: 2011-11-27 05:02:36
// Module/Method: phreepos
// ISO Language: nl_nl
// Version: 1.2
// +-----------------------------------------------------------------+
// Path: /modules/phreepos/language/nl_nl/admin.php

define('MODULE_PHREEPOS_TITLE','PhreePOS Module');
define('MODULE_PHREEPOS_DESCRIPTION','De PhreePOS module biedt een kassa / Point of Sale-interface Deze module is een aanvulling op de phreebooks module en is geen vervanging voor.');
define('BOX_PHREEPOS_ADMIN','Kassa / Point of Sale Administration');
define('PHREEPOS_REQUIRE_ADDRESS_DESC','Is adres informatie bij iedere handeling vereist');
define('PHREEPOS_RECEIPT_PRINTER_NAME_DESC','Stelt de naam van de printer in te gebruiken voor het afdrukken van kassa bonnen, zoals gedefinieerd in de printer voorkeuren voor het lokale werkstation');
define('PHREEPOS_RECEIPT_PRINTER_STARTING_LINE_DESC','Hier kunt u code invoeren om die aan het begin van de pagina hoort <br> Scheid de codes door een: en regels en door een , zoals: <i> 27:112:48:55:121,27:109 </ i> <br> De codes zijn een nummers van de chr dwz chr (13) is 13 <b> Plaats hier alleen de code geen tekst dit kan leiden tot fouten. </ b> Bekijk de printer documentatie voor de codes.');
define('PHREEPOS_RECEIPT_PRINTER_CLOSING_LINE_DESC','Hier kunt u code invoeren om lade te openen en / of bon af te snijden <br> Scheid de codes door een: en regels en door een , zoals: <i> 27:112:48:55:121,27:109 </ i> <br> De codes zijn een nummers van de chr dwz chr (13) is 13 <b> Plaats hier alleen de code geen tekst dit kan leiden tot fouten. </ b>');

?>
