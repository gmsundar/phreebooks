<?php
// +-----------------------------------------------------------------+
// Phreedom Language Translation File
// Generated: 2011-11-27 05:02:36
// Module/Method: phreepos
// ISO Language: nl_nl
// Version: 1.2
// +-----------------------------------------------------------------+
// Path: /modules/phreepos/language/nl_nl/menu.php

define('MENU_HEADING_PHREEPOS','Kassa / Point of Sale');
define('BOX_PHREEPOS','Kassa / Point of Sale');
define('BOX_POS_MGR','POS/POP Manager');
define('BOX_CUSTOMER_DEPOSITS','Klant Stortingen');
define('BOX_VENDOR_DEPOSITS','Leverancier Stortingen');

?>
