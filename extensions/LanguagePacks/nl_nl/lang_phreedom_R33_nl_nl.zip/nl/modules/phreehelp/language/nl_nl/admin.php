<?php
// +-----------------------------------------------------------------+
// Phreedom Language Translation File
// Generated: 2011-11-27 05:02:36
// Module/Method: phreehelp
// ISO Language: nl_nl
// Version: 3.3
// +-----------------------------------------------------------------+
// Path: /modules/phreehelp/language/nl_nl/admin.php

define('MODULE_PHREEHELP_TITLE','PhreeHelp Module');
define('MODULE_PHREEHELP_DESCRIPTION','De PhreeHelp module voorziet in een popup context help scherm om handleidingen te tonen die geleverd worden bij de modules. <b>Aantekening: Dit is een kern module en moet niet verwijderd worden!</b>');

?>
