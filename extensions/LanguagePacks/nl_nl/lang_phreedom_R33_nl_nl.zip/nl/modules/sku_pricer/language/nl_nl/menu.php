<?php
// +-----------------------------------------------------------------+
// Phreedom Language Translation File
// Generated: 2011-11-27 05:02:38
// Module/Method: sku_pricer
// ISO Language: nl_nl
// Version: 1.0
// +-----------------------------------------------------------------+
// Path: /modules/sku_pricer/language/nl_nl/menu.php

define('BOX_SKU_PRICER_TITLE','Artikel Prijzer');

?>
