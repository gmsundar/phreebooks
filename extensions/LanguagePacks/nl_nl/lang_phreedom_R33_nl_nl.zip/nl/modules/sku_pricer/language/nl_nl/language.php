<?php
// +-----------------------------------------------------------------+
// Phreedom Language Translation File
// Generated: 2011-11-27 05:02:38
// Module/Method: sku_pricer
// ISO Language: nl_nl
// Version: 1.0
// +-----------------------------------------------------------------+
// Path: /modules/sku_pricer/language/nl_nl/language.php

define('SKU_PRICER_PAGE_TITLE','Artikel Prijs Importeur');
define('SKU_PRICER_SELECT','Seleteer het csv bestand om te importeren');
define('SKU_PRICER_DIRECTIONS','Nadat het bestand geselecteerd is en op bewaren geklikt wordt het script uitgevoerd.<br />Het bestand formaat (Met koptekst):<br />sku,cost,full,upc_code<br>SKU_NUM,2.00, 4.00, upc<br />Waar nummers werkelijke waardes zijn met een punt als decimale splitser, en geen andere symbolen of karakters.');

?>
