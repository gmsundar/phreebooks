<?php
// +-----------------------------------------------------------------+
// Phreedom Language Translation File
// Generated: 2011-11-27 05:02:38
// Module/Method: shipping
// ISO Language: nl_nl
// Version: 3.3
// +-----------------------------------------------------------------+
// Path: /modules/shipping/language/nl_nl/menu.php

define('BOX_SHIPPING_MANAGER','Verzendings Manager');

?>
