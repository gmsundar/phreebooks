<?php
// +-----------------------------------------------------------------+
// Phreedom Language Translation File
// Generated: 2011-11-27 05:02:38
// Module/Method: shipping-ups
// ISO Language: nl_nl
// Version: 0.1
// +-----------------------------------------------------------------+
// Path: /modules/shipping/methods/ups/language/nl_nl/language.php

define('SHIPPING_UPS_ERROR_POSTAL_CODE','Postcode is vereist om de UPS module te gebruiken');
define('SHIPPING_UPS_ERROR_WEIGHT_150','Het gewicht van de zending mag niet groter zijn dan 150 lbs om de UPS module te gebruiken.');
define('SHIPPING_UPS_PACKAGE_ERROR','Gestorven moeite de splitsing van de zending in stukjes. Het gewicht van de zending was: ');
define('SRV_SHIP_UPS_BILL_DETAIL','Factuur Details');
define('SHIPPING_UPS_CURL_ERROR','cURL Error: ');
define('SRV_SHIP_UPS_EMAIL_NOTIFY','Email bevestigingen');
define('SRV_SHIP_UPS_RECP_INFO','ontvanger Informatie');
define('SRV_SHIP_UPS','Verzend een pakketje');
define('SHIPPING_UPS_TNT_ERROR',' UPS Tijd onder weg Error # ');
define('SHIPPING_UPS_RATE_TRANSIT',' Dag(en) Onderweg, arriveert');
define('SHIPPING_UPS_RATE_ERROR','UPS-tarief reactie fout:');
define('SHIPPING_UPS_RATE_CITY_MATCH','plaats komt niet overeen met de postcode.');
define('SHIPPING_UPS_SHIPMENTS_ON','UPS-zendingen op');
define('SHIPPING_UPS_HAZMAT_REPORTS','Hazmat Rapport');
define('SHIPPING_UPS_MULTIWGHT_REPORTS','Multigewicht Rapport');
define('SHIPPING_UPS_VIEW_REPORTS','Bekijk Rapporten voor');
define('SHIPPING_UPS_CLOSE_REPORTS','Sluit Rapport');
define('ups_IGND','Standard (Canada)');
define('ups_I2Dam','Wereldwijd Express');
define('ups_I3D','Wereldwijd Expedited');
define('ups_I2DEam','Wereldwijd Express Plus');
define('ups_2Dpm','2 dagen lucht');
define('ups_3Dpm','3 dagen Select');
define('ups_2Dam','2 dagen lucht vroeg AM');
define('ups_1Dpm','Volgende dag lucht voordeel');
define('ups_1DEam','Volgende dag lucht vroeg AM');
define('ups_1Dam','Volgende dag lucht');
define('ups_GND','Grond');
define('MODULE_SHIPPING_UPS_SORT_ORDER_DESC','Volgorde van tonen. Laagste wordt als eerste getoond');
define('MODULE_SHIPPING_UPS_TYPES_DESC','Selecteer de UPS service om standaard aangeboden te worden.');
define('MODULE_SHIPPING_UPS_LABEL_SIZE_DESC','Formaat van het label te gebruiken voor het printen van thermische etiketten, geldige waarden zijn 6 of 8 inches');
define('MODULE_SHIPPING_UPS_PRINTER_TYPE_DESC','Type printer te gebruiken voor het afdrukken van etiketten. GIF voor gewoon papier, Thermal voor UPS 2442 Thermal Label Printer (Zie Help-bestand voor het selecteren van thermische printer)');
define('MODULE_SHIPPING_UPS_ACCESS_KEY_DESC','Voer de XML Access Key in welke u heeft onvangen van UPS.');
define('MODULE_SHIPPING_UPS_PASSWORD_DESC','Voer het Wachtwoord in voor uw UPS account');
define('MODULE_SHIPPING_UPS_USER_ID_DESC','Voer de UPS account-id in voor toegang tot de verzendkosten schatter.');
define('MODULE_SHIPPING_UPS_TEST_MODE_DESC','Test mode te gebruiken voor het testen van verzendlabels');
define('MODULE_SHIPPING_UPS_SHIPPER_NUMBER_DESC','Voer het UPS verzend nummer in voor de verzendkosten schatter');
define('MODULE_SHIPPING_UPS_TITLE_DESC','Titel welke gebruikt word in de verzendkosten schatter');
define('MODULE_SHIPPING_UPS_QUANTUM_VIEW_TEST','https://wwwcie.ups.com/ups.app/xml/QVEvents');
define('MODULE_SHIPPING_UPS_QUANTUM_VIEW','https://www.ups.com/ups.app/xml/QVEvents');
define('MODULE_SHIPPING_UPS_VOID_SHIPMENT_TEST','https://wwwcie.ups.com/ups.app/xml/Void');
define('MODULE_SHIPPING_UPS_VOID_SHIPMENT','https://www.ups.com/ups.app/xml/Void');
define('MODULE_SHIPPING_UPS_LABEL_URL_TEST','https://wwwcie.ups.com/ups.app/xml/ShipAccept');
define('MODULE_SHIPPING_UPS_LABEL_URL','https://www.ups.com/ups.app/xml/ShipAccept');
define('MODULE_SHIPPING_UPS_SHIP_URL_TEST','https://wwwcie.ups.com/ups.app/xml/ShipConfirm');
define('MODULE_SHIPPING_UPS_SHIP_URL','https://www.ups.com/ups.app/xml/ShipConfirm');
define('MODULE_SHIPPING_UPS_TNT_URL_TEST','https://wwwcie.ups.com/ups.app/xml/TimeInTransit');
define('MODULE_SHIPPING_UPS_TNT_URL','https://www.ups.com/ups.app/xml/TimeInTransit');
define('MODULE_SHIPPING_UPS_RATE_URL_TEST','https://wwwcie.ups.com/ups.app/xml/Rate');
define('MODULE_SHIPPING_UPS_RATE_URL','https://www.ups.com/ups.app/xml/Rate');
define('MODULE_SHIPPING_UPS_TITLE_SHORT','UPS');
define('MODULE_SHIPPING_UPS_TEXT_DESCRIPTION','United Parcel Service');
define('MODULE_SHIPPING_UPS_TEXT_TITLE','United Parcel Service');
define('UPS_TRACKING_URL','http://wwwapps.ups.com/etracking/tracking.cgi?tracknums_displayed=5&TypeOfInquiryNumber=T&HTMLVersion=4.0&sort_by=status&InquiryNumber1=');

?>
