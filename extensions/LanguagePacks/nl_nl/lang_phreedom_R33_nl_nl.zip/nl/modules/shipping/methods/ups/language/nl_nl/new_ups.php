<?php
// +-----------------------------------------------------------------+
// Phreedom Language Translation File
// Generated: 2011-11-27 05:02:38
// Module/Method: shipping-ups
// ISO Language: nl_nl
// Version: 0.1
// +-----------------------------------------------------------------+
// Path: /modules/shipping/methods/ups/language/nl_nl/new_ups.php

define('SHIPPING_UPS_ERROR_POSTAL_CODE','Postcode is vereist om de UPS module te gebruiken');
define('SHIPPING_UPS_ERROR_WEIGHT_150','Het gewicht van de zending mag niet groter zijn dan 150 lbs om de UPS module te gebruiken.');
define('SHIPPING_UPS_CURL_ERROR','cURL Error: ');
define('SHIPPING_UPS_PACKAGE_ERROR','Gestorven moeite de splitsing van de zending in stukjes. Het gewicht van de zending was: ');
define('SRV_SHIP_UPS_BILL_DETAIL','Factuur Details');
define('SRV_SHIP_UPS_EMAIL_NOTIFY','Email bevestigingen');
define('SRV_SHIP_UPS','Verzend een pakketje');
define('SRV_SHIP_UPS_RECP_INFO','ontvanger Informatie');
define('SHIPPING_UPS_TNT_ERROR',' UPS Tijd onder weg Error # ');
define('SHIPPING_UPS_RATE_TRANSIT',' Dag(en) Onderweg, arriveert');
define('SHIPPING_UPS_RATE_CITY_MATCH','plaats komt niet overeen met de postcode.');
define('SHIPPING_UPS_RATE_ERROR','UPS-tarief reactie fout:');
define('SHIPPING_UPS_HAZMAT_REPORTS','Hazmat Rapport');
define('SHIPPING_UPS_SHIPMENTS_ON','UPS-zendingen op');
define('SHIPPING_UPS_MULTIWGHT_REPORTS','Multigewicht Rapport');
define('SHIPPING_UPS_CLOSE_REPORTS','Sluit Rapport');
define('MODULE_SHIPPING_UPS_STD','Standaard (Canada)');
define('SHIPPING_UPS_VIEW_REPORTS','Bekijk Rapporten voor');
define('MODULE_SHIPPING_UPS_XPD','Wereldwijd Expeditie');
define('MODULE_SHIPPING_UPS_XDM','Wereldwijd Expres Plus');
define('MODULE_SHIPPING_UPS_XPR','Wereldwijd Expres');
define('MODULE_SHIPPING_UPS_3DS','3 dagen Select');
define('MODULE_SHIPPING_UPS_2DP','2 dagen lucht');
define('MODULE_SHIPPING_UPS_1DA','Volgende dag lucht');
define('MODULE_SHIPPING_UPS_1DP','Volgende dag voordeel');
define('MODULE_SHIPPING_UPS_2DM','2 dagen lucht vroeg AM');
define('MODULE_SHIPPING_UPS_1DM','Volgende dag lucht vroeg AM');
define('MODULE_SHIPPING_UPS_GND','Grond');
define('UPS_TRACKING_URL','http://wwwapps.ups.com/etracking/tracking.cgi?tracknums_displayed=5&TypeOfInquiryNumber=T&HTMLVersion=4.0&sort_by=status&InquiryNumber1=');
define('MODULE_SHIPPING_UPS_LTL_RATE_TEST_URL','https://onlinetools.ups.com/webservices/FreightRate');
define('','http://wwwcie.ups.com/webservices/ShipBinding');
define('MODULE_SHIPPING_UPS_QUANTUM_VIEW_TEST','https://wwwcie.ups.com/ups.app/xml/QVEvents');
define('MODULE_SHIPPING_UPS_QUANTUM_VIEW','https://www.ups.com/ups.app/xml/QVEvents');
define('MODULE_SHIPPING_UPS_VOID_SHIPMENT_TEST','https://wwwcie.ups.com/ups.app/xml/Void');
define('MODULE_SHIPPING_UPS_VOID_SHIPMENT','https://www.ups.com/ups.app/xml/Void');
define('MODULE_SHIPPING_UPS_LABEL_URL_TEST','https://wwwcie.ups.com/ups.app/xml/ShipAccept');
define('MODULE_SHIPPING_UPS_LABEL_URL','https://www.ups.com/ups.app/xml/ShipAccept');
define('MODULE_SHIPPING_UPS_SHIP_URL_TEST','https://wwwcie.ups.com/ups.app/xml/ShipConfirm');
define('MODULE_SHIPPING_UPS_SHIP_URL','https://www.ups.com/ups.app/xml/ShipConfirm');
define('MODULE_SHIPPING_UPS_SHIP_URL_TEST','https://wwwcie.ups.com/ups.app/xml/ShipConfirm');
define('MODULE_SHIPPING_UPS_SHIP_URL','https://www.ups.com/ups.app/xml/ShipConfirm');
define('MODULE_SHIPPING_UPS_TNT_URL_TEST','https://wwwcie.ups.com/ups.app/xml/TimeInTransit');
define('MODULE_SHIPPING_UPS_TNT_URL','https://www.ups.com/ups.app/xml/TimeInTransit');
define('MODULE_SHIPPING_UPS_RATE_URL_TEST','https://wwwcie.ups.com/ups.app/xml/Rate');
define('MODULE_SHIPPING_UPS_RATE_URL','https://www.ups.com/ups.app/xml/Rate');
define('MODULE_SHIPPING_UPS_TEXT_DESCRIPTION','United Parcel Service');
define('MODULE_SHIPPING_UPS_TITLE_SHORT','UPS');
define('MODULE_SHIPPING_UPS_TEXT_TITLE','United Parcel Service');

?>
