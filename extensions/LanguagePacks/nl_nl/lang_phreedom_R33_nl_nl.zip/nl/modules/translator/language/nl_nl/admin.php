<?php
// +-----------------------------------------------------------------+
// Phreedom Language Translation File
// Generated: 2011-11-27 05:02:39
// Module/Method: translator
// ISO Language: nl_nl
// Version: 3.3
// +-----------------------------------------------------------------+
// Path: /modules/translator/language/nl_nl/admin.php

define('MODULE_TRANSLATOR_TITLE','Vertaal Module');
define('MODULE_TRANSLATOR_DESCRIPTION','De vertaal-module biedt een handige interface om taalbestanden vertalen van de ene taal naar de andere. Deze module behandelt versie updates en installatie ondersteuning.');

?>
