<?php
// +-----------------------------------------------------------------+
// Phreedom Language Translation File
// Generated: 2011-11-27 05:02:39
// Module/Method: translator
// ISO Language: nl_nl
// Version: 3.3
// +-----------------------------------------------------------------+
// Path: /modules/translator/language/nl_nl/menu.php

define('MENU_HEADING_TRANSLATOR','Vertaal Tool');
define('BOX_TRANSLATOR_MODULE','Vertaal Assistant');

?>
