<?php
// +-----------------------------------------------------------------+
// Phreedom Language Translation File
// Generated: 2011-11-27 05:02:34
// Module/Method: phreebooks
// ISO Language: nl_nl
// Version: 3.3
// +-----------------------------------------------------------------+
// Path: /modules/phreebooks/language/nl_nl/classes/is_budget.php

define('RW_FIN_REVENUES','Opbrengsten');
define('RW_FIN_COST_OF_SALES','Verkoop kosten');
define('RW_FIN_GROSS_PROFIT','Brutto Winst');
define('RW_FIN_EXPENSES','Uitgaven');
define('RW_FIN_NET_INCOME','Netto Winst');
define('IS_BUDGET_ACCOUNT','Rekeningnummer');
define('IS_BUDGET_CUR_MONTH','Huidige Maand');
define('IS_BUDGET_YTD','Jaar tot vandaag');
define('IS_BUDGET_LY_CUR','Vorig Jaar Huidig');
define('IS_BUDGET_LAST_YTD','Vorig Jaar tot vandaag');
define('IS_BUDGET_CUR_BUDGET','Huidig Budget');
define('IS_BUDGET_YTD_BUDGET','Budget Jaar tot Vandaag');

?>
