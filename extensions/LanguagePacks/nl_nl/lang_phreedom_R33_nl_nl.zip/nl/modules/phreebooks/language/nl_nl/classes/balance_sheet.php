<?php
// +-----------------------------------------------------------------+
// Phreedom Language Translation File
// Generated: 2011-11-27 05:02:34
// Module/Method: phreebooks
// ISO Language: nl_nl
// Version: 3.3
// +-----------------------------------------------------------------+
// Path: /modules/phreebooks/language/nl_nl/classes/balance_sheet.php

define('RW_FIN_CURRENT_ASSETS','Huidige Bezittingen');
define('RW_FIN_TOTAL_CURRENT_ASSETS','Totaal Huidige Bezittingen');
define('RW_FIN_PROP_EQUIP','Goederen en Materieel');
define('RW_FIN_TOTAL_PROP_EQUIP','Totaal Gebouwen en apparatuur');
define('RW_FIN_TOTAL_ASSETS','Totaal bezittingen');
define('RW_FIN_CUR_LIABILITIES','Schulden');
define('RW_FIN_TOTAL_CUR_LIABILITIES','Totaal huidige Verplichtingen');
define('RW_FIN_LONG_TERM_LIABILITIES','Lange Termijn Verplichtingen');
define('RW_FIN_TOTAL_LT_LIABILITIES','Totaal Lange Termijn Verplichtingen');
define('RW_FIN_TOTAL_LIABILITIES','Totaal Verplichtingen');
define('RW_FIN_CAPITAL','Kapitaal');
define('RW_FIN_NET_INCOME','Netto Winst');
define('RW_FIN_TOTAL_CAPITAL','Totaal Kapitaal');
define('RW_FIN_TOTAL_LIABILITIES_CAPITAL','Total Schulden & Kapital');

?>
