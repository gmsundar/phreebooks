<?php
// +-----------------------------------------------------------------+
// Phreedom Language Translation File
// Generated: 2011-11-27 05:02:34
// Module/Method: phreebooks
// ISO Language: nl_nl
// Version: 3.3
// +-----------------------------------------------------------------+
// Path: /modules/phreebooks/language/nl_nl/menu.php

define('MENU_HEADING_GL','Boekhouden');
define('MENU_HEADING_BANKING','Bankieren');
define('ORD_TEXT_0_WINDOW_TITLE','Begin Balans');
define('ORD_TEXT_2_WINDOW_TITLE','Algemeen Journaal');
define('ORD_TEXT_3_WINDOW_TITLE','Verzoek om Offerte');
define('ORD_TEXT_4_WINDOW_TITLE','Inkoop Order');
define('ORD_TEXT_6_WINDOW_TITLE','Inkoop / Ontvang Voorraad');
define('ORD_TEXT_7_WINDOW_TITLE','Leverancier Credit Nota');
define('ORD_TEXT_9_WINDOW_TITLE','Klant Offerte');
define('ORD_TEXT_10_WINDOW_TITLE','Verkoop Order');
define('ORD_TEXT_12_WINDOW_TITLE','Verkoop/Factuur');
define('ORD_TEXT_13_WINDOW_TITLE','Klant Credit Nota');
define('ORD_TEXT_18_WINDOW_TITLE','Kas ontvangsten');
define('ORD_TEXT_20_WINDOW_TITLE','Kas Distributie');
define('ORD_TEXT_18_C_WINDOW_TITLE','Klant Betalingen');
define('ORD_TEXT_18_V_WINDOW_TITLE','Leverancier Restituties');
define('ORD_TEXT_20_C_WINDOW_TITLE','Klant Restituties');
define('ORD_TEXT_20_V_WINDOW_TITLE','Leverancier Betalingen');
define('BOX_BANKING_SELECT_FOR_PAYMENT','Selecteer voor Betaling');
define('BOX_BANKING_BANK_ACCOUNT_REGISTER','Bank Rekening Register');
define('BOX_BANKING_ACCOUNT_RECONCILIATION','Grootboek Verrekening');
define('BOX_BANKING_VOID_CHECKS','Niet geldige Checks');
define('BOX_GL_BUDGET','Budgeteren');
define('BOX_GL_UTILITIES','Algemene Journaal Opties');
define('BOX_PHREEBOOKS_MODULE_ADM','PhreeBooks Admin');
define('BOX_STATUS_MGR','%s Manager');

?>
