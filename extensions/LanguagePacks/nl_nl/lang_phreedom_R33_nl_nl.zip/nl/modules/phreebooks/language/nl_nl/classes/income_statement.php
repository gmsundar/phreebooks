<?php
// +-----------------------------------------------------------------+
// Phreedom Language Translation File
// Generated: 2011-11-27 05:02:34
// Module/Method: phreebooks
// ISO Language: nl_nl
// Version: 3.3
// +-----------------------------------------------------------------+
// Path: /modules/phreebooks/language/nl_nl/classes/income_statement.php

define('RW_FIN_REVENUES','Opbrengsten');
define('RW_FIN_COST_OF_SALES','Verkoop kosten');
define('RW_FIN_GROSS_PROFIT','Brutto Winst');
define('RW_FIN_EXPENSES','Uitgaven');
define('RW_FIN_NET_INCOME','Netto Winst');

?>
