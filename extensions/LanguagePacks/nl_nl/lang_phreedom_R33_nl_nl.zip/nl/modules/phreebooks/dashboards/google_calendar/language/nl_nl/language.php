<?php
// +-----------------------------------------------------------------+
// Phreedom Language Translation File
// Generated: 2011-11-27 05:02:33
// Module/Method: phreebooks-google_calendar
// ISO Language: nl_nl
// Version: 0.1
// +-----------------------------------------------------------------+
// Path: /modules/phreebooks/dashboards/google_calendar/language/nl_nl/language.php

define('CP_GOOGLE_CALENDAR_TITLE','MC Kalender');
define('CP_GOOGLE_CALENDAR_DESCRIPTION','Kalender voor Computer.');
define('CP_GOOGLE_CALENDAR_NO_RESULTS','Geen resultaten gevonden!');

?>
