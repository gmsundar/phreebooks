<?php
// +-----------------------------------------------------------------+
// Phreedom Language Translation File
// Generated: 2011-11-27 05:02:33
// Module/Method: phreebooks-todays_orders
// ISO Language: nl_nl
// Version: 3.2
// +-----------------------------------------------------------------+
// Path: /modules/phreebooks/dashboards/todays_orders/language/nl_nl/language.php

define('CP_TODAYS_ORDERS_TITLE','Verkooporders van vandaag');
define('CP_TODAYS_ORDERS_DESCRIPTION','Lijst met verkooporders van vandaag. met links om orders te wijzigen.');
define('CP_TODAYS_ORDERS_NO_RESULTS','Geen resultaten!');

?>
