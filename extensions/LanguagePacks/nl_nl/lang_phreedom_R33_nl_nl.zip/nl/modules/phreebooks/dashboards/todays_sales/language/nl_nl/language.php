<?php
// +-----------------------------------------------------------------+
// Phreedom Language Translation File
// Generated: 2011-11-27 05:02:34
// Module/Method: phreebooks-todays_sales
// ISO Language: nl_nl
// Version: 3.2
// +-----------------------------------------------------------------+
// Path: /modules/phreebooks/dashboards/todays_sales/language/nl_nl/language.php

define('CP_TODAYS_SALES_TITLE','Verkopen vandaag');
define('CP_TODAYS_SALES_DESCRIPTION','Lijst met verkopen / facturen van vandaag. Met links om de facturen te bewerken.');
define('CP_TODAYS_SALES_NO_RESULTS','Geen resultaten!');

?>
