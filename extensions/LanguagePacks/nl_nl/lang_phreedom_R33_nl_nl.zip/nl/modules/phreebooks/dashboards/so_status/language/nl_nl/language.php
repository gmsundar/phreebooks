<?php
// +-----------------------------------------------------------------+
// Phreedom Language Translation File
// Generated: 2011-11-27 05:02:33
// Module/Method: phreebooks-so_status
// ISO Language: nl_nl
// Version: 3.2
// +-----------------------------------------------------------------+
// Path: /modules/phreebooks/dashboards/so_status/language/nl_nl/language.php

define('CP_SO_STATUS_TITLE','Openstaande Verkooporders');
define('CP_SO_STATUS_DESCRIPTION','Lijst met verkooporders met open status. Links om de verkooporders te herzien zijn aanwezig.');
define('CP_SO_STATUS_NO_RESULTS','Geen resultaten!');

?>
