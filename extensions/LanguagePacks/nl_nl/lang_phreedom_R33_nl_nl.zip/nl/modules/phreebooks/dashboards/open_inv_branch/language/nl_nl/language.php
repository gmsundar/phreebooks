<?php
// +-----------------------------------------------------------------+
// Phreedom Language Translation File
// Generated: 2011-11-27 05:02:33
// Module/Method: phreebooks-open_inv_branch
// ISO Language: nl_nl
// Version: 1.0
// +-----------------------------------------------------------------+
// Path: /modules/phreebooks/dashboards/open_inv_branch/language/nl_nl/language.php

define('CP_OPEN_INV_BRANCH_TITLE','Openstaande factuuren per Vestiging');
define('CP_OPEN_INV_BRANCH_DESCRIPTION','Een lijst met openstaande facturen bij de als standaard ingestelde vestiging. Koppelingen om de facturen in te zien zijn voorzien.');
define('CP_OPEN_INV_BRANCH_NO_RESULTS','Geen resultaten gevonden!');

?>
