<?php
// +-----------------------------------------------------------------+
// Phreedom Language Translation File
// Generated: 2011-11-27 05:02:33
// Module/Method: phreebooks-po_status
// ISO Language: nl_nl
// Version: 3.2
// +-----------------------------------------------------------------+
// Path: /modules/phreebooks/dashboards/po_status/language/nl_nl/language.php

define('CP_PO_STATUS_TITLE','Openstaade inkooporders');
define('CP_PO_STATUS_DESCRIPTION','Lijsten met inkooporders met \"open\" status. Links om de kooporder te links zijn aanwezig.');
define('CP_PO_STATUS_NO_RESULTS','Geen resultaten!');

?>
