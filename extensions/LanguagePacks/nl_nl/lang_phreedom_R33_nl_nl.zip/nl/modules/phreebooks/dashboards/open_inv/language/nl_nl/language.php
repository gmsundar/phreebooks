<?php
// +-----------------------------------------------------------------+
// Phreedom Language Translation File
// Generated: 2011-11-27 05:02:33
// Module/Method: phreebooks-open_inv
// ISO Language: nl_nl
// Version: 3.2
// +-----------------------------------------------------------------+
// Path: /modules/phreebooks/dashboards/open_inv/language/nl_nl/language.php

define('CP_OPEN_INV_TITLE','Openstaande Facturen');
define('CP_OPEN_INV_DESCRIPTION','Lijst van openstaande verkoopfacturen. Links om de facturen te herzien zijn aanwezig.');
define('CP_OPEN_INV_NO_RESULTS','Geen resultaten!');

?>
