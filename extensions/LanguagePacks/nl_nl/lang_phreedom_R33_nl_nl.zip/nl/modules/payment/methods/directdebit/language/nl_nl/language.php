<?php
// +-----------------------------------------------------------------+
// Phreedom Language Translation File
// Generated: 2011-11-27 05:02:31
// Module/Method: payment-directdebit
// ISO Language: nl_nl
// Version: 3.2
// +-----------------------------------------------------------------+
// Path: /modules/payment/methods/directdebit/language/nl_nl/language.php

define('MODULE_PAYMENT_DIRECTDEBIT_TEXT_TITLE','Pin');
define('MODULE_PAYMENT_DIRECTDEBIT_TEXT_DESCRIPTION','Pin, Chip, EFT(electronic funds transfer)');
define('MODULE_PAYMENT_DIRECTDEBIT_TEXT_REF_NUM','Referentie Nummer');
define('MODULE_PAYMENT_DIRECTDEBIT_SORT_ORDER_DESC','Volgorde van tonen. De laagste wordt als eerste getoond');

?>
