<?php
// +-----------------------------------------------------------------+
// Phreedom Language Translation File
// Generated: 2011-11-27 05:02:31
// Module/Method: payment-cod
// ISO Language: nl_nl
// Version: 3.2
// +-----------------------------------------------------------------+
// Path: /modules/payment/methods/cod/language/nl_nl/language.php

define('MODULE_PAYMENT_COD_TEXT_TITLE','Contant');
define('MODULE_PAYMENT_COD_TEXT_DESCRIPTION','Betalen bij levering');
define('MODULE_PAYMENT_COD_SORT_ORDER_DESC','Volgorde van tonen. Laagste wordt als eerste getoond.');

?>
