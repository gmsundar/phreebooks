<?php
// +-----------------------------------------------------------------+
// Phreedom Language Translation File
// Generated: 2011-11-27 05:02:32
// Module/Method: payment-freecharger
// ISO Language: nl_nl
// Version: 3.2
// +-----------------------------------------------------------------+
// Path: /modules/payment/methods/freecharger/language/nl_nl/language.php

define('MODULE_PAYMENT_FREECHARGER_TEXT_TITLE','Gratis betaling');
define('MODULE_PAYMENT_FREECHARGER_TEXT_DESCRIPTION','GRATIS, Gebruikt ALLEEN voor de verkopen die geen betaling vereisen');
define('MODULE_PAYMENT_FREECHARGER_SORT_ORDER_DESC','Volgorde van tonen. De laatste wordt als eerste getoond');

?>
