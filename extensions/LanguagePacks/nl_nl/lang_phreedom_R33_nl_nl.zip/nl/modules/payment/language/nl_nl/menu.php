<?php
// +-----------------------------------------------------------------+
// Phreedom Language Translation File
// Generated: 2011-11-27 05:02:32
// Module/Method: payment
// ISO Language: nl_nl
// Version: 3.3
// +-----------------------------------------------------------------+
// Path: /modules/payment/language/nl_nl/menu.php

define('MENU_HEADING_PHREEPAY','PhreePay Betaal Module');

?>
