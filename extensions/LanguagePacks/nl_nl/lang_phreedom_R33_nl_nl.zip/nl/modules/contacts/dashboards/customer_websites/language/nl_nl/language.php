<?php
// +-----------------------------------------------------------------+
// Phreedom Language Translation File
// Generated: 2011-11-27 05:02:30
// Module/Method: contacts-customer_websites
// ISO Language: nl_nl
// Version: 3.2
// +-----------------------------------------------------------------+
// Path: /modules/contacts/dashboards/customer_websites/language/nl_nl/language.php

define('CP_CUSTOMER_WEBSITES_TITLE','Websites van Klanten');
define('CP_CUSTOMER_WEBSITES_DESCRIPTION','Lijst met url\'s van klanten. ');
define('CP_CUSTOMER_WEBSITES_NO_RESULTS','Geen resultaten!');

?>
