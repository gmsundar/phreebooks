<?php
// +-----------------------------------------------------------------+
// Phreedom Language Translation File
// Generated: 2011-11-27 05:02:30
// Module/Method: contacts-vendor_websites
// ISO Language: nl_nl
// Version: 3.2
// +-----------------------------------------------------------------+
// Path: /modules/contacts/dashboards/vendor_websites/language/nl_nl/language.php

define('CP_VENDOR_WEBSITES_TITLE','Websites van Leveranciers');
define('CP_VENDOR_WEBSITES_DESCRIPTION','Lijst met url\'s van leveranciers. ');
define('CP_VENDOR_WEBSITES_NO_RESULTS','Geen resultaten!');

?>
