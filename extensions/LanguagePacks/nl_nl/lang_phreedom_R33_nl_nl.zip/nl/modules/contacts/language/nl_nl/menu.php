<?php
// +-----------------------------------------------------------------+
// Phreedom Language Translation File
// Generated: 2011-11-27 05:02:30
// Module/Method: contacts
// ISO Language: nl_nl
// Version: 3.5
// +-----------------------------------------------------------------+
// Path: /modules/contacts/language/nl_nl/menu.php

define('MENU_HEADING_CUSTOMERS','Klanten');
define('MENU_HEADING_VENDORS','Leveranciers');
define('MENU_HEADING_EMPLOYEES','Personeel');
define('BOX_PHREECRM_MODULE','PhreeCRM');
define('BOX_CONTACTS_NEW_BRANCH','Branche Toevoegen');
define('BOX_CONTACTS_MAINTAIN_BRANCHES','Branche Manager');
define('BOX_CONTACTS_NEW_CUSTOMER','Klant Toevoegen');
define('BOX_CONTACTS_MAINTAIN_CUSTOMERS','Klant Manager');
define('BOX_CONTACTS_NEW_EMPLOYEE','Medewerker Toevoegen');
define('BOX_CONTACTS_MAINTAIN_EMPLOYEES','Medewerker Manager');
define('BOX_CONTACTS_NEW_PROJECT','Project Toevoegen');
define('BOX_CONTACTS_MAINTAIN_PROJECTS','Project Manager');
define('BOX_CONTACTS_NEW_VENDOR','Leverancier Toevoegen');
define('BOX_CONTACTS_MAINTAIN_VENDORS','Leverancier Manager');
define('BOX_CONTACTS_NEW_CONTACT','Contact Toevoegen');
define('BOX_HR_DEPARTMENTS','Afdelingen');
define('BOX_PROJECTS_PHASES','Project Fasen');
define('BOX_PROJECTS_COSTS','Project Kosten');

?>
