<?php
// +-----------------------------------------------------------------+
// Phreedom Language Translation File
// Generated: 2011-01-21 08:32:36
// +-----------------------------------------------------------------+
// Path: /modules/translator/language/nl_nl/menu.php

define('MENU_HEADING_TRANSLATOR','Vertaal Tool');
define('BOX_TRANSLATOR_MODULE','Vertaal Assistant');

?>
