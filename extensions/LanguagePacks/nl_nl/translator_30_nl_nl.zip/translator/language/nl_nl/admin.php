<?php
// +-----------------------------------------------------------------+
// Phreedom Language Translation File
// Generated: 2011-01-21 08:32:36
// +-----------------------------------------------------------------+
// Path: /modules/translator/language/nl_nl/admin.php

define('MODULE_TRANSLATOR_TITLE','Vertaal Module');
define('MODULE_TRANSLATOR_DESCRIPTION','De vertaler-module biedt een handige interface om taalbestanden vertalen van de ene taal naar de andere. Deze module behandelt versie updates als eerste volledige vertaling te ondersteunen.');

?>
