<?php
// +-----------------------------------------------------------------+
// Phreedom Language Translation File
// Generated: 2011-01-21 08:30:35
// +-----------------------------------------------------------------+
// Path: /modules/phreebooks/dashboards/po_status/language/nl_nl/language.php

define('CP_PO_STATUS_TITLE','Open inkooporders');
define('CP_PO_STATUS_DESCRIPTION','Lijsten met inkooporders met \"open\" status. Links om de inkooporder te herzien zijn aanwezig.');
define('CP_PO_STATUS_NO_RESULTS','Geen resultaten!');
define('CP_PO_STATUS_SECURITY',SECURITY_ID_PURCHASE_ORDER);
?>
