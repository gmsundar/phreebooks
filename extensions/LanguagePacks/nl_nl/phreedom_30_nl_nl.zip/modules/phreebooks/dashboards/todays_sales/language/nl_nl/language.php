<?php
// +-----------------------------------------------------------------+
// Phreedom Language Translation File
// Generated: 2011-01-21 08:30:56
// +-----------------------------------------------------------------+
// Path: /modules/phreebooks/dashboards/todays_sales/language/nl_nl/language.php

define('CP_TODAYS_SALES_TITLE','Verkopen vandaag');
define('CP_TODAYS_SALES_DESCRIPTION','Lijst met verkopen / facturen van vandaag. Met links om de facturen te bewerken.');
define('CP_TODAYS_SALES_NO_RESULTS','Geen resultaten!');
define('CP_TODAYS_SALES_SECURITY',SECURITY_ID_SALES_INVOICE);
?>
