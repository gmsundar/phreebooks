<?php
// +-----------------------------------------------------------------+
// Phreedom Language Translation File
// Generated: 2011-01-21 08:30:51
// +-----------------------------------------------------------------+
// Path: /modules/phreebooks/dashboards/todays_orders/language/nl_nl/language.php

define('CP_TODAYS_ORDERS_TITLE','Verkooporders van vandaag');
define('CP_TODAYS_ORDERS_DESCRIPTION','Lijst met verkooporders van vandaag. met links om orders te wijzigen.');
define('CP_TODAYS_ORDERS_NO_RESULTS','Geen resultaten!');
define('CP_TODAYS_ORDERS_SECURITY',SECURITY_ID_SALES_ORDER);
?>
