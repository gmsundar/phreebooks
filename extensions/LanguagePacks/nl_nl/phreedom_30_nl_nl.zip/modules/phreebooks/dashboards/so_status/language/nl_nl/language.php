<?php
// +-----------------------------------------------------------------+
// Phreedom Language Translation File
// Generated: 2011-01-21 08:30:43
// +-----------------------------------------------------------------+
// Path: /modules/phreebooks/dashboards/so_status/language/nl_nl/language.php

define('CP_SO_STATUS_TITLE','Open Verkooporders');
define('CP_SO_STATUS_DESCRIPTION','Lijst met verkooporders met open status. Links om de verkooporders te herzien zijn aanwezig.');
define('CP_SO_STATUS_NO_RESULTS','Geen resultaten!');
define('CP_SO_STATUS_SECURITY',SECURITY_ID_SALES_ORDER);
?>
