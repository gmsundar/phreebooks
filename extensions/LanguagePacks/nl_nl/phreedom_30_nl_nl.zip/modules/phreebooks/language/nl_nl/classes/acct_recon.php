<?php
// +-----------------------------------------------------------------+
// Phreedom Language Translation File
// Generated: 2011-01-21 08:30:10
// +-----------------------------------------------------------------+
// Path: /modules/phreebooks/language/nl_nl/classes/acct_recon.php

define('RW_RECON_BB','Begin Balans');
define('RW_RECON_CR','Kassa Bonnen');
define('RW_RECON_CD','Contante Uitbetalingen');
define('RW_RECON_EB','Eind Balans');
define('RW_RECON_ADD_BACK','Voeg Terug Stortingen onderweg toe');
define('RW_RECON_DIT','Totale Stortingen onderweg');
define('RW_RECON_LOP','Minder Uitstaande Betalingen');
define('RW_RECON_TOP','Totaal Uitstaande Betalingen');
define('RW_RECON_DIFF','Niet Opgeloste Verschillen');
define('RW_RECON_TBD','Kolom Vasthouder');
define('RW_RECON_CLEARED','Transacties vrijgegeven');
define('RW_RECON_DCLEARED','Stortingen vrijgegeven');
define('RW_RECON_PCLEARED','Betalingen vrijgegeven');
define('RW_RECON_TDC','Totaal Stortingen vrijgegeven');
define('RW_RECON_TPC','Totaal Betalingen vrijgegeven');
define('RW_RECON_NCLEARED','Netto vrijgegeven');

?>
