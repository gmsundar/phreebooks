<?php
// +-----------------------------------------------------------------+
// Phreedom Language Translation File
// Generated: 2011-01-21 08:30:10
// +-----------------------------------------------------------------+
// Path: /modules/phreebooks/language/nl_nl/classes/backorders_report.php

define('RW_BO_RECORD_ID','Record ID');
define('RW_BO_STORE_ID','Winkel ID');
define('RW_BO_FRT_TOTAL','Verzend bedrag');
define('RW_BO_FRT_CARRIER','Verzend koerier');
define('RW_BO_FRT_SERVICE','Verzend Service');
define('RW_BO_SALES_TAX','Verkoop belasting');
define('RW_BO_TAX_AUTH','BTW tarief');
define('RW_BO_INV_TOTAL','Factuur bedrag');
define('RW_BO_BALANCE_DUE','Totaal openstaand');
define('RW_BO_CUR_CODE','Valuta Code');
define('RW_BO_CUR_EXC_RATE','Wisselkoers');
define('RW_BO_INV_NUM','Verkoop Order Nummer');
define('RW_BO_PO_NUM','Inkoop Order Nummer');
define('RW_BO_SALES_REP','Verkoopmedewerker');
define('RW_BO_AR_ACCT','Debiteuren Grootboek');
define('RW_BO_BILL_ACCT_ID','Factuur account ID');
define('RW_BO_BILL_ADD_ID','Factuur Adres ID');
define('RW_BO_BILL_PRIMARY_NAME','Factuur Primaire naam');
define('RW_BO_BILL_CONTACT','Factuur contact');
define('RW_BO_BILL_ADDRESS1','Factuur Adres 1');
define('RW_BO_BILL_ADDRESS2','Factuur Adres 2');
define('RW_BO_BILL_CITY','Factuur Plaats');
define('RW_BO_BILL_STATE','Factuur State/Provisie');
define('RW_BO_BILL_ZIP','Factuur Postcode');
define('RW_BO_BILL_COUNTRY','Factuur land');
define('RW_BO_BILL_TELE1','Factuur Telefoon 1');
define('RW_BO_QTY_ORDERED','Besteld');
define('RW_QTY_IN_STOCK','Op Voorraad');
define('RW_BO_QTY_BACKORDER','Backorder');

?>
