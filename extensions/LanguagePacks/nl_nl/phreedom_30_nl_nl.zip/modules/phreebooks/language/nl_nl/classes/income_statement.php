<?php
// +-----------------------------------------------------------------+
// Phreedom Language Translation File
// Generated: 2011-01-21 08:30:10
// +-----------------------------------------------------------------+
// Path: /modules/phreebooks/language/nl_nl/classes/income_statement.php

define('RW_FIN_REVENUES','Opbrengsten');
define('RW_FIN_COST_OF_SALES','Verkoop kosten');
define('RW_FIN_GROSS_PROFIT','Brutto Winst');
define('RW_FIN_EXPENSES','Uitgaven');
define('RW_FIN_NET_INCOME','Netto Winst');

?>
