<?php
// +-----------------------------------------------------------------+
// Phreedom Language Translation File
// Generated: 2011-01-21 08:30:10
// +-----------------------------------------------------------------+
// Path: /modules/phreebooks/language/nl_nl/menu.php

define('MENU_HEADING_GL','Boekhouden');
define('MENU_HEADING_BANKING','Bankieren');
define('BOX_AR_QUOTE','Offertes');
define('BOX_AR_QUOTE_STATUS','Verkoop Offerte Manager');
define('BOX_AR_SALES_ORDER','Verkoop Orders');
define('BOX_AR_ORDER_STATUS','Verkoop Order Manager');
define('BOX_AR_INVOICE','Verkoop Facturen');
define('BOX_AR_POINT_OF_SALE','Kassa');
define('BOX_AR_INVOICE_MGR','Factuur Manager');
define('BOX_AR_CREDIT_MEMO','Klant Crediteren');
define('BOX_AR_QUOTE_STATUS','Verkoop Offerte Manager');
define('BOX_AP_REQUEST_QUOTE','Verzoek om Offerte');
define('BOX_AP_RFQ_STATUS','Inkoop Offerte Manager');
define('BOX_AP_PURCHASE_ORDER','Aankoop Orders');
define('BOX_AP_ORDER_STATUS','Aankoop Order Manager');
define('BOX_AP_RECEIVE_INVENTORY','Aankoop/Ontvangen');
define('BOX_AR_POINT_OF_PURCHASE','Point of Purchase');
define('BOX_AP_CREDIT_MEMO','Leverancier Credit');
define('BOX_AP_RFQ_STATUS','Inkoop Offerte Manager');
define('BOX_BANKING_VENDOR_DEPOSITS','Leverancier stortingen');
define('BOX_BANKING_CUSTOMER_RECEIPTS','Klant Bonnen');
define('BOX_BANKING_CUSTOMER_PAYMENTS','Klant Terugbetaling');
define('BOX_BANKING_PAY_BILLS','Rekeningen Betalen');
define('BOX_BANKING_VENDOR_RECEIPTS','Restitutie van Leveranciers');
define('BOX_BANKING_SELECT_FOR_PAYMENT','Selecteer voor Betaling');
define('BOX_BANKING_BANK_ACCOUNT_REGISTER','Bank Rekening Register');
define('BOX_BANKING_ACCOUNT_RECONCILIATION','Grootboek Verrekening');
define('BOX_BANKING_VOID_CHECKS','Niet geldige Checks');
define('BOX_BANKING_CUSTOMER_DEPOSITS','Klant Stortingen');
define('BOX_GL_BUDGET','Budgeteren');
define('BOX_GL_JOURNAL_ENTRY','Journaal Posten');
define('BOX_GL_UTILITIES','Algemene Journaal Opties');
define('BOX_PRICE_SHEET_MANAGER','Prijslijst Manager');
define('BOX_PHREEBOOKS_MODULE_ADM','PhreeBooks Admin');

?>
