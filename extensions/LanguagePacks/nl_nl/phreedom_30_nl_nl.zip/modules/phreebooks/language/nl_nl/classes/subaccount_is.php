<?php
// +-----------------------------------------------------------------+
// Phreedom Language Translation File
// Generated: 2011-01-21 08:30:10
// +-----------------------------------------------------------------+
// Path: /modules/phreebooks/language/nl_nl/classes/subaccount_is.php

define('RW_SUB_ACT_BAL_SHT_IS_ACCT','0');
define('RW_FIN_NET_INCOME','Netto Winst');
define('RW_RECORD_ID','Kolom Plaatshouder');

?>
