<?php
// +-----------------------------------------------------------------+
// Phreedom Language Translation File
// Generated: 2011-01-21 08:31:41
// +-----------------------------------------------------------------+
// Path: /modules/phreehelp/language/nl_nl/language.php

define('HEADING_TITLE','PhreeBooks Inloggen');
define('HEADING_CONTENTS','Inhoud');
define('HEADING_INDEX','Index');
define('TEXT_DOCUMENT','Document');
define('TEXT_EXIT','Exit');
define('TEXT_FOLDER','Folder');
define('TEXT_FORWARD','Volgende');
define('TEXT_SUPPORT','PhreeSoft Online Support');
define('TEXT_KEYWORD','Voer een sleutelwoord in om te zoeken:');
define('TEXT_SEARCH_RESULTS','Uw zoek resultaten:');
define('TEXT_UNTITLED','Niet getiteld document');
define('TEXT_MANUAL','Handleiding');
define('TEXT_NO_RESULTS','Er zijn geen resultaten gevonden. De zoekterm moet minstens vier letters, en niet een algemeen woord.');

?>
