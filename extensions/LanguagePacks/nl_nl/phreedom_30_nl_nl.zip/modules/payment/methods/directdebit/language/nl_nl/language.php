<?php
// +-----------------------------------------------------------------+
// Phreedom Language Translation File
// Generated: 2011-01-21 08:29:26
// +-----------------------------------------------------------------+
// Path: /modules/payment/methods/directdebit/language/nl_nl/language.php

define('MODULE_PAYMENT_DIRECTDEBIT_TEXT_TITLE','Pin');
define('MODULE_PAYMENT_DIRECTDEBIT_TEXT_DESCRIPTION','Pin, Chip, EFT(electronic funds transfer)');
define('MODULE_PAYMENT_DIRECTDEBIT_TEXT_REF_NUM','Referentie Nummer');
define('MODULE_PAYMENT_DIRECTDEBIT_SORT_ORDER_DESC','Volgorde van tonen. De laagste wordt als eerste getoond');

?>
