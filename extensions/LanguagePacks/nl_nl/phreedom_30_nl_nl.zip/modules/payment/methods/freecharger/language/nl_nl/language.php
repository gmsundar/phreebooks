<?php
// +-----------------------------------------------------------------+
// Phreedom Language Translation File
// Generated: 2011-01-21 08:29:41
// +-----------------------------------------------------------------+
// Path: /modules/payment/methods/freecharger/language/nl_nl/language.php

define('MODULE_PAYMENT_FREECHARGER_TEXT_TITLE','de Zen Cart DIT PRODUCT GRATIS');
define('MODULE_PAYMENT_FREECHARGER_TEXT_DESCRIPTION','Gebruikt ALLEEN voor de verkopen GRATIS ');
define('MODULE_PAYMENT_FREECHARGER_SORT_ORDER_DESC','Volgorde van tonen. De laatste wordt als eerste getoond');

?>
