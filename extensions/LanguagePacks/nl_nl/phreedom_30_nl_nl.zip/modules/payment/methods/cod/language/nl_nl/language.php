<?php
// +-----------------------------------------------------------------+
// Phreedom Language Translation File
// Generated: 2011-01-21 08:29:19
// +-----------------------------------------------------------------+
// Path: /modules/payment/methods/cod/language/nl_nl/language.php

define('MODULE_PAYMENT_COD_TEXT_TITLE','Rembours');
define('MODULE_PAYMENT_COD_TEXT_DESCRIPTION','Betalen bij levering');
define('MODULE_PAYMENT_COD_SORT_ORDER_DESC','Volgorde van tonen. Laagste wordt als eerste getoond.');

?>
