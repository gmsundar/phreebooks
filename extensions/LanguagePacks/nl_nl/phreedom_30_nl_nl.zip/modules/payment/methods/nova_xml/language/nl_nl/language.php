<?php
// +-----------------------------------------------------------------+
// Phreedom Language Translation File
// Generated: 2011-01-21 08:30:01
// +-----------------------------------------------------------------+
// Path: /modules/payment/methods/nova_xml/language/nl_nl/language.php

define('MODULE_PAYMENT_NOVA_XML_TEXT_TITLE','Elevon');
define('MODULE_PAYMENT_NOVA_XML_TEXT_DESCRIPTION','Accepteer credit card betaalingen via Elevon payment gateway');
define('MODULE_PAYMENT_NOVA_XML_TEXT_INTRODUCTION','In test modus, De kaarten retourneren geaccepteerd maar er is niets verwerkt.<br /><br />');
define('MODULE_PAYMENT_NOVA_XML_STATUS_DESC','Wil u Elevon Netwerk betalingen accepteren ?');
define('MODULE_PAYMENT_NOVA_XML_MERCHANT_ID_DESC','Het Elevon Merchant ID om gebruik te kunnen maken van de  Elevon Netwerk service:');
define('MODULE_PAYMENT_NOVA_XML_USER_ID_DESC','Het Elevon User ID Om gebruik te maken van de Elevon Network service:');
define('MODULE_PAYMENT_NOVA_XML_PIN_DESC','PIN Voor de Elevon Network service:');
define('MODULE_PAYMENT_NOVA_XML_TESTMODE_DESC','Transaction mode gebruikt voor het verwerken van oders');
define('MODULE_PAYMENT_NOVA_XML_AUTHORIZATION_TYPE_DESC','Wil u credit card transacties alleen autoriseren of autoriseren en vastleggen?');
define('MODULE_PAYMENT_NOVA_XML_SORT_ORDER_DESC','Volgorde van tonen. De laagste wordt als eerste getoond');
define('MODULE_PAYMENT_NOVA_XML_TEXT_CATALOG_TITLE','Credit Card');
define('MODULE_PAYMENT_NOVA_XML_TEXT_CREDIT_CARD_TYPE','Credit Card Type:');
define('MODULE_PAYMENT_NOVA_XML_TEXT_CREDIT_CARD_OWNER','Credit Card Eigenaar:');
define('MODULE_PAYMENT_NOVA_XML_TEXT_CREDIT_CARD_NUMBER','Credit Card Nummer:');
define('MODULE_PAYMENT_NOVA_XML_TEXT_CREDIT_CARD_EXPIRES','Credit Card Expiratie Datum:');
define('MODULE_PAYMENT_NOVA_XML_TEXT_CVV','CVV Nummer (<a href=\"javascript:popupWindowCvv()\">\' . \'Meer Info\' . \'</a>)');
define('MODULE_PAYMENT_NOVA_XML_TEXT_JS_CC_OWNER','* De naam van de eigenaar van de credit card moet minstens  \' . CC_OWNER_MIN_LENGTH . \' charters lang zijn.\\n');
define('MODULE_PAYMENT_NOVA_XML_TEXT_JS_CC_NUMBER','* Het credit card nummer moet minstens  \' . CC_NUMBER_MIN_LENGTH . \' charters lang zijn.\\n');
define('MODULE_PAYMENT_NOVA_XML_TEXT_JS_CC_CVV','* Het 3 of 4 cijfer CVV nummer dat op de achterkant van de credit card staat moet ingevoerd worden.\\n');
define('MODULE_PAYMENT_NOVA_XML_TEXT_DECLINED_MESSAGE','De credit card transactie is niet correct verwerkt. Wanneer er geen reden wordt gegeven dan wordt de kaart geweigerd door de bank.');
define('MODULE_PAYMENT_NOVA_XML_NO_DUPS','De credit card is niet verwerkt hij was al eens verwerkt. Om hem opnieuw te verwerken, moet het credit card nummer geldig zijn gen geen * meer bevatten.');
define('MODULE_PAYMENT_NOVA_XML_TEXT_ERROR','Credit Card Error!');

?>
