<?php
// +-----------------------------------------------------------------+
// Phreedom Language Translation File
// Generated: 2011-01-21 08:29:57
// +-----------------------------------------------------------------+
// Path: /modules/payment/methods/moneyorder/language/nl_nl/language.php

define('MODULE_PAYMENT_MONEYORDER_TEXT_TITLE','Check/Money Order');
define('MODULE_PAYMENT_MONEYORDER_TEXT_DESCRIPTION','Maak uw check of money order over aan:<br />\' . MODULE_PAYMENT_MONEYORDER_PAYTO . \'<br /><br />Adresseer uw betaling aan:<br />\' . nl2br(COMPANY_NAME) . \'<br /><br />\' . \'Uw bestelling wordt niet verstuurd totdat de betaling is ontvangen.');
define('MODULE_PAYMENT_MONEYORDER_TEXT_REF_NUM','Referentie Nummer');
define('MODULE_PAYMENT_MONEYORDER_PAYTO_DESC','Doe betaling aan:');
define('MODULE_PAYMENT_MONEYORDER_SORT_ORDER_DESC','Volgorde van tonen. Laagste wordt als eerste getoond');

?>
