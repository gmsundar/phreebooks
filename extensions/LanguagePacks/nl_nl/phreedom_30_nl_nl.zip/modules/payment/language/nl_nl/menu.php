<?php
// +-----------------------------------------------------------------+
// Phreedom Language Translation File
// Generated: 2011-01-21 08:29:09
// +-----------------------------------------------------------------+
// Path: /modules/payment/language/nl_nl/menu.php

define('MENU_HEADING_PHREEPAY','PhreePay Betaal Module');

?>
