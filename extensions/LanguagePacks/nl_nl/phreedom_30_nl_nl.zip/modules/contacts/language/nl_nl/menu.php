<?php
// +-----------------------------------------------------------------+
// Phreedom Language Translation File
// Generated: 2011-01-21 08:28:45
// +-----------------------------------------------------------------+
// Path: /modules/contacts/language/nl_nl/menu.php

define('MENU_HEADING_CUSTOMERS','Klanten');
define('MENU_HEADING_VENDORS','Leveranciers');
define('MENU_HEADING_EMPLOYEES','Personeel');
define('BOX_PHREECRM_MODULE','PhreeCRM');
define('BOX_CONTACTS_NEW_BRANCH','Nieuwe Branche');
define('BOX_CONTACTS_MAINTAIN_BRANCHES','Bewerk Branches');
define('BOX_CONTACTS_NEW_CUSTOMER','Nieuwe Klant');
define('BOX_CONTACTS_MAINTAIN_CUSTOMERS','Bewerk Klanten');
define('BOX_CONTACTS_NEW_EMPLOYEE','Nieuwe Medewerker');
define('BOX_CONTACTS_MAINTAIN_EMPLOYEES','Bewerk Medewerker');
define('BOX_CONTACTS_NEW_PROJECT','Nieuw Project');
define('BOX_CONTACTS_MAINTAIN_PROJECTS','Bewerk Projecten');
define('BOX_CONTACTS_NEW_VENDOR','Nieuwe Leverancier');
define('BOX_CONTACTS_MAINTAIN_VENDORS','Bewerk Leverancier');
define('BOX_CONTACTS_NEW_CONTACT','Nieuw Contact');
define('BOX_HR_DEPARTMENTS','Afdelingen');
define('BOX_PROJECTS_PHASES','Project Fasen');
define('BOX_PROJECTS_COSTS','Project Kosten');

?>
