<?php
// +-----------------------------------------------------------------+
// Phreedom Language Translation File
// Generated: 2011-02-13 08:28:45
// +-----------------------------------------------------------------+
// Path: /modules/contacts/language/nl_nl/admin.php

define('MODULE_CONTACTS_TITLE','Contact module');
define('MODULE_CONTACTS_DESCRIPTION','De contact module beheert alle klanten, leveranciers, medewerkers, brances en projecten in de PhreeSoft Business Toolkit. <b>NOTE: Deze module moet niet verwijderd worden omdat hij tot de kern van het programma behoort!</b>');
define('BOX_CONTACTS_ADMIN','Contact Administratie');
define('TEXT_BILLING_PREFS','Factuur Adres Instellingen');
define('TEXT_SHIPPING_PREFS','Verzend Adres Instellingen');
define('COST_TYPE_LBR','Arbeidt');
define('COST_TYPE_MAT','Materialen');
define('COST_TYPE_CNT','Aannemers');
define('COST_TYPE_EQT','Gereedschap');
define('COST_TYPE_OTH','Overige');
define('CD_11_02_DESC','Of het verplicht is om contact veld in te vullen tijdens de rekeningen setup (leveranciers, klanten, werknemers)');
define('CD_11_03_DESC','Of het verplicht is om adres 1 veld in te vullen tijdens de rekeningen setup (leveranciers, klanten, werknemers)');
define('CD_11_04_DESC','Of het verplicht is om adres 2 veld in te vullen tijdens de rekeningen setup (leveranciers, klanten, werknemers)');
define('CD_11_05_DESC','Of het verplicht is om plaats veld in te vullen tijdens de rekeningen setup (leveranciers, klanten, werknemers)');
define('CD_11_06_DESC','Of het verplicht is om provincie veld in te vullen tijdens de rekeningen setup (leveranciers, klanten, werknemers)');
define('CD_11_07_DESC','Of het verplicht is om postcode veld in te vullen tijdens de rekeningen setup (leveranciers, klanten, werknemers)');
define('CD_11_08_DESC','Of het verplicht is om telefoon1 veld in te vullen tijdens de rekeningen setup (leveranciers, klanten, werknemers)');
define('CD_11_09_DESC','Of het verplicht is om Email adres veld in te vullen tijdens de rekeningen setup (leveranciers, klanten, werknemers)');
define('CD_11_10_DESC','Of het verplicht is om adres 1 veld in te vullen in de verzend module.');
define('CD_11_11_DESC','Of het verplicht is om adres 2 veld in te vullen in de verzend module.');
define('CD_11_12_DESC','Of het verplicht is om contact veld in te vullen in de verzend module.');
define('CD_11_13_DESC','Of het verplicht is om plaats veld in te vullen in de verzend module.');
define('CD_11_14_DESC','Of het verplicht is om provincie veld in te vullen in de verzend module.');
define('CD_11_15_DESC','Of het verplicht is om postcode veld in te vullen in de verzend module.');
define('HR_POPUP_WINDOW_TITLE','Afdelingen');
define('HR_HEADING_SUBACCOUNT','Sub afdeling');
define('HR_EDIT_INTRO','Maak de nodige Wijzigingen');
define('HR_ACCOUNT_ID','Afdelingen ID');
define('HR_INFO_SUBACCOUNT','Is deze afdelingen een sub afdeling?');
define('HR_INFO_PRIMARY_ACCT_ID','Ja, Selecteer het primaire afdeling:');
define('HR_INFO_ACCOUNT_TYPE','Afdeling type');
define('HR_INFO_ACCOUNT_INACTIVE','Afdeling inactief');
define('HR_INFO_INSERT_INTRO','Voer de nieuwe afdeling in met de bijbehorende data');
define('HR_INFO_NEW_ACCOUNT','Nieuwe afdeling');
define('HR_INFO_EDIT_ACCOUNT','Bewerk afdeling');
define('HR_INFO_DELETE_INTRO','Weet u zeker dat u deze afdeling wil verwijderen?');
define('HR_DEPARTMENT_REF_ERROR','De primaire afdeling kan niet het zelfde zijn als het sub afdeling!');
define('HR_LOG_DEPARTMENTS','Afdeling - ');
define('SETUP_TITLE_DEPT_TYPES','Afdeling Types');
define('SETUP_INFO_DEPT_TYPES_NAME','Afdeling Type Naam');
define('SETUP_DEPT_TYPES_INSERT_INTRO','Voer een nieuw afdeling type in');
define('SETUP_DEPT_TYPES_DELETE_INTRO','Weet u zeker dat u dit afdeling type wilt verwijderen?');
define('SETUP_DEPT_TYPES_DELETE_ERROR','Kan dit afdeling type niet verwijderen, het wordt namelijk gebruikt door een afdeling.');
define('SETUP_INFO_HEADING_NEW_DEPT_TYPES','Nieuw afdeling Type');
define('SETUP_INFO_HEADING_EDIT_DEPT_TYPES','Bewerk afdeling Type');
define('SETUP_DEPT_TYPES_LOG','Afdeling Types - ');
define('SETUP_TITLE_PROJECTS_COSTS','Project Kosten');
define('TEXT_SHORT_NAME','Korte Naam');
define('TEXT_COST_TYPE','Kosten Type');
define('SETUP_INFO_DESC_SHORT','Verkorte Naam (15 karakters max)');
define('SETUP_INFO_DESC_LONG','Lange Omschrijving (64 karakters max)');
define('SETUP_PROJECT_COSTS_INSERT_INTRO','Voer de nieuwe project kosten in met de bijbehorende eigenschappen.');
define('SETUP_PROJECT_COSTS_DELETE_INTRO','Weet u zeker dat u dit wil verwijderen.');
define('SETUP_INFO_HEADING_NEW_PROJECT_COSTS','Nieuwe Project Kosten');
define('SETUP_INFO_HEADING_EDIT_PROJECT_COSTS','Bewerk Project Kosten');
define('SETUP_INFO_COST_TYPE','Kosten Type');
define('SETUP_PROJECT_COSTS_LOG','Project kosten - ');
define('SETUP_PROJECT_COSTS_DELETE_ERROR','Kan deze project kosten niet verwijderen omdat het gebruikt wordt in een journaal post.');
define('SETUP_TITLE_PROJECTS_PHASES','Project fasen ');
define('TEXT_COST_BREAKDOWN','Kosten Splitsen');
define('SETUP_INFO_COST_BREAKDOWN','Gebruik maken van Kosten splitsen voor deze fase?');
define('SETUP_PROJECT_PHASES_INSERT_INTRO','Voer alstublieft de nieuwe Project fase in met hun eigenschappen');
define('SETUP_PROJECT_PHASES_DELETE_INTRO','Weet u zeker dat u deze project fase wilt verwijderen?');
define('SETUP_INFO_HEADING_NEW_PROJECT_PHASES','Nieuwe Project fase');
define('SETUP_INFO_HEADING_EDIT_PROJECT_PHASES','Bewerk Project fase');
define('SETUP_PROJECT_PHASESS_LOG','Project Fasen - ');
define('SETUP_PROJECT_PHASESS_DELETE_ERROR','Kan de project fase niet verwijderen, het wordt namelijk gebruikt in een journaal.');
define('HR_DISPLAY_NUMBER_OF_DEPTS', TEXT_DISPLAY_NUMBER . 'Afdelingen');
define('TEXT_DISPLAY_NUMBER_OF_DEPT_TYPES', TEXT_DISPLAY_NUMBER . 'Afdeling types');
define('SETUP_DISPLAY_NUMBER_OF_PROJECT_COSTS', TEXT_DISPLAY_NUMBER . 'project kosten');
define('SETUP_DISPLAY_NUMBER_OF_PROJECT_PHASES', TEXT_DISPLAY_NUMBER . 'project Fasen');
/************************** (Address Book Defaults) ***********************************************/
define('CONTACT_BILL_FIELD_REQ', 'Of het verplicht is of het veld: %s in gevult moet worden voor een nieuw hoofd/factuur adres(voor Leveranciers, Klanten and Personeel)');
define('CONTACT_SHIP_FIELD_REQ', 'Of het verplicht is of het veld: %s in gevult moet worden voor een nieuw verzend adres');

?>
