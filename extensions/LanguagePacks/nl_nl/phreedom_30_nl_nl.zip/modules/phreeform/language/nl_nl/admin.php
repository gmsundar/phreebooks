<?php
// +-----------------------------------------------------------------+
// Phreedom Language Translation File
// Generated: 2011-01-21 08:31:29
// +-----------------------------------------------------------------+
// Path: /modules/phreeform/language/nl_nl/admin.php

define('MODULE_PHREEFORM_TITLE','PhreeForm Module');
define('MODULE_PHREEFORM_DESCRIPTION','De phreeform module bevat alle rapport en formulier tools die nodig zijn om rapporten in PDF of HTML-formaat af te drukken. <b> LET OP: Dit is een kernmodule en dient niet te worden verwijderd </ b>!');
define('BOX_PHREEFORM_MODULE_ADM','PhreeForm Admin');
define('PB_CONVERT_REPORTS','Converteren .txt Rapporten naar PhreeForm');
define('PB_CONVERT_SAVE_ERROR','Er was en fout bij het opslaan van de geconverteerde rapport: %s');
define('PB_CONVERT_SUCCESS','Succesvol geconverteerd% s rapporten en formulieren. Eventuele fouten tijdens de conversie, zouden verschijnen in een voorafgaande melding.');
define('PF_DEFAULT_COLUMN_WIDTH_TEXT','Stelt de standaard breedte in te gebruiken voor de kolombreedte van de rapporten in mm (standaard: 25)');
define('PF_DEFAULT_MARGIN_TEXT','Stelt de standaard pagina marge in om te gebruiken voor rapporten en formulieren in mm (standaard: 8)');
define('PF_DEFAULT_TITLE1_TEXT','Stelt de standaard titeltekst in af te drukken als Hoofd 1 voor de rapporten (standaard: %rapportnaam%)');
define('PF_DEFAULT_TITLE2_TEXT','Stelt de standaard titeltekst in af te drukken als Hoofd 2 voor rapporten (standaard: rapport gegenereerd %date%)');
define('PF_DEFAULT_PAPERSIZE_TEXT','Stelt de standaard papierformaat in te gebruiken voor rapporten en formulieren (standaard: Letter)');
define('PF_DEFAULT_ORIENTATION_TEXT','Stelt het standaard afdrukstand in voor rapporten en formulieren (standaard: Portret)');
define('PF_DEFAULT_TRIM_LENGTH_TEXT','Stelt de trim lengte in van rapport en formulier namen bij de opsomming in de directory-indeling (standaard: 25)');
define('PF_DEFAULT_ROWSPACE_TEXT','Stelt de scheiding in tussen de Hoofd rijen voor rapporten (standaard: 2)');

?>
