<?php
// +-----------------------------------------------------------------+
// Phreedom Language Translation File
// Generated: 2011-01-21 08:31:36
// +-----------------------------------------------------------------+
// Path: /modules/phreeform/dashboards/favorite_reports/language/nl_nl/language.php

define('CP_FAVORITE_REPORTS_TITLE','Favoriete Rapporten');
define('CP_FAVORITE_REPORTS_DESCRIPTION','Lijst favoriete rapporten voor snelle display.');
define('CP_FAVORITE_REPORTS_NO_RESULTS','Geen resultaten gevonden!');
define('CP_FAVORITE_REPORTS_SECURITY',SECURITY_ID_PHREEFORM);
?>
