<?php
// +-----------------------------------------------------------------+
// Phreedom Language Translation File
// Generated: 2011-01-21 08:29:02
// +-----------------------------------------------------------------+
// Path: /modules/inventory/language/nl_nl/menu.php

define('MENU_HEADING_INVENTORY','Voorraad');
define('BOX_INV_MAINTAIN','Bewerk/Onderhoud');
define('BOX_INV_NEW','Voorraad Toevoegen');
define('BOX_INV_ADJUSTMENTS','Wijzigingen');
define('BOX_INV_ASSEMBLIES','Assemblages');
define('BOX_INV_TRANSFER','Transporteer Voorraad');

?>
