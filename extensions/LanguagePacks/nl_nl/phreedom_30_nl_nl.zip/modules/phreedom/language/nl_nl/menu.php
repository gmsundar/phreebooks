<?php
// +-----------------------------------------------------------------+
// Phreedom Language Translation File
// Generated: 2011-01-21 08:31:01
// +-----------------------------------------------------------------+
// Path: /modules/phreedom/language/nl_nl/menu.php

define('HEADER_TITLE_TOP','Home');
define('HEADER_TITLE_LOGOFF','Uitloggen');
define('MENU_HEADING_COMPANY','Bedrijf');
define('MENU_HEADING_TOOLS','Tools');
define('HEADING_TITLE_USERS','Gebruikers');
define('MENU_HEADING_MODULES','Modules');
define('BOX_HEADING_USERS','Gebruikers');
define('BOX_HEADING_BACKUP','Bedrijfs Backup');
define('BOX_HEADING_ENCRYPTION','Data versleuteling');
define('BOX_IMPORT_EXPORT','Import/Export');
define('BOX_COMPANY_MANAGER','Bedrijfs Manager');
define('BOX_HEADING_ADMIN_TOOLS','Administratieve Tools');
define('BOX_HEADING_CONFIGURATION','Module Administratie');
define('BOX_GENERAL_ADMIN','Algemene Instellingen');
define('BOX_HEADING_DEBUG_DL','Download Debug Bestand');

?>
