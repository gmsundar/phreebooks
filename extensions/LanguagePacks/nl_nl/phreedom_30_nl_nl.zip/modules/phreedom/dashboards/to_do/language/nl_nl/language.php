<?php
// +-----------------------------------------------------------------+
// Phreedom Language Translation File
// Generated: 2011-01-21 08:31:23
// +-----------------------------------------------------------------+
// Path: /modules/phreedom/dashboards/to_do/language/nl_nl/language.php

define('CP_TO_DO_TITLE','Mijn Te Doen Lijst');
define('CP_TO_DO_DESCRIPTION','Maakt een lijst met uit te voeren activiteiten en taken.');
define('CP_TO_DO_NO_RESULTS','Geen restultaten gevonden');
define('CP_TO_DO_SECURITY',4);
?>
