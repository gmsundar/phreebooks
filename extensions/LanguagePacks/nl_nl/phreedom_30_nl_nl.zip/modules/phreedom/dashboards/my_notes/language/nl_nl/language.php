<?php
// +-----------------------------------------------------------------+
// Phreedom Language Translation File
// Generated: 2011-01-21 08:31:13
// +-----------------------------------------------------------------+
// Path: /modules/phreedom/dashboards/my_notes/language/nl_nl/language.php

define('CP_MY_NOTES_TITLE','Mijn Aantekening');
define('CP_MY_NOTES_DESCRIPTION','Maak Notities en herinneringen.');
define('CP_MY_NOTES_NO_RESULTS','Geen resultaten!');
define('CP_MY_NOTES_SECURITY',4);
?>
