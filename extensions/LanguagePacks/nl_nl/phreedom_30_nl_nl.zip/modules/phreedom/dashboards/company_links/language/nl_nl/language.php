<?php
// +-----------------------------------------------------------------+
// Phreedom Language Translation File
// Generated: 2011-01-21 08:31:08
// +-----------------------------------------------------------------+
// Path: /modules/phreedom/dashboards/company_links/language/nl_nl/language.php

define('CP_COMPANY_LINKS_TITLE','Bedrijfs Links');
define('CP_COMPANY_LINKS_DESCRIPTION','Lijst met URLs voor alle gebruikers binnen het bedrijf. ');
define('CP_COMPANY_LINKS_NO_RESULTS','Geen resultaten!');

define('CP_COMPANY_LINKS_SECURITY',4);
?>
