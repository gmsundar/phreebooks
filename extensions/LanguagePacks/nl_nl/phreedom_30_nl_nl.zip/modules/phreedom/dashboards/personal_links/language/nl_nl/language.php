<?php
// +-----------------------------------------------------------------+
// Phreedom Language Translation File
// Generated: 2011-01-21 08:31:17
// +-----------------------------------------------------------------+
// Path: /modules/phreedom/dashboards/personal_links/language/nl_nl/language.php

define('CP_PERSONAL_LINKS_TITLE','Mijn Links');
define('CP_PERSONAL_LINKS_DESCRIPTION','lijst URLs voor persoonlijk gebruik als quicklinks.');
define('CP_PERSONAL_LINKS_NO_RESULTS','Geen resultaten gevonden!');
define('CP_PERSONAL_LINKS_SECURITY',4);
?>
