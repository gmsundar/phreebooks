<?php
// +-----------------------------------------------------------------+
// Phreedom Language Translation File
// Generated: 2011-01-21 08:32:03
// +-----------------------------------------------------------------+
// Path: /modules/shipping/methods/freeshipper/language/nl_nl/language.php

define('MODULE_SHIPPING_FREESHIPPER_TEXT_TITLE','Gratis Verzending!');
define('MODULE_SHIPPING_FREESHIPPER_TITLE_SHORT','Gratis Verzending');
define('MODULE_SHIPPING_FREESHIPPER_TEXT_DESCRIPTION','Gratis Verzending');
define('MODULE_SHIPPING_FREESHIPPER_TITLE_DESC','De titel welke gebruikt moet worden in weergaven. ');
define('MODULE_SHIPPING_FREESHIPPER_COST_DESC','Wat zijn de verzend kosten?');
define('MODULE_SHIPPING_FREESHIPPER_HANDLING_DESC','Kosten voor deze verzend optie');
define('MODULE_SHIPPING_FREESHIPPER_SORT_ORDER_DESC','Volgorde van tonen. Bepaalt in welke volgorde deze optie in lijsten voor moet komen.');
define('freeshipper_1DEam','Beste optie');
define('freeshipper_1Dam','Zender betaald 2 dagen');
define('freeshipper_1Dpm','Zender betaald 1 dag');
define('freeshipper_2Dpm','Koerier');
define('freeshipper_3Dpm','Zender betaald voordelig');
define('freeshipper_GND','Locale levering');
define('freeshipper_GDR','Klant haalt op');
define('SHIPPING_FREESHIPPER_SHIPMENTS_ON','Gratis Verzendingen op ');

?>
