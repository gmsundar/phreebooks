<?php
// +-----------------------------------------------------------------+
// Phreedom Language Translation File
// Generated: 2011-01-21 08:31:55
// +-----------------------------------------------------------------+
// Path: /modules/shipping/methods/flat/language/nl_nl/language.php

define('MODULE_SHIPPING_FLAT_TEXT_TITLE','Vast Tarief');
define('MODULE_SHIPPING_FLAT_TEXT_DESCRIPTION','Vast Tarief');
define('MODULE_SHIPPING_FLAT_TITLE_DESC','De titel welke gebruikt moet worden in weergaven. ');
define('MODULE_SHIPPING_FLAT_COST_DESC','Wat zijn de verzend kosten?');
define('MODULE_SHIPPING_FLAT_SORT_ORDER_DESC','Volgorde van tonen. Bepaalt in welke volgorde deze optie in lijsten voor moet komen.');
define('flat_1DEam','Beste optie');
define('flat_1Dam','Zender betaald 2 dagen');
define('flat_1Dpm','Zender betaald 1 dag');
define('flat_2Dpm','Koerier');
define('flat_3Dpm','Zender betaald voordelig');
define('flat_GND','Locale levering');
define('flat_GDR','Klant haalt op');
define('SHIPPING_FLAT_SHIPMENTS_ON','Vast Tarief Verzendingen op ');

?>
