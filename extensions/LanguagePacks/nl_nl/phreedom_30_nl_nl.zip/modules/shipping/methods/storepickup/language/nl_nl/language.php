<?php
// +-----------------------------------------------------------------+
// Phreedom Language Translation File
// Generated: 2011-01-21 08:32:12
// +-----------------------------------------------------------------+
// Path: /modules/shipping/methods/storepickup/language/nl_nl/language.php

define('MODULE_SHIPPING_STOREPICKUP_TEXT_TITLE','Ophalen in winkel');
define('MODULE_SHIPPING_STOREPICKUP_TEXT_DESCRIPTION','Ophalen door klant in winkel');
define('MODULE_SHIPPING_STOREPICKUP_STATUS_DESC','Wilt u \\\'Ophalen in winkel\\\' Aanbieden?');
define('MODULE_SHIPPING_STOREPICKUP_TITLE_DESC','Titel te gebruiken in de verzend schatter');
define('MODULE_SHIPPING_STOREPICKUP_COST_DESC','Verzend kosten voor alle orders die hier gebruik van maken');
define('MODULE_SHIPPING_STOREPICKUP_SORT_ORDER_DESC','De volgorde van tonen. Bepaalt de volgorde waarin deze optie getoond wordt.');
define('storepickup_1DEam','Beste optie');
define('storepickup_1Dam','Zender betaald 2 Dagen');
define('storepickup_1Dpm','Zender betaald 1 Dagen');
define('storepickup_2Dpm','Koerier');
define('storepickup_3Dpm','Zender betaald Goedkoop');
define('storepickup_GND','Locale levering');
define('storepickup_GDR','Klant ophalen');
define('SHIPPING_STOREPICKUP_SHIPMENTS_ON','Ophalen in winkel op');

?>
