<?php
// +-----------------------------------------------------------------+
// Phreedom Language Translation File
// Generated: 2011-01-21 08:31:46
// +-----------------------------------------------------------------+
// Path: /modules/shipping/language/nl_nl/admin.php

define('MODULE_SHIPPING_TITLE','Verzend Module');
define('MODULE_SHIPPING_DESCRIPTION','De verzend module is een omhulsel voor de gebruiker configureerbare verzendmethoden. Sommige methoden zijn opgenomen in de kernpakket en anderen zijn beschikbaar om te downloaden uit de PhreeSoft website.');
define('CD_10_01_DESC','Stelt de standaard meeteenheid voor alle pakketten. Geldige waarden zijn: <br /> LBS - Ponden <br /> KGS - Kilograms');
define('CD_10_02_DESC','Geldige waarden zijn <br /> USD - Amerikaanse dollar <br /> EUR - Euro');
define('CD_10_03_DESC','Pakket meeteenheid. Geldige waarden zijn: <br />IN - Inches <br /> CM - Centimeters');
define('CD_10_04_DESC','Standaard residentiële verzend doos (niet aangevinkt - Commercieel, aangevinkt - Residentieel)');
define('CD_10_05_DESC','Geef het standaard pakket type te gebruiken bij verzending.');
define('CD_10_06_DESC','Geeft de standaard type pick-up service voor uw pakket dienst.');
define('CD_10_07_DESC','Voer het standaard pakket lengte in te gebruiken voor een standaard zending.');
define('CD_10_10_DESC','Toon de extra administratiekosten checkbox');
define('CD_10_14_DESC','Toon verzekering selectie optie.');
define('CD_10_20_DESC','Toon de checkbox om zware zendingen worden uitgesplitst voor kleine pakket service.');
define('CD_10_26_DESC','Toon Bevestiging van aflevering Checkbox');
define('CD_10_32_DESC','Toon de administratiekosten selectievakje.');
define('CD_10_38_DESC','Schakel het selectievakje rembours en opties in');
define('CD_10_44_DESC','Toon Zaterdag pickup checkbox');
define('CD_10_48_DESC','Toon Zaterdag Bezorg checkbox');
define('CD_10_52_DESC','Toon Gevaarlijk Materiaal checkbox');
define('CD_10_56_DESC','Toon Droog IJS checkbox');
define('CD_10_60_DESC','Toon retour service checkbox');
define('SHIPPING_METHOD','Selecteer Methode:');
define('SHIPPING_MONTH','Selecteer Maand:');
define('SHIPPING_YEAR','Selecteer Jaar:');
define('SHIPPING_TOOLS_TITLE','Verzendlabel bestand Onderhoud');
define('SHIPPING_TOOLS_CLEAN_LOG_DESC','Deze handeling creëert een gedownload backup van uw verzendetiket bestanden. Dit zal helpen de server opslag grootte en de backup-bestand formaten klein te houden. Back-up van deze bestanden wordt aanbevolen voor het reinigen van oude bestanden om de PhreeBooks transactie geschiedenis te bewaren. <br /> INFORMATIE: Schoonmaak van de verzendlabels houd de huidige records in de verzend manager en logboeken.');

?>
