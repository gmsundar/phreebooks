<?php
// +-----------------------------------------------------------------+
// Phreedom Language Translation File
// Generated: 2011-01-21 08:31:46
// +-----------------------------------------------------------------+
// Path: /modules/shipping/language/nl_nl/menu.php

define('BOX_SHIPPING_MANAGER','Verzendings Manager');

?>
