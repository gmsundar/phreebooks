<?php
// +-----------------------------------------------------------------+
// Phreedom Language Translation File
// Generated: 2011-01-28 04:55:46
// +-----------------------------------------------------------------+
// Path: /modules/phreebooks/language/es_cr/menu.php

define('BOX_PHREEBOOKS_MODULE_ADM','Administración de PhreeBooks');
define('BOX_PRICE_SHEET_MANAGER','Lista de escalas de precios');
define('BOX_GL_BUDGET','Presupuestos');
define('BOX_GL_JOURNAL_ENTRY','Registro contable');
define('BOX_GL_UTILITIES','Utilitarios contabilidad');
define('BOX_BANKING_VOID_CHECKS','Cheques anulados');
define('BOX_BANKING_BANK_ACCOUNT_REGISTER','Registro de cuentas de efectivo');
define('BOX_BANKING_ACCOUNT_RECONCILIATION','Reconciliación de cuentas');
define('BOX_BANKING_SELECT_FOR_PAYMENT','Seleccione para pagar');
define('BOX_BANKING_CUSTOMER_RECEIPTS','Recibo de dinero de clientes');
define('BOX_BANKING_CUSTOMER_PAYMENTS','Pague a clientes');
define('BOX_BANKING_PAY_BILLS','Pague a proveedores');
define('BOX_BANKING_VENDOR_RECEIPTS','Reembolsos de proveedores');
define('BOX_BANKING_VENDOR_DEPOSITS','Depósitos de proveedores');
define('BOX_AP_CREDIT_MEMO','Créditos de proveedores');
define('BOX_AP_RFQ_STATUS','Lista de cotizaciones de proveedores');
define('BOX_BANKING_CUSTOMER_DEPOSITS','Depósitos de clientes');
define('BOX_AR_POINT_OF_PURCHASE','Punto de venta');
define('BOX_AP_PURCHASE_ORDER','Órden de compra nueva');
define('BOX_AP_ORDER_STATUS','Lista de órdenes de compra');
define('BOX_AP_RECEIVE_INVENTORY','Comprar/Ingresar');
define('BOX_AP_RFQ_STATUS','Lista de cotizaciones de proveedores');
define('BOX_AR_INVOICE_MGR','Lista de facturas');
define('BOX_AR_CREDIT_MEMO','Nota de crédito nueva');
define('BOX_AR_QUOTE_STATUS','Lista de cotizaciones a clientes');
define('BOX_AP_REQUEST_QUOTE','Solicitud de cotización a proveedor');
define('BOX_AR_POINT_OF_SALE','Punto de venta');
define('MENU_HEADING_BANKING','Bancos');
define('BOX_AR_QUOTE','Cotización a cliente nueva');
define('BOX_AR_QUOTE_STATUS','Lista de cotizaciones a clientes');
define('BOX_AR_SALES_ORDER','Órden de venta nueva');
define('BOX_AR_ORDER_STATUS','Lista de órdenes de venta');
define('BOX_AR_INVOICE','Factura nueva');
define('MENU_HEADING_GL','Contabilidad');

// Enter the new menu category heading if necessary
define('MENU_HEADING_GL', 'Contabilidad');
define('MENU_HEADING_BANKING','Bancos');
// Menu Titles
define('ORD_TEXT_0_WINDOW_TITLE', 'Saldos iniciales');
define('ORD_TEXT_2_WINDOW_TITLE', 'Registros contables');
define('ORD_TEXT_3_WINDOW_TITLE', 'Solicitud de cotización a proveedor');
define('ORD_TEXT_4_WINDOW_TITLE', 'Órden de compra');
define('ORD_TEXT_6_WINDOW_TITLE', 'Comprar/ingresar');
define('ORD_TEXT_7_WINDOW_TITLE', 'Nota de crédito de proveedor');
define('ORD_TEXT_9_WINDOW_TITLE', 'Cotización a cliente');
define('ORD_TEXT_10_WINDOW_TITLE','Órden de venta');
define('ORD_TEXT_12_WINDOW_TITLE','Factura');
define('ORD_TEXT_13_WINDOW_TITLE','Nota de crédito a cliente');
define('ORD_TEXT_18_WINDOW_TITLE','Recibo de dinero');
define('ORD_TEXT_20_WINDOW_TITLE','Distribución de efectivo');
define('ORD_TEXT_18_WINDOW_TITLE','Recibo de dinero');
define('ORD_TEXT_18_C_WINDOW_TITLE','Recibo de dinero de cliente');
define('ORD_TEXT_18_V_WINDOW_TITLE','Devolución de dinero a proveedor');
define('ORD_TEXT_20_WINDOW_TITLE','Pagar a proveedores');
define('ORD_TEXT_20_C_WINDOW_TITLE','Devolución de dinero a cliente');
define('ORD_TEXT_20_V_WINDOW_TITLE','Pagar');

define('BOX_BANKING_SELECT_FOR_PAYMENT', 'Seleccione para pagar');
define('BOX_BANKING_BANK_ACCOUNT_REGISTER', 'Registro de cuenta de efectivo');
define('BOX_BANKING_ACCOUNT_RECONCILIATION', 'Reconciliación de cuentas');
define('BOX_BANKING_VOID_CHECKS', 'Cheques nulos');
define('BOX_GL_BUDGET', 'Presupuestos');
define('BOX_GL_UTILITIES', 'Utilitarios de contabilidad');
define('BOX_PRICE_SHEET_MANAGER','Listas de escalas de precios');
define('BOX_PHREEBOOKS_MODULE_ADM','Administrador de PhreeBooks');
define('BOX_STATUS_MGR','Lista de %s ');



?>
