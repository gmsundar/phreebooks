<?php
// +-----------------------------------------------------------------+
// Phreedom Language Translation File
// Generated: 2011-01-28 04:55:46
// +-----------------------------------------------------------------+
// Path: /modules/phreebooks/dashboards/todays_sales/language/es_cr/language.php

define('CP_TODAYS_SALES_NO_RESULTS','¡No hay ninguna!');
define('CP_TODAYS_SALES_DESCRIPTION','Lista de ventas del día con vínculos para abrirlas.');
define('CP_TODAYS_SALES_TITLE','Ventas de hoy');
define('CP_TODAYS_SALES_SECURITY',SECURITY_ID_SALES_INVOICE);


?>
