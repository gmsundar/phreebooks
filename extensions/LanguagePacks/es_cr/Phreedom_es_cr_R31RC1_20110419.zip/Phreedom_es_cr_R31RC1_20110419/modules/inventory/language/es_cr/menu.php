<?php
// +-----------------------------------------------------------------+
// Phreedom Language Translation File
// Generated: 2011-01-28 04:55:46
// +-----------------------------------------------------------------+
// Path: /modules/inventory/language/es_cr/menu.php

// Enter the new menu category heading if necessary
define('MENU_HEADING_INVENTORY', 'Inventario');
// Menu Titles
define('BOX_INV_MAINTAIN', 'Lista de códigos');
define('BOX_INV_NEW', 'Agregar códigos');
define('BOX_INV_TRANSFER','Traslado de inventario');
define('ORD_TEXT_14_WINDOW_TITLE','Ensamblajes');
define('ORD_TEXT_16_WINDOW_TITLE','Adjustes de inventario');

?>
