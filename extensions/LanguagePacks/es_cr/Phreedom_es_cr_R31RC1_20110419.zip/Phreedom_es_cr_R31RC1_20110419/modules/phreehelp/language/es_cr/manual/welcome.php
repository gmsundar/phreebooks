<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<!--<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">   -->
 <meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<!-- document position within table of contents; levels separated by dots(.) ie 3.2.4 (one required)-->
<meta name="doc_pos" content="01.0">
<!-- index positions - used to build index list; up to two levels separated by a dot(.) (zero or more) -->
<meta name="doc_index_1" content="Ayuda.Inicio">
<!-- glossay items - used to build glossary (zero or more)-->
<!-- glossary terms are imploded with a colon separator -->
<!-- <meta name="doc_glossary_1" content="term:definition of glossary entry"> -->
<!-- Title - Used as the table of contents and index reference title (one required)-->
<meta name="doc_title" content="Bienvenido a PhreeBooks"> 
<!-- End of meta tags -->

<link rel="stylesheet" type="text/css" href="stylesheet.css">
<title>Bienvenido a PhreeBooks</title>
</head>

<body>

<h1 align="center">Bienvenido a PhreeBooks</h1>
<p>PhreeBooks es una aplicación de contabilidad de código fuente libre diseñado para fácil uso y funcionalidad robusta.  Escrito en PHP y MySQL, PhreeBooks ha sido probado en múltiples plataformas y navegadores para asegurar la mas amplia compatibilidad posible. </p>
<p>Algunos puntos sobresalientes son:</p>
<ul>
  <li>Interfase basada en navegador</li>
  <li>Programa completo de contabilidad</li>
  <li>Total control de inventario incluyendo ensamblajes</li>
  <li>Capacidad de multi-tienda</li>
  <li>Habilidad para lenguajes múltiples</li>
  <li>Sistema de reportes robusto </li>
  <li>Capacidad completa de importar/exportar</li>
  <li>Instalación gráfica fácil</li>
  <li>Extenso nivel de seguridad a nivel de usuario </li>
</ul>
<p>PhreeBooks es publicado bajo la licencia <a href="ch01-Introduction/licencia.html">GNU licencia</a>.</p>
<p>&nbsp;</p>
</body>
</html>
