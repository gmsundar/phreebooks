<?php
// +-----------------------------------------------------------------+
// Phreedom Language Translation File
// Generated: 2011-01-28 04:55:46
// +-----------------------------------------------------------------+
// Path: /modules/phreehelp/language/es_cr/language.php

define('TEXT_MANUAL','Manual');
define('TEXT_NO_RESULTS','No se encontró.  La palabra que quiere buscar debe contener por lo menos cuatro letras y no ser una palabra común.');
define('TEXT_UNTITLED','Documento sin título');
define('TEXT_SEARCH_RESULTS','Los resultados de la búsqueda:');
define('TEXT_FORWARD','Adelante');
define('TEXT_SUPPORT','Soporte en-línea por PhreeSoft');
define('TEXT_KEYWORD','Digite la palabra clave que desea encontrar:');
define('TEXT_FOLDER','Carpeta');
define('TEXT_DOCUMENT','Documento');
define('TEXT_EXIT','Salir');
define('HEADING_CONTENTS','Contenido');
define('HEADING_INDEX','Índice');
define('HEADING_TITLE','Phreebooks Ayuda - Impulsada por PhreeAyuda');

?>
