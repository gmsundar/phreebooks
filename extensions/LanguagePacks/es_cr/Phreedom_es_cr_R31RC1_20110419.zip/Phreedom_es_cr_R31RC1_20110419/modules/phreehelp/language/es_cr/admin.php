<?php
// +-----------------------------------------------------------------+
// Phreedom Language Translation File
// Generated: 2011-01-28 04:55:46
// +-----------------------------------------------------------------+
// Path: /modules/phreehelp/language/es_cr/admin.php

define('MODULE_PHREEHELP_DESCRIPTION','El módulo PhreeHelp genera pantallas emergentes de ayuda contextual para los módulos. <b>NOTA: ¡Este es un módulo del núcleo por lo que no debe ser desinstalado!</b>');
define('MODULE_PHREEHELP_TITLE','Módulo PhreeHelp');

?>
