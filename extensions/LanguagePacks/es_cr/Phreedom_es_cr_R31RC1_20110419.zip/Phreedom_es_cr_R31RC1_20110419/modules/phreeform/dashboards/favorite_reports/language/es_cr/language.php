<?php
// +-----------------------------------------------------------------+
// Phreedom Language Translation File
// Generated: 2011-01-28 04:55:46
// +-----------------------------------------------------------------+
// Path: /modules/phreeform/dashboards/favorite_reports/language/es_cr/language.php

define('CP_FAVORITE_REPORTS_NO_RESULTS','¡No hay ninguno!');
define('CP_FAVORITE_REPORTS_DESCRIPTION','Lista de reportes favoritos.');
define('CP_FAVORITE_REPORTS_TITLE','Reportes favoritos');
define('CP_FAVORITE_REPORTS_SECURITY',SECURITY_ID_PHREEFORM);

?>
