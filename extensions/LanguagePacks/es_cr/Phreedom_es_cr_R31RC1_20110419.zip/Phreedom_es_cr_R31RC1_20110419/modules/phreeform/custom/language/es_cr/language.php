<?php 
// +-----------------------------------------------------------------+
// |                   PhreeBooks Open Source ERP                    |
// +-----------------------------------------------------------------+
// | Copyright (c) 2008, 2009, 2010 PhreeSoft, LLC                   |
// | http://www.PhreeSoft.com                                        |
// +-----------------------------------------------------------------+
// | This program is free software: you can redistribute it and/or   |
// | modify it under the terms of the GNU General Public License as  |
// | published by the Free Software Foundation, either version 3 of  |
// | the License, or any later version.                              |
// |                                                                 |
// | This program is distributed in the hope that it will be useful, |
// | but WITHOUT ANY WARRANTY; without even the implied warranty of  |
// | MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the   |
// | GNU General Public License for more details.                    |
// |                                                                 |
// | The license that is bundled with this package is located in the |
// | file: /doc/manual/ch01-Introduction/license.html.               |
// | If not, see http://www.gnu.org/licenses/                        |
// +-----------------------------------------------------------------+
//  Path: /modules/phreebooks/custom/language/es_cr/language.php
// 

// PhreeBooks Custom Processing
define('PB_PF_CONTACT_ID','Identificación del contacto');
define('PB_PF_DEF_CURRENCY','Moneda predeterminada');
define('PB_PF_JOURNAL_DESC','Descripción del diario');
define('PB_PF_NULL_DEF_CURRENCY','Nulo 0 - Moneda predeterminada');
define('PB_PF_NULL_POSTED_CURRENCY','Nulo 0 - Moneda de la transacción');
define('PB_PF_ORDER_QTY','Cantidad pedida');
define('PB_PF_POSTED_CURRENCY','Moneda de la transacción');
define('PB_PF_ROUND_DECIMAL','Redondeo de decimales');
define('PB_PF_ROUND_PRECISE','Precisión de redondeo');
define('PB_PF_SHIP_METHOD','Método de envío');
define('PB_PF_TERMS_TO_LANGUAGE','Números a lenguaje');
define('PB_PF_USER_NAME','Nombre de usuario');
define('PB_PF_YES_SKIP_NO','Si, en blanco No');
define('PB_PF_COA_TYPE_DESC','Tipo de catálogo de cuentas');
?>
