<?php
// +-----------------------------------------------------------------+
// |                   PhreeBooks Open Source ERP                    |
// +-----------------------------------------------------------------+
// | Copyright (c) 2008, 2009, 2010, 2011 PhreeSoft, LLC             |
// | http://www.PhreeSoft.com                                        |
// +-----------------------------------------------------------------+
// | This program is free software: you can redistribute it and/or   |
// | modify it under the terms of the GNU General Public License as  |
// | published by the Free Software Foundation, either version 3 of  |
// | the License, or any later version.                              |
// |                                                                 |
// | This program is distributed in the hope that it will be useful, |
// | but WITHOUT ANY WARRANTY; without even the implied warranty of  |
// | MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the   |
// | GNU General Public License for more details.                    |
// +-----------------------------------------------------------------+
//  Path: /modules/phreepos/language/es_cr/classes/pos_builder.php
//
define('RW_EB_RECORD_ID','Número de registro');
define('RW_EB_JOURNAL_ID','Número de diario');
define('RW_EB_STORE_ID','Número de tienda');
define('RW_EB_JOURNAL_DESC','Descripción de registro contable');
define('RW_EB_CLOSED','Cerado');
define('RW_EB_INV_DISCOUNT','Descuento de factura');
define('RW_EB_SALES_TAX','Impuesto de ventas');
define('RW_EB_TAX_AUTH','Autoridad de impuestos');
define('RW_EB_TAX_DETAILS','Detalles de impuestos');
define('RW_EB_INV_SUBTOTAL','Subtotal de factura');
define('RW_EB_INV_TOTAL','Monto de factura');
define('RW_EB_CUR_CODE','Código de moneda');
define('RW_EB_CUR_EXC_RATE','Tipo de cambio');
define('RW_EB_INV_NUM','Número de factura');
define('RW_EB_SALES_REP','Vendedor');
define('RW_EB_AR_ACCT','Cuenta por cobrar');
define('RW_EB_BILL_ACCT_ID','Número de cuenta');
define('RW_EB_BILL_ADD_ID','Número de dirección de cobro');
define('RW_EB_BILL_PRIMARY_NAME','Nombre a quien cobrar');
define('RW_EB_BILL_CONTACT','Contacto persona para cobranzas');
define('RW_EB_BILL_ADDRESS1','Dirección para cobranzas 1');
define('RW_EB_BILL_ADDRESS2','Dirección para cobranzas 1');
define('RW_EB_BILL_CITY','Ciudad/pueblo');
define('RW_EB_BILL_STATE','Estado/provincia');
define('RW_EB_BILL_ZIP','Zona postal');
define('RW_EB_BILL_COUNTRY','Pais');
define('RW_EB_BILL_TELE1','Teléfono 1');
define('RW_EB_BILL_TELE2','Teléfono 2');
define('RW_EB_BILL_FAX','Fax');
define('RW_EB_BILL_TELE4','Teléfono celular');
define('RW_EB_BILL_EMAIL','Correo electrónico');
define('RW_EB_BILL_WEBSITE','Sitio de cliente');
define('RW_EB_CUSTOMER_ID','Número de cliente');
define('RW_EB_ACCOUNT_NUMBER','Número de cuenta');
define('RW_EB_GOV_ID_NUMBER','Número de cédula jurídica');
define('RW_EB_TOTAL_PAID','Monto pagado');
define('RW_EB_PAYMENT_DATE','Fecha de pago');
define('RW_EB_PAYMENT_METHOD','Método de pago');
define('RW_EB_PAYMENT_REF','Referencia de pago');
define('RW_EB_BALANCE_DUE','Saldo');
define('RW_EB_PAYMENT_DETAIL','Detalle de pago');

// Data table defines
define('RW_EB_INV_DESC','factura_descripción');
define('RW_EB_INV_QTY','factura_cantidad');
define('RW_EB_INV_TOTAL_PRICE','factura_monto');
define('RW_EB_INV_UNIT_PRICE','factura_precio_unitario');
define('RW_EB_INV_DISCOUNT','factura_descuento');
define('RW_EB_INV_PRICE','factura_precio');
define('RW_EB_INV_SKU','factura_código');
define('RW_EB_INV_SERIAL_NUM','factura_núm_serie');

?>
