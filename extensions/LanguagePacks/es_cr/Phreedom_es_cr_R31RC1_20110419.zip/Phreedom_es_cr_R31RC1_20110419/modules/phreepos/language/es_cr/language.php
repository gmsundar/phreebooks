<?php
// +-----------------------------------------------------------------+
// |                   PhreeBooks Open Source ERP                    |
// +-----------------------------------------------------------------+
// | Copyright (c) 2008, 2009, 2010, 2011 PhreeSoft, LLC             |
// | http://www.PhreeSoft.com                                        |
// +-----------------------------------------------------------------+
// | This program is free software: you can redistribute it and/or   |
// | modify it under the terms of the GNU General Public License as  |
// | published by the Free Software Foundation, either version 3 of  |
// | the License, or any later version.                              |
// |                                                                 |
// | This program is distributed in the hope that it will be useful, |
// | but WITHOUT ANY WARRANTY; without even the implied warranty of  |
// | MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the   |
// | GNU General Public License for more details.                    |
// +-----------------------------------------------------------------+
//  Path: /modules/phreepos/language/es_cr/language.php
//

// Page Titles
define('BOX_PHREEPOS_RETURN','Punto de venta - Devolución');
define('PHREEPOS_PAYMENT_TITLE','Digite pago');

// General Text
define('TEXT_ADD_UPDATE','Agregue/actualice');
define('TEXT_SUBTOTAL','Subtotal');
define('TEXT_AMOUNT_PAID','Monto pagado');
define('TEXT_BALANCE_DUE','Saldo');
define('TEXT_PAYMENT','Pago');
define('TEXT_RETURN','Procese devolución');
define('TEXT_DISCOUNT_PERCENT','Porcentaje de descuento');
define('TEXT_REFUND','Devolver dinero al cliente');
define('TEXT_REFUND_METHOD','Forma de pago');
define('TEXT_ENTRIES','Transacciones');

define('PHREEPOS_ITEM_NOTES','El cursor debe estar posicionado sobre el campo del código para que el escaneador de códigos de barra funcione.');
define('PHREEPOS_PAYMENT_NOTES','El cursor debe estar posicionado sobre el primer campo para registrar la información de la tarjeta de crédito.');
define('POS_MSG_DELETE_CONFIRM','¿Está seguro que quiere borrar esta transacción de punto de venta?');

?>
