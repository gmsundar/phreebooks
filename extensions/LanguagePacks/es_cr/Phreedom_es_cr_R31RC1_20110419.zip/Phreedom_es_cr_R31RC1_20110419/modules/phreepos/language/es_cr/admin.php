<?php
// +-----------------------------------------------------------------+
// |                   PhreeBooks Open Source ERP                    |
// +-----------------------------------------------------------------+
// | Copyright (c) 2008, 2009, 2010, 2011 PhreeSoft, LLC             |
// | http://www.PhreeSoft.com                                        |
// +-----------------------------------------------------------------+
// | This program is free software: you can redistribute it and/or   |
// | modify it under the terms of the GNU General Public License as  |
// | published by the Free Software Foundation, either version 3 of  |
// | the License, or any later version.                              |
// |                                                                 |
// | This program is distributed in the hope that it will be useful, |
// | but WITHOUT ANY WARRANTY; without even the implied warranty of  |
// | MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the   |
// | GNU General Public License for more details.                    |
// +-----------------------------------------------------------------+
//  Path: /modules/phreepos/language/es_cr/admin.php
//

// Module information
define('MODULE_PHREEPOS_TITLE','Módulo PhreePOS');
define('MODULE_PHREEPOS_DESCRIPTION','El módulo PhreePOS es la interface de punto de venta. Este módulo es un complemento del módulo Phreebooks y no un sustituto de él.');
// Headings
define('BOX_PHREEPOS_ADMIN','Administración del módulo Punto de venta');
// General Defines
define('PHREEPOS_REQUIRE_ADDRESS_DESC','¿Require la dirección del cliente para toda venta?');
define('PHREEPOS_RECEIPT_PRINTER_NAME_DESC','Nombre de la impresora de recibos tal como está nombrada en las preferencias de impresora del computador local.');
?>
