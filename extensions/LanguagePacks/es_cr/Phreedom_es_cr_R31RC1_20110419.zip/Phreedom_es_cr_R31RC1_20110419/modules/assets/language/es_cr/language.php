<?php
// +-----------------------------------------------------------------+
// Phreedom Language Translation File
// Generated: 2011-01-28 04:55:45
// +-----------------------------------------------------------------+
// Path: /modules/assets/language/es_cr/language.php

define('ASSETS_MSG_DELETE_ASSET','¿Esta seguro que quiere eliminar este activo?');
define('ASSETS_MSG_RENAME_INTRO','Nuevo número de activo.');
define('ASSETS_ENTRY_IMAGE_PATH','Ubicación de la imagen');
define('ASSETS_MSG_COPY_INTRO','Digite la identificación del nuevo activo.');
define('ASSETS_PURCHASE_CONDITION','Condición de compra');
define('ASSETS_DATE_LAST_JOURNAL_DATE','Fecha de retiro');
define('ASSETS_DATE_ACCOUNT_CREATION','Fecha de compra');
define('ASSETS_DATE_LAST_UPDATE','Última fecha de mantenimiento');
define('ASSETS_ENTRY_ASSETS_SERIALIZE','Serie # o VIN');
define('ASSETS_ENTRY_ACCT_COS','Cuenta de mantenimiento');
define('ASSETS_ENTRY_ACCT_SALES','Cuenta de activo');
define('ASSETS_ENTRY_ACCT_INV','Cuenta de depreciación');
define('ASSETS_ENTRY_FULL_PRICE','Costo original');
define('ASSETS_ENTRY_ASSETS_TYPE','Tipo de activo');
define('ASSETS_ENTER_ASSET_ID','Crear un activo nuevo');
define('ASSETS_ENTRY_ASSET_TYPE','Tipo de activo');
define('ASSETS_HEADING_NEW_ITEM','Activo nuevo');
define('TEXT_USED','Usado');
define('TEXT_VEHICLE','Vehículo');
define('TEXT_TABS','Pestaña');
define('TEXT_RETIRE_DATE','Fecha de retiro');
define('TEXT_SOFTWARE','Software');
define('TEXT_NEW_USED','Nuevo/usado');
define('TEXT_IMAGE','Imagen');
define('TEXT_LAND','Lote');
define('TEXT_FURNITURE','Mueble');
define('TEXT_DETAIL_DESCRIPTION','Descripción detallada');
define('TEXT_EQUIP','Equipo y moviliario');
define('TEXT_CONDITION','Condición');
define('TEXT_BUILDING','Edificio');
define('TEXT_COMPUTER','Computador');
define('TEXT_ASSETS','activo');
define('TEXT_ACQ_DATE','Fecha de adquisición');
define('TEXT_ASSET_ID','Identificación #');

?>
