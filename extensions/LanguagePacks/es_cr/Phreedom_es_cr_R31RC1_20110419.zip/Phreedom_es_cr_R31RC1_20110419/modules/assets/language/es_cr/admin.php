<?php
// +-----------------------------------------------------------------+
// Phreedom Language Translation File
// Generated: 2011-01-28 04:55:45
// +-----------------------------------------------------------------+
// Path: /modules/assets/language/es_cr/admin.php

define('INV_FIELD_NAME_RULES','Los nombres de campo no pueden contener espacios o caracteres<br />especiales y deben tener 64 o menos caracteres');
define('INV_LABEL_TIME_STAMP_FIELD','Sello con la hora');
define('INV_LABEL_TIME_STAMP_VALUE','Campo del sistema para control de la última fecha y hora que se hizo un cambio a un código de inventario en particular.');
define('INV_LABEL_CHECK_BOX_FIELD','Casilla para marcar (opciones: Sí o No)');
define('INV_LABEL_DATE_TIME_FIELD','Fecha y hora');
define('INV_LABEL_RADIO_FIELD','Selección mediante botón de radio<br />Digite las opciones, separadas por comas así:<br />valor1:desc1:def1,valor2:desc2:def2<br /><u>Clave:</u><br />valor = El valor para poner en la base de datos<br />desc = Descripción de la opción<br />def = Valor predeterminado 0 ó 1, siendo 1 el valor predeterminado<br />Nota: Solo se permite un valor predeterminado de 1 por lista');
define('INV_LABEL_DEFAULT_DISPLAY_VALUE','Formato a mostrar (máx, decimales)');
define('INV_LABEL_DROP_DOWN_FIELD','Lista plegable');
define('INV_LABEL_DECIMAL_RANGE','Rango decimal');
define('INV_LABEL_DECIMAL_FIELD','Número decimal');
define('INV_LABEL_INTEGER_FIELD','Número entero');
define('INV_LABEL_INTEGER_RANGE','Rango de números enteros');
define('INV_LABEL_IMAGE_LINK','Nombre de archivo de imagen');
define('INV_LABEL_INVENTORY_LINK','Enlace de ítem de inventario (enlace apuntando a otro ítem de inventario (URL))');
define('INV_LABEL_HYPERLINK','Enlace');
define('INV_LABEL_TEXT_FIELD','Campo de texto');
define('INV_LABEL_HTML_TEXT_FIELD','Código HTML');
define('INV_LABEL_CHOICES','Digite selección');
define('INV_LABEL_MAX_255','(para longitudes de menos de 256 caracteres )');
define('INV_LABEL_FIXED_255_CHARS','Fijo de 255 caracteres máximo');
define('INV_LABEL_DEFAULT_TEXT_VALUE','Valor predeterminado: ');
define('INV_LABEL_MAX_NUM_CHARS','Máximo número de caracteres (longitud)');
define('INV_CATEGORY_MEMBER','Miembro de categoría:');
define('ASSETS_TABS_LOG','Pestaña activos - ');
define('INV_FIELD_NAME','Campo: ');
define('ASSETS_INFO_DELETE_ERROR','El nombre de la pestaña ya existe.  Use otro nombre.');
define('ASSETS_INFO_INSERT_INTRO','Digite la nueva pestaña y sus propiedades');
define('ASSETS_INFO_DELETE_INTRO','Está seguro que quiere borrar esta pestaña?\\nPestañas no se pueden borrar si existe un campo asignado a la pestaña.');
define('ASSETS_INFO_CATEGORY_NAME','Pestaña<br />El nombre debe ser corto (10) sin caracteres especiales y sin espacios.');
define('INV_TEXT_GREATER_THAN','Mayor que');
define('TEXT_SGL_PREC','Precisión sencilla');
define('TEXT_DBL_PREC','Doble precisión');
define('TEXT_EDIT_FIELD','Edite el campo del activo');
define('TEXT_EDIT_TAB','Edite la pestaña del activo');
define('TEXT_NEW_FIELD','Campo de activo nuevo');
define('TEXT_ASSET_TABS','Pestañas de activos');
define('TEXT_NEW_TAB','Pestaña de activo nueva');
define('TEXT_ASSET_FIELDS','Pestañas de activos');
define('BOX_ASSETS_ADMIN','Administración de módulo de activos');
define('MODULE_ASSETS_DESCRIPTION','El módulo activos mantiene la informacion de la propiedad de la compañía. El módulo permite la creación de pestañas y campos adicionales de acuerdo a las necesidades del usuario.');
define('MODULE_ASSETS_TITLE','Módulo Activos');

?>
