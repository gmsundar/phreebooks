<?php
// +-----------------------------------------------------------------+
// Phreedom Language Translation File
// Generated: 2011-01-28 04:55:47
// +-----------------------------------------------------------------+
// Path: /modules/translator/language/es_cr/admin.php

define('MODULE_TRANSLATOR_DESCRIPTION','El módulo traductor es una interface que facilita la traduccion del programa de un idioma a otro. Este módulo sirve para actualizar versiones anteriores así como también para iniciar nuevas traducciones.');
define('MODULE_TRANSLATOR_TITLE','Módulo Traductor');

?>
