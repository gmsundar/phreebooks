<?php
// +-----------------------------------------------------------------+
// Phreedom Language Translation File
// Generated: 2011-01-28 04:55:46
// +-----------------------------------------------------------------+
// Path: /modules/shipping/methods/storepickup/language/es_cr/language.php


define('SHIPPING_STOREPICKUP_SHIPMENTS_ON','Recoje el cliente el ');
define('storepickup_GDR','Recoje el cliente');
define('storepickup_GND','Entrega a domicilio');
define('storepickup_3Dpm','Económica pagado por el que envía');
define('storepickup_2Dpm','Curier');
define('storepickup_1Dam','2 días pagado por el que envía');
define('storepickup_1Dpm','1 día pagado por el que envía');
define('storepickup_1DEam','Mejor modo');
define('MODULE_SHIPPING_STOREPICKUP_SORT_ORDER_DESC','Orden para mostrar. Determina el órden en que el método aparece en las listas.');
define('MODULE_SHIPPING_STOREPICKUP_COST_DESC','¿Cual es el costo del flete?');
define('MODULE_SHIPPING_STOREPICKUP_HANDLING_DESC','Cargo por manejo para este método de envío.');
define('MODULE_SHIPPING_STOREPICKUP_TITLE_DESC','Título para mostrar en el estimador de tarifas de envíos');
define('MODULE_SHIPPING_STOREPICKUP_TEXT_DESCRIPTION','El cliente recoje en tienda');
define('MODULE_SHIPPING_STOREPICKUP_TEXT_TITLE','Recoje en tienda');
define('MODULE_SHIPPING_STOREPICKUP_STATUS_DESC','¿Quiere ofrecer tarifa para recojer en tienda?');

?>
