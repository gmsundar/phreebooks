<?php
// +-----------------------------------------------------------------+
// Phreedom Language Translation File
// Generated: 2011-01-28 04:55:46
// +-----------------------------------------------------------------+
// Path: /modules/shipping/methods/item/language/es_cr/language.php

define('SHIPPING_ITEM_SHIPMENTS_ON','Envío por ítem el ');
define('item_GDR','Recoje el cliente');
define('item_GND','Entrega a domicilio');
define('item_3Dpm','Económica pagado por el que envía');
define('item_2Dpm','Curier');
define('item_1Dam','2 días pagado por el que envía');
define('item_1Dpm','1 día pagado por el que envía');
define('item_1DEam','Mejor modo');
define('MODULE_SHIPPING_ITEM_SORT_ORDER_DESC','Orden para mostrar. Determina el órden en que el método aparece en las listas.');
define('MODULE_SHIPPING_ITEM_HANDLING_DESC','Cargo por manejo para este método de envío.');
define('MODULE_SHIPPING_ITEM_TITLE_DESC','Título para mostrar en el estimador de tarifas de envíos');
define('MODULE_SHIPPING_ITEM_TEXT_DESCRIPTION','Por ítem');
define('MODULE_SHIPPING_ITEM_TEXT_TITLE','Por ítem');
define('MODULE_SHIPPING_ITEM_STATUS_DESC','¿Quiere ofrecer tarifa para recojer en tienda?');
define('MODULE_SHIPPING_ITEM_COST_DESC','El costo de envío sera multiplicado por el número de ítems en una órden que usa este método de envío.')

?>
