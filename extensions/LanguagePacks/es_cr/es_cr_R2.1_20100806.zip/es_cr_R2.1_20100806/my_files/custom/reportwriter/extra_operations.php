<?php
// Extra pull down options on forms
$PaperSizes['HL:215.9:139.7'] = 'Media Carta';

?>
