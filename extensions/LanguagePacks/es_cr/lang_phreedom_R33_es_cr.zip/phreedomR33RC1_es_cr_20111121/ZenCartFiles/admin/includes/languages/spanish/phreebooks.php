<?php
/**
 * @module PhreeBooks
 * @copyright Copyright 2010 PhreeSoft LLC
 * @copyright Portions Copyright 2003-2006 Zen Cart Development Team
 * @copyright Portions Copyright 2003 osCommerce
 * @license http://www.zen-cart.com/license/2_0.txt GNU Public License V2.0
 * @version $Id: /admin/language/english/phreebooks.php $
 */

define('HEADING_TITLE_MODULES_PHREEBOOKS', 'Interfase PhreeBooks ERP');

define('TABLE_HEADING_MODULES', 'Módulos');
define('TABLE_HEADING_SORT_ORDER', 'Número de ordenamiento');
define('TABLE_HEADING_ACTION', 'Acción');

?>
