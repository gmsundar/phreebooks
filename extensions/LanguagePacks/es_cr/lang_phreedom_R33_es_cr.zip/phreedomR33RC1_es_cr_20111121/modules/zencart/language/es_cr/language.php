<?php
// Path: /modules/zencart/language/es_cr/language.php
//
define('ZENCART_PRODUCT_SYNC','Sincronización de productos ZenCart');
define('ZENCART_SHIP_CONFIRM','Confirmación de envíos ZenCart');
define('ZENCART_BULK_UPLOAD','Cargar en bloque ZenCart');
define('ZENCART_UPLOAD_PRODUCT','Cargar producto ZenCart');
define('ZENCART_INVALID_SKU','Hubo un error con la identificación del producto de inventario, no se encontro en la base de datos');
define('ZENCART_INVALID_ACTION','Se solicitó una acción inválida. ¡Abortando!');
define('ZENCART_ERROR_NO_PRICE_SHEET','No se encontró un escala de precios predeterminada para:  ');
define('ZENCART_ERROR_CONFRIM_NO_DATA','No se encontraron registros con esta fecha para confirmar con ZenCart.');
define('ZENCART_ERROR_NO_ITEMS','No se seleccionaron artículos de inventario para subir al catálogo de ZenCart.  Buscando el campo de la casilla con nombre de catálogo para identificar los artículos a subir.');
define('ZENCART_SHIP_CONFIRM_BTN','Confirme envíos');
define('ZENCART_TEXT_CONFIRM_ON','Para órdenes enviados el');
define('ZENCART_SHIP_CONFIRM_TEXT','Envíe confirmación de envíos');
define('ZENCART_SHIP_CONFIRM_INFO','Confirma todos los envíos en la fecha seleccionada del administrador de envíos y fija el estatus en ZenCart. Actualiza órdenes completadas y parcialmente enviadas. No envía notificaciones a los clientes por correo electrónico.');
define('ZENCART_SHIP_CONFIRM_TITLE','Confirme envíos');
define('ZENCART_PRODUCT_SYNC_BTN','Sincronice');
define('ZENCART_PRODUCT_SYNC_TEXT','Sincronice productos con Zencart');
define('ZENCART_PRODUCT_SYNC_INFO','Sincronice productos activos en la base de datos de PhreeBooks (marcados para mostrar en el catálogo y activos) con la lista actual de ZenCart. Muestra los códigos que no deben estar en Zencart. Deben ser eliminados de ZenCart manualmente a través del módulo admin de ZenCart.');
define('ZENCART_PRODUCT_SYNC_TITLE','Sincronice códigos');
define('ZENCART_INCLUDE_IMAGES','Incluya imágenes');
define('ZENCART_BULK_UPLOAD_BTN','Cargue en bloque');
define('ZENCART_BULK_UPLOAD_TEXT','Cargue en bloque productos a la tienda de ZenCart');
define('ZENCART_BULK_UPLOAD_INFO','Cargue en bloque todos los productos seleccionado que van a ser mostrados en la tienda de ZenCart.  Las imágenes no se incluyen a no ser que la casilla correspondiente esté marcada.');
define('ZENCART_BULK_UPLOAD_TITLE','Cargue en bloque');
define('ZENCART_IVENTORY_UPLOAD','Cargue a ZenCart');
define('ZENCART_TEXT_ERROR','Error # ');
define('ZENCART_BULK_UPLOAD_SUCCESS','Exitosamente cargados %s código(s) a ZenCart.');
define('ZENCART_CONFIRM_MESSAGE','Su orden se envió %s vía %s %s, con número de seguimiento: %s');
define('BOX_ZENCART_ADMIN','Administración de ZenCart');

?>
