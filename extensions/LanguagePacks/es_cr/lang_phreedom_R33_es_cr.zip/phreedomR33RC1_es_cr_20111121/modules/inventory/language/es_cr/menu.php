<?php
// Path: /modules/inventory/language/es_cr/menu.php
//
// Enter the new menu category heading if necessary
define('MENU_HEADING_INVENTORY', 'Inventario');
// Menu Titles
define('BOX_INV_MAINTAIN', 'Lista de códigos');
define('BOX_INV_NEW', 'Código nuevo');
define('BOX_INV_TRANSFER','Traslado de inventario');
define('ORD_TEXT_14_WINDOW_TITLE','Ensamblaje');
define('ORD_TEXT_16_WINDOW_TITLE','Adjuste de inventario');
define('BOX_PRICE_SHEET_MANAGER','Listas de escalas de precios');
define('BOX_SALES_PRICE_SHEETS','Escalas de precios a clientes');
define('BOX_PURCHASE_PRICE_SHEETS','Escalas de precios de provedores');

?>
