<?php
// Path: /modules/translator/language/es_cr/menu.php
//
define('BOX_TRANSLATOR_MODULE','Asistente de traducción');
define('MENU_HEADING_TRANSLATOR','Traductor de idioma');

?>
