<?php
// Path: /modules/translator/language/es_cr/admin.php
//
define('MODULE_TRANSLATOR_DESCRIPTION','El módulo traductor es una interface que facilita la traducción del programa de un idioma a otro. Este módulo sirve para actualizar versiones anteriores así como también para iniciar nuevas traducciones.');
define('MODULE_TRANSLATOR_TITLE','Módulo Traductor');

?>
