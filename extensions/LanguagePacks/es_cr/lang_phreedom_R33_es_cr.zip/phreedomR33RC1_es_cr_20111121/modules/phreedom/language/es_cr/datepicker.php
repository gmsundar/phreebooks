<?php

//  Path: /modules/phreedom/language/en_us/datepicker.php
//
// English (US) initialization for the jQuery UI date picker plugin.
// Written by Dave. This (English) is a sample file for translation and is loaded by default.
// Translated versions can be found at: http://jquery-ui.googlecode.com/svn/trunk/ui/i18n/
?>
<script type="text/javascript"> // jQuery UI datepicker Calendar translation
jQuery(function($){
	$.datepicker.regional['es'] = {
		closeText: 'Cierre',
		prevText: 'Ante',
		nextText: 'Próx',
		currentText: 'Hoy',
		monthNames: ['Enero','Febrero','Marzo','Abril','Mayo','Junio',
		'Julio','Agosto','Setiembre','Octubre','Noviembre','Diciembre'],
		monthNamesShort: ['Ene', 'Feb', 'Mar', 'Abr', 'May', 'Jun',
		'Jul', 'Ago', 'Set', 'Oct', 'Nov', 'Dic'],
		dayNames: ['Domingo', 'Lunes', 'Martes', 'Miércoles', 'Jueves', 'Viernes', 'Sábado'],
		dayNamesShort: ['Dom', 'Lun', 'Mar', 'Mié', 'Jue', 'Vie', 'Sáb'],
		dayNamesMin: ['Do','Lu','Ma','Mi','Ju','Vi','Sá'],
		weekHeader: 'Sem',
		dateFormat: '<?php echo DATE_FORMAT_CALENDAR; ?>',
		firstDay: 1,
		isRTL: false,
		showMonthAfterYear: true,
		yearSuffix: ''};
	$.datepicker.setDefaults($.datepicker.regional['es']);
});
</script>
