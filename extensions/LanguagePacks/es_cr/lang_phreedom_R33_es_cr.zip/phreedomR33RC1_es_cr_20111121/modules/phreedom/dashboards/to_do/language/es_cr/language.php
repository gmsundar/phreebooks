<?php
// +-----------------------------------------------------------------+
// Phreedom Language Translation File
// Generated: 2011-01-28 04:55:46
// +-----------------------------------------------------------------+
// Path: /modules/phreedom/dashboards/to_do/language/es_cr/language.php

define('CP_TO_DO_NO_RESULTS','¡No hay!');
define('CP_TO_DO_DESCRIPTION','Lista de deberes y pendientes.');
define('CP_TO_DO_TITLE','Mi lista de pendientes');
define('CP_TO_DO_SECURITY',4);

?>
