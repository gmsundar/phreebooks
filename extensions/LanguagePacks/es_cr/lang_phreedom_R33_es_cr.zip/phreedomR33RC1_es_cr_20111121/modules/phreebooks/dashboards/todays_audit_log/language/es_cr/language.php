<?php
//  Path: /modules/phreebooks/dashboards/todays_audit_log/language/es_cr/language.php
//
define('CP_TODAYS_AUDIT_LOG_TITLE','Bitácora de auditoraje de hoy');
define('CP_TODAYS_AUDIT_LOG_DESCRIPTION','Lista de registros de la bitácora de auditoraje de hoy.');
define('CP_TODAYS_AUDIT_LOG_NO_RESULTS','¡No hay ninguno!');
define('CP_TODAYS_AUDIT_LOG_SECURITY',4);

?>
