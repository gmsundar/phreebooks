<?php
// +-----------------------------------------------------------------+
// Phreedom Language Translation File
// Generated: 2011-01-28 04:55:46
// +-----------------------------------------------------------------+
// Path: /modules/phreebooks/dashboards/open_inv/language/es_cr/language.php

define('CP_OPEN_INV_NO_RESULTS','¡No hay ninguna!');
define('CP_OPEN_INV_DESCRIPTION','Lista de facturas no canceladas.  Las facturas tienen vínculos para abrirlas.');
define('CP_OPEN_INV_TITLE','Facturas pendientes');
define('CP_OPEN_INV_SECURITY',SECURITY_ID_SALES_INVOICE);

?>
