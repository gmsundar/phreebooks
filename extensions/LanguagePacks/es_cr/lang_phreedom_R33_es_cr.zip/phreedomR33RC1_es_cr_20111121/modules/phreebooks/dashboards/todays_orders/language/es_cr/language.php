<?php
// +-----------------------------------------------------------------+
// Phreedom Language Translation File
// Generated: 2011-01-28 04:55:46
// +-----------------------------------------------------------------+
// Path: /modules/phreebooks/dashboards/todays_orders/language/es_cr/language.php

define('CP_TODAYS_ORDERS_NO_RESULTS','¡No hay ninguna!');
define('CP_TODAYS_ORDERS_DESCRIPTION','Lista de órdenes de venta de hoy con vínculos para abrirlas.');
define('CP_TODAYS_ORDERS_TITLE','Órdenes de venta de hoy');
define('CP_TODAYS_ORDERS_SECURITY',SECURITY_ID_SALES_ORDER);


?>
