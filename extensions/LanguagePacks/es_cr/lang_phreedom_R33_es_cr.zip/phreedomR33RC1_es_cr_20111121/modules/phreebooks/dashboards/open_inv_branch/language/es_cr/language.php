<?php
//  Path: /modules/phreebooks/dashboards/open_inv_branch/language/es_cr/language.php
//

define('CP_OPEN_INV_BRANCH_TITLE','Facturas pendientes de mi tienda');
define('CP_OPEN_INV_BRANCH_DESCRIPTION','Lista de facturas no canceladas de la tienda predeterminada del usuario.  Las facturas tienen vínculos para abrirlas.');
define('CP_OPEN_INV_BRANCH_SECURITY',SECURITY_ID_SALES_INVOICE);
define('CP_OPEN_INV_BRANCH_NO_RESULTS','¡No hay ninguna!');

?>


