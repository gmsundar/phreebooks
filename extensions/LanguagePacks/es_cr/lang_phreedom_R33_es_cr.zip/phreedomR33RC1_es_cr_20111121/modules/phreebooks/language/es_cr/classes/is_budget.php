<?php
// +-----------------------------------------------------------------+
// Phreedom Language Translation File
// Generated: 2011-01-28 04:55:46
// +-----------------------------------------------------------------+
// Path: /modules/phreebooks/language/es_cr/classes/is_budget.php

define('IS_BUDGET_YTD_BUDGET','Presupuesto año a hoy');
define('IS_BUDGET_CUR_BUDGET','Presupueto actual');
define('IS_BUDGET_LAST_YTD','Último año a hoy');
define('IS_BUDGET_YTD','Año a hoy');
define('IS_BUDGET_LY_CUR','Presente año anterior');
define('IS_BUDGET_CUR_MONTH','Presente mes');
define('IS_BUDGET_ACCOUNT','Cuenta');
define('RW_FIN_NET_INCOME','Utilidad Neta');
define('RW_FIN_EXPENSES','Gastos');
define('RW_FIN_GROSS_PROFIT','Utilidad bruta');
define('RW_FIN_REVENUES','Ingresos');
define('RW_FIN_COST_OF_SALES','Costo de ventas');

?>
