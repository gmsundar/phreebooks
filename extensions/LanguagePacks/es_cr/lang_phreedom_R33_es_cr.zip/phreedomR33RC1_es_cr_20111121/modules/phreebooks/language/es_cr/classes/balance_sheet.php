<?php
// +-----------------------------------------------------------------+
// Phreedom Language Translation File
// Generated: 2011-01-28 04:55:46
// +-----------------------------------------------------------------+
// Path: /modules/phreebooks/language/es_cr/classes/balance_sheet.php

define('RW_FIN_TOTAL_LIABILITIES_CAPITAL','Total Pasivo y Patrimonio');
define('RW_FIN_TOTAL_CAPITAL','Total Patrimonio');
define('RW_FIN_CAPITAL','Patrimonio');
define('RW_FIN_NET_INCOME','Utilidad Neta');
define('RW_FIN_TOTAL_LIABILITIES','Total Pasivos');
define('RW_FIN_LONG_TERM_LIABILITIES','Pasivo a Largo Plazo');
define('RW_FIN_TOTAL_LT_LIABILITIES','Total Pasivo a Largo Plazo');
define('RW_FIN_TOTAL_CUR_LIABILITIES','Total Pasivo a Corto Plazo');
define('RW_FIN_CUR_LIABILITIES','Pasivo Circulante');
define('RW_FIN_TOTAL_ASSETS','Total Activos');
define('RW_FIN_TOTAL_PROP_EQUIP','Total Mobiliario y Equipo');
define('RW_FIN_PROP_EQUIP','Mobiliario y Equipo');
define('RW_FIN_TOTAL_CURRENT_ASSETS','Total Activo Circulante');
define('RW_FIN_CURRENT_ASSETS','Activo Circulante');

?>
