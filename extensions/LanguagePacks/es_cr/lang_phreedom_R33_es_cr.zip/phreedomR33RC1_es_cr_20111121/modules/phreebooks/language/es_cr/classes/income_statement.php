<?php
// +-----------------------------------------------------------------+
// Phreedom Language Translation File
// Generated: 2011-01-28 04:55:46
// +-----------------------------------------------------------------+
// Path: /modules/phreebooks/language/es_cr/classes/income_statement.php

define('RW_FIN_NET_INCOME','Utilidad neta');
define('RW_FIN_EXPENSES','Gastos');
define('RW_FIN_GROSS_PROFIT','Utilidad bruta');
define('RW_FIN_COST_OF_SALES','Costo de ventas');
define('RW_FIN_REVENUES','Ingresos');

?>
