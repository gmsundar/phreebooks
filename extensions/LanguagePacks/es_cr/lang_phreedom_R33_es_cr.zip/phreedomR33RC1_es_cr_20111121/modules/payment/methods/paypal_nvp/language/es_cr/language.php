<?php
// +-----------------------------------------------------------------+
// Phreedom Language Translation File
// Generated: 2011-01-28 04:55:46
// +-----------------------------------------------------------------+
// Path: /modules/payment/methods/paypal_nvp/language/es_cr/language.php

define('MODULE_PAYMENT_PAYPAL_NVP_DECLINE_CODE','Código de rechazo #');
define('MODULE_PAYMENT_PAYPAL_NVP_SUCCESSE_CODE','%s - Transacción #: %s --> CVV2 resultados: %s');
define('MODULE_PAYMENT_PAYPAL_NVP_TEXT_ERROR','¡Error de tarjeta de crédito!');
define('MODULE_PAYMENT_PAYPAL_NVP_NO_DUPS','La tarjeta de crédito no se procesó porque ya había sido procesada. Para volver a hacerle cargo a la tarjeta de crédito, la tarjeta de crédito debe ser válida y no contener ningún caracter *.');
define('MODULE_PAYMENT_PAYPAL_NVP_TEXT_DECLINED_MESSAGE','La transacción de la tarjeta de crédito no se procesó correctamente. Si no dan una razón, la tarjeta fue rechazada por el banco.');
define('MODULE_PAYMENT_PAYPAL_NVP_TEXT_JS_CC_CVV','* Debe digitar el código CVV de 3 ó 4 digitos que está ubicado en la parte de atrás de la tarjeta de crédito.\\n');
define('MODULE_PAYMENT_PAYPAL_NVP_TEXT_JS_CC_NUMBER','* El número de la tarjeta de crédito debe tener al menos \' . CC_NUMBER_MIN_LENGTH . \' caracteres.\\n');
define('MODULE_PAYMENT_PAYPAL_NVP_TEXT_JS_CC_OWNER','* El nombre del dueño de la tarjeta de crédito debe tener una longitud de al menos \' . CC_OWNER_MIN_LENGTH . \' caracteres.\\n');
define('MODULE_PAYMENT_PAYPAL_NVP_TEXT_CVV','CVV Número (<a href=\"javascript:popupWindowCvv()\">\' . \'Más Info\' . \'</a>)');
define('MODULE_PAYMENT_PAYPAL_NVP_TEXT_CREDIT_CARD_EXPIRES','Fecha de vencimiento de la tarjeta:');
define('MODULE_PAYMENT_PAYPAL_NVP_TEXT_CREDIT_CARD_NUMBER','Tarjeta #:');
define('MODULE_PAYMENT_PAYPAL_NVP_TEXT_CREDIT_CARD_OWNER','Primer nombre / Apellidos');
define('MODULE_PAYMENT_PAYPAL_NVP_TEXT_CREDIT_CARD_TYPE','Tipo de tarjeta de crédito:');
define('MODULE_PAYMENT_PAYPAL_NVP_TEXT_CATALOG_TITLE','Tarjeta de crédito');
define('MODULE_PAYMENT_PAYPAL_NVP_LIVE_WDSL','https://www.paypal.com/wsdl/PayPalSvc.wsdl');
define('MODULE_PAYMENT_PAYPAL_NVP_LIVE_CERT_URL','https://api.paypal.com/nvp');
define('MODULE_PAYMENT_PAYPAL_NVP_LIVE_SIG_URL','https://api-3t.paypal.com/nvp');
define('MODULE_PAYMENT_PAYPAL_NVP_SANDBOX_WSDL','https://www.sandbox.paypal.com/wsdl/PayPalSvc.wsdl');
define('MODULE_PAYMENT_PAYPAL_NVP_SANDBOX_CERT_URL','https://api.sandbox.paypal.com/nvp');
define('MODULE_PAYMENT_PAYPAL_NVP_SANDBOX_SIG_URL','https://api-3t.sandbox.paypal.com/nvp');
define('MODULE_PAYMENT_PAYPAL_NVP_SORT_ORDER_DESC','Órden para mostrar. el número mas bajo se muestra de primero en la lista.');
define('MODULE_PAYMENT_PAYPAL_NVP_AUTHORIZATION_TYPE_DESC','¿Quiere que las transacciones de tarjeta de crédito remitidas sean solamente aprobadas o autorizadas y capturadas?');
define('MODULE_PAYMENT_PAYPAL_NVP_TESTMODE_DESC','Modo de transacción usado para procesar órdenes');
define('MODULE_PAYMENT_PAYPAL_NVP_SIG_DESC','Firma electrónica dada por PayPal para accesar el API.');
define('MODULE_PAYMENT_PAYPAL_NVP_PW_DESC','Contraseña para usar el servicio de PayPal Payment Pro:');
define('MODULE_PAYMENT_PAYPAL_NVP_USER_ID_DESC','Nombre de usuario para el servicio de PayPal:');
define('MODULE_PAYMENT_PAYPAL_NVP_TEXT_INTRODUCTION','Cuando en modo de prueba, las tarjetas devuelven un código de aprovado pero no son procesadas.');
define('MODULE_PAYMENT_PAYPAL_NVP_TEXT_DESCRIPTION','Acepte pagos con tarjeta de crédito a través del servicio PayPal NVP');
define('MODULE_PAYMENT_PAYPAL_NVP_TEXT_TITLE','PayPal Payment Pro');

?>
