<?php
// Path: /modules/shipping/methods/freeshipper/language/es_cr/language.php
//
define('SHIPPING_FREESHIPPER_SHIPMENTS_ON','Envíe flete gratis el ');
define('freeshipper_GDR','Recoje el cliente');
define('freeshipper_GND','Entrega a domicilio');
define('freeshipper_3Dpm','Económica pagado por el que envía');
define('freeshipper_2Dpm','Curier');
define('freeshipper_1Dam','2 días pagado por el que envía');
define('freeshipper_1Dpm','1 día pagado por el que envía');
define('freeshipper_1DEam','Mejor modo');
define('MODULE_SHIPPING_FREESHIPPER_SORT_ORDER_DESC','Orden para mostrar. Determina el órden en que el método aparece en las listas.');
define('MODULE_SHIPPING_FREESHIPPER_COST_DESC','¿Cual es el costo del flete?');
define('MODULE_SHIPPING_FREESHIPPER_HANDLING_DESC','Cargo por manejo para este método de envío.');
define('MODULE_SHIPPING_FREESHIPPER_TEXT_DESCRIPTION','Flete gratis');
define('MODULE_SHIPPING_FREESHIPPER_TITLE_DESC','Título para mostrar en el estimador de tarifas de envíos');
define('MODULE_SHIPPING_FREESHIPPER_TITLE_SHORT','Flete gratis');
define('MODULE_SHIPPING_FREESHIPPER_TEXT_TITLE','¡Flete gratis!');

?>
