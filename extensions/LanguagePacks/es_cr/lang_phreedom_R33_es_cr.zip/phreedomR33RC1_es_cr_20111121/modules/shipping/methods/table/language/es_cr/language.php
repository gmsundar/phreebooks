<?php
// Path: /modules/shipping/methods/table/language/es_cr/language.php
//
define('SHIPPING_TABLE_SHIPMENTS_ON','Envíe por tarifario el ');
define('table_GDR','Recoje el cliente');
define('table_GND','Entrega a domicilio');
define('table_3Dpm','Económica pagado por el que envía');
define('table_2Dpm','Curier');
define('table_1Dam','2 días pagado por el que envía');
define('table_1Dpm','1 día pagado por el que envía');
define('table_1DEam','Mejor modo');
define('MODULE_SHIPPING_TABLE_SORT_ORDER_DESC','Orden para mostrar. Determina el órden en que el método aparece en las listas.');
define('MODULE_SHIPPING_TABLE_HANDLING_DESC','Cargo por manejo para este método de envío.');
define('MODULE_SHIPPING_TABLE_TITLE_DESC','Título para mostrar en el estimador de tarifas de envíos');
define('MODULE_SHIPPING_TABLE_STATUS_DESC','¿Quiere ofrecer tarifa para recojer en tienda?');
define('MODULE_SHIPPING_TABLE_MODE_DESC','El costo del envío está basado en el total de la órden o en el total del ítem pedido.');
define('MODULE_SHIPPING_TABLE_COST_DESC','El costo del envío está basado en el costo total o peso de los ítems. Ejemplo: 25:8.50,50:5.50, etc. Hasta 25 cargue 8.50, de allí a 50 cargue 5.50, etc');
define('MODULE_SHIPPING_TABLE_TEXT_DESCRIPTION','Tarifario');
define('MODULE_SHIPPING_TABLE_TEXT_TITLE','Tarifario');

define('MODULE_SHIPPING_TABLE_TITLE_SHORT', 'Tarifa según tabla');

?>
