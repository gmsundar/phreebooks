<?php
// +-----------------------------------------------------------------+
// Phreedom Language Translation File
// Generated: 2011-01-28 04:55:47
// +-----------------------------------------------------------------+
// Path: /modules/translator/language/es_cr/menu.php

define('BOX_TRANSLATOR_MODULE','Asistente de traducción');
define('MENU_HEADING_TRANSLATOR','Traductor de idioma');

?>
