<?php
// +-----------------------------------------------------------------+
// Phreedom Language Translation File
// Generated: 2011-01-28 04:55:47
// +-----------------------------------------------------------------+
// Path: /modules/translator/language/es_cr/language.php

define('TRANS_ERROR_DUPLICATE','Error importando el módulo: %s, idioma: %s, versión: %s, los archivos para ese idioma ya existen. ¡No se hizo el importe!');
define('TRANS_ERROR_NO_SOURCE','¡No se encontró ninguna fuente para la versión del idioma! Importe primero la fuente del idioma.');
define('TRANSLATION_HEADER','Archivo de traducción de idioma Phreedom');
define('TEXT_TRANSLATIONS_SAVED','Se salvaron los registros de la traducción.');
define('TEXT_STATS_VALUES','%s de %s traducido (%s porciento)');
define('TEXT_DEFAULT_TRANSLATION','Traducción actual');
define('TEXT_CONSTANT','Constante definida');
define('MESSAGE_DELETE_TRANSLATION','Está seguro que quiere eliminar esta traducción?');
define('TRANSLATOR_UPLOAD_ZIPFILE','Seleccione el archivo zip para cargar a la base de datos del traductor:');
define('TRANSLATOR_RELEASE_CREATE','Número de versión a crear:');
define('TRANSLATOR_MODULE_CREATE','Asigne esta traducción al módulo:');
define('TRANSLATOR_ISO_CREATE','Idioma ISO a crear (formato xx_xx):');
define('TRANSLATOR_UPLOAD_DESC','Este formulario cargará un archivo de idioma en formato zip y hará el importe de todas las definiciones del idioma a la base de datos del traductor. Sirve para asistir en convertir y actualizar la traducción de versiones anteriores a nuevas versiones o para modificar traducciones a nuevos idiomas.');
define('TRANSLATOR_INSTALL_IMPORT','Nombre del directorio install (al que lo cambió después instalar PhreeBooks):');
define('TRANSLATOR_MODULE_IMPORT','Nombre del módulo a importar:');
define('TRANSLATOR_ISO_EXPORT','Idioma ISO a exportar:');
define('TRANSLATOR_ISO_IMPORT','Idioma ISO a importar (formato xx_xx):');
define('TRANSLATOR_EXPORT_DESC','Esta página exporta todos los módulos de una versión de una traducción dada a un solo archivo en formato .zip.');
define('TRANSLATOR_IMPORT_DESC','Esta página hace el importe de uno o mas módulos instalados a la base de datos del traductor. Si se selecciona el módulo install y al subdirectorio se le ha cambiado el nombre, el nuevo nombre del directorio debe digitarse en el formulario abajo.');
define('TRANSLATOR_NEW_OVERRIDE','Sobre-escriba (si está disponible) un idioma instalado:');
define('TEXT_SOURCE_LANGUAGE','Idioma fuente:');
define('TRANSLATOR_NEW_SOURCE','Módulo fuente:');
define('TRANSLATOR_NEW_DESC','Este formulario crea una nueva versión de la traducción. Si quiere que suponga el nombre de la traducción, basado en las versiones anteriores y que sobre-escriba el idioma fuente, marque la casilla Sobre-escriba y digite el código ISO del idioma a usar. Note que este idioma debe existir en la base de datos del traductor. El módulo fuente y el idioma también deben estar en la base de datos del traductor. (El número de versión será creado automáticamente)');
define('TEXT_CREATE_NEW_TRANSLATION','Crear nueva traducción');
define('TEXT_TRANSLATED','Traducido');
define('TEXT_TRANSLATIONS','Traducciones');
define('TEXT_TRANSLATION','Traducción');
define('TEXT_LANGUAGE_CODE','Código de idioma ISO');
define('TEXT_UPLOAD','Cargar');
define('TEXT_LANGUAGE','Idioma');
define('TEXT_FILTERS','Filtros:');
define('TEXT_APPLY','Aplique');
define('TEXT_EDIT_TRANSLATION','Módulo Traductor');
define('TEXT_UPLOAD_LANGUAGE_FILE','Cargue un archivo de idioma en formato zip a la base de datos del traductor');
define('TEXT_EXPORT_CURRENT_LANGUAGE','Exporte todos para un idioma y versión');
define('TEXT_IMPORT_CURRENT_LANGUAGE','Importe a la base de datos del traductor un idioma actualmente instalado');
define('TEXT_UPLOAD_TRANSLATION','Cargue traducción');
define('TEXT_EXPORT_TRANSLATION','Exporte traducción');
define('TEXT_IMPORT_TRANSLATION','Importe traducción');
define('TEXT_NEW_TRANSLATION','Traducción nueva');
define('BOX_TRANSLATOR_MAINTAIN','Asistente de traducción');

?>
