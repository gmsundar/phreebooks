<?php
// Path: /install/language/es_cr/language.php
//
define('MSG_ERROR_INNODB_NOT_ENABLED','¡InnoDB en MYSQL no está instalado! Phreedom requiere generar transacciones InnoDB con MySQL para operar apropiadamente.');
define('TEXT_GO_TO_COMPANY','Vaya a su compañía');
define('TITLE_FINISH','Termine - Phreedom Solución para la pequeña empresa');
define('MSG_ERROR_CONFIGURE_EXISTS','El archivo includes/configure.php existe.  Esto puede indicar que Phreedom ya ha sido instalado o está siendo re-instalado. ¡Este archivo debe ser removido para completar la instalación exitosamente!');
define('MSG_ERROR_CANNOT_CONNECT_DB','No hay conexión con la base de datos.  Revise su configuración. Hubo un error: ');
define('ERROR_TEXT_DB_PASSWORD_ISEMPTY','La contraseña para la base de datos no puede estar vacía');
define('MSG_ERROR_MODULE_INSTALL','Hubo errores instalando el módulo: %s. Vea los mensajes arriba para mas detalles.');
define('ERROR_TEXT_DB_USERNAME_ISEMPTY','El nombre del usuario de la base de datos está en blanco');
define('ERROR_TEXT_DB_NAME_ISEMPTY','El nombre de la base de datos está en blanco');
define('ERROR_TEXT_DB_HOST_ISEMPTY','El nombre del servidor de base de datos está en blanco');
define('ERROR_TEXT_DB_PREFIX_NODOTS','El prefijo para las tablas de la base de datos no puede contener ninguno de los siguientes caracteres: / o \\\\ o . ');
define('ERROR_TEXT_LOGIN_PASS_NOTEQUAL','Las contraseñas no concuerdan');
define('ERROR_TEXT_LOGIN_PASS_ISEMPTY','La contraseña para Admin está en blanco');
define('ERROR_TEXT_ADMIN_EMAIL_ISEMPTY','El correo electrónico de Admin está en blanco');
define('ERROR_TEXT_ADMIN_USERNAME_ISEMPTY','El nombre del usuario Admin está en blanco');
define('ERROR_TEXT_ADMIN_COMPANY_ISEMPTY','El nombre de la compañía está en blanco');
define('TEXT_FY_YEAR_INFO','Seleccione el primer año para el año fiscal. El mes seleccionado arriba y la selección de este año serán la fecha mas temprana en la que puede digitar transacciones.');
define('TEXT_FY_MONTH_INFO','Seleccione el mes para para empezar su primer período contable. Inicialmente, PhreeBooks fijará el comienzo del período 1 como el primer día del mes seleccionado.');
define('TEXT_DB_PASSWORD','Digite la contraseña para la base de datos');
define('TEXT_DB_USER','Digite el nombre del usuario para la base de datos');
define('TEXT_DB_PREFIX','Si esta base de datos está compartida con otra aplicación, digite el prefijo a usar para esta instalación (use solo caracteres del alfabeto y el caracter de subrayado):');
define('TEXT_DB_NAME','Digite el nombre de la base de datos (la base de datos ya debe existir en el servidor.  Si aún no existe, créalo ya, antes de seguir.)');
define('TEXT_DB_HOST','Digite el nombre del servidor de la base de datos');
define('TEXT_HTTPS_SRVR','Digite el URL del servidor https al directorio raiz para transacciones seguras (usualmente el directorio predeterminado es suficiente)');
define('TEXT_USE_SSL','Use SSL para accesar su compañía (Nota: un certificado SSL válido debe estar instalado en su servidor). Esto puede cambiarse en el futuro si SSL no es necesario en este momento.');
define('TEXT_HTTP_SRVR','Digite el URL para el servidor http al directorio raiz (usualmente el directorio predeterminado es suficiente)');
define('TEXT_USER_EMAIL','Digite la dirección de correo electrónico para el administrador del sitio.');
define('TEXT_UER_PW_CONFIRM','Vuelva a digitar la contraseña del administrador del sitio');
define('TEXT_USER_PASSWORD','Digite la contraseña del administrador del sitio');
define('TEXT_USER_NAME','Digite el nombre del usuario administrador del sitio');
define('TEXT_INSTALL_DEMO_DATA','¿Quiere instalar los datos de demostración para cada módulo si están disponibles? NOTA: Si selecciona Sí, las tablas se van a limpiar antes de grabar los datos de demostración. Use el catálogo de cuentas US Retail.');
define('TEXT_FISCAL_INFO','Información fiscal');
define('TEXT_COMPANY_NAME','Digite un nombre corto para su compañía. Este es el nombre que va a aparecer en el menú plegable cuando vaya a hacer el login.');
define('TEXT_DB_INFO','Información de la base de datos');
define('TEXT_ADMIN_INFO','Información del administrador');
define('TEXT_SRVR_INFO','Información del servidor');
define('TEXT_COMPANY_INFO','Información de la compañía');
define('MSG_INSTALL_INTRO','Digite la información de su compañía, administrador, servidor y base de datos.');
define('TEXT_INSTALL','Instale');
define('TITLE_INSTALL','Instale - Phreedom Solución para la pequeña empresa');
define('TEXT_RECHECK','Vuelva a revisar');
define('INSTALL_ERROR_MY_FILES_DIR','no se puede escribir al directorio /my_files. El instalador necesita tener acceso a este directorio para almacenar los archivos de su compañía.');
define('INSTALL_ERROR_INCLUDES_DIR','no se puede escribir al directorio /includes. El instalador necesita tener acceso a este directorio para crear el archivo de configuración.');
define('INSTALL_ERROR_FTP','la aplicación PHP de su servidor fue instalado sin soporte para FTP. Algunos módulos no pueden operar si esta función no está disponible.');
define('INSTALL_ERROR_XML','la aplicación PHP de su servidor fue instalado sin soporte para XML. Algunos módulos no pueden operar si esta función no está disponible.');
define('INSTALL_ERROR_UPLOAD_DIR','no se pudo encontrar un directorio temporal para cargar archivos en este servidor.');
define('INSTALL_ERROR_UPLOADS','la aplicación PHP de su servidor fue instalado sin soporte cargar archivos. Soporte para cargar archivos es necesario para importar archivos a Phreedom.');
define('INSTALL_ERROR_CURL','la aplicación PHP de su servidor fue instalado sin soporte para cURL. Soporte para cURL es necesarop para comunicaciones seguras para mandar y recibir información a aplicaciones remotas.');
define('INSTALL_ERROR_OPENSSL','su servidor necesita tener openssl instalado.');
define('INSTALL_ERROR_SESSION_SUPPORT','su configuración PHP no tiene sopore de sesión instalado. Se necesita tener soporte de sesión para correr Phreedom.');
define('INSTALL_ERROR_SAFE_MODE','su configuración PHP está en safe mode. Safe mode debe apagarse para instalar Phreedom.');
define('INSTALL_ERROR_REGISER_GLOBALS','register globals debe estar apagado.');
define('TITLE_INSPECT','Inspección - Phreedom Solución para la pequeña empresa');
define('INSTALL_ERROR_PHP_VERSION','La versión de PHP debe ser 5.2 o mayor.');
define('DESC_DISAGREE','He leido los términos de la licencia aquí descritos y NO estoy de acuerdo.');
define('DESC_AGREE','He leido los términos de la licencia aquí descritos y estoy de acuerdo.');
define('TEXT_AGREE','De acuerdo');
define('TEXT_DISAGREE','En desacuerdo');
define('TITLE_WELCOME','Bienvenido - Phreedom Solución para la pequeña empresa');
define('CHARSET','UTF-8');
define('LANGUAGE_TEXT','Idiomas disponibles para la instalación: ');
define('HTML_PARAMS','lang=\"es-CR\" xml:lang=\"es-CR\"');
define('LANGUAGE','Español (CR)');
define('INTRO_WELCOME', '<h2>Bienvenido a Phreedom Solución para la pequeña empresa</h2>
<p>Este guión le asistirá en la instalación de Phreedom y verificar que su servidor cumple con los requisitos mínimos. Necesitará la siguiente información para continuar:</p>
<ul>
  <li>Una base de datos MYSQL que ya exista y la información para accesarla</li>
  <li>Permisos de escritura (777) en el servidor, a los directorios: /includes and /my_files</li>
  <li>Un nombre de usario para el administrator del sistema, una dirección de correo electrónico y una contraseña</li>
  <li>Información de la ruta al servidor SSL (esto es recomendado pero puede ser modificado en el futuro si fuera necesario)</li>
  <li>El primer mes y año del período fiscal para empezar a digitar transacciones</li>
</ul>
<p>Confirme su aceptación a los términos de la licencia y presione Continúe para proceder.</p>');
define('MSG_INSPECT_ERRORS','Se encontraron los siguientes errores de instalación:
<ul>
  <li>Errores (en rosado) deben ser correjidos antes de poder continuar con la instalación.</li>
  <li>Precauciones (en amarillo) no le impedirán continuar con la instalación pero pueda que evitan que algunos módulos trabajen correctamente.</li>
</ul>');
define('INTRO_FINISHED','<h2>¡Felicitaciones!</h2>
<h3>¡Ha concluido exitósamene la instalación de Phreedom&trade; Solución para la pequeña empresa en su sistema!</h3>
<h2>Pasos siguientes</h2>
<p>Ha sido generada una lista de pendientes donde se identifican las acciones necesarias para configurar los módulos instalados. Esta lista le aparecerá en la pizarra de la pantalla de inicio del administrador del sistema. Las modificaciones de los parámetros de configuración y preferencias adicionales para los módulos se pueden hacer a través de Compañía -&gt; Módulo Admin Menú.</p>
<p>Por razones de seguridad, cambie el archivo de configuración para que tenga permisos de solo lectura. Este archivo lo puede encontrar en <strong>/includes/configure.php</strong>. Si habilitó acceso completo  a la carpeta --includes-- para esta instalación, devuélvale los permisos originales. También debe eliminar o cambiarle el nombre a la carpeta <strong>/install</strong> para prevenir re-instalar la aplicación.</p>
<h2>Documentación y soporte</h2>
<p>Phreedom incluye un sistema de ayuda sensible al contexto. Como sucede con otras aplicaciones de fuente libre, esto representa trabajo en progreso pero allí puede encontrar una guía y soporte.</p>
<p>También hay documentación en línea en el sitio de PhreeSoft (<a target="_blank" href="http://www.phreesoft.com">www.PhreeSoft.com</a>). Allí encontrará la documentación mas actualizada de los módulos asi como respuesta a las preguntas frecuentes y soporte para hacerle modificaciones al programa para ajustarse a sus necesidades.</p>
<p>Finalmente, el foro de usuarios localizado en el sitio de PhreeSoft provee soporte de la comunidad y le permite presentar sus preguntas, reportar pulgas y sugerencias. ¡Si está impresionado, siéntase en libertad de comentar! Tenemos una comunidad conocedora, amistosa y dispuesta a ayudarle, que le da la bienvenida.</p>');

?>
