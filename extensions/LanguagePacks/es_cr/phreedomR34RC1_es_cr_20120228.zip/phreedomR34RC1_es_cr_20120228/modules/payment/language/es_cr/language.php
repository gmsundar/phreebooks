<?php

//  Path: /modules/payment/language/es_cr/language.php
//

// Headings 

// General Defines
define('TEXT_MORE_INFO','Más info');
define('MODULE_PAYMENT_CC_TEXT_CATALOG_TITLE', 'Tarjeta de crédito');
define('MODULE_PAYMENT_CC_TEXT_CREDIT_CARD_OWNER', 'Dueño de la tarjeta de crédito:');
define('MODULE_PAYMENT_CC_TEXT_CREDIT_CARD_NUMBER', 'Número de la tarjeta de crédito:');
define('MODULE_PAYMENT_CC_TEXT_CREDIT_CARD_EXPIRES', 'Fecha de vencimiento de la tarjeta de crédito:');
define('MODULE_PAYMENT_CC_TEXT_CVV', 'Número CVV');
define('MODULE_PAYMENT_CC_TEXT_JS_CC_OWNER', '* El nombre del dueño de la tarjeta de crédito debe ser de al menos %s caracteres.');
define('MODULE_PAYMENT_CC_TEXT_JS_CC_NUMBER', '* El número de la tarjeta de crédito debe ser de al menos %s caracteres.');
define('MODULE_PAYMENT_CC_TEXT_JS_CC_CVV', '* Debe digitar el código CVV, de 3 ó 4 dígitos, que se encuentra en la parte posterior de la tarjeta de crédito.');
define('MODULE_PAYMENT_CC_TEXT_DECLINED_MESSAGE', 'La transacción de la tarjeta de crédito no se procesó correctamente. Si no apareció una razón, la tarjeta fue negada por el banco.');
define('MODULE_PAYMENT_CC_NO_DUPS','La transacción de la tarjeta de crédito no fue procesado ya que ya había sido procesada. Para volver a cargar una tarjeta de crédito, la tarjeta de crédito debe ser válida y no puede contener ningún caracter *.');
define('MODULE_PAYMENT_CC_TEXT_ERROR', '¡Error de tarjeta de crédito!');

?>
