<?php
//  Author: Harry Lu @ 2009/08/01
//  Path: /modules/payment/methods/linkpoint_api/language/en_us/language.php
//
 
define('MODULE_PAYMENT_LINKPOINT_API_TEXT_TITLE', 'LinkPoint Gateway');
define('MODULE_PAYMENT_LINKPOINT_API_TEXT_DESCRIPTION','Acepte pagos con tarjeta de crédito a través de LinkPoint/YourPay API payment gateway');

//    define('MODULE_PAYMENT_LINKPOINT_API_TEXT_DESCRIPTION', '<a target="_blank" href="https://secure.linkpt.net/lpcentral/servlet/LPCLogin">Linkpoint/YourPay Merchant Login</a>' . (MODULE_PAYMENT_LINKPOINT_API_TRANSACTION_MODE_RESPONSE != 'LIVE: Production' ? '<br /><br /><strong>Linkpoint/YourPay API Test Card Numbers:</strong><br /><strong>Visa:</strong> 4111111111111111<br /><strong>MasterCard:</strong> 5419840000000003<br /><strong>Amex:</strong> 371111111111111<br /><strong>Discover:</strong> 6011111111111111' : '') . '<br />');
define('MODULE_PAYMENT_LINKPOINT_API_TEXT_INTRODUCTION', '<a target="_blank" href="http://www.zen-cart.com/index.php?main_page=infopages&pages_id=30">Aplicar para  una cuenta</a><br /><br /><a target="_blank" href="https://secure.linkpt.net/lpcentral/servlet/LPCLogin">Area de mercante Linkpoint/YourPay API </a><br /><br /><a target="_blank" href="http://tutorials.zen-cart.com/index.php?article=298">Instrucciones para configurar/resolver problemas</a><br /><br /><strong>Requisitos:</strong><br /><hr />*<strong>LinkPoint o cuenta YourPay</strong> (vea el enlace arriba para inscribirse)<br />*<strong>cURL </strong>Se requiere cURL y debe estar compilado en la version de PHP que corre en su servidor<br />*<strong>El puerto 1129</strong> se usa como canal de comunicación bidireccional, por lo que debe estar abierto en su router/pared de fuego<br />*<strong>Archivo PEM RSA Key </strong>Certificado digital:<br />Para obtener y subir su clave de certificado digital (.PEM):<br />- Ingrese a su cuenta LinkPoint/Yourpay en el sitio de ellos<br />- Presione "Support" en la barra del menú principal.<br />- Presione la palabra "Download Center" bajo Downloads de la casilla lateral de menú.<br />- Presione la palabra "download" al lado de la sección "Store PEM File" al lado derecho de la página.<br />- Digite la información necesaria para empezar a descargar. Deberá digitar su número de seguro social (SSN) o número Tax ID que suministró cuando creó la cuenta mercante.<br />- Suba este archivo a /modules/payment/methods/linkpoint_api/XXXXXX.pem (suministrado por LinkPoint - xxxxxx es su número de tienda)');

define('MODULE_PAYMENT_LINKPOINT_API_LOGIN_DESC','Digite su número de identificación Linkpoint/YourPay.<br />Este es el mismo número que aparece en el archivo del certificado digital PEM para su cuenta.');
define('MODULE_PAYMENT_LINKPOINT_API_TRANSACTION_MODE_RESPONSE_DESC','<strong>Producción:</strong> Use para tiendas en funcionamiento.<br />o seleccione alguna de estas opciones si desea probar el módulo:<br /><strong>Aceptado:</strong> Use para probar forzando una transacción exitosa<br /><strong>Denegado:</strong> Use para probar forzando una transacción denegada');
define('MODULE_PAYMENT_LINKPOINT_API_AUTHORIZATION_MODE_DESC','¿Quiere tramitar solicitudes de transacciones de tarjeta de crédito solamente para ser aprobadas, o para ser cargadas/capturadas inmediatamente?<br />En la mayoría de los casos quiere hacer <strong>Cargo inmediato</strong> para capturar el pago inmediatamente. En algunas situaciones, pueda que prefiera simplemente transacciones de <strong>Autorizar</strong>, y luego, manualmente usar su terminal para formalmente capturar los fondos de pago (especialmente si el monto de pago fluctuará entre el momento de poner la orden y el momento de enviarla)');
define('MODULE_PAYMENT_LINKPOINT_API_FRAUD_ALERT_DESC','¿Quiere ser notificado por correo electrónico sobre actividad de tarjetas de crédito fraudulentas?<br />(envía al correo electrónico del dueño de la tienda)');
define('MODULE_PAYMENT_LINKPOINT_API_STORE_DATA_DESC','Almacene detalles adicionales de cada transacción.  Con la información adicional, podrá hacer labores de auditoraje de actividad fraudulenta mas efectivas y hasta empatar o seguirle la pista a las órdenes entre los registros de Zen Cart y LinkPoint. Puede ver esta información en Admin->Clientes->Historia Linkpoint CC.');
define('MODULE_PAYMENT_LINKPOINT_API_DEBUG_DESC','¿Quire habilitar modo de despulgar?  Con el modo de alerta, el dueño de la tienda recibirá correos electrónicos de transacciones que fallaron.');
define('MODULE_PAYMENT_LINKPOINT_API_TRANSACTION_MODE_DESC','Modo de transacción para procesar órdenes');
define('MODULE_PAYMENT_LINKPOINT_API_SORT_ORDER_DESC','Cualquier monto mayor que cero causará que este modo de pago aparezca en  la página de carro de compras de la orden.');

// general defines
define('TEXT_TEST_SUCCESS','Prueba - Respuesta: aprobada');
define('TEXT_TEST_FAIL','Prueba - Respuesta: denegada');
define('TEXT_DEV_TEST','Desarrollo - prueba');
define('TEXT_OFF','Apagado');
define('TEXT_FAIL_ALERTS','Solo alertas de falla');
define('TEXT_LOG_FILE','Archivo de bitácora');
define('TEXT_LOG_EMAIL','Bitácora y correo electrónico');


  define('MODULE_PAYMENT_LINKPOINT_API_TEXT_CREDIT_CARD_TYPE', 'Tipo de tarjeta de crédito:');
  define('MODULE_PAYMENT_LINKPOINT_API_TEXT_CREDIT_CARD_OWNER', 'Dueño de la tarjeta:');
  define('MODULE_PAYMENT_LINKPOINT_API_TEXT_CREDIT_CARD_NUMBER', 'Número de la tarjeta:');
  define('MODULE_PAYMENT_LINKPOINT_API_TEXT_CVV', 'Número CVV:');
  define('MODULE_PAYMENT_LINKPOINT_API_TEXT_CREDIT_CARD_EXPIRES', 'Fecha de vencimiento:');
  define('MODULE_PAYMENT_LINKPOINT_API_TEXT_JS_CC_OWNER', '* El nombre del dueño de la tarjeta de crédito debe tener al menos ' . CC_OWNER_MIN_LENGTH . ' caracteres.\n');
  define('MODULE_PAYMENT_LINKPOINT_API_TEXT_JS_CC_NUMBER', '* El número de la tarjeta de crédito debe tener al menos ' . CC_NUMBER_MIN_LENGTH . ' caracteres.\n');
  define('MODULE_PAYMENT_LINKPOINT_API_TEXT_JS_CC_CVV', '* Debe digitar el número de 3 ó 4 dígitos que aparece en la parte trasera de la tarjeta de crédito');
  define('MODULE_PAYMENT_LINKPOINT_API_TEXT_ERROR', '¡Error de tarjeta de crédito!');
  define('MODULE_PAYMENT_LINKPOINT_API_TEXT_DECLINED_MESSAGE', 'Tarjeta denegada.  Vuelva a digitar la información de su tarjeta o intente con otra tarjeta, o contacte el dueño de la tienda para solicitar ayuda.');
  define('MODULE_PAYMENT_LINKPOINT_API_TEXT_DECLINED_AVS_MESSAGE', 'Dirección de cobro inválida.  Vuelva a digitar la información de su tarjeta o intente con otra tarjeta, o contacte el dueño de la tienda para solicitar ayuda.');
  define('MODULE_PAYMENT_LINKPOINT_API_TEXT_DECLINED_GENERAL_MESSAGE', 'Su tarjeta ha sido denegada.  Vuelva a digitar la información de su tarjeta o intente con otra tarjeta, o contacte el dueño de la tienda para solicitar ayuda..');
  define('MODULE_PAYMENT_LINKPOINT_API_TEXT_POPUP_CVV_LINK', '¿Qué es esto?');
  define('ALERT_LINKPOINT_API_PREAUTH_TRANS', '***SOLAMENTE AUTORIZACIONES -- LOS CARGOS SERAN RESUELOS LUEGO, POR EL ADMINISTRADOR.***' . "\n");
  define('ALERT_LINKPOINT_API_TEST_FORCED_SUCCESSFUL', 'NOTA: Esta era una transacción de PRUEBA...forzada a devolver una respuesta de ACEPTADA.');
  define('ALERT_LINKPOINT_API_TEST_FORCED_DECLINED', 'NOTA: Esta era una transacción de PRUEBA...forzada a devolver una respuesta de DENEGADA.');
  define('MODULE_PAYMENT_LINKPOINT_API_TEXT_NOT_CONFIGURED', '<b>&nbsp;(NOTA: El módulo aún no ha sido configurado)</b>');
  define('MODULE_PAYMENT_LINKPOINT_API_TEXT_PEMFILE_MISSING', '<b>&nbsp;No se encontró el archivo del certificado xyzxyz.pem.</b>');
  define('MODULE_PAYMENT_LINKPOINT_API_TEXT_ERROR_CURL_NOT_FOUND', 'CURL functions not found - required for Linkpoint API payment module');
  define('MODULE_PAYMENT_LINKPOINT_API_TEXT_DUPLICATE_MESSAGE', 'Usted ha tramitado una transacción duplicada.');
  

  define('MODULE_PAYMENT_LINKPOINT_API_TEXT_FAILURE_MESSAGE', 'Disculpe la inconveniencia pero en este momento no nos podemos comunicar con la compañía de la tarjeta de crédito para autorizaciones. Contacte el dueño de la tienda para otras opciones de pago.');
  // note: the above error can occur as a result of:
     // - port 1129 not open for bidirectional communication 
     // - CURL is not installed or not functioning
     // - incorrect or invalid or "no" .PEM file found in modules/payment/linkpoint_api folder
     // - In general it means that there was no valid connection made to the gateway... it was stopped before it got outside your server
  
  define('MODULE_PAYMENT_LINKPOINT_API_TEXT_GENERAL_ERROR', 'Lo sentimos. Hubo un error del sistema mientras se procesaba su tarjeta. Su informació está segura. Por favor, notifique el dueño de la tienda para otras opciones de pago.');
  // note: the above error is a general error message which is reported when serious and known error conditions occur. Further details are given immediately following the display of this message. If database storage is enabled, details can be found there too.
  
  
  // Admin definitions

  define('MODULE_PAYMENT_LINKPOINT_API_LINKPOINT_ORDER_ID', 'Número de orden Linkpoint:');
  define('MODULE_PAYMENT_LINKPOINT_API_AVS_RESPONSE', 'Respuesta AVS:');
  define('MODULE_PAYMENT_LINKPOINT_API_MESSAGE', 'Mensaje de respuesta:');
  define('MODULE_PAYMENT_LINKPOINT_API_APPROVAL_CODE', 'Código de aprobación:');
  define('MODULE_PAYMENT_LINKPOINT_API_TRANSACTION_REFERENCE_NUMBER', 'Número de referencia:');
  define('MODULE_PAYMENT_LINKPOINT_API_FRAUD_SCORE', 'Calificación de fraude:');
  define('MODULE_PAYMENT_LINKPOINT_API_TEXT_TEST_MODE', '<b>&nbsp;(NOTA: El módulo está en modo de prueba)</b>');
  define('MODULE_PAYMENT_LINKPOINT_API_TEXT_ORDERTYPE', 'Tipo de orden:');


// admin tools:
  define('MODULE_PAYMENT_LINKPOINT_API_TEXT_NO_MATCHING_ORDER_FOUND', 'Error: No se pudo encontrar los detalles de la transacción del registro especificado.');
  define('MODULE_PAYMENT_LINKPOINT_API_ENTRY_REFUND_BUTTON_TEXT', 'Hacer reintegro');
  define('MODULE_PAYMENT_LINKPOINT_API_TEXT_REFUND_CONFIRM_ERROR', 'Error: Solicitó hacer un reintegro pero no marcó la casilla de confirmación.');
  define('MODULE_PAYMENT_LINKPOINT_API_TEXT_INVALID_REFUND_AMOUNT', 'Error: Solicitó hacer un reintegro pero digitó un monto inválido.');
  define('MODULE_PAYMENT_LINKPOINT_API_TEXT_CC_NUM_REQUIRED_ERROR', 'Error: Solicitó hacer un reintegro pero no digitó los cuatro últimos dígitos del número de la tarjeta de crédito.');
  define('MODULE_PAYMENT_LINKPOINT_API_TEXT_REFUND_INITIATED', 'Reintegro iniciado. Número de la transacción : %s - número de la orden: %s');
  define('MODULE_PAYMENT_LINKPOINT_API_TEXT_CAPTURE_CONFIRM_ERROR', 'Error: Solicitó hacer una captura pero no marcó la casilla de confirmación.');
  define('MODULE_PAYMENT_LINKPOINT_API_ENTRY_CAPTURE_BUTTON_TEXT', 'Capturar');
  define('MODULE_PAYMENT_LINKPOINT_API_TEXT_INVALID_CAPTURE_AMOUNT', 'Error: Solicitó hacer un reintegro pero necesita digitar un monto.');
  define('MODULE_PAYMENT_LINKPOINT_API_TEXT_TRANS_ID_REQUIRED_ERROR', 'Error: Necesita especificar un número de la transacción.');
  define('MODULE_PAYMENT_LINKPOINT_API_TEXT_CAPT_INITIATED', 'Captura de fondos iniciado. Monto: %s.  Número de transacción: %s - Código de aprobación: %s');
  define('MODULE_PAYMENT_LINKPOINT_API_ENTRY_VOID_BUTTON_TEXT', 'Anular');
  define('MODULE_PAYMENT_LINKPOINT_API_TEXT_VOID_CONFIRM_ERROR', 'Error: Solicitó hacer una anulación pero no marcó la casilla de confirmación');
  define('MODULE_PAYMENT_LINKPOINT_API_TEXT_VOID_INITIATED', 'Anulación iniciada. Número de transacción: %s - Número de orden: %s ');

  define('MODULE_PAYMENT_LINKPOINT_API_ENTRY_REFUND_TITLE', '<strong>Transacciones de reintegro</strong>');
  define('MODULE_PAYMENT_LINKPOINT_API_ENTRY_REFUND', 'Aquí puede reintegrar fondos a la tarjeta de crédito de cliente original.');
  define('MODULE_PAYMENT_LINKPOINT_API_TEXT_REFUND_CONFIRM_CHECK', 'Marque esta casilla para confirmar su intención: ');
  define('MODULE_PAYMENT_LINKPOINT_API_ENTRY_REFUND_AMOUNT_TEXT', 'Digite el monto que desea reintegrar');
  define('MODULE_PAYMENT_LINKPOINT_API_ENTRY_REFUND_DEFAULT_TEXT', 'digite número de transacción');
  define('MODULE_PAYMENT_LINKPOINT_API_ENTRY_REFUND_CC_NUM_TEXT', 'Digite los últimos 4 dígitos de la tarjeta de crédito a la que va a reintegrar fondos.');
  define('MODULE_PAYMENT_LINKPOINT_API_ENTRY_REFUND_TRANS_ID', 'Digite el número de la transacción original <em>(que usualmente tiene la siguiente apariencia: <strong>1193684363</strong>)</em>:');
  define('MODULE_PAYMENT_LINKPOINT_API_ENTRY_REFUND_TEXT_COMMENTS', 'Notas (serán mostradas en la historia de la orden):');
  define('MODULE_PAYMENT_LINKPOINT_API_ENTRY_REFUND_DEFAULT_MESSAGE', 'Reintegro realizado');
  define('MODULE_PAYMENT_LINKPOINT_API_ENTRY_REFUND_SUFFIX', 'Puede reintegrar fondos de una orden hasta el monto capturado. Debe digitar los últimos 4 dígitos del número de la tarjeta de crédito usado en la orden inicial.<br />No se pueden procesar reintegros si la tarjeta de crédito está vencida. Para reintegrar fondos a una tarjeta vencida, mas bien procese un crédito usando la terminal.');

  define('MODULE_PAYMENT_LINKPOINT_API_ENTRY_CAPTURE_TITLE', '<strong>Transacciones de captura</strong>');
  define('MODULE_PAYMENT_LINKPOINT_API_ENTRY_CAPTURE', 'Puede capturar fondos pre-autorizados:');
  define('MODULE_PAYMENT_LINKPOINT_API_ENTRY_CAPTURE_AMOUNT_TEXT', 'Digite el monto a capturar: ');
  define('MODULE_PAYMENT_LINKPOINT_API_TEXT_CAPTURE_CONFIRM_CHECK', 'Marque esta casilla para confirmar su intención: ');
  define('MODULE_PAYMENT_LINKPOINT_API_ENTRY_CAPTURE_TRANS_ID', 'Digite el número original de la orden <em>(ie: <strong>5138-i4wcYM</strong>)</em> : ');
  define('MODULE_PAYMENT_LINKPOINT_API_ENTRY_CAPTURE_DEFAULT_TEXT', 'digite número de orden');
  define('MODULE_PAYMENT_LINKPOINT_API_ENTRY_CAPTURE_TEXT_COMMENTS', 'Notas (serán mostradas en la historia de la orden):');
  define('MODULE_PAYMENT_LINKPOINT_API_ENTRY_CAPTURE_DEFAULT_MESSAGE', 'Finiquite fondos pre-autorizadas.');
  define('MODULE_PAYMENT_LINKPOINT_API_ENTRY_CAPTURE_SUFFIX', 'La capturas deben hacerse de 2 a 10 días despues de la transacción original, dependiendo de los requisitos del banco mercante. Puede capturar la orden SOLAMENTE UNA VEZ. <br />Asegúrese que el monto especificado esté correcto.<br />Si deja el monto en blanco, en su lugar se usará el monto original.');

  define('MODULE_PAYMENT_LINKPOINT_API_ENTRY_VOID_TITLE', '<strong>Anulación de transacciones</strong>');
  define('MODULE_PAYMENT_LINKPOINT_API_ENTRY_VOID', 'Puede anular una transacción (pre-autorizada/captura/reintegro) que aun no ha sido finiquitada. Digite el número de identificación de la transacción original <em>(usualmente tiene la siguiente apariencia: <strong>1193684363</strong>)</em>:');
  define('MODULE_PAYMENT_LINKPOINT_API_TEXT_VOID_CONFIRM_CHECK', 'Marque esta casilla para confirmar su intención:');
  define('MODULE_PAYMENT_LINKPOINT_API_ENTRY_VOID_DEFAULT_TEXT', 'Digite el número de la transacción.');
  define('MODULE_PAYMENT_LINKPOINT_API_ENTRY_VOID_TEXT_COMMENTS', 'Notas (serán mostradas en la historia de la orden):');
  define('MODULE_PAYMENT_LINKPOINT_API_ENTRY_VOID_DEFAULT_MESSAGE', 'Transacción cancelada');
  define('MODULE_PAYMENT_LINKPOINT_API_ENTRY_VOID_SUFFIX', 'La anulaciones deben completarse antes de que la transacción original sea finiquitada y aparezca en el voucher diario que ocurre a las 7:00PM hora del Pacifico.');


?>
