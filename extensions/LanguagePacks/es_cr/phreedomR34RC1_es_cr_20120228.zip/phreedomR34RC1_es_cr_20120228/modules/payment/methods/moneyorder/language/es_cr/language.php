<?php
// +-----------------------------------------------------------------+
// Phreedom Language Translation File
// Generated: 2011-01-28 04:55:46
// +-----------------------------------------------------------------+
// Path: /modules/payment/methods/moneyorder/language/es_cr/language.php

define('MODULE_PAYMENT_MONEYORDER_SORT_ORDER_DESC','Órden para mostrar. el número mas bajo se muestra de primero en la lista.');
define('MODULE_PAYMENT_MONEYORDER_PAYTO_DESC','Haga los pagos a:');
define('MODULE_PAYMENT_MONEYORDER_TEXT_REF_NUM','Número de referencia');
define('MODULE_PAYMENT_MONEYORDER_TEXT_INTRODUCTION', 'Haga su cheque a nombre de:<br />' . MODULE_PAYMENT_MONEYORDER_PAYTO . '<br />Envíe por correo su pago a:<br />' . nl2br(COMPANY_NAME));
define('MODULE_PAYMENT_MONEYORDER_TEXT_TITLE','Cheque');
define('MODULE_PAYMENT_MONEYORDER_TEXT_DESCRIPTION', 'Pagos via cheque, cheque de gerencia, transferencia electrónica u otra forma de pago directa que no requiere de una conexion a un servidor para autorización.');


?>
