<?php
// +-----------------------------------------------------------------+
// Phreedom Language Translation File
// Generated: 2011-01-28 04:55:46
// +-----------------------------------------------------------------+
// Path: /modules/payment/methods/authorizenet/language/es_cr/language.php

define('MODULE_PAYMENT_AUTHORIZENET_TEXT_VOID_INITIATED','Anulación iniciada. Número de transacción: %s - Aut #: %s ');
define('MODULE_PAYMENT_AUTHORIZENET_TEXT_VOID_CONFIRM_ERROR','Error: Solicitó una anulación pero no marcó la casilla de confirmación.');
define('MODULE_PAYMENT_AUTHORIZENET_ENTRY_VOID_BUTTON_TEXT','Proceda con la anulación');
define('MODULE_PAYMENT_AUTHORIZENET_TEXT_TRANS_ID_REQUIRED_ERROR','Error: necesita especificar el número de transacción.');
define('MODULE_PAYMENT_AUTHORIZENET_TEXT_REFUND_INITIATED','Reintegro iniciado. Número de transacción: %s - Aut #: %s');
define('MODULE_PAYMENT_AUTHORIZENET_TEXT_CC_NUM_REQUIRED_ERROR','Error: Solicitó un reintegro pero no digitó los últimos cuatro dígitos de la tarjeta de crédito.');
define('MODULE_PAYMENT_AUTHORIZENET_TEXT_INVALID_REFUND_AMOUNT','Error: Solicitó un reintegro pero digitó un monto inválido.');
define('MODULE_PAYMENT_AUTHORIZENET_TEXT_REFUND_CONFIRM_ERROR','Error: Solicitó un reintegro pero no marcó la casilla de confirmación.');
define('MODULE_PAYMENT_AUTHORIZENET_ENTRY_REFUND_BUTTON_TEXT','Proceda con un reintegro');
define('MODULE_PAYMENT_AUTHORIZENET_TEXT_AUTHENTICITY_WARNING','ADVERTENCIA: problema de seguridad en el proceso de codificación. Contacte la tienda inmediatamente. Su órden *no* fue autorizada completamente.');
define('MODULE_PAYMENT_AUTHORIZENET_TEXT_DECLINED_MESSAGE','La transacción de la tarjeta de credito no se procesó correctamente. Si no dieron razón, la tarjeta fue rechazada por el banco.');
define('MODULE_PAYMENT_AUTHORIZENET_TEXT_JS_CC_CVV','* Debe digitar el código CVV de 3 ó 4 digitos que está ubicado en la parte de atrás de la tarjeta de crédito.\\n');
define('MODULE_PAYMENT_AUTHORIZENET_TEXT_JS_CC_NUMBER','* El número de la tarjeta de crédito debe tener al menos \' . CC_NUMBER_MIN_LENGTH . \' caracteres.\\n');
define('MODULE_PAYMENT_AUTHORIZENET_TEXT_JS_CC_OWNER','* El nombre del dueño de la tarjeta de crédito debe tener una longitud de al menos \' . CC_OWNER_MIN_LENGTH . \' caracteres.\\n');
define('MODULE_PAYMENT_AUTHORIZENET_TEXT_CVV','CVV Número (<a href=\"javascript:popupWindowCvv()\">\' . \'Más Info\' . \'</a>)');
define('MODULE_PAYMENT_AUTHORIZENET_TEXT_CREDIT_CARD_NUMBER','Tarjeta #:');
define('MODULE_PAYMENT_AUTHORIZENET_TEXT_CREDIT_CARD_EXPIRES','Fecha de vencimiento de la tarjeta:');
define('MODULE_PAYMENT_AUTHORIZENET_TEXT_CREDIT_CARD_OWNER','Dueño de la tarjeta de crédito:');
define('MODULE_PAYMENT_AUTHORIZENET_TEXT_CATALOG_TITLE','Tarjeta de crédito');
define('MODULE_PAYMENT_AUTHORIZENET_SORT_ORDER_DESC','Órden para mostrar. el número mas bajo se muestra de primero en la lista.');
define('MODULE_PAYMENT_AUTHORIZENET_DEBUGGING_DESC','¿Quiere habilitar el modo de despulgar?  El detalle completo de la bitácora de la transacción fallada puede ser enviada por correo electrónico al dueño de la tienda.');
define('MODULE_PAYMENT_AUTHORIZENET_USE_CVV_DESC','¿Quiere pedirle el número CVV de la tarjeta al cliente?');
define('MODULE_PAYMENT_AUTHORIZENET_AUTHORIZATION_TYPE_DESC','¿Quiere que las transacciones de tarjeta de crédito remitidas sean solamente aprobadas o autorizadas y capturadas?');
define('MODULE_PAYMENT_AUTHORIZENET_TESTMODE_DESC','Modo de transacción usado para procesar órdenes');
define('MODULE_PAYMENT_AUTHORIZENET_MD5HASH_DESC','Clave de encripción usada para validar los datos recibidos (MAX 20 CARACTERES, exactamente como aparecen en la cuenta de Authorize.net ). O déjelo en blanco.');
define('MODULE_PAYMENT_AUTHORIZENET_TXNKEY_DESC','Clave de transacción usado para encriptar datos TP data<br />(Vea su cuenta Authorizenet->Security Settings->API Login ID and Transaction Key para mas detalles.)');
define('MODULE_PAYMENT_AUTHORIZENET_LOGIN_DESC','Nombre de usuario API para Login usado para el servicio Authorize.net');
define('MODULE_PAYMENT_AUTHORIZENET_TEXT_DESCRIPTION','Acepte pagos con tarjeta de crédito a través del servicio Authorize.net');
define('MODULE_PAYMENT_AUTHORIZENET_TEXT_TITLE','Authorize.net');

?>
