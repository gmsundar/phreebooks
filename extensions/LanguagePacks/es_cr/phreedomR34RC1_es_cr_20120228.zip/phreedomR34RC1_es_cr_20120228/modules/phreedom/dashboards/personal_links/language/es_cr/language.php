<?php
// Path: /modules/phreedom/dashboards/personal_links/language/es_cr/language.php

define('CP_PERSONAL_LINKS_NO_RESULTS','¡No hay ninguno!');
define('CP_PERSONAL_LINKS_DESCRIPTION','Lista de URL de uso personal.');
define('CP_PERSONAL_LINKS_TITLE','Mis vínculos');
define('CP_PERSONAL_LINKS_SECURITY',SECURITY_ID_MY_PROFILE);

?>
