<?php
// Path: /modules/phreedom/dashboards/company_links/language/es_cr/language.php

define('CP_COMPANY_LINKS_NO_RESULTS','¡No hay ninguno!');
define('CP_COMPANY_LINKS_DESCRIPTION','Lista de URL para todos los usuarios como vínculos de la compañía entera. ');
define('CP_COMPANY_LINKS_TITLE','Vínculos de la compañía');
define('CP_COMPANY_LINKS_SECURITY',SECURITY_ID_PHREEFORM);

?>
