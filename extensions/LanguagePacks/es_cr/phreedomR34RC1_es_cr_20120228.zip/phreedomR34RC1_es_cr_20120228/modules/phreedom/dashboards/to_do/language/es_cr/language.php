<?php
// Path: /modules/phreedom/dashboards/to_do/language/es_cr/language.php

define('CP_TO_DO_NO_RESULTS','¡No hay!');
define('CP_TO_DO_DESCRIPTION','Lista de deberes y pendientes.');
define('CP_TO_DO_TITLE','Mi lista de pendientes');
define('CP_TO_DO_SECURITY',SECURITY_ID_MY_PROFILE);

?>
