<?php
// Path: /modules/phreedom/dashboards/my_notes/language/es_cr/language.php

define('CP_MY_NOTES_NO_RESULTS','¡No hay ninguna!');
define('CP_MY_NOTES_TITLE','Mis notas');
define('CP_MY_NOTES_DESCRIPTION','Lista de notas y recordatorios.');
define('CP_MY_NOTES_SECURITY',SECURITY_ID_MY_PROFILE);

?>
