<?php

// Path: /modules/phreebooks/language/es_cr/classes/acct_recon.php

define('RW_RECON_NCLEARED','No reconciliados');
define('RW_RECON_TPC','Total pagos reconciliados');
define('RW_RECON_TDC','Total depósitos reconciliados');
define('RW_RECON_PCLEARED','Pagos reconciliados');
define('RW_RECON_CLEARED','Transacciones reconciliadas');
define('RW_RECON_DCLEARED','Depósitos reconciliados');
define('RW_RECON_TBD','Marcador de columna');
define('RW_RECON_DIFF','Diferencia sin reconciliar');
define('RW_RECON_DIT','Total de depósitos en tránsito');
define('RW_RECON_LOP','Menos pagos pendientes');
define('RW_RECON_TOP','Total de pagos pendientes');
define('RW_RECON_ADD_BACK','Agregue depósitos en tránsito');
define('RW_RECON_EB','Saldo final');
define('RW_RECON_CD','Salidas de efectivo');
define('RW_RECON_CR','Entradas de efectivo');
define('RW_RECON_BB','Saldo inicial');

?>
