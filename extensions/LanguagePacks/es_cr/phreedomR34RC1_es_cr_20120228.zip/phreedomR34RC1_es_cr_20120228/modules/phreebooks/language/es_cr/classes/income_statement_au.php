<?php

//  Path: /modules/phreebooks/language/es_cr/classes/income_statement_au.php

define('RW_FIN_REVENUES','Ingresos');
define('RW_FIN_COST_OF_SALES','Costo de ventas');
define('RW_FIN_GROSS_PROFIT','Utilidad bruta');
define('RW_FIN_EXPENSES','Gastos');
define('RW_FIN_NET_INCOME','Ingreso neto');

?>
