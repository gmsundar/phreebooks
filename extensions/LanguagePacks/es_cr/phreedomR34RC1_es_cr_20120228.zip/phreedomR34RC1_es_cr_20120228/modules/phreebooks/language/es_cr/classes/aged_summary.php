<?php

// Path: /modules/phreebooks/language/es_cr/classes/aged_summary.php

define('RW_AR_SHIP_DATE','Fecha de envío');
define('RW_AR_CUSTOMER_ID','Cliente');
define('RW_AR_ACCOUNT_NUMBER','Número de cuenta');
define('RW_AR_SHIP_EMAIL','Envío correo electrónico');
define('RW_AR_SHIP_WEBSITE','Envío sitio internet');
define('RW_AR_SHIP_FAX','Envío fax');
define('RW_AR_SHIP_TELE2','Envío teléfono 2');
define('RW_AR_SHIP_COUNTRY','Envío país');
define('RW_AR_SHIP_TELE1','Envío teléfono 1');
define('RW_AR_SHIP_ZIP','Envío código postal');
define('RW_AR_SHIP_CITY','Envío ciudad');
define('RW_AR_SHIP_STATE','Envío provincia/estado');
define('RW_AR_SHIP_ADDRESS2','Envío dirección línea 2');
define('RW_AR_SHIP_CONTACT','Envío contacto');
define('RW_AR_SHIP_ADDRESS1','Envío dirección L1');
define('RW_AR_SHIP_PRIMARY_NAME','Envío nombre principal');
define('RW_AR_SHIP_ADD_ID','Envío identificación de dirección');
define('RW_AR_SHIP_ACCT_ID','Envío identificación de cuenta');
define('RW_AR_BILL_WEBSITE','Cobro sitio internet');
define('RW_AR_BILL_EMAIL','Cobro correo electrónico');
define('RW_AR_BILL_TELE2','Cobro teléfono 2');
define('RW_AR_BILL_FAX','Cobro fax');
define('RW_AR_BILL_TELE1','Cobro teléfono 1');
define('RW_AR_BILL_ZIP','Cobro código postal');
define('RW_AR_BILL_COUNTRY','Cobro país');
define('RW_AR_BILL_STATE','Cobro provincia/estado');
define('RW_AR_BILL_CITY','Cobro ciudad');
define('RW_AR_BILL_ADDRESS1','Cobro dirección línea 1');
define('RW_AR_BILL_ADDRESS2','Cobro dirección línea 2');
define('RW_AR_BILL_CONTACT','Cobro contacto');
define('RW_AR_BILL_PRIMARY_NAME','Cobro nombre principal');
define('RW_AR_BILL_ADD_ID','Cobro identificación dirección');
define('RW_AR_BILL_ACCT_ID','Cobro identificación cuenta');
define('RW_AR_AR_ACCT','Cuenta por cobrar');
define('RW_AR_SALES_REP','Vendedor');
define('RW_AR_PO_NUM','Número de orden de compra');
define('RW_AR_INV_NUM','Número de Factura');
define('RW_AR_CUR_EXC_RATE','Tipo de Cambio');
define('RW_AR_SO_NUM','Número de orden de venta');
define('RW_AR_CUR_CODE','Código de moneda');
define('RW_AR_INV_TOTAL','Monto de la factura');
define('RW_AR_BALANCE_DUE','Saldo pendiente');
define('RW_AR_TAX_AUTH','Autoridad del impuesto');
define('RW_AR_SALES_TAX','Impuesto de ventas');
define('RW_AR_TERMS','Términos');
define('RW_AR_FRT_SERVICE','Servicio de transporte');
define('RW_AR_FRT_TOTAL','Monto flete');
define('RW_AR_FRT_CARRIER','Transportista');
define('RW_AR_CLOSED','Cerrado');
define('RW_AR_STORE_ID','Tienda');
define('RW_AR_JOURNAL_DESC','Descripción del diario');
define('RW_AR_RECORD_ID','No. de registro');
define('RW_AR_JOURNAL_ID','Diario');
define('TEXT_AGE','Edad');
?>
