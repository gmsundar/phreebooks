<?php

// Path: /modules/phreebooks/language/es_cr/classes/balance_sheet.php

define('RW_FIN_TOTAL_LIABILITIES_CAPITAL','Total pasivo y patrimonio');
define('RW_FIN_TOTAL_CAPITAL','Total patrimonio');
define('RW_FIN_CAPITAL','Patrimonio');
define('RW_FIN_NET_INCOME','Utilidad neta');
define('RW_FIN_TOTAL_LIABILITIES','Total pasivos');
define('RW_FIN_LONG_TERM_LIABILITIES','Pasivo a largo plazo');
define('RW_FIN_TOTAL_LT_LIABILITIES','Total pasivo a largo plazo');
define('RW_FIN_TOTAL_CUR_LIABILITIES','Total pasivo a corto plazo');
define('RW_FIN_CUR_LIABILITIES','Pasivo circulante');
define('RW_FIN_TOTAL_ASSETS','Total activos');
define('RW_FIN_TOTAL_PROP_EQUIP','Total mobiliario y equipo');
define('RW_FIN_PROP_EQUIP','Mobiliario y equipo');
define('RW_FIN_TOTAL_CURRENT_ASSETS','Total activo circulante');
define('RW_FIN_CURRENT_ASSETS','Activo circulante');

?>
