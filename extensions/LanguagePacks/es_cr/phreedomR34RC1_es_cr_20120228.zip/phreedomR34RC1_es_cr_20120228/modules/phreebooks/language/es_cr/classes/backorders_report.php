<?php

// Path: /modules/phreebooks/language/es_cr/classes/backorders_report.php

define('RW_BO_QTY_BACKORDER','Pendiente');
define('RW_QTY_IN_STOCK','En inventario');
define('RW_BO_QTY_ORDERED','Pedido');
define('RW_BO_BILL_TELE1','Cobro teléfono 1');
define('RW_BO_BILL_ZIP','Cobro código postal');
define('RW_BO_BILL_COUNTRY','Cobro país');
define('RW_BO_BILL_STATE','Cobro provincia/estado');
define('RW_BO_BILL_CITY','Cobro ciudad');
define('RW_BO_BILL_ADDRESS2','Cobro dirección l2');
define('RW_BO_BILL_ADDRESS1','Cobro dirección l1');
define('RW_BO_BILL_CONTACT','Cobro contacto');
define('RW_BO_BILL_PRIMARY_NAME','Cobro nombre principal');
define('RW_BO_BILL_ADD_ID','Cobro identificación de dirección');
define('RW_BO_BILL_ACCT_ID','Cobro identificación de cuenta');
define('RW_BO_AR_ACCT','Cuenta por cobrar');
define('RW_BO_SALES_REP','Vendedor');
define('RW_BO_PO_NUM','Número de orden de compra');
define('RW_BO_INV_NUM','Número de orden de venta');
define('RW_BO_CUR_EXC_RATE','Tipo de cambio');
define('RW_BO_BALANCE_DUE','Saldo pendiente');
define('RW_BO_CUR_CODE','Código de moneda');
define('RW_BO_INV_TOTAL','Monto de la factura');
define('RW_BO_FRT_SERVICE','Servicio de transporte');
define('RW_BO_SALES_TAX','Impuesto de ventas');
define('RW_BO_TAX_AUTH','Autoridad impuesto');
define('RW_BO_FRT_CARRIER','Tansportista');
define('RW_BO_FRT_TOTAL','Monto de flete');
define('RW_BO_STORE_ID','Tienda');
define('RW_BO_RECORD_ID','No. de registro');

?>
