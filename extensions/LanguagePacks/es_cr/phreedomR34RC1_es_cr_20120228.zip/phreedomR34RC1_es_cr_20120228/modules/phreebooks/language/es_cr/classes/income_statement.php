<?php

// Path: /modules/phreebooks/language/es_cr/classes/income_statement.php

define('RW_FIN_NET_INCOME','Ingreso neto');
define('RW_FIN_EXPENSES','Gastos');
define('RW_FIN_GROSS_PROFIT','Utilidad bruta');
define('RW_FIN_COST_OF_SALES','Costo de ventas');
define('RW_FIN_REVENUES','Ingresos');

?>
