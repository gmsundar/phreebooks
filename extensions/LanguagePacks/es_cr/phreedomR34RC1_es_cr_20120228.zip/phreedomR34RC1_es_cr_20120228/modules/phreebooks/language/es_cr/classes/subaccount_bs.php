<?php

// Path: /modules/phreebooks/language/es_cr/classes/subaccount_bs.php

define('RW_FIN_NET_INCOME','Utilidad neta');
define('RW_RECORD_ID','Posición columnar');
define('RW_SUB_ACT_BAL_SHT_IS_ACCT','0');

?>
