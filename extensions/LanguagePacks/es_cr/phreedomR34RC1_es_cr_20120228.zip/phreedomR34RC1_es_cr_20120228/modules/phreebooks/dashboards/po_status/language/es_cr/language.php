<?php
// Path: /modules/phreebooks/dashboards/po_status/language/es_cr/language.php

define('CP_PO_STATUS_DESCRIPTION','Lista de órdenes de compra pendientes con vínculos para abrirlas.');
define('CP_PO_STATUS_TITLE','Órdenes de compra pendientes');
define('MAX_NUM_PO_LIST',20);
define('CP_PO_STATUS_SECURITY',SECURITY_ID_PURCHASE_ORDER);
define('CP_PO_STATUS_SORT_ORDER','Ordene por fecha de la transacción');
define('CP_PO_STATUS_HIDE_FUTURE','Restrinja la fecha de las órdenes a hoy para atrás');

?>
