<?php
// Path: /modules/phreeform/language/es_cr/admin.php
//

define('PHREEFORM_TOOLS_REBUILD_TITLE','Verificación de estructura / reconstrucción de PhreeForm');
define('PHREEFORM_TOOLS_REBUILD_DESC','Esta herramienta verifica y reconstruye la estructura de los reportes y formularios.  Recarga la estructura de carpetas, verifica que no haya reportes huérfanos y elimina registros de la tabla phreeform que no tienen un reporte o formulario asociado.');
define('PHREEFORM_TOOLS_REBUILD_SUBMIT','Inicie verificación de estructura / reconstrucción');
define('PHREEFORM_TOOLS_REBUILD_SUCCESS','Se reconstruyó exitósamente la tabla de reportes. El número de reportes reconstruidos fue %s. Se colocaron %s reportes huérfanos en la carpeta Miscelaneos.');
define('PF_DEFAULT_ROWSPACE_TEXT','Separación entre renglones de encabezado para reportes (predeterminado: 2)');
define('PF_DEFAULT_PAPERSIZE_TEXT','Tamaño predeterminado del papel a ser usado para reportes y formularios (predeterminado: Carta)');
define('PF_DEFAULT_ORIENTATION_TEXT','Orientación predeterminada del papel a ser usado para reportes y formularios (predeterminado: Vertical)');
define('PF_DEFAULT_TRIM_LENGTH_TEXT','Longitud predeterminada para recortar el nombre de los reportes y formularios para los listados en formato de directorio (predeterminado: 25)');
define('PF_DEFAULT_TITLE2_TEXT','Texto de título predeterminado en el encabezado 2 para reportes (predeterminado: Reporte generado %date%)');
define('PF_DEFAULT_COLUMN_WIDTH_TEXT','Ancho de columna predeterminado a ser usado para reportes en mm (predeterminado: 25)');
define('PF_DEFAULT_MARGIN_TEXT','Márgen de página predeterminado a ser usado para reportes y formularios en mm (predeterminado: 8)');
define('PF_DEFAULT_TITLE1_TEXT','Texto del título predeterminado en el encabezado 1 a ser usado para reportes (predeterminado: %reportname%)');
define('PB_CONVERT_SUCCESS','Se convirtieron exitósamente %s reportes y formularios. Si alguno tuvo errores de conversión, estos aparecieron en el mensaje previo.');
define('BOX_PHREEFORM_MODULE_ADM','Administración de PhreeForm');
define('PB_CONVERT_REPORTS','Convierta reportes .txt a PhreeForm');
define('PB_CONVERT_SAVE_ERROR','Hubo un error salvando la conversión del reporte: %s');
define('MODULE_PHREEFORM_TITLE','Módulo PhreeForm');
define('MODULE_PHREEFORM_DESCRIPTION','El módulo Phreeform contiene todas las herramientas necesarias para imprimir reportes y formularios in formato PDF o HTML. <b>NOTA: ¡Este es un módulo del núcleo por lo que no debe ser desinstalado!</b>');
define('PDF_APP_TEXT','Aplicación predeterminada que genera los PDF. Nota: TCPDF es requerido para codificación UTF-8 y generación de códigos de barra.');

?>
