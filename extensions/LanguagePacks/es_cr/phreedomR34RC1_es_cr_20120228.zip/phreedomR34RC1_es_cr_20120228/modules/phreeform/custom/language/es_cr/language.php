<?php 
//  Path: /modules/phreebooks/custom/language/es_cr/language.php
// 
// PhreeBooks Custom Processing
define('PB_PF_CONTACT_ID','Identificación del contacto');
define('PB_PF_DEF_CURRENCY','Moneda predeterminada');
define('PB_PF_JOURNAL_DESC','Descripción del diario');
define('PB_PF_NULL_DEF_CURRENCY','Nulo 0 - Moneda predeterminada');
define('PB_PF_NULL_POSTED_CURRENCY','Nulo 0 - Moneda de la transacción');
define('PB_PF_ORDER_QTY','Cantidad pedida');
define('PB_PF_POSTED_CURRENCY','Moneda de la transacción');
define('PB_PF_ROUND_DECIMAL','Redondeo de decimales');
define('PB_PF_ROUND_PRECISE','Precisión de redondeo');
define('PB_PF_SHIP_METHOD','Método de envío');
define('PB_PF_TERMS_TO_LANGUAGE','Números a lenguaje');
define('PB_PF_USER_NAME','Nombre de usuario');
define('PB_PF_YES_SKIP_NO','Sí, en blanco No');
define('PB_PF_COA_TYPE_DESC','Tipo de catálogo de cuentas');

?>
