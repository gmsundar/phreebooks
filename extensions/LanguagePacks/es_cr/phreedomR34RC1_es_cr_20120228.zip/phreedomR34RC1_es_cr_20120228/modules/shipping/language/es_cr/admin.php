<?php
// Path: /modules/shipping/language/es_cr/admin.php
//
define('SHIPPING_TOOLS_CLEAN_LOG_DESC','Esta operación descarga un respaldo de sus archivos de etiqueta de envíos. Esto le ayuda a bajar el tamaño del almacenamiento de archivos en el servidor y reducir el tamaño del respaldo del archivo de la compañía. Se recomienda que respalde estos archivos antes de eliminar archivos anteriores para preservar la historia de transacciones de PhreeBooks. <br />INFORMACIÓN: Borrar los archivos de etiquetas de envíos deja intactos los registros actuales en la base de datos del administrador de envíos.');
define('SHIPPING_TOOLS_TITLE','Mantenimiento del archivo para crear etiquetas de envío');
define('SHIPPING_YEAR','Seleccione el año:');
define('SHIPPING_MONTH','Selecione el mes:');
define('SHIPPING_METHOD','Seleccione el método:');
define('CD_10_56_DESC','Muestre casilla hielo seco');
define('CD_10_60_DESC','Muestre casilla de servicio de devolución');
define('CD_10_52_DESC','Muestre casilla de material peligroso');
define('CD_10_48_DESC','Muestre casilla entregue día sábado');
define('CD_10_44_DESC','Muestre la casilla para recoger el día sábado');
define('CD_10_38_DESC','Habilite la casilla de opciones de pago contra entrega');
define('CD_10_32_DESC','Muestre la casilla de cargos por manejo.');
define('CD_10_26_DESC','Muestre la casilla de confirme recibido');
define('CD_10_14_DESC','Muestre la opción de seguros.');
define('CD_10_20_DESC','Muestre la casilla para permitir que envíos pesados sean divididos en paquetes pequeños.');
define('CD_10_10_DESC','Muestre la casilla de cargo por manejo especial');
define('CD_10_07_DESC','Longitud predeterminada del paquete a usar para un envío estandar.');
define('CD_10_06_DESC','Tipo de servicio predeterminado para recojer el paquete.');
define('CD_10_05_DESC','Tipo de paquete predeterminado a usar en envíos.');
define('CD_10_04_DESC','0 - Fija como predeterminado la casilla de envíe a dirección residencial y marcado (dirección comercial)<br />1 - Fija como predeterminado la casilla de envíe a dirección residencial y marcado (dirección residencial)');
define('CD_10_02_DESC','Valores válidos son<br />USD - US Dólares<br />EUR - Euros');
define('CD_10_03_DESC','Unidades de medida del paquete. Valores válidos son:<br />PULG -Pulgadas<br />CM - Centímetros');
define('CD_10_01_DESC','Unidad de medida de peso predeterminada para los pesos de todos los paquetes.  Valores válidos son:<br />LBS - Libra<br />KGS - Kilogramos');
define('MODULE_SHIPPING_DESCRIPTION','El módulo envíos es un programa envolvente para métodos de envío configurables por el usuario. Algunos métodos están incluidos en el paquete núcleo y otros están disponibles para descargar del sitio PhreeSoft.');
define('MODULE_SHIPPING_TITLE','Módulo Envíos');
define('CONTACT_SHIP_FIELD_REQ', 'Requiera que el campo: %s sea digitado para una nueva dirección de envío');

define('TEXT_SHIPPING_PREFS','Configuración del libro de direcciones de envío');
define('PB_PF_SHIP_METHOD','Método de envío');

define('NEXT_SHIPMENT_NUM_DESC','Próximo número de envío');


?>
