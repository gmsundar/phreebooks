<?php
// Path: /modules/shipping/methods/item/language/es_cr/language.php
//
define('item_GND','Por ítem');
define('SHIPPING_ITEM_SHIPMENTS_ON','Envío por ítem el ');
define('MODULE_SHIPPING_ITEM_SORT_ORDER_DESC','Orden para mostrar. Determina el orden en que el método aparece en las listas.');
define('MODULE_SHIPPING_ITEM_HANDLING_DESC','Cargo por manejo para este método de envío.');
define('MODULE_SHIPPING_ITEM_TITLE_DESC','Título para mostrar en el estimador de tarifas de envíos');
define('MODULE_SHIPPING_ITEM_TEXT_TITLE','Por ítem');
define('MODULE_SHIPPING_ITEM_STATUS_DESC','¿Quiere ofrecer tarifa para recojer en tienda?');
define('MODULE_SHIPPING_ITEM_COST_DESC','El costo de envío sera multiplicado por el número de items en una orden que usa este método de envío.');

define('MODULE_SHIPPING_ITEM_TITLE_SHORT', 'Por ítem');
define('MODULE_SHIPPING_ITEM_TEXT_DESCRIPTION', 'Cargo por ítem basado en el número de items enviados.');

?>
