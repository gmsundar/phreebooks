<?php
// Path: /modules/shipping/methods/fedex_v7/language/es_cr/language.php
//
define('MODULE_SHIPPING_FEDEX_V7_2DA','Expres 2 días A.M.');
define('MODULE_SHIPPING_FEDEX_V7_3DA','Smart Post');
define('SHIPPING_FEDEX_RECON_COST_OVER_INV','Fecha de envío: %s Referencia %s, # de seguimiento %s - El costo: (%s) es mayor que el monto facturado: (%s)');
define('GUAR_TIME_RE','19:00:00');
define('GUAR_TIME_GD','17:00:00');
define('GUAR_TIME_CM','15:00:00');
define('GUAR_TIME_2D','16:30:00');
define('GUAR_TIME_P1','10:30:00');
define('GUAR_TIME_PR','12:00:00');
define('GUAR_TIME_A5','10:00:00');
define('GUAR_TIME_A2','08:30:00');
define('GUAR_TIME_A4','09:00:00');
define('GUAR_TIME_A1','08:00:00');
define('SHIPPING_FEDEX_END_OF_DAY','FedEx - Cierre de Fin de Día');
define('SHIPPING_FEDEX_LABEL_DELETED','Etiqueta FedEx - Borrada');
define('SHIPPING_FEDEX_CANNOT_DELETE','Error - No se puede borrar un envío cuya etiqueta no fue generada hoy.');
define('SHIPPING_FEDEX_DELETE_ERROR','Error - No se puede borrar el envío, no hay suficiente información.');
define('SHIPPING_FEDEX_NO_PACKAGES','No habían paquetes para enviar, la cantidad total o el peso es de cero.');
define('SHIPPING_FEDEX_ERROR_POSTAL_CODE','Se necesita un código postal para usar el módulo FedEx');
define('UNKNOWN','Desconocido');
define('NINETEEN_DAYS','Diecinueve días de tránsito');
define('TWENTY_DAYS','Veinte días de tránsito');
define('EIGHTEEN_DAYS','Dieciocho días de tránsito');
define('SEVENTEEN_DAYS','Diecisiete días de tránsito');
define('FIFTEEN_DAYS','Quince días de tránsito');
define('SIXTEEN_DAYS','Sieciseis días de tránsito');
define('FOURTEEN_DAYS','Catorce días de tránsito');
define('THIRTEEN_DAYS','Trece días de tránsito');
define('TWELVE_DAYS','Doce días de tránsito');
define('TEN_DAYS','Diez días de tránsito');
define('ELEVEN_DAYS','Once días de tránsito');
define('NINE_DAYS','Nueve días de tránsito');
define('EIGHT_DAYS','Ocho días de tránsito');
define('SIX_DAYS','Seis días de tránsito');
define('SEVEN_DAYS','Siete días de tránsito');
define('FIVE_DAYS','Cinco días de tránsito');
define('THREE_DAYS','Tres días de tránsito');
define('FOUR_DAYS','Cuatro días de tránsito');
define('TWO_DAYS','Dos días de tránsito');
define('ONE_DAY','Un día de tránsito');
define('SRV_FEDEX_LTL_CLASS','Clase de Carga');
define('TEXT_TRACK_CONFIRM','Confirmación de recibo');
define('SRV_SHIP_FEDEX_LTL_FREIGHT','Carga LTL');
define('SRV_SHIP_FEDEX_EMAIL_NOTIFY','Notificaciones por correo electrónico');
define('SRV_SHIP_FEDEX_BILL_DETAIL','Detalles de facturación');
define('SRV_SHIP_FEDEX_RECP_INFO','Informacion del destinatario');
define('SRV_TRACK_FEDEX_V7','Siga los envíos FedEx de hoy');
define('SRV_SHIP_FEDEX_V7','Envíe un paquete');
define('SRV_LOG_FEDEX_V7','Digite un envío');
define('SHIPPING_FEDEX_V7_CLOSE_SUCCESS','Envíos FedEx de hoy cerrados exitósamente.');
define('SHIPPING_FEDEX_V7_TRACK_FAIL','El paquete con el siguiente número de referencia fue entregado despues de la fecha-hora esperada: ');
define('SHIPPING_FEDEX_V7_TRACK_STATUS','El paquete con el número de referencia: %s no ha sido entregado, el código de estatus es: (Código %s) %s.');
define('SHIPPING_FEDEX_V7_TRACK_SUCCESS','Se le dió seguimiento al paquete exitósamente, referencia # ');
define('SHIPPING_FEDEX_V7_TRACK_ERROR','FedEx seguieminto del paquete error: ');
define('SHIPPING_FEDEX_V7_DEL_SUCCESS','Etiqueta de envío FedEx borrada exitósamente. Seguimiento # ');
define('SHIPPING_FEDEX_V7_DEL_ERROR','FedEx borrar etiqueta error: ');
define('SHIPPING_FEDEX_V7_TNT_ERROR',' FedEx Tiempo en tránsito error # ');
define('SHIPPING_FEDEX_V7_RATE_TRANSIT',' Día(s) de tránsito, llega ');
define('SHIPPING_FEDEX_V7_RATE_CITY_MATCH','El nombre de la ciudad no concuerda con la zonaa postal.');
define('SHIPPING_FEDEX_V7_RATE_ERROR','Error en la tarifas de respuesta de FedEx: ');
define('SHIPPING_FEDEX_CURL_ERROR','Hubo un error en la comunicación con el servidor FedEx:');
define('SHIPPING_FEDEX_V7_SHIPMENTS_ON','Envíos FedEx activo');
define('SHIPPING_FEDEX_V7_HAZMAT_REPORTS','Reporte de hazmat');
define('SHIPPING_FEDEX_V7_MULTIWGHT_REPORTS','Reporte de multipesos');
define('SHIPPING_FEDEX_V7_VIEW_REPORTS','Vea reportes para ');
define('SHIPPING_FEDEX_V7_CLOSE_REPORTS','Reporte de cierre');
define('MODULE_SHIPPING_FEDEX_V7_ECF','Carga por tierra económica');
define('MODULE_SHIPPING_FEDEX_V7_GDF','Carga por tierra prioritaria');
define('MODULE_SHIPPING_FEDEX_V7_3DF','3 días carga');
define('MODULE_SHIPPING_FEDEX_V7_2DF','2 días carga');
define('MODULE_SHIPPING_FEDEX_V7_1DF','1 día carga');
define('MODULE_SHIPPING_FEDEX_V7_XPR','Prioridad int.');
define('MODULE_SHIPPING_FEDEX_V7_XPD','Económica Int.');
define('MODULE_SHIPPING_FEDEX_V7_XDM','Primera Int.');
define('MODULE_SHIPPING_FEDEX_V7_3DS','Expres ahorrativa');
define('MODULE_SHIPPING_FEDEX_V7_2DP','Expres 2 días');
define('MODULE_SHIPPING_FEDEX_V7_1DP','Estandard día siguiente');
define('MODULE_SHIPPING_FEDEX_V7_1DA','Prioridad día siguiente');
define('MODULE_SHIPPING_FEDEX_V7_1DM','Primera día siguiente');
define('MODULE_SHIPPING_FEDEX_V7_GND','Tierra');
define('MODULE_SHIPPING_FEDEX_V7_GDR','Entrega a domicilio');
define('MODULE_SHIPPING_FEDEX_V7_SORT_ORDER_DESC','Orden para mostrar. El valor mas bajo se muestra de primero.');
define('MODULE_SHIPPING_FEDEX_V7_TYPES_DESC','Seleccione el servicio FEDEX para ser ofrecido como predeterminado.');
define('MODULE_SHIPPING_FEDEX_V7_PRINTER_TYPE_DESC','Tipo de impresora para imprimir etiquetas. PDF para papel corriente, termal para impresora FedEx 2844 (vea el archivo de ayuda antes de seleccionar la impresora termal)');
define('MODULE_SHIPPING_FEDEX_V7_TEST_MODE_DESC','Modo prueba/producción usado para probar las etiquetas de envío');
define('MODULE_SHIPPING_FEDEX_V7_METER_NUMBER_DESC','Digite el número del medidor que le dió FedEx.');
define('MODULE_SHIPPING_FEDEX_V7_AUTH_PWD_DESC','Digite la contraseña de programador que le dió FedEx.');
define('MODULE_SHIPPING_FEDEX_V7_AUTH_KEY_DESC','Digite la clave de programador que le dió FedEx.');
define('MODULE_SHIPPING_FEDEX_V7_LTL_ACCOUNT_NUMBER_DESC','Digite el número de cuenta FedEx LTL para usar para estimados de tarifas. Deje este campo en blanco si no va a usar LTL.');
define('MODULE_SHIPPING_FEDEX_V7_ACCOUNT_NUMBER_DESC','Digite el número de cuenta FedEx para usar para estimados de tarifas');
define('MODULE_SHIPPING_FEDEX_V7_TITLE_DESC','Título a usar para mostrar en envíos por FedEx.');
define('MODULE_SHIPPING_FEDEX_V7_TEXT_DESCRIPTION','Federal Express');
define('MODULE_SHIPPING_FEDEX_V7_TITLE_SHORT','FedEx');
define('MODULE_SHIPPING_FEDEX_V7_TEXT_TITLE','Federal Express');
define('DOCTABLOCATION','TOP');
define('DOCTABCONTENT','Zone001');
define('LABELORIENTATION_PDF','PAPER_8.5X11_TOP_HALF_LABEL');
define('LABELORIENTATION_THERMAL','STOCK_4X6.75_LEADING_DOC_TAB');
define('FEDEX_V7_TRACKING_URL','http://www.fedex.com/Tracking?ascend_header=1&amp;clienttype=dotcom&amp;cntry_code=us&amp;language=english&amp;tracknumbers=');


define('MODULE_SHIPPING_FEDEX_V7_TEXT_INTRODUCTION', '<h3>Paso 1. Desarrolle y pruebe la aplicación Web Services Enabled Application</h3>
Este paso ha sido hecho por PhreeSoft. Debe seguir los siguientes pasos para habilitar la generación de etiquetas.
<h3>Paso 2. Registrese para pasar a la modalidad producción</h3>
Comience el proceso de certificación apicando para un número de medidor (FedEx Production Meter Number) en en centro de recursos para desarrolladores (FedEx Developer Resource Center). <a href="http://www.fedex.com/developer">http://www.fedex.com/developer</a>
<h3>Paso 3. Obtenga credenciales de producción</h3>
Obtenga sus credenciales de producción (número de medidor de producción, clave de autenticación de produccción y clave de seguridad de producción) en-línea durante el preoceso de registración. Su clave le debio ser enviada por via aparte en una comunacación via correo electrónico.
Nota: Es necesario un número de medidor de producción para cada uno de sus locales.  Si se permite usar la misma clave de autenticación para múltiples localidades. Se pueden obtener números de medidores adicionales usando el servicio de suscripción avanzado (Subscribe (Advanced) Web Service).
<br />Nota importante: Debido a lo delicado que es esta information, la clave de autenticación de production no se le envía en el correo electrónico de confirmation (Paso 4). Guarde esto para sus registros.
<h3>Paso 4. Reciba el correo electrónico de confirmación</h3>
Recibirá un correo de confirmación via correo electrónico.
<h3>Paso 5. Contacte el equipo de soporte (Regional Web Integration Solutions (WIS) Support Team)</h3>
Contacte el equipo de soluciones (Web Integration Solutions Team) para su región con la información de su aplicación y credenciales de producción. Solicite que su aplicación sea habilitada usando servicios en línea para usar etiquetas de envío. (US &amp; Canada - 1.877.339.2774)
<h3>Paso 6. El equipo regional le proveerá las instrucciones para enviar etiquetas</h3>
El equipo de soporte de su región le enviará un correo electrónico con las instrucciones para certificar las etiquetas generadas por su aplicación.
<h3>Paso 7. Genere y envíe las etiquetas de prueba</h3>
Genere las etiquetas asociadas con la aplicación y envíelas al equipo de evaluacion de etiquetas de FedEx para que sean aprovadas. Los datos de muestra están localizados en /modules/shipping/methods/fedex_v7/sample_data.php. <a href="index.php?module=shipping&amp;page=fedex_v7_qualify" target="_blank">Download Sample Labels</a>
<br />Nota: Los equipos de evaluación de etiquetas de FedEx requieren de cinco días para evaluar sus etiquetas.
<h3>Paso 8. Evaluación de etiquetas</h3>
Los equipos de evaluación de etiquetas de FedEx evalúan las etiquetas enviadas y las aprueban o rechazan. El equipo de apoyo de su región se pondrá en contacto con usted acerca de la aprovación o rechazo de las etiquetas de prueba que usted presentó.  Si las etiquetas son aprobadas, continúe con el paso siguiente. Si las etiquetas fueron rechazadas, corríjalas y vuelva a presentarlas para su aprobación.
<h3>Paso 9. Habilitación de la aplicación por parte del equipo regional WIS/h3>
Una vez que las etiquetas han sido aprobadas para estatus de producción por los equipos de evaluación de etiquetas, el equipo de soporte de su región autoriza su perfil para transmitir las transacciones de etiquetas de envío y le notifica de su certificación exitosa.
<h3>Paso 10. Reemplace el URL y las credenciales</h3>
Reemplace el URL de prueba y pruebe las credenciales con el URL de producción y las credenciales de producción.');

define('MODULE_SHIPPING_FEDEX_V7_LTL_ACCOUNT_NUMBER_DESC','Digite el número de cuenta FedEx LTL a usar para estimados de tarifas. Deje este campo en blanco si no va a usar LTL.');

define('MODULE_SHIPPING_FEDEX_V7_LTL_ACCOUNT_NUMBER_DESC','Digite el número de cuenta FedEx Carga a usar para estimados de tarifas. Deje este campo en blanco si no va a usar LTL.');
define('MODULE_SHIPPING_FEDEX_V7_NAT_ACCOUNT_NUMBER_DESC','Digite el número de cuenta FedEx Natinal LTL a usar para estimados de tarifas. Deje este campo en blanco si no va a usar LTL.');

define('MODULE_SHIPPING_FEDEX_V7_PRINTER_NAME_DESC', 'Define el nombre de la impresora a usar para imprimir etiquetas tal como está definida en las preferencias de impresora del computador local.');

define('MODULE_SHIPPING_FEDEX_V7_GDF','Carga terrestre prioritaria');
define('MODULE_SHIPPING_FEDEX_V7_ECF','Carga terrestre económica');


// Label Manager

define('SHIPPING_FEDEX_RECON_TITLE','Reporte de reconciliación FedEx generado: ');
define('SHIPPING_FEDEX_RECON_INTRO','Factura número: %s con fecha %s');
define('SHIPPING_FEDEX_RECON_NO_RECORDS','Fecha de envío: %s Referencia %s, # de seguimiento %s - No se encontraron registros, envíos de %s a %s costando %s');
define('SHIPPING_FEDEX_RECON_TOO_MANY','Fecha de envío: %s Referencia %s, # de seguimiento %s - Se encontraron demasiadas referencias, envío de %s a %s costando %s');
define('SHIPPING_FEDEX_RECON_COST_OVER','Fecha de envío: %s Referencia %s, # de seguimiento %s - Costo facturado: (%s) costo cotizado: (%s)');
define('SHIPPING_FEDEX_RECON_SUMMARY','Número total de registros reconciliados: %s');
define('TEXT_PRINT_PDF_DOCUMENTS','Imprima documentos PDF (después de terminar de imprimir las etiquetas)');
define('TEXT_PRINT_PAPER','Imprima documentos en papel');
?>
