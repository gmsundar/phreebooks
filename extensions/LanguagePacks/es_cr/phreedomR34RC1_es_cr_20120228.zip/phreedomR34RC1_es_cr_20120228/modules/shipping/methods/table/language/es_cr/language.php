<?php
// Path: /modules/shipping/methods/table/language/es_cr/language.php
//
define('SHIPPING_TABLE_SHIPMENTS_ON','Envíos según tabla el ');
define('table_GND','Tarifa según tabla');
define('MODULE_SHIPPING_TABLE_SORT_ORDER_DESC','Orden para mostrar. Determina el orden en que el método aparece en las listas.');
define('MODULE_SHIPPING_TABLE_HANDLING_DESC','Cargo por manejo para este método de envío.');
define('MODULE_SHIPPING_TABLE_TITLE_DESC','Título para mostrar en el estimador de tarifas de envíos');
define('MODULE_SHIPPING_TABLE_MODE_DESC','El costo del envío está basado en el total de la orden o en el total del ítem pedido.');
define('MODULE_SHIPPING_TABLE_COST_DESC','El costo del envío está basado en el costo total o peso de los items. Ejemplo: 25:8.50,50:5.50, etc. Hasta 25 cargue 8.50, de allí a 50 cargue 5.50, etc');
define('MODULE_SHIPPING_TABLE_TEXT_DESCRIPTION','Tarifario');
define('MODULE_SHIPPING_TABLE_TEXT_TITLE','Tarifario');

define('MODULE_SHIPPING_TABLE_TITLE_SHORT', 'Tarifa según tabla');

?>
