<?php
// Path: /modules/shipping/methods/storepickup/language/es_cr/language.php
//
define('SHIPPING_STOREPICKUP_SHIPMENTS_ON','Recoje el cliente el ');
define('storepickup_GND','Recoje el cliente');
define('MODULE_SHIPPING_STOREPICKUP_SORT_ORDER_DESC','Orden para mostrar. Determina el órden en que el método aparece en las listas.');
define('MODULE_SHIPPING_STOREPICKUP_COST_DESC','¿Cual es el costo del flete?');
define('MODULE_SHIPPING_STOREPICKUP_TITLE_DESC','Título para mostrar en el estimador de tarifas de envíos');
define('MODULE_SHIPPING_STOREPICKUP_TEXT_DESCRIPTION','El cliente recoje en tienda');
define('MODULE_SHIPPING_STOREPICKUP_TEXT_TITLE','Recoje en tienda');
define('MODULE_SHIPPING_STOREPICKUP_STATUS_DESC','¿Quiere ofrecer tarifa para recojer en tienda?');
define('MODULE_SHIPPING_STOREPICKUP_TITLE_SHORT', 'Recoje en tienda');

?>
