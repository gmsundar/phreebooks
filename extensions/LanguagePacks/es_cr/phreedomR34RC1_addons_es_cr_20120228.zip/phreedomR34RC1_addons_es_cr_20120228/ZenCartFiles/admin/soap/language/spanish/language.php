<?php
//  Path: /admin/soap/language/es_cr/language.php
//
define('ZENCART_PRODUCT_TAX_CLASS_ID',2); // sets the record id for the default sales tax to use
// General defines for SOAP interface
define('SOAP_NO_USER_PW','El nombre de usuario y contraseña no se pueden encontrar en el código XML.');
define('SOAP_USER_NOT_FOUND','No es válido el nombre de usuario.');
define('SOAP_PASSWORD_NOT_FOUND','La contraseña no es válida.');
define('SOAP_UNEXPECTED_ERROR','El servidor devolvió un error inesperado en el código.');
define('SOAP_BAD_LANGUAGE_CODE','No se pudo encontrar el código ISO en la tabla de idiomas de Zencart. Se esperaba encontrar el código = ');
define('SOAP_BAD_PRODUCT_TYPE','No se pudo encontrar el tipo de producto en la tabla de Zencart product_types table. Se esperaba encontrar type_name %s para el código %s.');
define('SOAP_BAD_MANUFACTURER','No se pudo encontrar el nombre del fabricante en la tabla de fabricantes de Zencart. Se esperaba encontrar el nombre de fabricante %s para el código %s.');
define('SOAP_BAD_CATEGORY','No se pudo encontrar el nombre de la categoría o no es único en la tabla categories_description de ZenCart. Se esperaba encontrar el nombre de la categoría de %s para el código %s.');
define('SOAP_BAD_CATEGORY_A','El nombre de la categoría no está en el nivel mas bajo del árbol de categorías. ¡Este es un requisito de ZenCart!');
define('SOAP_NO_SKU','No se encontró el código. ¡El código sku debe estar presente en el archivo XML!');
define('SOAP_BAD_ACTION','Se intentó procesar una acción errónea .');
define('SOAP_OPEN_FAILED','Hubo un error abriendo el archivo de imagen para escribir. Intentando escribir a: ');
define('SOAP_ERROR_WRITING_IMAGE','Error salvando un archivo de imagen en el directorio de imágenes de Zencart.');
define('SOAP_PU_POST_ERROR','Hubo un error actualizando el producto enZencart. Descripción - ');
define('SOAP_PRODUCT_UPLOAD_SUCCESS','El producto con código SKU %s se cargó exitósamente.');
define('SOAP_NO_ORDERS_TO_CONFIRM', 'Ninguna orden se cargó para confirmar.');
define('SOAP_CONFIRM_SUCCESS','La confirmación de órdenes se completó exitósamente. El número de órdenes actualizado fue: %s');
define('SOAP_NO_SKUS_UPLOADED','No se cargaron códigos skus para sincronizar.');
define('SOAP_SKUS_MISSING','Los siguientes códigos están en Zencart pero no se marcaron para estar allí por PhreeBooks: ');
define('SOAP_PRODUCTS_IN_SYNC','Los listados de productos entre PhreeBooks y ZenCart están sincronizados.');

?>
