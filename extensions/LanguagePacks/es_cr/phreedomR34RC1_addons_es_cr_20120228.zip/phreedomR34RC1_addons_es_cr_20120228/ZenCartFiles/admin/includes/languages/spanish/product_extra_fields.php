<?php

// Rene Kervezee

define('HEADING_TITLE', 'Opciones de producto adicionales');
define('TABLE_HEADING_EXTRA_VELDEN', 'Campos de producto adicionales');
define('TABLE_HEADING_ACTION', 'Acción(es)');
define('TEXT_INFO_HEADING_NEW_WAARDEN','nuevos valores para una opción ');
define('TEXT_HEADING_DELETE_WAARDEN', '¿Está seguro que quiere borrar valores?');
define('TEXT_HEADING_DELETE_OPTIE', '¿Está seguro que quiere borrar una opción?');
define('TEXT_INFO_EDIT_INTRO', 'Haga el(los) cambio(s) necesario(s)');
define('TEXT_DELETE_INTRO', 'Despues de borrarlo, no lo puede restaurar.');
define('TEXT_INFO_VERTALING', 'Traducciones: ');
define('TEXT_INFO_HEADING_EDIT_WAARDEN_OPTIES', 'Cambie las opciones para: ');
define('TEXT_INFO_INSERT_NEW_OPTIE','Digite la nueva opción');
define('TEXT_INFO_HEADING_EDIT_OPTIE','Edite opción');
define('TEXT_INFO_HEADING_NEW_OPTIE','Agregue nueva opción ');
define('TEXT_INFO_PPRODUCT_EXTRA_VELDEN_OMSCHRIJVING', 'Descripción del campo ');
define('TEXT_INFO_HEADING_EDIT_OPTIE_VERTAAL','Traducción para la opción ');
define('TEXT_MASTER_TYPE','Tipo de producto: ');
define('TYPE_KEUZE_VELD','Tipo de campo');
define('INTERN_GEBRUIK','Uso interno ');
define('EXTRA_VELD_BEWERKEN', 'edite campo ');
define('IMAGE_VERTALEN', 'traduzca');//create images
define('IMAGE_TERUG','regresar');//create images
define('WAARDEN_EXTRA_VELD_BEWERKEN','Editar valores');
define('ProductCheckBox','Check_box');
define('ProductPullDown','Pull_down_box');
define('ProductTextBox','text_box');
define('ProductMultiSelect', 'Multi_Select_Check_box');  
?>
