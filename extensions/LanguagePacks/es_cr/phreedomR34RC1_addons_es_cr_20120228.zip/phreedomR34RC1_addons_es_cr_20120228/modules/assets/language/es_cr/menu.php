<?php
// Path: /modules/assets/language/es_cr/menu.php
//
define('MENU_HEADING_ASSETS','Detalles de activos');
define('BOX_ASSET_MODULE','Lista de activos');

?>
