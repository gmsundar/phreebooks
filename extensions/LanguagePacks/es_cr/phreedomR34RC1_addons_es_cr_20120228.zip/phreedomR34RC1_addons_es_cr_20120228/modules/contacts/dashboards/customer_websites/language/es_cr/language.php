<?php
//  Path: /modules/contacts/dashboards/customer_websites/language/es_cr/language.php
//

define('CP_CUSTOMER_WEBSITES_TITLE','Sitio de internet de los clientes');
define('CP_CUSTOMER_WEBSITES_DESCRIPTION','Lista de los URLs de todos los clientes. ');
define('CP_CUSTOMER_WEBSITES_NO_RESULTS','¡No hay ninguno!');
define('CP_CUSTOMER_WEBSITES_SECURITY',SECURITY_ID_MAINTAIN_CUSTOMERS);

?>
