<?php

//  Path: /modules/contacts/dashboards/vendor_websites/language/es_cr/language.php
//

define('CP_VENDOR_WEBSITES_TITLE','Sitio de internet de los proveedores');
define('CP_VENDOR_WEBSITES_DESCRIPTION','Lista de los URLs de todos los proveedores. ');
define('CP_VENDOR_WEBSITES_NO_RESULTS','¡No hay ninguno!');
define('CP_VENDOR_WEBSITES_SECURITY',SECURITY_ID_MAINTAIN_VENDORS);

?>
