<?php

//  Path: /modules/linkpoint/language/es_cr/menu.php
//  created by harry
//

// Title to use in the pull down menu
define('BOX_BANKING_LINK_POINT_CC_REVIEW', 'Lista Linkpoint CC');

?>
