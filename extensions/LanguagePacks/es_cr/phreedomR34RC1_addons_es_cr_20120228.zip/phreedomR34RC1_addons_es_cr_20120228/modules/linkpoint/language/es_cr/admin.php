<?php
//  Path: /modules/linkpoint/language/es_cr/admin.php
//  created by harry
//

// Module information
define('MODULE_LINKPOINT_TITLE','Link Point CC');
define('MODULE_LINKPOINT_DESCRIPTION','Historia de pagos con tarjeta de crédito vía Link Point. Desarrollado por <a target="_blank" href="http://www.strowger.com">Strowger.com</a>');

?>
