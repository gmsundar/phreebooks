<?php

//  Path: /modules/linkpoint/language/es_cr/language.php
//  created by harry
//

// Headings 
define('TABLE_HEADING_CUSTOMER', 'Cliente');
define('TABLE_HEADING_LASTNAME', 'Apellidos');
define('TABLE_HEADING_FIRSTNAME', 'Nombre');
define('TABLE_HEADING_ACCOUNT_CREATED', 'Cuenta creada ');
define('GEN_LAST_NAME', 'Apellidos');
define('GEN_FIRST_NAME', 'Nombre');



// General Defines
define('GEN_CUSTOMER', 'Cliente');
define('GEN_VENDOR', 'Proveedor');
define('GEN_ACCOUNT_CREATED', 'Cuenta creada ');
define('GEN_LINK_POINT_ID','Link Point ID');

// Error Messages

// Javascrpt Defines

// Audit Log Messages

?>
