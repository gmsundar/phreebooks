<?php
//  Path: /modules/doc_ctl/language/es_cr/language.php
//
// General
define('TEXT_BOOKMARK_DOC','Marque documento');
define('TEXT_BOOKMARKED','Marcado');
define('TEXT_CANCEL_CHECKOUT','Cancele marca de sacado');
define('TEXT_CHECKED_OUT','Sacado');
define('TEXT_CHECKOUT_DOC','Saque documento');
define('TEXT_CREATE_DATE','Fecha de creación');
define('TEXT_DETAILS','Detalles');
define('TEXT_DOCUMENT','Documento: ');
define('TEXT_DOCUMENT_TITLE','Contenido de: ');
define('TEXT_DOCUMENTS','Lista de documentos');
define('TEXT_DOWNLOAD_DOCUMENT','Descargue documento');
define('TEXT_FILENAME','Nombre del archivo');
define('TEXT_IMG_NOT_AVAILABLE','Imagen no disponible');
define('TEXT_LAST_UPDATE','Última actualización');
define('TEXT_LAST_VIEW','Última vista');
define('TEXT_LOCK_DOC','Congele documento');
define('TEXT_LOCKED','Congelado');
define('TEXT_MY_BOOKMARKS','Mis marcas');
define('TEXT_MY_CHECKED_OUT','Archivos sacados');
define('TEXT_NEW_FOLDER','Carpeta nueva');
define('TEXT_NEW_DOCUMENT','Documento nuevo');
define('TEXT_NO_BOOKMARKS','No se hay ningún documento marcado.');
define('TEXT_NO_CHECKED_OUT','No se encontraron documentos congelados.');
define('TEXT_NO_DOCUMENTS','No se encontraron documentos.');
define('TEXT_OWNER','Dueño');
define('TEXT_PATH','Ruta');
define('TEXT_RECENTLY_ADDED','Documentos agregados recientemente');
define('TEXT_REMOVE_BOOKMARK','Elimine marca');
define('TEXT_REVISION','Revisión');
define('TEXT_THUMBNAIL','Imagen miniatura');
define('TEXT_UNLOCK_DOC','Descongele el documento');
define('TEXT_UPLOAD_FILE','Cargue el documento modificado');
// Specific to this module
define('DOC_CTL_EMPTY_FOLDER','La carpeta no contiene documentos.');
define('DOC_CTL_FILE_WRITE_ERROR','Hubo un error grabando el archivo. Revise los permisos de la carpeta (%s) e intente de nuevo.');
define('DOC_CTL_ITEMS', 'Carpetas y documentos');
define('DOC_CTL_DELETE_DOCUMENT','¿Está seguro que quiere borrar este documento?');
define('DOC_CTL_DELETE_DIRECTORY','¿Está seguro que quiere borrar esta carpeta?');
// Javascript defines
define('DOC_CTL_JS_DEL_BOOKMARK','¿Está seguro que quiere borrar este marcador?');
define('DOC_CTL_JS_DIR_DELETED_ERROR','¡La carpeta no está vacía, no se puede borrar!');
define('TEXT_NO_RESULTS','No hay.');
?>
