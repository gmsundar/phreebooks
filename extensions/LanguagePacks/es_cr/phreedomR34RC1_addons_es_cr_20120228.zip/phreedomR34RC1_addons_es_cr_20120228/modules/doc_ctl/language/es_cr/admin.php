<?php
//  Path: /modules/doc_ctl/language/es_cr/admin.php
//
// Module information
define('MODULE_DOC_CTL_TITLE','Módulo documentos');
define('MODULE_DOC_CTL_DESCRIPTION','El módulo documentos es un sistema para administrar y controlar múltiples tipos de documentos. El módulo tienen la funcionalidad de sacar en préstamo un documento, devolver un documento, congelar documentos para evitar que múltiples usuarios intenten editarlos simultaneamente, seguridad y administración estructurada de directorios.');
define("TEXT_DRIVE","Unidad de almacenamiento");

?>
