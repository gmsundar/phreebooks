<?php
//  Path: /modules/doc_ctl/language/es_cr/menu.php
//
// Menu Headings
define('MENU_HEADING_QUALITY','Calidad');
// Title to use in the pull down menu
define('BOX_DOC_CTL_MODULE','Control de documentos');

?>
