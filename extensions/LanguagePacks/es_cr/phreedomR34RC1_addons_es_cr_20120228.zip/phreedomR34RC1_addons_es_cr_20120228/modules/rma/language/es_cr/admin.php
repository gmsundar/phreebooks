<?php
// Path: /modules/rma/language/es_cr/admin.php
//
define('MODULE_RMA_DESCRIPTION','El módulo (RMA) es para administrar los reclamos de garantía de los clientes.');
define('MODULE_RMA_TITLE','Módulo RMA');

// Headings

define('NEXT_RMA_NUM_DESC','Próximo No.RMA');

?>
