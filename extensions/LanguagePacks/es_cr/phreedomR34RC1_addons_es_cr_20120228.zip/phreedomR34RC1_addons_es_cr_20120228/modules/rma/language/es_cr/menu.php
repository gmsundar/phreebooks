<?php
// Path: /modules/rma/language/es_cr/menu.php
//
define('BOX_RMA_MODULE','Lista de RMA');
define('MENU_HEADING_RMA','Detalles del RMA');

?>
