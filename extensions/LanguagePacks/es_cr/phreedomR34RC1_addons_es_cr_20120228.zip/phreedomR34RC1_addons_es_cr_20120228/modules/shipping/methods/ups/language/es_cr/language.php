<?php
// Path: /modules/shipping/methods/ups/language/es_cr/language.php
//
define('SHIPPING_UPS_ERROR_POSTAL_CODE','Se necesita un código postal para usar el módulo UPS');
define('SHIPPING_UPS_ERROR_WEIGHT_150','El peso del envío no puede ser de mas de 68 Kg. para usar el módulo de UPS.');
define('SHIPPING_UPS_PACKAGE_ERROR','Se paró por problemas dividiendo el embarque en partes.  El peso del embarque es: ');
define('SHIPPING_UPS_CURL_ERROR','Error cURL: ');
define('SRV_SHIP_UPS_BILL_DETAIL','Detalles de facturación');
define('SRV_SHIP_UPS_EMAIL_NOTIFY','Notificaciones por correo electrónico');
define('SRV_SHIP_UPS_RECP_INFO','Información del destinatario');
define('SRV_SHIP_UPS','Envíe un paquete');
define('SHIPPING_UPS_TNT_ERROR',' Error en tiempo de tránsito UPST # ');
define('SHIPPING_UPS_RATE_TRANSIT',' Día(s) en tránsito, llega ');
define('SHIPPING_UPS_RATE_CITY_MATCH','La ciudad no concuerda con el código póstal.');
define('SHIPPING_UPS_RATE_ERROR','Error en respuesta de tarifa UPS: ');
define('SHIPPING_UPS_SHIPMENTS_ON','Envíos UPS el día ');
define('SHIPPING_UPS_HAZMAT_REPORTS','Reporte hazmat (materiales peligrosos)');
define('SHIPPING_UPS_MULTIWGHT_REPORTS','Reporte multipesos');
define('SHIPPING_UPS_CLOSE_REPORTS','Reporte de cierre');
define('SHIPPING_UPS_VIEW_REPORTS','Vea reportes para ');
define('ups_I3D','Worldwide Expedited');
define('ups_IGND','Standard (Canada)');
define('ups_I2Dam','Worldwide Express');
define('ups_I2DEam','Worldwide Express Plus');
define('ups_2Dpm','2nd Day Air');
define('ups_3Dpm','3 Day Select');
define('ups_2Dam','2nd Day Air Early AM');
define('ups_1Dpm','Next Day Air Saver');
define('ups_GND','Ground');
define('ups_1DEam','Next Day Air Early AM');
define('ups_1Dam','Next Day Air');
define('MODULE_SHIPPING_UPS_SORT_ORDER_DESC','Orden a mostrar. El que tiene valor mas bajo se muestra primero.');
define('MODULE_SHIPPING_UPS_TYPES_DESC','Seleccione el servicio UPS como servicio predeterminado.');
define('MODULE_SHIPPING_UPS_LABEL_SIZE_DESC','Tamaño de etiqueta a usar para imprimir etiquetas termales, valores válidos son 6 ú 8 pulgadas');
define('MODULE_SHIPPING_UPS_PRINTER_TYPE_DESC','Tipo de impresora para usar para imprimir etiquetas. GIF para papel corriente, termal para la impresora UPS 2442 (vea el archivo de ayuda antes de seleccionar la impresora termal)');
define('MODULE_SHIPPING_UPS_ACCESS_KEY_DESC','Digite la clave de acceso XML que le dió UPS.');
define('MODULE_SHIPPING_UPS_PASSWORD_DESC','Digite la contraseña usada para accesar su cuenta con UPS');
define('MODULE_SHIPPING_UPS_TEST_MODE_DESC','Modo de prueba para probar la impresión de etiquetas de envío');
define('MODULE_SHIPPING_UPS_USER_ID_DESC','Digite la cuenta de UPS registrada para accesar el estimador de tarifas');
define('MODULE_SHIPPING_UPS_SHIPPER_NUMBER_DESC','Digite el número de cuenta de cliente que tiene con UPS para usar el estimador de tarifas');
define('MODULE_SHIPPING_UPS_TITLE_DESC','Título para mostrar en el estimador de tarifas');
define('MODULE_SHIPPING_UPS_QUANTUM_VIEW_TEST','https://wwwcie.ups.com/ups.app/xml/QVEvents');
define('MODULE_SHIPPING_UPS_QUANTUM_VIEW','https://www.ups.com/ups.app/xml/QVEvents');
define('MODULE_SHIPPING_UPS_VOID_SHIPMENT_TEST','https://wwwcie.ups.com/ups.app/xml/Void');
define('MODULE_SHIPPING_UPS_VOID_SHIPMENT','https://www.ups.com/ups.app/xml/Void');
define('MODULE_SHIPPING_UPS_LABEL_URL_TEST','https://wwwcie.ups.com/ups.app/xml/ShipAccept');
define('MODULE_SHIPPING_UPS_LABEL_URL','https://www.ups.com/ups.app/xml/ShipAccept');
define('MODULE_SHIPPING_UPS_SHIP_URL_TEST','https://wwwcie.ups.com/ups.app/xml/ShipConfirm');
define('MODULE_SHIPPING_UPS_SHIP_URL','https://www.ups.com/ups.app/xml/ShipConfirm');
define('MODULE_SHIPPING_UPS_TNT_URL_TEST','https://wwwcie.ups.com/ups.app/xml/TimeInTransit');
define('MODULE_SHIPPING_UPS_TNT_URL','https://www.ups.com/ups.app/xml/TimeInTransit');
define('MODULE_SHIPPING_UPS_RATE_URL_TEST','https://wwwcie.ups.com/ups.app/xml/Rate');
define('MODULE_SHIPPING_UPS_RATE_URL','https://www.ups.com/ups.app/xml/Rate');
define('MODULE_SHIPPING_UPS_TEXT_DESCRIPTION','Servicio Postal Unido');
define('MODULE_SHIPPING_UPS_TITLE_SHORT','UPS');
define('MODULE_SHIPPING_UPS_TEXT_TITLE','Servicio Postal Unido');
define('UPS_TRACKING_URL','http://wwwapps.ups.com/etracking/tracking.cgi?tracknums_displayed=5&TypeOfInquiryNumber=T&HTMLVersion=4.0&sort_by=status&InquiryNumber1=');

?>
