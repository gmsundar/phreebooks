<?php
//  Path: /modules/import_bank/language/es_cr/admin.php
//
define('MODULE_IMPORT_BANK_TITLE','Importe de banco');
define('MODULE_IMPORT_BANK_DESCRIPTION','Con este módulo puede importar un archivo con el estado de cuenta del banco que esté en formato .csv.  Esta lista luego puede ser revisada contra cheques pendientes o cheques con el mismo nombre.');
define('BOX_BANK_IMPORT_ADMIN','Configuración importe de banco');
define('TEXT_BANK_IMPORT_SETTINGS','Configuración importe de banco');
define('MODULE_BANK_IMPORT_CONFIG_INFO','Digite un valor de configuración');
define('BANK_IMPORT_QUESTION_POSTS','Para asegurarse que las transacciones no sean registradas por el guión, como último recurso, las transacciones son almacenadas en la lista de ítems con dudas <B> Esto debe ser completado sino el guión no funcionará.</B>');
define('BANK_IMPORT_DEBIT_CREDIT','La descripción cuando montos son acreditados a su cuenta <br> <B>  esto es para el campo xml debit_credit</B>');

?>
