<?php
//  Path: /modules/import_bank/language/es_cr/language.php
//
define('MODULE_IMPORT_BANK_TITLE',  'Importe de banco');
define('HEADING_MODULE_IMPORT_BANK','Importe de banco');
define('GEN_BANK_IMPORT_MESSAGE',	'Seleccione el archivo .csv para importar y presione Importe <br> Si no hay columna de cuenta de banco en el archivo .csv entonces seleccione la cuenta de la lista plegable. ');
define('TEXT_IMPORT',				'Importe');
define('SAMPLE_CSV',				'Ejemplo CSV');
define('TEXT_REQUIRED',				'REQUERIDO');

define('TEXT_BIMP_ERMSG1','el dueño de la cuenta está vacío');
define('TEXT_BIMP_ERMSG2','hay dos o mas cuentas contables con la descripción: ');
define('TEXT_BIMP_ERMSG3','la otra cuenta de banco está vacía');
define('TEXT_BIMP_ERMSG4','hay dos o mas cuentas contables con la misma cuenta: ');
define('TEXT_BIMP_ERMSG5','no hay cuentas contables con la descripcion:  ');

?>
