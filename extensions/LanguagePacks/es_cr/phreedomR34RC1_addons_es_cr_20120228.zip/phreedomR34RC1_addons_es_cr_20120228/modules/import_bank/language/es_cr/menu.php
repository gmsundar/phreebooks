<?php
//  Path: /modules/import_bank/language/es_cr/menu.php
//
define('BOX_IMPORT_BANK_MODULE','Importe de banco');

?>
