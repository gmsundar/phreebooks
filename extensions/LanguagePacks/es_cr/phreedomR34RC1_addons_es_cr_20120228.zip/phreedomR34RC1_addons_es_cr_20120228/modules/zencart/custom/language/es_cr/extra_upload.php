<?php
// Path: /modules/zencart/custom/language/es_cr/extra_upload.php
//

define('TEXT_CUSTOM_TAB','Campos extra para subir');
define('ZENCART_DISCOUNT_NAME_DESC','Seleccione lista de descuentos');

?>
