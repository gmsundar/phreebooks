<?php
// Path: /modules/zencart/language/es_cr/admin.php
//
define('ZENCART_LOG_FIELDS','Agregue campo a inventario Zencart');
define('ZENCART_LOG_TABS','Agregue pestaña a inventario Zencart');
define('ZENCART_CATALOG_MANUFACTURER','Necesita coincidir con el nombre del fabricante tal como está definido en ZenCart.');
define('ZENCART_CATALOG_CATEGORY_ID','Necesita coincidir una categoría definida en ZenCart.');
define('ZENCART_CATALOG_ADD','Agregue al catálogo de ZenCart');
define('ZENCART_CONFIG_SAVED','Se actualizaron/salvaron los valores de configuración Zencart.');
define('ZENCART_PARTIAL_ID','Código númerico de estatus de órdenes parcialmente enviadas en ZenCart');
define('ZENCART_SHIP_ID','Código númerico de estatus de órdenes enviadas en ZenCart');
define('ZENCART_TEXT_PRICE_SHEET','Escala de precios a usar en ZenCart');
define('ZENCART_USE_PRICES','¿Quiere usar escalas de precios?');
define('ZENCART_TAX_CLASS','Digite el nombre del campo de texto para la clase de impuesto en ZenCart (Debe coincidir exactamente con ZenCart si cobra impuestos)');
define('MODULE_ZENCART_CONFIG_INFO','Fije los valores de configuración para ZenCart.');
define('ZENCART_ADMIN_PASSWORD','Clave para ZenCart admin (puede se exclusivo para la interface PhreeBooks)');
define('ZENCART_ADMIN_USERNAME','Nombe de usuario para ZenCart admin (puede se exclusivo para la interface PhreeBooks');
define('ZENCART_ADMIN_URL','Enlace a ZenCart Admin (sin raya hacia adelante)');
define('MODULE_ZENCART_DESCRIPTION','El módulo ZenCart es una interface entre las bases de datos de PhreeBooks y de ZenCart. La funciones que tiene incluyen cargar códigos, descargar órdenes y sincronizar las tablas de productos.');
define('MODULE_ZENCART_TITLE','Módulo ZenCart');
define('TEXT_ZENCART_SETTINGS','Configuración');
?>
