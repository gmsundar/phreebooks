<?php
//  Path: /modules/sku_pricer/language/es_cr/menu.php
//
// Title to use in the pull down menu
define('BOX_SKU_PRICER_TITLE', 'Importe precios');

?>
