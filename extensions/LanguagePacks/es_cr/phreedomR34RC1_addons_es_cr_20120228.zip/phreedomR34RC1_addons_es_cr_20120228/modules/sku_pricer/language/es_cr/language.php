<?php
//  Path: /modules/sku_pricer/language/es_cr/language.php
//
// The module was written without multi-language support. 
// If multi-language support is required, This file should hold the translations.
// Headings 
define('SKU_PRICER_PAGE_TITLE','Importe precios');
// General Defines
define('SKU_PRICER_SELECT','Seleccione el archivo en formato .csv a importar');
define('SKU_PRICER_DIRECTIONS','Después de seleccionar el archivo a importar, presione el icono Salve para ejecutar el guión.<br />El formato del archivo debe ser así (con encabezados):<br />código,costo,precio<br>SKU_NUM,2.00, 4.00<br />Los números con un punto para delimitar la parte decimal y sin símbolos de moneda u otros caracteres.');
// Error Messages
// Javascrpt Defines
// Audit Log Messages

?>
