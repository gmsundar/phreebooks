<?php
//  Path: /modules/sku_pricer/language/es_cr/admin.php
//
// Module information
define('MODULE_SKU_PRICER_TITLE','Importe precios');
define('MODULE_SKU_PRICER_DESCRIPTION','Este módulo actualizará el precio de venta y el costo de los códigos a partir de un archivo que esté en formato csv que contenga la información.');
// Headings
// Defaults

?>
