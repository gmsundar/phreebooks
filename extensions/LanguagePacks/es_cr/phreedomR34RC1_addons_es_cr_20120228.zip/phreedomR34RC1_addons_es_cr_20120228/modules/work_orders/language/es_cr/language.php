<?php
//
//  Path: modules/work_orders/language/es_cr/language.php
//
// Headings 
define('WO_POPUP_TASK_WINDOW_TITLE','Tareas de la orden de trabajo');
define('HEADING_WORK_ORDER_MODULE_NEW','Crear orden de trabajo');
define('HEADING_WORK_ORDER_MODULE_EDIT','Editar orden de trabajo');
define('HEADING_WORK_ORDER_MODULE_BUILD','Hacer y darle seguimiento a una orden de trabajo');
// General Defines
define('TEXT_APPROVALS','Aprobaciones');
define('TEXT_BUILD','Crear una orden de trabajo');
define('TEXT_CLOSE_DATE','Fecha de finalización');
define('TEXT_COMPLETE','Completado');
define('TEXT_DATA_ENTRY','Digitación de datos');
define('TEXT_DAYS','Días');
define('TEXT_DOCUMENTS','Documentos de referencia');
define('TEXT_DRAWINGS','Planos de referencia');
define('TEXT_ENTRY_VALUE','Digitación de valores');
define('TEXT_ERP_ENTRY','Digitación de contactos');
define('TEXT_HOURS','Horas');
define('TEXT_MFG','Fabricante');
define('TEXT_MFG_INIT','Aprobación de fabricación');
define('TEXT_MINUTES','Minutos');
define('TEXT_NA','N/D');
define('TEXT_PRIORITY','Prioridad');
define('TEXT_PROCEDURE','Procedimiento');
define('TEXT_QA','CC');
define('TEXT_QA_INIT','Aprobación de CC');
define('TEXT_REVISION','Revisión');
define('TEXT_REVISION_DATE','Fecha de Rev');
define('TEXT_SPECIAL_NOTES','Notas y comentarios');
define('TEXT_STEP','Paso');
define('TEXT_TASKS','Tareas');
define('TEXT_TASK_DESC','Descripción de tarea');
define('TEXT_TASK_NAME','Nombre de tarea');
define('TEXT_TASK_SEQUENCE','Secuencia de tarea');
define('TEXT_TASK_STATUS','Estatus de tarea');
define('TEXT_TASK_TIME','Duración de tarea');
define('TEXT_USE_ALLOCATION','Restrinja');
define('TEXT_WORK_ORDERS','Órdenes de trabajo');
define('TEXT_WORK_ORDERS_TASK','Tareas');
define('TEXT_WO_ID','Número de identificación');
define('TEXT_WO_TITLE','Nombre de orden');
// Error and Information Messages
define('WO_MESSAGE_BUILDER_ERROR','Hubo un error agregando/editando el registro de la orden de trabajo. Revise los datos y vuelva a intentar.');
define('WO_ERROR_CANNOT_DELETE_BUILDER','Esta orden de trabajo ya ha sido usada en el sistema.  No se puede borrar.');
define('WO_BUILDER_ERROR_DUP_TITLE','El nombre de la orden de trabajo ya existe.  ¡Vuelva a intentar!');
define('WO_MSG_COPY_INTRO','Didite el nombre de la nueva orden de trabajo.');
define('WO_SKU_NOT_FOUND','¡El código que digitó no se encuentra en el sistema!');
define('WO_INSUFFICIENT_INVENTORY','No hay suficiente cantidad en inventario para la fabricación. Los códigos insuficientes incluyen:');
define('WO_MESSAGE_SUCCESS_MAIN_UPDATE','¡Se actualizó exitósamente la orden de trabajo!');
define('WO_MESSAGE_SUCCESS_MAIN_ADD','¡Se agregó exitósamente la orden de trabajo!');
define('WO_MESSAGE_SUCCESS_MAIN_DELETE','¡Se borró sexitósamente la orden de trabajo!');
define('WO_MESSAGE_STEP_UPDATE_SUCCESS','Se actualizó exitósamente el paso %s de la orden de trabajo.');
define('WO_MESSAGE_SUCCESS_COMPLETE','Ha sido finalizada exitósamente la orden de trabajo %s.');
define('WO_MESSAGE_MAIN_ERROR','Hubo un error agregando/editando el registro de la orden de trabajo. Revise los datos y vuelva a intentar');
define('WO_MFG_PASSWORD_BAD','La contraseña de fabricación no concuerda con el nombre del usuario.');
define('WO_QA_PASSWORD_BAD','La contraseña del control de calidad no concuerda con el nombre del usuario.');
define('WO_DATA_VALUE_BLANK','Se requiere un valor pero está en blanco.');
define('WO_DB_UPDATE_ERROR','Hubo un error actualizando la base de datos.');
define('WO_MESSAGE_SUCCESS_UPDATE','¡Se actualizó exitósamente la tarea de la orden de trabajo!');
define('WO_MESSAGE_SUCCESS_ADD','¡Se agregó exitósamente la tarea a la orden de trabajo!');
define('WO_MESSAGE_ERROR','Hubo un error agregando/editando la tarea de la orden de trabajo. Revise los datos y vuelva a intentar.');
define('WO_SKU_ID_REQUIRED','El código y el nombre de la orden de trabajo son campos requeridos.');
define('WO_CANNOT_SAVE','Esta orden de trabajo tiene un número mayor de revisión, no se pueden salvar cambios a esta orden de trabajo.');
define('WO_ROLL_REVISION','Esta orden de trabajo ya ha sido usada en el sistema.  Cualquier cambio le asignará un nuevo número de revisión.');
define('WO_ERROR_CANNOT_DELETE','¡No se puede borrar la tarea de la orden de trabajo porque está siendo usada en una orden de trabajo! Vea la orden de trabajo # ');
define('WO_DUPLICATE_TASK_ID','No se modificó el registro.  ¡Ya existe en el sistema una tarea con el mismo número de identificación!');
define('WO_TASK_ID_MISSING','¡Se requiere ambos, la descripción y el número de identificación de la tarea!');
define('WO_TEXT_PARTS_SHORTAGE','(%s de %s) necesarios del código %s - %s');
// Audit log defines
define('WO_AUDIT_LOG_MAIN','OT total (%s) - ');
define('WO_AUDIT_LOG_BUILDER','OT definición (%s) - ');
define('WO_AUDIT_LOG_TASK','OT tarea ($s) - ');
define('WO_AUDIT_LOG_STEP_COMPLETE','OT paso %s - Completado');
define('WO_AUDIT_LOG_WO_COMPLETE','OT %s - Completado');
// Javascrpt defines
define('WORK_ORDER_MSG_DELETE_WO','¿Está seguro que quiere borrar esta digitación?');

?>
