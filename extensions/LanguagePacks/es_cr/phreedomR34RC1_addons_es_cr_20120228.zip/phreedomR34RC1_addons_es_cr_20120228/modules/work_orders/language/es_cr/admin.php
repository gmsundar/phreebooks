<?php
//  Path: /modules/work_orders/language/es_cr/admin.php
//
// Module information
define('MODULE_WORK_ORDERS_TITLE','Módulo orden de trabajo');
define('MODULE_WORK_ORDERS_DESCRIPTION','El módulo orden de trabajo es un sistema de control completo para la fabricación de artículos de inventario. Este módulo hace interfase con el módulo de inventario pra controlar el proceso de fabricación y administración del inventario.');
// Headings
// Defaults

?>
