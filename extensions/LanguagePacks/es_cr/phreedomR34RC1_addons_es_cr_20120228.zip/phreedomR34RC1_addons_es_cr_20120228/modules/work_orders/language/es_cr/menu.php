<?php
//  Path: /modules/work_orders/language/es_cr/menu.php
//
// Enter the new menu category heading if necessary
define('MENU_HEADING_WORK_ORDERS',    'Órdenes de trabajo');
// Menu Titles
define('BOX_WORK_ORDERS_MODULE',      'Lista de órdenes de trabajo');
define('BOX_WORK_ORDERS_BUILDER',     'Definiciónes de órdenes de trabajo');
define('BOX_WORK_ORDERS_MODULE_TASK', 'Tareas para órdenes de trabajo');

?>
