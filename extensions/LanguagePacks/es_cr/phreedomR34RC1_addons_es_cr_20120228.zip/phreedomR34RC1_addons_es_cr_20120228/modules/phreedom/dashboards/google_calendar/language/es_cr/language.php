<?php

//  Path: /modules/phreedom/dashboards/google_calendar/language/en_us/google_calendar.php
//

define('CP_GOOGLE_CALENDAR_TITLE','Calendario Google');
define('CP_GOOGLE_CALENDAR_DESCRIPTION','Calendarios Google.');
define('CP_GOOGLE_CALENDAR_SECURITY',4);

define('CP_GOOGLE_CALENDAR_NO_RESULTS','¡No hay ninguno!');

?>
