<?php
//  Path: /modules/phreepos/language/es_cr/language.php
//
// Page Titles
define('BOX_PHREEPOS_RETURN','Punto de venta - Devolución');
define('PHREEPOS_PAYMENT_TITLE','Digite pago');

// General Text
define('TEXT_ADD_UPDATE','Agregue/actualice');
define('TEXT_SUBTOTAL','Subtotal');
define('TEXT_AMOUNT_PAID','Monto pagado');
define('TEXT_BALANCE_DUE','Saldo');
define('TEXT_PAYMENT','Pago');
define('TEXT_RETURN','Procese devolución');
define('TEXT_DISCOUNT_PERCENT','Porcentaje de descuento');
define('TEXT_REFUND','Devolver dinero al cliente');
define('TEXT_REFUND_METHOD','Forma de pago');
define('TEXT_ENTRIES','Transacciones');

define('PHREEPOS_ITEM_NOTES','El cursor debe estar posicionado sobre el campo del código para que el escaneador de códigos de barra funcione.');
define('PHREEPOS_PAYMENT_NOTES','El cursor debe estar posicionado sobre el primer campo para registrar la información de la tarjeta de crédito.');
define('POS_MSG_DELETE_CONFIRM','¿Está seguro que quiere borrar esta transacción de punto de venta?');
define('BNK_19_AMOUNT_PAID', 'Monto recibido');

?>
