<?php
//  Path: /modules/phreepos/language/es_cr/admin.php
//
// Module information
define('MODULE_PHREEPOS_TITLE','Módulo PhreePOS');
define('MODULE_PHREEPOS_DESCRIPTION','El módulo PhreePOS es la interface de punto de venta. Este módulo es un complemento del módulo Phreebooks y no un sustituto de él.');
// Headings
define('BOX_PHREEPOS_ADMIN','Administración del módulo Punto de venta');
// General Defines
define('PHREEPOS_REQUIRE_ADDRESS_DESC','¿Require la dirección del cliente para toda venta?');
define('PHREEPOS_RECEIPT_PRINTER_NAME_DESC','Nombre de la impresora de recibos tal como está nombrada en las preferencias de impresora del computador local.');

?>
