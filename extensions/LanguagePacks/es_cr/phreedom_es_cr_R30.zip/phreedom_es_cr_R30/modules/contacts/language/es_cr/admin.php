<?php
// +-----------------------------------------------------------------+
// Phreedom Language Translation File
// Generated: 2011-01-28 04:55:45
// +-----------------------------------------------------------------+
// Path: /modules/contacts/language/es_cr/admin.php

define('SETUP_PROJECT_PHASESS_DELETE_ERROR','¡No se puede borrar esta fase de proyecto, está ligada a una transacción contable!');
define('SETUP_INFO_HEADING_NEW_PROJECT_PHASES','Fase de proyecto nueva');
define('SETUP_INFO_HEADING_EDIT_PROJECT_PHASES','Edite fase de proyecto');
define('SETUP_PROJECT_PHASESS_LOG','Fases de proyecto - ');
define('SETUP_PROJECT_PHASES_DELETE_INTRO','¿Está seguro que quiere borrar esta fase de proyecto?');
define('SETUP_PROJECT_PHASES_INSERT_INTRO','Digite una nueva fase de proyecto y sus características');
define('SETUP_INFO_COST_BREAKDOWN','¿Va a desglosar los costos de esta fase?');
define('TEXT_COST_BREAKDOWN','Desglose de costo');
define('SETUP_TITLE_PROJECTS_PHASES','Fases de proyecto');
define('SETUP_PROJECT_COSTS_DELETE_ERROR','¡No se puede borrar este costo de proyecto, está ligado a transacciones contables!');
define('SETUP_PROJECT_COSTS_LOG','Costos de proyecto - ');
define('SETUP_INFO_COST_TYPE','Tipo de costo (si no va a desglosar los costos)');
define('SETUP_INFO_HEADING_EDIT_PROJECT_COSTS','Edite el costo de proyecto');
define('SETUP_INFO_HEADING_NEW_PROJECT_COSTS','Costo de proyecto nuevo');
define('SETUP_PROJECT_COSTS_DELETE_INTRO','¿Está seguro que quiere borrar este costo de proyecto?');
define('SETUP_PROJECT_COSTS_INSERT_INTRO','Digite el costo de proyecto nuevo y sus características');
define('SETUP_INFO_DESC_LONG','Descripción larga (máx 64 caract.)');
define('SETUP_INFO_DESC_SHORT','Nombre corto (15 caracteres máx.)');
define('TEXT_SHORT_NAME','Nombre corto');
define('TEXT_COST_TYPE','Tipo de costo');
define('SETUP_TITLE_PROJECTS_COSTS','Costos de proyecto');
define('SETUP_DEPT_TYPES_LOG','Tipos de dept - ');
define('SETUP_INFO_HEADING_EDIT_DEPT_TYPES','Edite tipo de departamento');
define('SETUP_INFO_HEADING_NEW_DEPT_TYPES','Nuevo tipo de departamento');
define('SETUP_DEPT_TYPES_DELETE_ERROR','No se puede borrar este tipo de departamento.  Esta siendo usado por un departamento.');
define('SETUP_DEPT_TYPES_DELETE_INTRO','Está seguro que quiere borrar este tipo de departamento?');
define('SETUP_DEPT_TYPES_INSERT_INTRO','Digite un nuevo tipo de departamento');
define('SETUP_INFO_DEPT_TYPES_NAME','Nombre del tipo de departamento');
define('SETUP_TITLE_DEPT_TYPES','Tipos de departamento');
define('HR_LOG_DEPARTMENTS','Departamentos - ');
define('HR_DEPARTMENT_REF_ERROR','¡El departamento primario no puede ser el mismo que este sub-departamento que está salvando!');
define('HR_INFO_DELETE_INTRO','¿Está seguro que quiere borrar este departamento?');
define('HR_INFO_EDIT_ACCOUNT','Edite el departamento');
define('HR_INFO_NEW_ACCOUNT','Nuevo departamento');
define('HR_INFO_INSERT_INTRO','Digite un nuevo departamento y sus propiedades');
define('HR_INFO_ACCOUNT_INACTIVE','Departamento inactivo');
define('HR_INFO_ACCOUNT_TYPE','Tipo de departamento');
define('HR_INFO_PRIMARY_ACCT_ID','Sí, seleccione el departamento primario:');
define('HR_INFO_SUBACCOUNT','¿Es este departamento un sub-departamento?');
define('HR_ACCOUNT_ID','Departamento');
define('HR_EDIT_INTRO','Haga los cambios necesarios');
define('HR_POPUP_WINDOW_TITLE','Departamentos');
define('HR_HEADING_SUBACCOUNT','Sub-departamento');
define('HR_DISPLAY_NUMBER_OF_DEPTS', TEXT_DISPLAY_NUMBER . 'departamentos');
define('TEXT_DISPLAY_NUMBER_OF_DEPT_TYPES', TEXT_DISPLAY_NUMBER . 'tipos de departamentos');

define('CONTACT_SHIP_FIELD_REQ','Require o no que el campo: %s sea digitado para una nueva dirección de envío');
define('CONTACT_BILL_FIELD_REQ','Require o no que el campo: %s sea digitado para una nueva dirección principal o de cobro (para proveedores, clientes y empleados)');
define('COST_TYPE_EQT','Equipo');
define('COST_TYPE_OTH','Otros');
define('COST_TYPE_CNT','Sub-contratistas');
define('COST_TYPE_MAT','Materiales');
define('TEXT_SHIPPING_PREFS','Configuración para direcciones');
define('COST_TYPE_LBR','Mano de obra');
define('TEXT_BILLING_PREFS','Configuración para direcciones de cobro');
define('BOX_CONTACTS_ADMIN','Administración de contactos');
define('MODULE_CONTACTS_DESCRIPTION','El módulo contactos sirve para administrar los clientes, proveedores, empleados, sucursales y proyectos usados en Phreedom. <b>NOTA: ¡Este es un módulo del núcleo por lo que no debe ser desinstalado!</b>');
define('MODULE_CONTACTS_TITLE','Módulo Contactos');
define('SETUP_DISPLAY_NUMBER_OF_PROJECT_COSTS', TEXT_DISPLAY_NUMBER . 'costos de proyecto');
define('SETUP_DISPLAY_NUMBER_OF_PROJECT_PHASES', TEXT_DISPLAY_NUMBER . 'fases de proyecto');











?>
