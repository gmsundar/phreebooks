<?php
// +-----------------------------------------------------------------+
// Phreedom Language Translation File
// Generated: 2011-01-28 04:55:46
// +-----------------------------------------------------------------+
// Path: /modules/phreebooks/dashboards/mini_financial/language/es_cr/language.php

define('RW_FIN_TOTAL_LIABILITIES_CAPITAL','Total pasivo y patrimonio');
define('RW_FIN_CAPITAL','Patrimonio');
define('RW_FIN_NET_INCOME','Utilidad neta');
define('RW_FIN_EXPENSES','Gastos');
define('RW_FIN_GROSS_PROFIT','Utilidad bruta');
define('RW_FIN_COST_OF_SALES','Costo de ventas');
define('RW_FIN_TOTAL_INCOME','Total ingreso');
define('RW_FIN_TOTAL_LIABILITIES','Total pasivos');
define('RW_FIN_LT_LIABILITIES','Pasivo no circulante');
define('RW_FIN_CUR_LIABILITIES','Pasivo circulante');
define('RW_FIN_INCOME','Total ingresos');
define('RW_FIN_ASSETS','Total activos');
define('RW_FIN_HEAD_44','Sin usar');
define('RW_FIN_HEAD_42','Sin usar');
define('RW_FIN_HEAD_40','Sin usar');
define('RW_FIN_HEAD_24','Sin usar');
define('RW_FIN_HEAD_22','Sin usar');
define('RW_FIN_HEAD_20','Sin usar');
define('RW_FIN_HEAD_12','Sin usar');
define('RW_FIN_HEAD_10','Sin usar');
define('RW_FIN_HEAD_8','Sin usar');
define('RW_FIN_HEAD_6','Otros activos');
define('RW_FIN_HEAD_4','Inventario');
define('RW_FIN_HEAD_2','Cuentas por cobrar');
define('RW_FIN_HEAD_0','Efectivo');
define('RW_FIN_PROP_EQUIP','Mobiliario y equipo');
define('RW_FIN_CURRENT_ASSETS','Activo circulante');
define('CP_MINI_FINANCIAL_NO_OPTIONS','¡No hay opciones seleccionables para este ítem!');
define('CP_MINI_FINANCIAL_DESCRIPTION','Lista abreviada de la situación financiera.');
define('CP_MINI_FINANCIAL_TITLE','Resumen financiero');
define('CP_MINI_FINANCIAL_SECURITY',SECURITY_ID_JOURNAL_ENTRY);
?>
