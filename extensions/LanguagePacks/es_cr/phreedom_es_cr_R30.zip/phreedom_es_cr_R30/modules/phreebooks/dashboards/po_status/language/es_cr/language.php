<?php
// +-----------------------------------------------------------------+
// Phreedom Language Translation File
// Generated: 2011-01-28 04:55:46
// +-----------------------------------------------------------------+
// Path: /modules/phreebooks/dashboards/po_status/language/es_cr/language.php

define('CP_PO_STATUS_NO_RESULTS','¡No hay ninguna!');
define('CP_PO_STATUS_DESCRIPTION','Lista de órdenes de compra pendientes con vínculos para abrirlas.');
define('CP_PO_STATUS_TITLE','Órdenes de compra pendientes');
define('MAX_NUM_PO_LIST',20);
define('CP_PO_STATUS_SECURITY',SECURITY_ID_PURCHASE_ORDER);

?>
