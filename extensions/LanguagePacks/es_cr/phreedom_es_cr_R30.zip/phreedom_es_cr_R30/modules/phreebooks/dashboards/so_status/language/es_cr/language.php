<?php
// +-----------------------------------------------------------------+
// Phreedom Language Translation File
// Generated: 2011-01-28 04:55:46
// +-----------------------------------------------------------------+
// Path: /modules/phreebooks/dashboards/so_status/language/es_cr/language.php

define('CP_SO_STATUS_NO_RESULTS','¡No hay ninguna!');
define('CP_SO_STATUS_DESCRIPTION','Lista de órdenes de venta pendientes con vínculos para abrirlas.');
define('CP_SO_STATUS_TITLE','Órdenes de venta pendientes');
define('MAX_NUM_SO_LIST',20);
define('CP_SO_STATUS_SECURITY',SECURITY_ID_SALES_ORDER);

?>
