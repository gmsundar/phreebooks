<?php
// +-----------------------------------------------------------------+
// Phreedom Language Translation File
// Generated: 2011-01-28 04:55:46
// +-----------------------------------------------------------------+
// Path: /modules/phreebooks/language/es_cr/classes/backorders_report.php

define('RW_BO_QTY_BACKORDER','Pendiente');
define('RW_QTY_IN_STOCK','En Inventario');
define('RW_BO_QTY_ORDERED','Pedido');
define('RW_BO_BILL_TELE1','Cobro Teléfono 1');
define('RW_BO_BILL_ZIP','Cobro Código Postal');
define('RW_BO_BILL_COUNTRY','Cobro País');
define('RW_BO_BILL_STATE','Cobro Provincia/Estado');
define('RW_BO_BILL_CITY','Cobro Ciudad');
define('RW_BO_BILL_ADDRESS2','Cobro Dirección L2');
define('RW_BO_BILL_ADDRESS1','Cobro Dirección L1');
define('RW_BO_BILL_CONTACT','Cobro Contacto');
define('RW_BO_BILL_PRIMARY_NAME','Cobro Nombre Principal');
define('RW_BO_BILL_ADD_ID','Cobro Identificación de Dirección');
define('RW_BO_BILL_ACCT_ID','Cobro Identificación de Cuenta');
define('RW_BO_AR_ACCT','Cuenta por Cobrar');
define('RW_BO_SALES_REP','Vendedor');
define('RW_BO_PO_NUM','Número de Órden de Compra');
define('RW_BO_INV_NUM','Número de Órden de Venta');
define('RW_BO_CUR_EXC_RATE','Tipo de Cambio');
define('RW_BO_BALANCE_DUE','Saldo Pendiente');
define('RW_BO_CUR_CODE','Código de Moneda');
define('RW_BO_INV_TOTAL','Monto de la Factura');
define('RW_BO_FRT_SERVICE','Servicio de Transporte');
define('RW_BO_SALES_TAX','Impuesto de Ventas');
define('RW_BO_TAX_AUTH','Tax Authorities');
define('RW_BO_FRT_CARRIER','Tansportista');
define('RW_BO_FRT_TOTAL','Monto de Flete');
define('RW_BO_STORE_ID','Tienda');
define('RW_BO_RECORD_ID','No. de Registro');

?>
