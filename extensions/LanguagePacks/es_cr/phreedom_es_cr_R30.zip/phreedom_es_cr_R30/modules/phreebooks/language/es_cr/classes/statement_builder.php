<?php
// +-----------------------------------------------------------------+
// Phreedom Language Translation File
// Generated: 2011-01-28 04:55:46
// +-----------------------------------------------------------------+
// Path: /modules/phreebooks/language/es_cr/classes/statement_builder.php

define('RW_SB_INV_TOTAL','Monto de la factura');
define('RW_SB_PMT_RCVD','Recibo de dinero');
define('RW_SB_PO_NUM','Número de órden de compra');
define('RW_SB_DUE_DATE','Vence');
define('RW_SB_INV_NUM','Número de factura');
define('RW_SB_JOURNAL_DESC','Descripción');
define('RW_SB_BALANCE_DUE','Saldo a pagar');
define('RW_SB_PRIOR_BALANCE','Saldo anterior');
define('RW_SB_BILL_EMAIL','Cobro correo electrónico');
define('RW_SB_BILL_WEBSITE','Cobro sito internet');
define('RW_SB_BILL_FAX','Cobro fax');
define('RW_SB_BILL_TELE2','Cobro teléfono 2');
define('RW_SB_BILL_CITY','Cobro ciudad');
define('RW_SB_BILL_STATE','Cobro provincia/estado');
define('RW_SB_BILL_ZIP','Cobro código postal');
define('RW_SB_BILL_COUNTRY','Cobro país');
define('RW_SB_BILL_TELE1','Cobro teléfono 1');
define('RW_SB_BILL_ADDRESS2','Cobro dirección línea 2');
define('RW_SB_BILL_CONTACT','Cobro contacto');
define('RW_SB_BILL_ADDRESS1','Cobro dirección línea 1');
define('RW_SB_BILL_PRIMARY_NAME','Cobro nombre principal');
define('RW_SB_SALES_REP','Vendedor');
define('RW_SB_TERMS','Términos');
define('RW_SB_ACCOUNT_NUMBER','Número de cuenta');
define('RW_SB_CUSTOMER_ID','Identificación de cliente');
define('RW_SB_POST_DATE','Fecha de registro');
define('RW_SB_JOURNAL_ID','Identificación de registro');
define('RW_SB_RECORD_ID','Identificación de registro');

?>
