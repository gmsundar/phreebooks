<?php
// +-----------------------------------------------------------------+
// Phreedom Language Translation File
// Generated: 2011-01-28 04:55:46
// +-----------------------------------------------------------------+
// Path: /modules/phreebooks/language/es_cr/menu.php

define('BOX_PHREEBOOKS_MODULE_ADM','Administración de PhreeBooks');
define('BOX_PRICE_SHEET_MANAGER','Lista de escalas de precios');
define('BOX_GL_BUDGET','Presupuestos');
define('BOX_GL_JOURNAL_ENTRY','Registro contable');
define('BOX_GL_UTILITIES','Utilitarios contabilidad');
define('BOX_BANKING_VOID_CHECKS','Cheques anulados');
define('BOX_BANKING_BANK_ACCOUNT_REGISTER','Registro de cuentas de efectivo');
define('BOX_BANKING_ACCOUNT_RECONCILIATION','Reconciliación de cuentas');
define('BOX_BANKING_SELECT_FOR_PAYMENT','Seleccione para pagar');
define('BOX_BANKING_CUSTOMER_RECEIPTS','Recibo de dinero de clientes');
define('BOX_BANKING_CUSTOMER_PAYMENTS','Pague a clientes');
define('BOX_BANKING_PAY_BILLS','Pague a proveedores');
define('BOX_BANKING_VENDOR_RECEIPTS','Reembolsos de proveedores');
define('BOX_BANKING_VENDOR_DEPOSITS','Depósitos de proveedores');
define('BOX_AP_CREDIT_MEMO','Créditos de proveedores');
define('BOX_AP_RFQ_STATUS','Lista de cotizaciones de proveedores');
define('BOX_BANKING_CUSTOMER_DEPOSITS','Depósitos de clientes');
define('BOX_AR_POINT_OF_PURCHASE','Punto de venta');
define('BOX_AP_PURCHASE_ORDER','Órden de compra nueva');
define('BOX_AP_ORDER_STATUS','Lista de órdenes de compra');
define('BOX_AP_RECEIVE_INVENTORY','Comprar/Ingresar');
define('BOX_AP_RFQ_STATUS','Lista de cotizaciones de proveedores');
define('BOX_AR_INVOICE_MGR','Lista de facturas');
define('BOX_AR_CREDIT_MEMO','Nota de crédito nueva');
define('BOX_AR_QUOTE_STATUS','Lista de cotizaciones a clientes');
define('BOX_AP_REQUEST_QUOTE','Solicitud de cotización a proveedor nueva');
define('BOX_AR_POINT_OF_SALE','Punto de venta');
define('MENU_HEADING_BANKING','Bancos');
define('BOX_AR_QUOTE','Cotización a cliente nueva');
define('BOX_AR_QUOTE_STATUS','Lista de cotizaciones a clientes');
define('BOX_AR_SALES_ORDER','Órden de venta nueva');
define('BOX_AR_ORDER_STATUS','Lista de órdenes de venta');
define('BOX_AR_INVOICE','Factura nueva');
define('MENU_HEADING_GL','Contabilidad');

?>
