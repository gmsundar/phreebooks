<?php
// +-----------------------------------------------------------------+
// Phreedom Language Translation File
// Generated: 2011-01-28 04:55:46
// +-----------------------------------------------------------------+
// Path: /modules/phreebooks/language/es_cr/classes/subaccount_is.php

define('RW_RECORD_ID','Posición columnar');
define('RW_FIN_NET_INCOME','Utilidad neta');
define('RW_SUB_ACT_BAL_SHT_IS_ACCT','0');

?>
