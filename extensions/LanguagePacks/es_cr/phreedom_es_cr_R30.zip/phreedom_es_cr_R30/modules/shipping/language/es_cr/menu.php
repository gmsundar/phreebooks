<?php
// +-----------------------------------------------------------------+
// Phreedom Language Translation File
// Generated: 2011-01-28 04:55:47
// +-----------------------------------------------------------------+
// Path: /modules/shipping/language/es_cr/menu.php

define('BOX_SHIPPING_MANAGER','Lista de fletes');

?>
