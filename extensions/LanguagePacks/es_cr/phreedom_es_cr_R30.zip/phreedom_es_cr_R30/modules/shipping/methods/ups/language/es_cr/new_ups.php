<?php
// +-----------------------------------------------------------------+
// Phreedom Language Translation File
// Generated: 2011-01-28 04:55:46
// +-----------------------------------------------------------------+
// Path: /modules/shipping/methods/ups/language/es_cr/new_ups.php

define('SHIPPING_UPS_ERROR_POSTAL_CODE','Se necesita un código postal para usar el módulo UPS');
define('SHIPPING_UPS_ERROR_WEIGHT_150','El peso del envío no puede ser de mas de 68 Kg. para usar el módulo de UPS.');
define('SHIPPING_UPS_PACKAGE_ERROR','Se paró por problemas dividiendo el embarque en partes.  El peso del embarque es: ');
define('SHIPPING_UPS_CURL_ERROR','Error cURL: ');
define('SRV_SHIP_UPS_BILL_DETAIL','Detalles de facturación');
define('SRV_SHIP_UPS_EMAIL_NOTIFY','Notificaciones por correo electrónico');
define('SRV_SHIP_UPS_RECP_INFO','Información del destinatario');
define('SRV_SHIP_UPS','Envíe un paquete');
define('SHIPPING_UPS_TNT_ERROR',' Error en tiempo de tránsito UPST # ');
define('SHIPPING_UPS_RATE_TRANSIT',' Día(s) en tránsito, llega ');
define('SHIPPING_UPS_RATE_CITY_MATCH','La ciudad no concuerda con el código postal.');
define('SHIPPING_UPS_RATE_ERROR','Error en respuesta de tarifa UPS: ');
define('SHIPPING_UPS_SHIPMENTS_ON','Envíos UPS el día ');
define('SHIPPING_UPS_HAZMAT_REPORTS','Reporte hazmat (materiales peligrosos)');
define('SHIPPING_UPS_MULTIWGHT_REPORTS','Reporte multipesos');
define('SHIPPING_UPS_CLOSE_REPORTS','Reporte de cierre');
define('SHIPPING_UPS_VIEW_REPORTS','Vea reportes para ');
define('MODULE_SHIPPING_UPS_STD','Estandard (Canada)');
define('MODULE_SHIPPING_UPS_XPD','Worldwide Expeditado');
define('MODULE_SHIPPING_UPS_XPR','Worldwide Expres');
define('MODULE_SHIPPING_UPS_XDM','Worldwide Expres Plus');
define('MODULE_SHIPPING_UPS_3DS','3 días selecto');
define('MODULE_SHIPPING_UPS_2DP','Segundo día aéreo');
define('MODULE_SHIPPING_UPS_2DM','Segundo día aéreo temprano AM');
define('MODULE_SHIPPING_UPS_1DP','Aéreo día siguiente ahorrativo');
define('MODULE_SHIPPING_UPS_1DA','Aéreo día siguiente');
define('MODULE_SHIPPING_UPS_1DM','Aéreo día siguiente temprano AM');
define('MODULE_SHIPPING_UPS_GND','Tierra');
define('UPS_TRACKING_URL','http://wwwapps.ups.com/etracking/tracking.cgi?tracknums_displayed=5&TypeOfInquiryNumber=T&HTMLVersion=4.0&sort_by=status&InquiryNumber1=');
define('','');
define('MODULE_SHIPPING_UPS_LTL_RATE_TEST_URL','https://onlinetools.ups.com/webservices/FreightRate');
define('MODULE_SHIPPING_UPS_QUANTUM_VIEW_TEST','https://wwwcie.ups.com/ups.app/xml/QVEvents');
define('MODULE_SHIPPING_UPS_QUANTUM_VIEW','https://www.ups.com/ups.app/xml/QVEvents');
define('MODULE_SHIPPING_UPS_VOID_SHIPMENT','https://www.ups.com/ups.app/xml/Void');
define('MODULE_SHIPPING_UPS_VOID_SHIPMENT_TEST','https://wwwcie.ups.com/ups.app/xml/Void');
define('MODULE_SHIPPING_UPS_LABEL_URL_TEST','https://wwwcie.ups.com/ups.app/xml/ShipAccept');
define('MODULE_SHIPPING_UPS_LABEL_URL','https://www.ups.com/ups.app/xml/ShipAccept');
define('MODULE_SHIPPING_UPS_SHIP_URL_TEST','https://wwwcie.ups.com/ups.app/xml/ShipConfirm');
define('MODULE_SHIPPING_UPS_SHIP_URL','https://www.ups.com/ups.app/xml/ShipConfirm');
define('MODULE_SHIPPING_UPS_SHIP_URL_TEST','https://wwwcie.ups.com/ups.app/xml/ShipConfirm');
define('MODULE_SHIPPING_UPS_SHIP_URL','https://www.ups.com/ups.app/xml/ShipConfirm');
define('MODULE_SHIPPING_UPS_TNT_URL_TEST','https://wwwcie.ups.com/ups.app/xml/TimeInTransit');
define('MODULE_SHIPPING_UPS_TNT_URL','https://www.ups.com/ups.app/xml/TimeInTransit');
define('MODULE_SHIPPING_UPS_RATE_URL_TEST','https://wwwcie.ups.com/ups.app/xml/Rate');
define('MODULE_SHIPPING_UPS_RATE_URL','https://www.ups.com/ups.app/xml/Rate');
define('MODULE_SHIPPING_UPS_TEXT_TITLE','United Parcel Service');
define('MODULE_SHIPPING_UPS_TITLE_SHORT','UPS');
define('MODULE_SHIPPING_UPS_TEXT_DESCRIPTION','United Parcel Service');

?>
