<?php
// +-----------------------------------------------------------------+
// Phreedom Language Translation File
// Generated: 2011-01-28 04:55:46
// +-----------------------------------------------------------------+
// Path: /modules/phreedom/dashboards/personal_links/language/es_cr/language.php

define('CP_PERSONAL_LINKS_NO_RESULTS','¡No hay ninguno!');
define('CP_PERSONAL_LINKS_DESCRIPTION','Lista de URL de uso personal.');
define('CP_PERSONAL_LINKS_TITLE','Mis vínculos');
define('CP_PERSONAL_LINKS_SECURITY',4);
?>
