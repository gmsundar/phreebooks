<?php
// +-----------------------------------------------------------------+
// Phreedom Language Translation File
// Generated: 2011-01-28 04:55:46
// +-----------------------------------------------------------------+
// Path: /modules/phreedom/language/es_cr/menu.php

define('BOX_HEADING_DEBUG_DL','Descargue archivo para despulgar');
define('BOX_HEADING_CONFIGURATION','Administración de módulos');
define('BOX_GENERAL_ADMIN','Módulo Phreedom - configuración general');
define('BOX_IMPORT_EXPORT','Importar/Exportar');
define('BOX_COMPANY_MANAGER','Compañías');
define('BOX_HEADING_ADMIN_TOOLS','Herramientas administrativas');
define('BOX_HEADING_ENCRYPTION','Servicios de encriptar datos');
define('BOX_HEADING_BACKUP','Respaldo de archivo de compañía');
define('MENU_HEADING_MODULES','Módulos');
define('BOX_HEADING_USERS','Lista de usuarios');
define('MENU_HEADING_TOOLS','Herramientas');
define('HEADING_TITLE_USERS','Usuarios');
define('MENU_HEADING_COMPANY','Compañía');
define('HEADER_TITLE_TOP','Inicio');
define('HEADER_TITLE_LOGOFF','Salir');

?>
