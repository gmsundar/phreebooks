<?php
// +-----------------------------------------------------------------+
// Phreedom Language Translation File
// Generated: 2011-01-28 04:55:46
// +-----------------------------------------------------------------+
// Path: /modules/payment/methods/directdebit/language/es_cr/language.php

define('MODULE_PAYMENT_DIRECTDEBIT_SORT_ORDER_DESC','Órden para mostrar. el número mas bajo se muestra de primero en la lista.');
define('MODULE_PAYMENT_DIRECTDEBIT_TEXT_REF_NUM','Número de Referencia');
define('MODULE_PAYMENT_DIRECTDEBIT_TEXT_DESCRIPTION','Depósito o tranferencia electrónica.');
define('MODULE_PAYMENT_DIRECTDEBIT_TEXT_TITLE','Depósito');

?>
