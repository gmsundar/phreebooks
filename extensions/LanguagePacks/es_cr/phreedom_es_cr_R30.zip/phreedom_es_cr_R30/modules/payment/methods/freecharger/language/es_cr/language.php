<?php
// +-----------------------------------------------------------------+
// Phreedom Language Translation File
// Generated: 2011-01-28 04:55:46
// +-----------------------------------------------------------------+
// Path: /modules/payment/methods/freecharger/language/es_cr/language.php

define('MODULE_PAYMENT_FREECHARGER_SORT_ORDER_DESC','Órden para mostrar. el número mas bajo se muestra de primero en la lista.');
define('MODULE_PAYMENT_FREECHARGER_TEXT_DESCRIPTION','Usado para compra de flete gratis solamente');
define('MODULE_PAYMENT_FREECHARGER_TEXT_TITLE','Flete gratis');

?>
