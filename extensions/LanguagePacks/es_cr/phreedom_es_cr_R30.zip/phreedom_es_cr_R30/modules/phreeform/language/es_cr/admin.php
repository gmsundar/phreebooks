<?php
// +-----------------------------------------------------------------+
// Phreedom Language Translation File
// Generated: 2011-01-28 04:55:46
// +-----------------------------------------------------------------+
// Path: /modules/phreeform/language/es_cr/admin.php

define('PF_DEFAULT_ROWSPACE_TEXT','Fija la separación entre los renglones de encabezado para reportes (predeterminado: 2)');
define('PF_DEFAULT_PAPERSIZE_TEXT','Fija el tamaño predeterminado del papel a ser usado para reportes y formularios (predeterminado: Carta)');
define('PF_DEFAULT_ORIENTATION_TEXT','Fija la orientación predeterminada del papel a ser usado para reportes y formularios (predeterminado: Vertical)');
define('PF_DEFAULT_TRIM_LENGTH_TEXT','Fija la longitud predeterminada para recortar el nombre de los reportes y formularios para los listados en formato de directorio (predeterminado: 25)');
define('PF_DEFAULT_TITLE2_TEXT','Fija el texto de título predeterminado en el encabezado 2 para reportes (predeterminado: Reporte generado %date%)');
define('PF_DEFAULT_COLUMN_WIDTH_TEXT','Fija el ancho de columna predeterminado a ser usado para reportes en mm (predeterminado: 25)');
define('PF_DEFAULT_MARGIN_TEXT','Fija márgen de página predeterminado a ser usado para reportes y formularios en mm (predeterminado: 8)');
define('PF_DEFAULT_TITLE1_TEXT','Fija el texto del título predeterminado en el encabezado 1 a ser usado para reportes (predeterminado: %reportname%)');
define('PB_CONVERT_SUCCESS','Se convirtieron exitósamente %s reportes y formularios. Si alguno tuvo errores de conversión, estos aparecieron en el mensaje previo.');
define('BOX_PHREEFORM_MODULE_ADM','Administración de PhreeForm');
define('PB_CONVERT_REPORTS','Convierta reportes .txt a PhreeForm');
define('PB_CONVERT_SAVE_ERROR','Hubo un error salvando la conversión del reporte: %s');
define('MODULE_PHREEFORM_TITLE','Módulo PhreeForm');
define('MODULE_PHREEFORM_DESCRIPTION','El módulo Phreeform contiene todas las herramientas necesarias para imprimir reportes y formularios in formato PDF o HTML. <b>NOTA: ¡Este es un módulo del núcleo por lo que no debe ser desinstalado!</b>');

?>
