<?php
// +-----------------------------------------------------------------+
// Phreedom Language Translation File
// Generated: 2011-01-28 04:55:46
// +-----------------------------------------------------------------+
// Path: /modules/inventory/language/es_cr/menu.php

define('BOX_INV_TRANSFER','Traslado de inventario');
define('BOX_INV_ASSEMBLIES','Ensamblajes');
define('BOX_INV_NEW','Agregar inventario');
define('BOX_INV_ADJUSTMENTS','Ajuste de inventario');
define('BOX_INV_MAINTAIN','Lista de códigos');
define('MENU_HEADING_INVENTORY','Inventario');

?>
