<?php
// +-----------------------------------------------------------------+
// |                   PhreeBooks Open Source ERP                    |
// +-----------------------------------------------------------------+
// | Copyright (c) 2010 PhreeSoft, LLC                               |
// | http://www.PhreeSoft.com                                        |
// +-----------------------------------------------------------------+
// | This program is free software: you can redistribute it and/or   |
// | modify it under the terms of the GNU General Public License as  |
// | published by the Free Software Foundation, either version 3 of  |
// | the License, or any later version.                              |
// |                                                                 |
// | This program is distributed in the hope that it will be useful, |
// | but WITHOUT ANY WARRANTY; without even the implied warranty of  |
// | MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the   |
// | GNU General Public License for more details.                    |
// +-----------------------------------------------------------------+
//  Path: /admin/soap/language/es_cr/language.php
//

define('ZENCART_PRODUCT_TAX_CLASS_ID',2); // sets the record id for the default sales tax to use
// General defines for SOAP interface
define('SOAP_NO_USER_PW','El nombre de usuario y contraseña no se pueden encontrar en el código XML.');
define('SOAP_USER_NOT_FOUND','El nombre de usuario no es válido.');
define('SOAP_PASSWORD_NOT_FOUND','La contraseña no es válida.');
define('SOAP_UNEXPECTED_ERROR','Un error inesperado en el código fue devuelto por el servidor.');
define('SOAP_BAD_LANGUAGE_CODE','El código ISO no se pudo encontrar en la tabla de idiomas de Zencart. Se esperaba encontrar el código = ');
define('SOAP_BAD_PRODUCT_TYPE','El tipo de producto no se puedo encontrar en la tabla de Zencart product_types table. Se esperaba encontrar type_name %s para el código %s.');
define('SOAP_BAD_MANUFACTURER','El nombre del fabricante no se pudo encontrar en la tabla de fabricantes de Zencart. Se esperaba encontrar el nombre de fabricante %s para el código %s.');
define('SOAP_BAD_CATEGORY','El nombre de la categoría no se pudo encontrar o no es único en la tabla categories_description de ZenCart. Se esperaba encontrar el nombre de la categoría de %s para el código %s.');
define('SOAP_BAD_CATEGORY_A','El nombre de la categoría no está en el nivel mas bajo del árbol de categorías. ¡Este es un requisito de ZenCart!');
define('SOAP_NO_SKU','No se encontró el código. ¡El código sku debe estar presente en el archivo XML!');
define('SOAP_BAD_ACTION','Una acción erronea se intentó procesar.');
define('SOAP_OPEN_FAILED','Hubo un error abriendo el archivo de imagen para escribir. Intentando escribir a: ');
define('SOAP_ERROR_WRITING_IMAGE','Error salvando un archivo de imagen en el directorio de imágenes de Zencart.');
define('SOAP_PU_POST_ERROR','Hubo un error actualizando el producto enZencart. Descripción - ');
define('SOAP_PRODUCT_UPLOAD_SUCCESS','El producto con código SKU %s se cargó exitósamente.');
define('SOAP_NO_ORDERS_TO_CONFIRM', 'Ninguna órden se cargó para confirmar.');
define('SOAP_CONFIRM_SUCCESS','La confirmación de órdenes se completó exitósamente. El número de órdenes actualizado fue: %s');
define('SOAP_NO_SKUS_UPLOADED','No se cargaron códigos skus para sincronizar.');
define('SOAP_SKUS_MISSING','Los siguientes códigos estan en Zencart pero no se marcaron para estar alli por PhreeBooks: ');
define('SOAP_PRODUCTS_IN_SYNC','Los listados de productos entre PhreeBooks y ZenCart están sincronizados.');

?>
