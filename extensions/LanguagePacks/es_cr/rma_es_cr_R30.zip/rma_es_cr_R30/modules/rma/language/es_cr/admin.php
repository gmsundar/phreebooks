<?php
// +-----------------------------------------------------------------+
// Phreedom Language Translation File
// Generated: 2011-01-28 04:55:46
// +-----------------------------------------------------------------+
// Path: /modules/rma/language/es_cr/admin.php

define('MODULE_RMA_DESCRIPTION','El módulo (RMA) es para administrar las devoluciones de los clientes.');
define('MODULE_RMA_TITLE','Módulo RMA');

?>
