<?php
// Path: /modules/contacts/language/es_cr/menu.php
//
define('BOX_PROJECTS_COSTS','Costos de proyecto');
define('BOX_HR_DEPARTMENTS','Departamentos');
define('BOX_PROJECTS_PHASES','Fases de proyecto');
define('BOX_CONTACTS_NEW_CONTACT','Contacto nuevo');
define('BOX_CONTACTS_NEW_VENDOR','Proveedor nuevo');
define('BOX_CONTACTS_MAINTAIN_VENDORS','Lista de proveedores');
define('BOX_CONTACTS_NEW_PROJECT','Proyecto nuevo');
define('BOX_CONTACTS_MAINTAIN_PROJECTS','Lista de proyectos');
define('BOX_CONTACTS_MAINTAIN_EMPLOYEES','Lista de empleados');
define('BOX_CONTACTS_MAINTAIN_CUSTOMERS','Lista de clientes');
define('BOX_CONTACTS_NEW_EMPLOYEE','Empleado nuevo');
define('BOX_CONTACTS_NEW_CUSTOMER','Cliente nuevo');
define('BOX_CONTACTS_NEW_BRANCH','Sucursal nueva');
define('BOX_CONTACTS_MAINTAIN_BRANCHES','Lista de sucursales');
define('BOX_PHREECRM_MODULE','Lista de contactos');
define('MENU_HEADING_EMPLOYEES','Empleados');
define('MENU_HEADING_CUSTOMERS','Clientes');
define('MENU_HEADING_VENDORS','Proveedores');

?>
