<?php
// Path: /modules/shipping/language/es_cr/menu.php
//
define('BOX_SHIPPING_MANAGER','Lista de fletes');

?>
