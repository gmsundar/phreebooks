<?php
// Path: /modules/shipping/methods/flat/language/es_cr/language.php
//
define('flat_GDR','Recoje el cliente');
define('SHIPPING_FLAT_SHIPMENTS_ON','Envíe tarifa fija el ');
define('flat_GND','Entrega local');
define('flat_3Dpm','Económica pagada por el que envía');
define('flat_1Dpm','1 día pagado por el que envía');
define('flat_2Dpm','Curier');
define('flat_1DEam','Mejor modo');
define('flat_1Dam','2 días pagado por el que envía');
define('MODULE_SHIPPING_FLAT_SORT_ORDER_DESC','Órden para mostrar.  Determina el órden en que este método aparecen en las listas.');
define('MODULE_SHIPPING_FLAT_COST_DESC','Costo total del flete para todas las órdenes usando este método de envío.');
define('MODULE_SHIPPING_FLAT_TITLE_DESC','Título usado para mostrar en el estimador de tarifas de envío.');
define('MODULE_SHIPPING_FLAT_TEXT_DESCRIPTION','Tarifa fija');
define('MODULE_SHIPPING_FLAT_TEXT_TITLE','Tarifa fija');

define('MODULE_SHIPPING_FLAT_TITLE_SHORT', 'Fijo');
define('SHIPPING_FLAT_SHIPMENTS_ON','Envíos tarifa fija activado ');


?>
