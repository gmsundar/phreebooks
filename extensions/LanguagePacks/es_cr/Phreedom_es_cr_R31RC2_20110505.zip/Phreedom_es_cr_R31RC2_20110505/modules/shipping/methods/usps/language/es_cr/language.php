<?php
// Path: /modules/shipping/methods/usps/language/es_cr/language.php
//
define('SHIPPING_USPS_ERROR_STATUS','<strong>Advertencia:</strong> Al módulo de envíos por USPS le falta el nombre de usuario o está en modo de PRUEBA en lugar de PRODUCCIÓN y así no puede trabajar.<br />Si no puede consultar las cotizaciones de fletes de USPS, comuníquese con USPS para activar su cuenta. 1-800-344-7779 o icustomercare@usps.com');
define('SHIPPING_USPS_SHIPMENTS_ON','Envíos de Servicio Postal de Estados Unidos del día ');
define('usps_GND','Parcel Post');
define('usps_3Dpm','Priority');
define('usps_1Dam','Express');
define('MODULE_SHIPPING_USPS_TYPES_INTL_DESC','Seleccione los servicios internacionales que va a ofrecer:');
define('MODULE_SHIPPING_USPS_TYPES_DESC','Seleccione los servicios domésticos de USPS que va a ofrecer como predeterminados.');
define('MODULE_SHIPPING_USPS_SORT_ORDER_DESC','Órden a mostrar.  Determina el órden en que este método aparecen en las listas.');
define('MODULE_SHIPPING_USPS_SERVER_DESC','Es necesaria una cuenta de USPS para un servidor de producción');
define('MODULE_SHIPPING_USPS_MACHINABLE_DESC','¿Todos los artículos enviados son factibles a ser procesados mecánicamente basado en el documento C700 Package Services 2.0 Nonmachinable PARCEL POST USPS Rules and Regulations?<br /><br /><strong>Nota: paquetes que no se puede mecanizar usualmente están sujetos a tarifas mas altas.<br /><br />Paquetes de 35lbs o mas, o menos de 6 onzas (.375), seran marcados como Falso</strong>');
define('MODULE_SHIPPING_USPS_USERID_DESC','Digite el USERID que le asignór USPS.');
define('MODULE_SHIPPING_USPS_TITLE_DESC','Título para ser mostrado en el estimador de tarifas');
define('MODULE_SHIPPING_USPS_TRACKING_URL','http://trkcnfrm1.smi.usps.com/PTSInternetWeb/InterLabelInquiry.do');
define('MODULE_SHIPPING_USPS_TEXT_DESCRIPTION','Servicio Postal de Estados Unidos<br /><br />Debe tener una cuenta registrada con USPS en http://www.uspsprioritymail.com/et_regcert.html para usar este módulo<br /><br />USPS espera que use libras como medida de peso para sus envíos.');
define('MODULE_SHIPPING_USPS_TITLE_SHORT','USPS');
define('MODULE_SHIPPING_USPS_TEXT_TITLE','Servicio postal de Estados Unidos');

?>
