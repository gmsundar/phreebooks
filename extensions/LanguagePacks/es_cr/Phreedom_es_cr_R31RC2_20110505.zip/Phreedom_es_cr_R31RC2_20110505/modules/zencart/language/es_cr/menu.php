<?php
// Path: /modules/zencart/language/es_cr/menu.php
//
define('BOX_ZENCART_MODULE','Interface ZenCart');
define('MENU_HEADING_ZENCART','ZenCart');

?>
