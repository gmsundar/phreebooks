<?php
//  Path: /modules/phreepos/language/es_cr/menu.php
//
// Enter the new menu category heading if necessary
define('MENU_HEADING_PHREEPOS', 'Punto de venta');
// Menu Titles
define('BOX_PHREEPOS', 'Punto de venta');
define('BOX_POS_MGR', 'Lista de punto de venta');
define('BOX_CUSTOMER_DEPOSITS', 'Depósito de cliente');
define('BOX_VENDOR_DEPOSITS', 'Depósito de proveedor');

?>
