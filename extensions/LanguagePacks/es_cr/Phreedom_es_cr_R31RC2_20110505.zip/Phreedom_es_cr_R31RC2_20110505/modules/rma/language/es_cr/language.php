<?php
// Path: /modules/rma/language/es_cr/language.php
//
define('RMA_ACTION_99','Otro (Especifique en las notas)');
define('RMA_ACTION_4','Reemplazo por garantía');
define('RMA_ACTION_5','Pérdida');
define('RMA_ACTION_3','Pruebe y reemplace');
define('RMA_ACTION_1','Devuelva al inventario');
define('RMA_ACTION_2','Devuelva al cliente');
define('RMA_REASON_99','Otro (Especifique en las notas)');
define('RMA_ACTION_0','Selecione acción ...');
define('RMA_REASON_5','Dañado en tránsito');
define('RMA_REASON_80','Conector equivocado');
define('RMA_REASON_1','No lo necesitó');
define('RMA_REASON_2','Pídió la parte equivocada');
define('RMA_REASON_3','No calzó');
define('RMA_REASON_4','Defectivo/se reemplazó');
define('RMA_STATUS_99','Cerrado');
define('RMA_REASON_0','Seleccione la razón para la devolución...');
define('RMA_STATUS_90','Cerrado - No llegó');
define('RMA_STATUS_6','Esperando para que se le acredite');
define('RMA_STATUS_7','Cerrado - reemplazado');
define('RMA_STATUS_5','En prueba');
define('RMA_STATUS_3','En inspección');
define('RMA_STATUS_4','Esperando tomar una decisión');
define('RMA_STATUS_2','Partes recibidas');
define('RMA_STATUS_0','Selecione estatus ...');
define('RMA_STATUS_1','RMA creado/esperando repuestos');
define('RMA_LOG_USER_UPDATE','RMA actualizado - RMA # ');
define('RMA_LOG_USER_ADD','RMA creado - RMA # ');
define('RMA_ROW_DELETE_ALERT','¿Está seguro que quiere borrar el ítem de esta fila?');
define('RMA_MSG_DELETE_RMA','¿Está seguro que quiere borrar este RMA?');
define('RMA_MESSAGE_DELETE','El RMA se borró exitósamente.');
define('RMA_ERROR_CANNOT_DELETE','Hubo un error borrando el RMA.');
define('RMA_MESSAGE_SUCCESS_UPDATE','Se actualizó exitósamene el RMA # ');
define('RMA_MESSAGE_SUCCESS_ADD','Se creó exitósamente el RMA # ');
define('RMA_MESSAGE_ERROR','Hubo un creando/actualizando el RMA.');
define('TEXT_RECEIVE_TRACKING_NUM','Número de seguimiento de envío:');
define('TEXT_RECEIVE_NOTES','Notas de quien recibió');
define('TEXT_RECEIVE_CARRIER','Transportista');
define('TEXT_CALLER_NAME','Cliente');
define('TEXT_CLOSED','Cerrado');
define('TEXT_TELEPHONE','Teléfono');
define('TEXT_DETAILS','Detalles');
define('TEXT_REASON_FOR_RETURN','Razón para la devolución');
define('TEXT_ENTERED_BY','Digitado por');
define('TEXT_RECEIVE_DATE','Recibido');
define('TEXT_RECEIVED_BY','Recibido por');
define('TEXT_PURCHASE_INVOICE_ID','Factura #');
define('TEXT_ASSIGNED_BY_SYSTEM',' (Asignado por el sistema)');
define('TEXT_CREATION_DATE','Fecha de reclamo');
define('TEXT_RMA_ID','RMA #');
define('MENU_HEADING_NEW_RMA','Reclamo de garantía nueva (RMA)');
define('TEXT_RMAS','RMA');
define('BOX_RMA_MAINTAIN','RMA - Control de garantías a clientes');

?>
