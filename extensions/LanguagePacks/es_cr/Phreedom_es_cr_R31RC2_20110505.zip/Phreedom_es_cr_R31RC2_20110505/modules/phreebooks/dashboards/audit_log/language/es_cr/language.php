<?php
//  Path: /modules/phreebooks/dashboards/audit_log/language/es_cr/language.php
//
define('CP_AUDIT_LOG_TITLE','Bitácora de auditoraje');
define('CP_AUDIT_LOG_DESCRIPTION','Lista de registros de la bitácora de auditoraje para un día particular.  El módulo tiene un control para fijar el día de los registros para mostrar.');
define('CP_AUDIT_LOG_NO_RESULTS','¡No hay ninguno!');
//define('CP_AUDIT_LOG_SECURITY',SECURITY_ID_REPORTS);
define('CP_AUDIT_LOG_SECURITY',4);

define('CP_AUDIT_LOG_DISPLAY','Muestre registros de ');
define('CP_AUDIT_LOG_DISPLAY2',' día(s) atrás (Hoy=0)');

?>
