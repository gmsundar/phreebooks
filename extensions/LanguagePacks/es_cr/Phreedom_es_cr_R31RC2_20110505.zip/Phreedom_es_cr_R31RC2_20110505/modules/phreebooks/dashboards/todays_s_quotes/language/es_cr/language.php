<?php
//  Path: /modules/phreebooks/dashboards/todays_s_quotes/language/es_cr/todays_s_quotes.php
//
define('CP_TODAYS_S_QUOTES_TITLE','Cotizaciones a clientes de hoy');
define('CP_TODAYS_S_QUOTES_DESCRIPTION','Lista de las cotizaciones a clientes de hoy. Las cotizaciones tienen los vínculos para abrilas.');
define('CP_TODAYS_S_QUOTES_SECURITY',SECURITY_ID_SALES_QUOTE);
define('CP_TODAYS_S_QUOTES_NO_RESULTS','¡No hay ninguna!');

?>
