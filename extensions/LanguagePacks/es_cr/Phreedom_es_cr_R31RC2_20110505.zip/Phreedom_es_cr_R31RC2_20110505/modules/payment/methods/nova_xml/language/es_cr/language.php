<?php
// +-----------------------------------------------------------------+
// Phreedom Language Translation File
// Generated: 2011-01-28 04:55:46
// +-----------------------------------------------------------------+
// Path: /modules/payment/methods/nova_xml/language/es_cr/language.php

define('MODULE_PAYMENT_NOVA_XML_TEXT_ERROR','¡Error de tarjeta de crédito!');
define('MODULE_PAYMENT_NOVA_XML_NO_DUPS','La tarjeta de crédito no se procesó porque ya fue procesada.  Para volver a cargar la tarjeta, la tarjeta de crédito debe ser válida y no contener caracteres *.');
define('MODULE_PAYMENT_NOVA_XML_TEXT_DECLINED_MESSAGE','La transacción de la tarjeta de crédito no se procesó correctamente.  Si no se da una razón, la tarjeta fue rechazada por el banco.');
define('MODULE_PAYMENT_NOVA_XML_TEXT_JS_CC_CVV','* Debe digitarse el código CVV de 3 o 4 dígitos que está en la parte de atrás de la tarjeta de crédito.\\n');
define('MODULE_PAYMENT_NOVA_XML_TEXT_JS_CC_NUMBER','* El número de la tarjeta de crédito debe ser de al menos \' . CC_NUMBER_MIN_LENGTH . \' caracteres.\\n');
define('MODULE_PAYMENT_NOVA_XML_TEXT_JS_CC_OWNER','* El nombre del dueño de la tarjeta de crédito debe ser de al menos \' . CC_OWNER_MIN_LENGTH . \' caracteres.\\n');
define('MODULE_PAYMENT_NOVA_XML_TEXT_CVV', 'CVV #(<a href="javascript:popupWindowCvv()">' . 'Mas info' . '</a>)');
define('MODULE_PAYMENT_NOVA_XML_TEXT_CREDIT_CARD_EXPIRES','Vence:');
define('MODULE_PAYMENT_NOVA_XML_TEXT_CREDIT_CARD_NUMBER','Número de la tarjeta:');
define('MODULE_PAYMENT_NOVA_XML_TEXT_CREDIT_CARD_OWNER','Dueño de la tarjeta:');
define('MODULE_PAYMENT_NOVA_XML_TEXT_CREDIT_CARD_TYPE','Tipo de tarjeta de crédito:');
define('MODULE_PAYMENT_NOVA_XML_TEXT_CATALOG_TITLE','Tarjeta de crédito');
define('MODULE_PAYMENT_NOVA_XML_SORT_ORDER_DESC','Órden para mostrar. el número mas bajo se muestra de primero en la lista.');
define('MODULE_PAYMENT_NOVA_XML_AUTHORIZATION_TYPE_DESC','¿Quiere que las transacciones de tarjeta de crédito remitidas sean solamente aprobadas o autorizadas y capturadas?');
define('MODULE_PAYMENT_NOVA_XML_TESTMODE_DESC','Modeo de transacción usado para procesar órdenes');
define('MODULE_PAYMENT_NOVA_XML_PIN_DESC','Clave PIN usado para el servicio Elevon Network:');
define('MODULE_PAYMENT_NOVA_XML_USER_ID_DESC','Nombre de usuario para el servicio Elevon Network:');
define('MODULE_PAYMENT_NOVA_XML_MERCHANT_ID_DESC','Número de comerciante para el servicio Elevon Network:');
define('MODULE_PAYMENT_NOVA_XML_STATUS_DESC','Quiere aceptar pagos a traves de Elevon Network?');
define('MODULE_PAYMENT_NOVA_XML_TEXT_INTRODUCTION','Cuando en modo de prueba, las tarjetas devuelven un código de aprovado pero no son procesadas.');
define('MODULE_PAYMENT_NOVA_XML_TEXT_DESCRIPTION','Cuando en modo de prueba, las tarjetas devuelven un código de éxito sin embargo, no son procesadas.<br /><br />');
define('MODULE_PAYMENT_NOVA_XML_TEXT_TITLE','Elevon (mercante virtual)');

?>
