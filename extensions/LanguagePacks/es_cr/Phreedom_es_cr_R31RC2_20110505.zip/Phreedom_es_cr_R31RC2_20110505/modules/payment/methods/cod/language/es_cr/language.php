<?php
// Path: /modules/payment/methods/cod/language/es_cr/language.php
//
define('MODULE_PAYMENT_COD_SORT_ORDER_DESC','Órden para mostrar. el número mas bajo se muestra de primero en la lista.');
define('MODULE_PAYMENT_COD_TEXT_DESCRIPTION','Efectivo');
define('MODULE_PAYMENT_COD_TEXT_TITLE','Efectivo');

?>
