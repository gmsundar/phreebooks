<?php
// +-----------------------------------------------------------------+
// Phreedom Language Translation File
// Generated: 2011-01-28 04:55:46
// +-----------------------------------------------------------------+
// Path: /modules/payment/language/es_cr/menu.php

define('MENU_HEADING_PHREEPAY','Administración de pagos PhreePay');

?>
