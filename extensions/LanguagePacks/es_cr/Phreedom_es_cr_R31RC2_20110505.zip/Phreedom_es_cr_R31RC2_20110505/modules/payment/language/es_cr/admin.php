<?php
// +-----------------------------------------------------------------+
// Phreedom Language Translation File
// Generated: 2011-01-28 04:55:46
// +-----------------------------------------------------------------+
// Path: /modules/payment/language/es_cr/admin.php

define('TEXT_REMOVE_MESSAGE','¿Está seguro de que quiere eliminar este módulo y toda la información asociada?');
define('TEXT_AUTHORIZE','Autorice');
define('TEXT_CAPTURE','Capture');
define('TEXT_PRODUCTION','Producción');
define('TEXT_PAYMENT_MODULES_AVAILABLE','Módulos de pago disponibles');
define('MODULE_PAYMENT_TITLE','Módulo Pagos');
define('MODULE_PAYMENT_DESCRIPTION','El módulo pagos es un programa envolvete para métodos de pago configurados por el usuario. Algunos métodos de pago se incluyen con el programa núcleo y otros están disponibles para descargar en el sitio de PhreeSoft <b>NOTA: ¡Este es un módulo del núcleo por lo que no debe ser desinstalado!</b>');

?>
