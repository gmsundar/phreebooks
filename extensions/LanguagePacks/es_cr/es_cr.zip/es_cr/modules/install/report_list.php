<?php
// +-----------------------------------------------------------------+
// |                   PhreeBooks Open Source ERP                    |
// +-----------------------------------------------------------------+
// | Copyright (c) 2008, 2009, 2010 PhreeSoft, LLC                   |
// | http://www.PhreeSoft.com                                        |
// +-----------------------------------------------------------------+
// | This program is free software: you can redistribute it and/or   |
// | modify it under the terms of the GNU General Public License as  |
// | published by the Free Software Foundation, either version 3 of  |
// | the License, or any later version.                              |
// |                                                                 |
// | This program is distributed in the hope that it will be useful, |
// | but WITHOUT ANY WARRANTY; without even the implied warranty of  |
// | MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the   |
// | GNU General Public License for more details.                    |
// |                                                                 |
// | The license that is bundled with this package is located in the |
// | file: /doc/manual/ch01-Introduction/license.html.               |
// | If not, see http://www.gnu.org/licenses/                        |
// +-----------------------------------------------------------------+
//  Path: /modules/install/report_list.php
//

/* This file holds the list of reports to import during setup. */
$report_list = array();

// es_cr
// Receivables Reports and Forms
$report_list[] = 'FacturaDescuento.rpt.txt';
$report_list[] = 'AntiguedadCxC.rpt.txt';
$report_list[] = 'NotaCredito.rpt.txt';
$report_list[] = 'HistoriaFacturaCliente.rpt.txt';
$report_list[] = 'ListaClientes.rpt.txt';
$report_list[] = 'PagosClientes.rpt.txt';
$report_list[] = 'CotizacionesClientes.rpt.txt';
$report_list[] = 'Factura.rpt.txt';
$report_list[] = 'OrdenesVentaAbiertas.rpt.txt';
$report_list[] = 'ListaEmpaque.rpt.txt';
$report_list[] = 'OrdenVenta.rpt.txt';
$report_list[] = 'ReporteVentas.rpt.txt';
$report_list[] = 'EstadoCuentaCliente.rpt.txt';
$report_list[] = 'ListaEmpaqueCliente.rpt.txt';
$report_list[] = 'TransaccionesCliente.rpt.txt';

// Payables Reports and Forms
$report_list[] = 'AntiguedadCxP.rpt.txt';
$report_list[] = 'OrdenCompraAbiertas.rpt.txt';
$report_list[] = 'OrdenCompra.rpt.txt';
$report_list[] = 'FechasEntregaCompras.rpt.txt';
$report_list[] = 'SolicitudCotizacionProveedor.rpt.txt';
$report_list[] = 'ListaProveedores.rpt.txt';
$report_list[] = 'PagosAProveedor.rpt.txt';
$report_list[] = 'EstadoCuentaProveedor.rpt.txt';
$report_list[] = 'NotaCreditoProveedor.rpt.txt';

// Inventory Reports and Forms
$report_list[] = 'AntiguedadInventario.rpt.txt';
$report_list[] = 'ListaItemsEnsamblaje.rpt.txt';
$report_list[] = 'ListaInventario.rpt.txt';
$report_list[] = 'HojaTrabajoCompras.rpt.txt';
$report_list[] = 'PedidosPendientes.rpt.txt';
$report_list[] = 'ReporteCompras.rpt.txt';
$report_list[] = 'ValorInventario.rpt.txt';

// Human Resources Reports and Forms
$report_list[] = 'ListaEmpleados.rpt.txt';

// Manufacturing Reports and Forms

// General Ledger Reports and Forms
$report_list[] = 'BalanceGeneral.rpt.txt';
$report_list[] = 'CuadroDeCuentas.rpt.txt';
$report_list[] = 'LibroMayor.rpt.txt';
$report_list[] = 'BalanceDePrueba.rpt.txt';
$report_list[] = 'EstadoDeResultados.rpt.txt';
$report_list[] = 'EstadoResultados24meses.rpt.txt';

// Banking Reports and Forms
$report_list[] = 'Cheque-3partes.rpt.txt';
$report_list[] = 'ReciboDeposito.rpt.txt';

// Miscellaneous Reports and Forms
$report_list[] = 'BitacoraAuditoria.rpt.txt';

?>
