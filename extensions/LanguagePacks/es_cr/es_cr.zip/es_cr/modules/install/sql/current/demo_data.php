<?php
// +-----------------------------------------------------------------+
// |                   PhreeBooks Open Source ERP                    |
// +-----------------------------------------------------------------+
// | Copyright (c) 2008, 2009, 2010 PhreeSoft, LLC                   |
// | http://www.PhreeSoft.com                                        |
// +-----------------------------------------------------------------+
// | This program is free software: you can redistribute it and/or   |
// | modify it under the terms of the GNU General Public License as  |
// | published by the Free Software Foundation, either version 3 of  |
// | the License, or any later version.                              |
// |                                                                 |
// | This program is distributed in the hope that it will be useful, |
// | but WITHOUT ANY WARRANTY; without even the implied warranty of  |
// | MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the   |
// | GNU General Public License for more details.                    |
// |                                                                 |
// | The license that is bundled with this package is located in the |
// | file: /doc/manual/ch01-Introduction/license.html.               |
// | If not, see http://www.gnu.org/licenses/                        |
// +-----------------------------------------------------------------+
//  Path: /modules/install/sql/current/demo_data.php
//

$extra_sqls = array();

// Data for table `address_book`

$extra_sqls[] = "INSERT INTO " . DB_PREFIX . "address_book VALUES (1, 1, 'vm', 'Mi Video', '', '63 Avenida 28', '', 'San Diego', 'CA', '93245', 'USA', '800.345.5678', '', '', '', 'info@mivideo.com', '', '');";
$extra_sqls[] = "INSERT INTO " . DB_PREFIX . "address_book VALUES (2, 2, 'cm', 'Sistemas Casa Cómputo', '', '8086 Avenida Intel', '', 'San José', 'CA', '94354', 'USA', '800-555-1234', '', '', '', 'ventas@casacomputo.com', '', '');";
$extra_sqls[] = "INSERT INTO " . DB_PREFIX . "address_book VALUES (3, 3, 'vm', 'Electro Veloz S.A..', '', '777 Calle 12', 'Casa #2B', 'San José', 'CA', '92666', 'USA', '802-555-9876', '', '', '', 'servcliente@electroveloz.com', '', '');";
$extra_sqls[] = "INSERT INTO " . DB_PREFIX . "address_book VALUES (4, 4, 'cm', 'Servicio Reparación CompuMás', '', '12932 136 Ave.', 'No.456', 'Denver', 'CO', '80021', 'USA', '303-555-5469', '', '', '', 'servicio@compumas.net', '', '');";
$extra_sqls[] = "INSERT INTO " . DB_PREFIX . "address_book VALUES (5, 5, 'vm', 'Monitores y Mar Corp.', '', '28973 Calle de los Pixeles', '', 'Los Angeles', 'CA', '90001', 'USA', '800-555-5548', '', '', '', 'arturo@moymar.com', '', '');";
$extra_sqls[] = "INSERT INTO " . DB_PREFIX . "address_book VALUES (6, 6, 'vm', 'Corporación Caja Grande', '', '11 Cuadra D', '', 'Largo', 'CO', '80501', 'USA', '303-555-9652', '', '', '', 'caja.grande@yahoo.com', '', '');";
$extra_sqls[] = "INSERT INTO " . DB_PREFIX . "address_book VALUES (7, 7, 'cm', 'Juan Torres', '', '13546 Ave. Euclides', '', 'Ontario', 'CA', '92775', 'USA', '818-555-1000', '', '', '', 'jtorres@aol.com', '', '');";
$extra_sqls[] = "INSERT INTO " . DB_PREFIX . "address_book VALUES (8, 8, 'cm', 'Andrés Lucas', '', '995 Higueron II', 'Unidad #56', 'Nortigua', 'CO', '80234', 'USA', 'unlisted', '', '', '', 'alb23@hotmail.com', '', '');";
$extra_sqls[] = "INSERT INTO " . DB_PREFIX . "address_book VALUES (9, 9, 'cm', 'Lisa Conejo', '', '1005 Gilligan', '', 'Butaca', 'CO', '80303', 'USA', '303-555-6677', '', '', '', 'lisa@freeservers.com', '', '');";
$extra_sqls[] = "INSERT INTO " . DB_PREFIX . "address_book VALUES (10, 10, 'cm', 'Repuestos Locales S.R.L.', '', '55 Calle del Sisne', '', 'San Marcos', 'FL', '33445', 'USA', '215-555-0987', '', '', '', 'partes@replocales.com', '', '');";
$extra_sqls[] = "INSERT INTO " . DB_PREFIX . "address_book VALUES (11, 11, 'vm', 'Digitación Precisa, S. A.', '', '1111 Calle Tecla Trabada', '', 'San Bernardino', 'CA', '91505', 'USA', '800-555-1267', '', '818-555-5555', '', 'ventas@precision.com', 'www.precision.com', '');";
$extra_sqls[] = "INSERT INTO " . DB_PREFIX . "address_book VALUES (12, 12, 'vm', 'Sistemas de Respaldo S.A.', '', '1324 Avenida 44', '', 'Nueva York', 'NY', '10019', 'USA', '212-555-9854', '', '', '', 'juan@respaldo.com', '', '');";
$extra_sqls[] = "INSERT INTO " . DB_PREFIX . "address_book VALUES (13, 13, 'vm', 'Fábrica Los Patitos', 'Fernando', '23 Circunvalación Norte', '', 'Nueva York', 'NY', '10019', 'USA', '888-555-6322', '800-555-5716', '', '', 'ventas@patitos.net', '', '');";
$extra_sqls[] = "INSERT INTO " . DB_PREFIX . "address_book VALUES (14, 14, 'vm', 'Fuentes de Poder MegaWatts', '', '11 Calle Joules', '', 'Denver', 'CO', '80234', 'USA', '303-222-5617', '', '', '', 'help@hotmail.com', '', '');";
$extra_sqls[] = "INSERT INTO " . DB_PREFIX . "address_book VALUES (15, 15, 'vm', 'Discos para Cómputo S.R.L.', 'Cuentas por Cobrar', '1426 Calle Principal', 'Suite #1', 'La Veranita', 'CA', '91750', 'USA', '714-555-0001', '', '', '', 'ventas@discos.com', '', '');";
$extra_sqls[] = "INSERT INTO " . DB_PREFIX . "address_book VALUES (16, 16, 'em', '', '', '123 Birch Ave', 'Apt 12', 'Puebla', 'CO', '80234', 'USA', '303-555-3451', '', '', '', 'juan@micompania.com', '', '');";
$extra_sqls[] = "INSERT INTO " . DB_PREFIX . "address_book VALUES (17, 17, 'em', '', '', '6541 Calle Primera', '', 'Puebla', 'CO', '80234', 'USA', '303-555-7426', '', '', '', 'naty@misitio.com', '', '');";

// Data for table `contacts`

$extra_sqls[] = "INSERT INTO " . DB_PREFIX . "contacts VALUES (1, 'v', 'Mi Video', '', '', '', '', '', '2000', '', '', '', '3:1:10:30:2500.00', '', now(), NULL, NULL, NULL);";
$extra_sqls[] = "INSERT INTO " . DB_PREFIX . "contacts VALUES (2, 'c', 'Sistemas Casa Cómputo', '', '', '', '', '', '4000', '', '', '', '0::::2500.00', '', now(), NULL, NULL, NULL);";
$extra_sqls[] = "INSERT INTO " . DB_PREFIX . "contacts VALUES (3, 'v', 'Electro Veloz', '', '', '', '', '', '2000', '', '', '', '0::::2500.00', '', now(), NULL, NULL, NULL);";
$extra_sqls[] = "INSERT INTO " . DB_PREFIX . "contacts VALUES (4, 'c', 'CompuMar', '', '', '', '', '', '4000', '', '', '', '0::::2500.00', '', now(), NULL, NULL, NULL);";
$extra_sqls[] = "INSERT INTO " . DB_PREFIX . "contacts VALUES (5, 'v', 'Monitores y Más', '', '', '', '', '', '2000', '', '', '', '0::::2500.00', '', now(), NULL, NULL, NULL);";
$extra_sqls[] = "INSERT INTO " . DB_PREFIX . "contacts VALUES (6, 'v', 'Caja Grande', '', '', '', '', '', '2000', '', '', '', '0::::2500.00', '', now(), NULL, NULL, NULL);";
$extra_sqls[] = "INSERT INTO " . DB_PREFIX . "contacts VALUES (7, 'c', 'Torres Juan', '', '', '', '', '', '4000', '', '', '', '0::::2500.00', '', now(), NULL, NULL, NULL);";
$extra_sqls[] = "INSERT INTO " . DB_PREFIX . "contacts VALUES (8, 'c', 'AndresLucas', '', '', '', '', '', '4000', '', '', '', '0::::2500.00', '', now(), NULL, NULL, NULL);";
$extra_sqls[] = "INSERT INTO " . DB_PREFIX . "contacts VALUES (9, 'c', 'Conejo', '', '', '', '', '', '4000', '', '', '', '0::::2500.00', '', now(), NULL, NULL, NULL);";
$extra_sqls[] = "INSERT INTO " . DB_PREFIX . "contacts VALUES (10, 'c', 'RepuestosLocales', '', '', '', '', '', '4000', '', '', '', '3:0:10:30:2500.00', '', now(), NULL, NULL, NULL);";
$extra_sqls[] = "INSERT INTO " . DB_PREFIX . "contacts VALUES (11, 'v', 'Digitación Precisa', '', '', '', '', '', '2000', '', '', 'SK200706', '3:0:10:30:2500.00', '', now(), NULL, NULL, NULL);";
$extra_sqls[] = "INSERT INTO " . DB_PREFIX . "contacts VALUES (12, 'v', 'Sistemas de Respaldo', '', '', '', '', '', '2000', '', '', '', '0::::2500.00', '', now(), NULL, NULL, NULL);";
$extra_sqls[] = "INSERT INTO " . DB_PREFIX . "contacts VALUES (13, 'v', 'Los Patitos', '', '', '', '', '', '2000', '', '', '', '0::::2500.00', '', now(), NULL, NULL, NULL);";
$extra_sqls[] = "INSERT INTO " . DB_PREFIX . "contacts VALUES (14, 'v', 'MegaWatts', '', '', '', '', '', '2000', '', '', 'MW20070301', '0::::2500.00', '', now(), NULL, NULL, NULL);";
$extra_sqls[] = "INSERT INTO " . DB_PREFIX . "contacts VALUES (15, 'v', 'Discos para Cómputo', '', '', '', '', '', '2000', '', '', '', '0::::2500.00', '', now(), NULL, NULL, NULL);";
$extra_sqls[] = "INSERT INTO " . DB_PREFIX . "contacts VALUES (16, 'e', 'Juan', '', 'Juan', '', 'Torres', '', 'b', '', 'Ventas', '', '::::', '', now(), NULL, NULL, NULL);";
$extra_sqls[] = "INSERT INTO " . DB_PREFIX . "contacts VALUES (17, 'e', 'Nati', '', 'Nati', '', 'Conejo', '', 'e', '', 'Contabilidad', '', '::::', '', now(), NULL, NULL, NULL);";

// Data for table `departments`

$extra_sqls[] = "INSERT INTO " . DB_PREFIX . "departments VALUES ('1','Ventas', 'Ventas', '0', '', 2, '0');";
$extra_sqls[] = "INSERT INTO " . DB_PREFIX . "departments VALUES ('2','Administración', 'Administración y Operaciones', '0', '', 1, '0');";
$extra_sqls[] = "INSERT INTO " . DB_PREFIX . "departments VALUES ('3','Contabilidad', 'Contabilidad y Finanzas', '0', '', 1, '0');";
$extra_sqls[] = "INSERT INTO " . DB_PREFIX . "departments VALUES ('4','Envíos', 'Bodega de Envíos', '0', '', 4, '0');";
$extra_sqls[] = "INSERT INTO " . DB_PREFIX . "departments VALUES ('5','Recibos', 'Recibo de Materiales', '0', '', 4, '0');";

// Data for table `departments_types`

$extra_sqls[] = "INSERT INTO " . DB_PREFIX . "departments_types VALUES (1, 'Administración');";
$extra_sqls[] = "INSERT INTO " . DB_PREFIX . "departments_types VALUES (2, 'Ventas y Mercadeo');";
$extra_sqls[] = "INSERT INTO " . DB_PREFIX . "departments_types VALUES (3, 'Fabricación');";
$extra_sqls[] = "INSERT INTO " . DB_PREFIX . "departments_types VALUES (4, 'Envíos y Recibos');";

// Data for table `inventory`

$extra_sqls[] = "INSERT INTO " . DB_PREFIX . "inventory VALUES (1, 'CPU-AMD-3600', '0', 'si', 'Procesador CPU AMD 3600+ Athlon', 'Procesador CPU AMD 3600+ Athlon', 'Procesador CPU AMD 3600+ Athlon', 'demo/athlon.jpg', '4000', '1200', '5000', '1', '0', 100, 'f','', 150, 1, 0, 0, 0, 0, 0, 3, 1, '', '0', now(), '', '');";
$extra_sqls[] = "INSERT INTO " . DB_PREFIX . "inventory VALUES (2, 'SIS-BASICO', '0', 'lb', 'Mano de Obra - Sistema Básico', 'Mano de Obra - Ensamblaje de Sistema Básico', 'Mano de Obra - Ensamblaje de Sistema Básico', '', '4000', '6000', '5000', '1', '0', 25, 'f','', 0, 0, 0, 0, 0, 0, 0, 0, 1, '', '0', now(), '', '');";
$extra_sqls[] = "INSERT INTO " . DB_PREFIX . "inventory VALUES (3, 'CAJA-TW-322', '0', 'si', 'Caja Cartón TW-322', 'Caja Cartón TW-322 - 30 x 30 x 30', 'Caja Cartón TW-322', '', '4000', '6800', '5000', '1', '0', 1.35, 'f','', 0, 0, 0, 0, 0, 15, 25, 0, 1, '', '0', now(), '', '');";
$extra_sqls[] = "INSERT INTO " . DB_PREFIX . "inventory VALUES (4, 'CAJA-TW-553', '0', 'si', 'Caja Cartón TW-533', 'Caja Cartón TW-533 - 60 x 30 x 30', 'Caja Cartón TW-533', '', '4000', '6800', '5000', '1', '0', 1.75, 'f','', 0, 0, 0, 0, 0, 0, 0, 0, 1, '', '0', now(), '', '');";
$extra_sqls[] = "INSERT INTO " . DB_PREFIX . "inventory VALUES (5, 'CASE-ALIEN', '0', 'si', 'Case Alien - Rojo', 'Case - Rojo Torre ATX sin fuente de poder', 'Case Alien - Rojo', 'demo/red_alien.jpg', '4000', '1200', '5000', '1', '0', 47, 'f','', 98.26, 11, 0, 0, 0, 2, 1, 13, 5, '', '0', now(), '', '');";
$extra_sqls[] = "INSERT INTO " . DB_PREFIX . "inventory VALUES (6, 'CERT-GAR', '0', 'ai', 'Certificado de Garantía', 'Certificado de Garantía', 'Certificado de Garantía', '', '1000', '1000', '1000', '1', '0', 0, 'f','', 0, 0, 0, 0, 0, 0, 0, 0, 1, '', '0', now(), '', '');";
$extra_sqls[] = "INSERT INTO " . DB_PREFIX . "inventory VALUES (7, 'DVD-RW', '0', 'si', 'DVD RW con Lightscribe', 'DVD RW con Lightscribe - 8x', 'DVD RW con Lightscribe', 'demo/lightscribe.jpg', '4000', '1200', '5000', '1', '0', 23.6, 'f','', 45, 2, 0, 0, 0, 3, 1, 15, 14, '', '0', now(), '', '');";
$extra_sqls[] = "INSERT INTO " . DB_PREFIX . "inventory VALUES (8, 'DD-150GB', '0', 'si', 'Disco Duro 150GB SATA', 'Disco Duro 150GB SATA - 7200 RPM', 'Disco Duro 150GB SATA', 'demo/150gb_sata.jpg', '4000', '1200', '5000', '1', '0', 27, 'f','', 56, 2, 0, 0, 0, 10, 15, 15, 30, '', '0', now(), '', '');";
$extra_sqls[] = "INSERT INTO " . DB_PREFIX . "inventory VALUES (9, 'TECL-128-ERGO', '0', 'si', 'Teclado Ergonómico KeysRus', 'Teclado Ergonómico KeysRus - Iluminado para Juegos', 'Teclado Ergonómico KeysRus', 'demo/ergo_key.jpg', '4000', '1200', '5000', '0', '1', 23.51, 'f','', 56.88, 0, 0, 0, 0, 5, 10, 11, 1, '', '0', now(), '', '');";
$extra_sqls[] = "INSERT INTO " . DB_PREFIX . "inventory VALUES (10, 'LCD-21-WS', '0', 'si', 'Monitor 21\" LCD', 'Monitor 21\" LCD - Pantalla Ancha c/anti-reflejos, Negro', 'Monitor 21\" LCD', 'demo/monitor.jpg', '4000', '1200', '5000', '1', '0', 145.01, 'f','', 189.99, 0, 0, 0, 0, 2, 1, 5, 3, '', '0', now(), '', '');";
$extra_sqls[] = "INSERT INTO " . DB_PREFIX . "inventory VALUES (11, 'TM-ATI-K8', '0', 'si', 'Tarjeta Madre ATI K8', 'Tarjeta Madre ATI-K8-TW AMD socket 939 para procesadores Athlon', 'Tarjeta Madre ATI K8', 'demo/mobo.jpg', '4000', '1200', '5000', '1', '0', 125, 'f','', 155.25, 1, 0, 0, 0, 5, 10, 3, 3, '', '0', now(), '', '');";
$extra_sqls[] = "INSERT INTO " . DB_PREFIX . "inventory VALUES (12, 'TM-ATI-K8N', '0', 'si', 'Tarjeta Madre ATI K8 con red', 'Tarjeta Madre ATI-K8-TW AMD socket 939 para procesadores Athlon con puertos de red', 'Tarjeta Madre ATI K8 con red', 'demo/mobo.jpg', '4000', '1200', '5000', '1', '0', 135, 'f','', 176.94, 1.2, 0, 0, 0, 3, 10, 3, 3, '', '0', now(), '', '');";
$extra_sqls[] = "INSERT INTO " . DB_PREFIX . "inventory VALUES (13, 'MOUSE-S', '0', 'si', 'Ratón Serial - 300 DPI', 'Ratón Serial - 300 DPI', 'Ratón Serial - 300 DPI', 'demo/serial_mouse.jpg', '4000', '1200', '5000', '1', '0', 4.85, 'f','', 13.99, 0.6, 0, 0, 0, 15, 25, 11, 1, '', '0', now(), '', '');";
$extra_sqls[] = "INSERT INTO " . DB_PREFIX . "inventory VALUES (14, 'PC-2GB-120GB-21', '0', 'as', 'Computador 2GB-120GB-21', 'Sistema Completo AMD/ATI 2048GB Ram/DD 1282 GB/Case Rojo/ Monitor/ Teclado/ Mouse', 'Computador 2GB-120GB-21', 'demo/complete_computer.jpg', '4000', '1200', '5000', '1', '0', 0, 'f','', 750, 21.3, 0, 0, 0, 0, 0, 0, 1, '', '0', now(), '', '');";
$extra_sqls[] = "INSERT INTO " . DB_PREFIX . "inventory VALUES (15, 'FUENTE-450W', '0', 'si', 'Fuente de Poder 450 Watt Silenciosa', 'Fuente de Poder 450 Watt Silenciosa - para procesadores Intel o AMD', 'Fuente de Poder 450 Watt Silenciosa', 'demo/power_supply.jpg', '4000', '1200', '5000', '1', '0', 86.26, 'f','', 124.5, 4.7, 0, 0, 0, 10, 6, 14, 5, '', '0', now(), '', '');";
$extra_sqls[] = "INSERT INTO " . DB_PREFIX . "inventory VALUES (16, 'RAM-2GB-0.2', '0', 'si', 'Memoria 2GB SDRAM', 'Memoria 2GB PC3200 SDRAM - p/CPU Athlon', 'Memoria 2GB SDRAM', 'demo/2gbram.jpg', '4000', '1200', '5000', '1', '0', 56.25, 'f','', 89.65, 0, 0, 0, 0, 8, 10, 3, 2, '', '0', now(), '', '');";
$extra_sqls[] = "INSERT INTO " . DB_PREFIX . "inventory VALUES (17, 'VID-NV-512MB', '0', 'si', 'Tarjeta de Video nVidia 512 MB', 'Tarjeta de Video nVidia 512 MB - con SLI', 'Tarjeta de Video nVidia 512 MB', 'demo/nvidia_512.jpg', '4000', '1200', '5000', '1', '0', 0, 'f','', 300, 0.7, 0, 0, 0, 4, 5, 1, 4, '', '0', now(), '', '');";
$extra_sqls[] = "INSERT INTO " . DB_PREFIX . "inventory VALUES (18, 'PC-BB-512', '0', 'as', 'Sistema Básico 2600+/2GB', 'Sistema Básico Ensamblado AMD/ATI 512MB/2GB/Case Rojo', 'Sistema Básico 2600+/2GB', 'demo/barebones.jpg', '4000', '1200', '5000', '1', '0', 0, 'f','', 750, 21.3, 0, 0, 0, 0, 0, 0, 1, '', '0', now(), '', '');";

// Data for table `inventory_assy_list`

$extra_sqls[] = "INSERT INTO " . DB_PREFIX . "inventory_assy_list VALUES (1, 14, 'LCD-21-WS', 'Monitor LCD 21', 1);";
$extra_sqls[] = "INSERT INTO " . DB_PREFIX . "inventory_assy_list VALUES (2, 14, 'DD-150GB', 'Disco Duro 150GB SATA', 1);";
$extra_sqls[] = "INSERT INTO " . DB_PREFIX . "inventory_assy_list VALUES (3, 14, 'DVD-RW', 'DVD RW con Lightscribe', 1);";
$extra_sqls[] = "INSERT INTO " . DB_PREFIX . "inventory_assy_list VALUES (4, 14, 'VID-NV-512MB', 'Tarjeta de Video nVidia 512 MB', 1);";
$extra_sqls[] = "INSERT INTO " . DB_PREFIX . "inventory_assy_list VALUES (5, 14, 'RAM-2GB-0.2', 'Memoria 2GB SDRAM', 2);";
$extra_sqls[] = "INSERT INTO " . DB_PREFIX . "inventory_assy_list VALUES (6, 14, 'CPU-AMD-3600', 'CPU AMD 3600+ Athlon', 1);";
$extra_sqls[] = "INSERT INTO " . DB_PREFIX . "inventory_assy_list VALUES (7, 14, 'TM-ATI-K8N', 'Tarjeta Madre ATI K8 c/red', 1);";
$extra_sqls[] = "INSERT INTO " . DB_PREFIX . "inventory_assy_list VALUES (8, 14, 'CASE-ALIEN', 'Case Juegos Alien - Rojo', 1);";
$extra_sqls[] = "INSERT INTO " . DB_PREFIX . "inventory_assy_list VALUES (9, 14, 'MOUSE-S', 'Ratón Serial - 300 DPI', 1);";
$extra_sqls[] = "INSERT INTO " . DB_PREFIX . "inventory_assy_list VALUES (10, 14, 'TECL-128-ERGO', 'Teclado Ergonómico Español Genérico', 1);";
$extra_sqls[] = "INSERT INTO " . DB_PREFIX . "inventory_assy_list VALUES (11, 18, 'RAM-2GB-0.2', 'Memoria 2GB SDRAM', 2);";
$extra_sqls[] = "INSERT INTO " . DB_PREFIX . "inventory_assy_list VALUES (12, 18, 'CPU-AMD-3600', 'CPU AMD 3600+ Athlon', 1);";
$extra_sqls[] = "INSERT INTO " . DB_PREFIX . "inventory_assy_list VALUES (13, 18, 'TM-ATI-K8N', 'Tarjeta Madre ATI K8 c/red', 1);";
$extra_sqls[] = "INSERT INTO " . DB_PREFIX . "inventory_assy_list VALUES (14, 18, 'CASE-ALIEN', 'Case Juegos Alien - Rojo', 1);";
$extra_sqls[] = "INSERT INTO " . DB_PREFIX . "inventory_assy_list VALUES (15, 18, 'VID-NV-512MB', 'Tarjeta de Video nVidia 512 MB', 1);";

// Data for table `tax_authorities`

//$extra_sqls[] = "INSERT INTO " . DB_PREFIX . "tax_authorities VALUES (1, 'c', 'City Tax', 'City Tax on Taxable Items', '2312', 0, 2.5);";
//$extra_sqls[] = "INSERT INTO " . DB_PREFIX . "tax_authorities VALUES (2, 'c', 'State Tax', 'State Sales Tax Payable', '2316', 0, 5.1);";
//$extra_sqls[] = "INSERT INTO " . DB_PREFIX . "tax_authorities VALUES (3, 'c', 'Special Dist', 'Special District Tax (RTD, etc)', '2316', 0, 1.1);";
$extra_sqls[] = "INSERT INTO " . DB_PREFIX . "tax_authorities VALUES (1, 'c', 'IV', 'Ministerio de Hacienda', '2312', 0, 13.0);";


// Data for table `tax_rates`

//$extra_sqls[] = "INSERT INTO " . DB_PREFIX . "tax_rates VALUES (1, 'c', 'Local Tax', 'Local POS Tax', '1:2:3', '0');";
//$extra_sqls[] = "INSERT INTO " . DB_PREFIX . "tax_rates VALUES (2, 'c', 'State Only', 'State Only Tax - Shipments', '2', '0');";
$extra_sqls[] = "INSERT INTO " . DB_PREFIX . "tax_rates VALUES (1, 'c', 'IV', 'Impuesto de Ventas', '1', '0');";


?>
