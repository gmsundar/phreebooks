<?php
// +-----------------------------------------------------------------+
// |                   PhreeBooks Open Source ERP                    |
// +-----------------------------------------------------------------+
// | Copyright (c) 2007 PhreeSoft, LLC                               |
// | http://www.PhreeSoft.com                                        |
// +-----------------------------------------------------------------+
// | This program is free software: you can redistribute it and/or   |
// | modify it under the terms of the GNU General Public License as  |
// | published by the Free Software Foundation, either version 3 of  |
// | the License, or any later version.                              |
// |                                                                 |
// | This program is distributed in the hope that it will be useful, |
// | but WITHOUT ANY WARRANTY; without even the implied warranty of  |
// | MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the   |
// | GNU General Public License for more details.                    |
// |                                                                 |
// | The license that is bundled with this package is located in the |
// | file: /doc/manual/ch01-Introduction/license.html.               |
// | If not, see http://www.gnu.org/licenses/                        |
// +-----------------------------------------------------------------+
//  Path: /modules/orders/language/hu_hu/language.php
//
// +---------------------------------------+
// | Hungarian translation/Magyar fordítás |
// +---------------------------------------+
// | Hungarian translation: Zsolt Győri    |
// | Hungarian bookkeeping: Tímea Tiszai   |
// | E-mail: gyori.zsolt@gmail.com         |
// | If you have any questions or comment  |
// | do not hesitate to contact us!        |
// +---------------------------------------+
// | Magyar fordítás: Győri Zsolt          |
// | Magyar könyvelés: Tiszai Tímea        |
// | E-mail: gyori.zsolt@gmail.com         |
// | Ha bármi kérdésed vagy észrevételed   |
// | van, ne habozz írni!                  |
// +---------------------------------------+

// General
define('ORD_ADD_UPDATE', 'Felvesz/Frissít');
define('ORD_AP_ACCOUNT', 'Kötelezettség számla');
define('ORD_AR_ACCOUNT', 'Követelés számla');
define('ORD_CASH_ACCOUNT', 'Készpénzszámla');
define('ORD_CLOSED','Zárva?');
define('ORD_COPY_BILL','Másol -->');
define('ORD_CUSTOMER_NAME','Ügyfél neve');
define('ORD_DELETE_ALERT','Biztos törölni akarod a rendelést?');
define('ORD_DELIVERY_DATES', 'Szállítási dátumok');
define('ORD_DROP_SHIP', 'Közvetlenül');
define('ORD_EXPECTED_DATES','Tervezett szállítási dátumok - ');
define('ORD_FREIGHT', 'Fuvarköltség');
define('ORD_FREIGHT_ESTIMATE', 'Fuvarköltség becslő');
define('ORD_FREIGHT_SERVICE', 'Szolgáltatás');
define('ORD_INVOICE_TOTAL', 'Számla összesen');
define('ORD_MANUAL_ENTRY', 'Manuális megadás');
define('ORD_NA','N/A');
define('ORD_NEW_DELIVERY_DATES', 'Új szállítási dátumok');
define('ORD_PAID', 'Fizetve');
define('ORD_ROW_DELETE_ALERT','Biztos törölni akarod a sort?');
define('ORD_SALES_TAX', 'ÁFA');
define('ORD_SHIP_CARRIER', 'Szállító');
define('ORD_SHIP_TO', 'Szállítás célja:');
define('ORD_SHIPPED', 'Szállítva');
define('ORD_SUBTOTAL', 'Összesen');
define('ORD_TAXABLE', 'Adóköteles');
define('ORD_VENDOR_NAME','Forgalmazó neve');
define('ORD_VOID_SHIP','Üres szállítás');
define('ORD_WAITING_FOR_INVOICE','Számlára vár');
define('ORD_WAITING','Vár?');


// Javascript Messages
define('ORD_JS_RECUR_NO_INVOICE','Ismétlődő tranzakcióhoz induló számlaszám megadása szükséges. A program minden ismétlődésnél növelni fogja ezt a számot.');
define('ORD_JS_RECUR_ROLL_REQD','Ez egy ismétlődő tranzakció. Jövőbeni tranzakciók frissítése is?? (Mégsem esetén csak a mostani lesz frissítve)');
define('ORD_JS_RECUR_DEL_ROLL_REQD','Ez egy ismétlődő tranzakció. Jövőbeni tranzakiókat is törölni akarod? (Mégsem esetén csak a mostani lesz törölve)');
define('ORD_JS_WAITING_FOR_PAYMENT','Vagy pipáld ki a számlára vár opciót, vagy adj meg számla számot.');
define('ORD_JS_SERIAL_NUM_PROMPT','Add meg a sorozatszámát a terméknek. MEGJEGYZÉS: A mennyiségnek egynek kell lennie sorszámozott termékek esetén.');

// Audit log messages
define('ORD_DELIVERY_DATES','Kimenő/Bejövő rendelések szállítási dátumai - ');

// Recur Transactions
define('ORD_RECUR_INTRO','Ezt a tranzakciót többszörözheted a későbbiekben, a tranzakciók számának és az előfordulások gyakoriságának megadásával. A mostani lesz az első tranzakció.');
define('ORD_RECUR_ENTRIES','Ismétlődések száma');
define('ORD_RECUR_FREQUENCY','Ismétlődések gyakorisága');
define('ORD_TEXT_WEEKLY','Hetente');
define('ORD_TEXT_BIWEEKLY','Kéthetente');
define('ORD_TEXT_MONTHLY','Havonta');
define('ORD_TEXT_QUARTERLY','Negyedévente');
define('ORD_TEXT_YEARLY','Évente');

// Purchase Quote Specific
define('ORD_TEXT_3_BILL_TO', 'Átutalás kedvezményezettje:');
define('ORD_TEXT_3_REF_NUM', 'Hivatkozási #');
define('ORD_TEXT_3_WINDOW_TITLE','Árajánlatkérés');
define('ORD_TEXT_3_EXPIRES', 'Lejárat dátuma');
define('ORD_TEXT_3_NUMBER', 'Árajánlat száma');
define('ORD_TEXT_3_TEXT_REP', 'Ügyfél');
define('ORD_TEXT_3_ITEM_COLUMN_1','Mennyiség');
define('ORD_TEXT_3_ITEM_COLUMN_2','Érkezett');
define('ORD_TEXT_3_ERROR_NO_VENDOR','Nincs kiválasztva forgalmazó! Add meg az azonosító mezőben, vagy kattints az utána található ikonon és válassz. Új forgalmazó felvétele esetén pipáld ki a ' . ORD_ADD_UPDATE . ' dobozt.');
define('ORD_TEXT_3_NUMBER_OF_ORDERS', TEXT_DISPLAY_NUMBER . 'forgalmazói árajánlatok');
define('ORD_TEXT_3_CLOSED_TEXT',TEXT_CLOSE);

// Purchase Order Specific
define('ORD_TEXT_4_BILL_TO', 'Átutalás kedvezményezettje:');
define('ORD_TEXT_4_REF_NUM', 'Hivatkozási #');
define('ORD_TEXT_4_WINDOW_TITLE','Kimenő rendelés');
define('ORD_TEXT_4_EXPIRES', 'Lejárat dátuma');
define('ORD_TEXT_4_NUMBER', 'Kimenő rendelés száma');
define('ORD_TEXT_4_TEXT_REP', 'Ügyfél');
define('ORD_TEXT_4_ITEM_COLUMN_1','Mennyiség');
define('ORD_TEXT_4_ITEM_COLUMN_2','Érkezett');
define('ORD_TEXT_4_ERROR_NO_VENDOR','Nincs kiválasztva forgalmazó! Add meg az azonosító mezőben, vagy kattints az utána található ikonon és válassz. Új forgalmazó felvétele esetén pipáld ki a ' . ORD_ADD_UPDATE . ' dobozt.');
define('ORD_TEXT_4_NUMBER_OF_ORDERS', TEXT_DISPLAY_NUMBER . 'kimenő rendelések');
define('ORD_TEXT_4_CLOSED_TEXT',TEXT_CLOSE);

// Purchase/Receive Specific
define('ORD_TEXT_6_BILL_TO', 'Átutalás kedvezményezettje:');
define('ORD_TEXT_6_REF_NUM', 'Hivatkozási szám #');
define('ORD_TEXT_6_WINDOW_TITLE','Beszerzés/Fogadás készlet');
define('ORD_TEXT_6_ERROR_NO_VENDOR','Nincs kiválasztva forgalmazó! Add meg az azonosító mezőben, vagy kattints az utána található ikonon és válassz. Új forgalmazó felvétele esetén pipáld ki a ' . ORD_ADD_UPDATE . ' dobozt.');
define('ORD_TEXT_6_NUMBER', 'Számlaszám');
define('ORD_TEXT_6_TEXT_REP', 'Ügyfél');
define('ORD_TEXT_6_ITEM_COLUMN_1','Kimenő rendelés mérleg');
define('ORD_TEXT_6_ITEM_COLUMN_2','Érkezett');
define('ORD_TEXT_6_NUMBER_OF_ORDERS', TEXT_DISPLAY_NUMBER . 'tétel elismervények');
define('ORD_TEXT_6_CLOSED_TEXT','Kifizetett számla');

// Vendor Credit Memo Specific
define('ORD_TEXT_7_BILL_TO', 'Átutalás kedvezményezettje:');
define('ORD_TEXT_7_REF_NUM', 'Hivatkozási #');
define('ORD_TEXT_7_WINDOW_TITLE','Forgalmazói hiteljegyzőköynv');
define('ORD_TEXT_7_ERROR_NO_VENDOR','Nincs kiválasztva forgalmazó! Add meg az azonosító mezőben, vagy kattints az utána található ikonon és válassz. Új forgalmazó felvétele esetén pipáld ki a ' . ORD_ADD_UPDATE . ' dobozt.');
define('ORD_TEXT_7_NUMBER', 'Hiteljegyzőkönyv száma');
define('ORD_TEXT_7_TEXT_REP', 'Ügyfél');
define('ORD_TEXT_7_ITEM_COLUMN_1','Érkezett');
define('ORD_TEXT_7_ITEM_COLUMN_2','Visszaküldve');
define('ORD_TEXT_7_NUMBER_OF_ORDERS', TEXT_DISPLAY_NUMBER . 'forgalmazó számlák');
define('ORD_TEXT_7_CLOSED_TEXT','Felvett hitel');

// Customer Quote Specific
define('ORD_TEXT_9_BILL_TO', 'Számlázási név:');
define('ORD_TEXT_9_REF_NUM', 'Kimenő rendelés #');
define('ORD_TEXT_9_WINDOW_TITLE','Ügyfél árajánlat');
define('ORD_TEXT_9_EXPIRES', 'Lejárat');
define('ORD_TEXT_9_NUMBER', 'Ajánlatszám');
define('ORD_TEXT_9_TEXT_REP', 'Értékesítő');
define('ORD_TEXT_9_ITEM_COLUMN_1','Mennyiség');
define('ORD_TEXT_9_ITEM_COLUMN_2','Számlázva');
define('ORD_TEXT_9_ERROR_NO_VENDOR','Nincs kiválasztva ügyfél! Add meg az azonosító mezőben, vagy kattints az utána található ikonon és válassz. Új ügyfél felvétele esetén pipáld ki a ' . ORD_ADD_UPDATE . ' dobozt.');
define('ORD_TEXT_9_NUMBER_OF_ORDERS', TEXT_DISPLAY_NUMBER . 'ügyfél árajánlatok');
define('ORD_TEXT_9_CLOSED_TEXT',TEXT_CLOSE);

// Sales Order Specific
define('ORD_TEXT_10_BILL_TO', 'Számlázási név:');
define('ORD_TEXT_10_REF_NUM', 'Kimenő rendelés #');
define('ORD_TEXT_10_WINDOW_TITLE','Bejövő rendelés');
define('ORD_TEXT_10_EXPIRES', 'Szállítás dátuma');
define('ORD_TEXT_10_NUMBER', 'Bejövő rendelési szám');
define('ORD_TEXT_10_TEXT_REP', 'Értékesítési jelentés');
define('ORD_TEXT_10_ITEM_COLUMN_1','Mennyiség');
define('ORD_TEXT_10_ITEM_COLUMN_2','Számlázva');
define('ORD_TEXT_10_ERROR_NO_VENDOR','Nincs kiválasztva ügyfél! Add meg az azonosító mezőben, vagy kattints az utána található ikonon és válassz. Új ügyfél felvétele esetén pipáld ki a ' . ORD_ADD_UPDATE . ' dobozt.');
define('ORD_TEXT_10_NUMBER_OF_ORDERS', TEXT_DISPLAY_NUMBER . 'bejövő rendelések');
define('ORD_TEXT_10_CLOSED_TEXT',TEXT_CLOSE);

// Sales/Invoice Specific
define('ORD_TEXT_12_BILL_TO', 'Számlázási név:');
define('ORD_TEXT_12_REF_NUM', 'Kimenő számla #');
define('ORD_TEXT_12_WINDOW_TITLE','Eladás/Számla');
define('ORD_TEXT_12_EXPIRES', 'Szállítás ezen dátummal');
define('ORD_TEXT_12_ERROR_NO_VENDOR','Nincs kiválasztva ügyfél!');
define('ORD_TEXT_12_NUMBER', 'Számla száma');
define('ORD_TEXT_12_TEXT_REP', 'Értékesítő');
define('ORD_TEXT_12_ITEM_COLUMN_1','Bejövő rendelés egyenleg');
define('ORD_TEXT_12_ITEM_COLUMN_2','Mennyiség');
define('ORD_TEXT_12_NUMBER_OF_ORDERS', TEXT_DISPLAY_NUMBER . 'számlák');
define('ORD_TEXT_12_CLOSED_TEXT','Kifizetett');

// Customer Credit Memo Specific
define('ORD_TEXT_13_BILL_TO', 'Számlázási név:');
define('ORD_TEXT_13_REF_NUM', 'Kimenő rendelés #');
define('ORD_TEXT_13_WINDOW_TITLE','Ügyfél hiteljegyzőkönyv');
define('ORD_TEXT_13_EXPIRES', 'Szállítás ezen dátummal');
define('ORD_TEXT_13_ERROR_NO_VENDOR','Nincs kiválasztva ügyfél!');
define('ORD_TEXT_13_NUMBER', 'Hiteljegyzőkönyv száma');
define('ORD_TEXT_13_TEXT_REP', 'Értékesítő');
define('ORD_TEXT_13_ITEM_COLUMN_1','Szállítva');
define('ORD_TEXT_13_ITEM_COLUMN_2','Visszaküldve');
define('ORD_TEXT_13_CLOSED_TEXT','Fizetett hitel');

/*
// Cash Receipts Specific
define('ORD_TEXT_18_BILL_TO', 'Sale to:');
define('ORD_TEXT_18_REF_NUM', 'Purchase Order #');
define('ORD_TEXT_18_WINDOW_TITLE','Cash Receipts');
define('ORD_TEXT_18_EXPIRES', 'Ship By Date');
define('ORD_TEXT_18_ERROR_NO_VENDOR','No customer was selected!');
define('ORD_TEXT_18_NUMBER', 'Receipt Number');
define('ORD_TEXT_18_TEXT_REP', 'Sales Rep');
define('ORD_TEXT_18_ITEM_COLUMN_1','SO Bal');
define('ORD_TEXT_18_ITEM_COLUMN_2','Qty');
define('ORD_TEXT_18_NUMBER_OF_ORDERS', TEXT_DISPLAY_NUMBER . 'receipts');

// Point of Sale Specific
define('ORD_TEXT_19_BILL_TO', 'Sale to:');
define('ORD_TEXT_19_REF_NUM', 'Purchase Order #');
define('ORD_TEXT_19_WINDOW_TITLE','Point of Sale');
define('ORD_TEXT_19_EXPIRES', 'Ship By Date');
define('ORD_TEXT_19_ERROR_NO_VENDOR','No customer was selected!');
define('ORD_TEXT_19_NUMBER', 'Receipt Number');
define('ORD_TEXT_19_TEXT_REP', 'Sales Rep');
define('ORD_TEXT_19_ITEM_COLUMN_1','SO Bal');
define('ORD_TEXT_19_ITEM_COLUMN_2','Qty');
define('ORD_TEXT_19_NUMBER_OF_ORDERS', TEXT_DISPLAY_NUMBER . 'sales');

// Cash Distribution Journal
define('ORD_TEXT_20_BILL_TO', 'Remit to:');
define('ORD_TEXT_20_REF_NUM', 'Reference #');
define('ORD_TEXT_20_WINDOW_TITLE','Cash Distribution');
define('ORD_TEXT_20_ERROR_NO_VENDOR','No vendor was selected! Either select a vendor from the popup menu or enter the information and select: ' . ORD_ADD_UPDATE);
define('ORD_TEXT_20_NUMBER', 'Payment Number');
define('ORD_TEXT_20_TEXT_REP', 'Buyer');
define('ORD_TEXT_20_ITEM_COLUMN_1','PO Bal');
define('ORD_TEXT_20_ITEM_COLUMN_2','Rcvd');
define('ORD_TEXT_20_NUMBER_OF_ORDERS', TEXT_DISPLAY_NUMBER . 'payments');

// Direct Inventory Purchase/Receive (Checks)
define('ORD_TEXT_21_BILL_TO', 'Remit to:');
define('ORD_TEXT_21_REF_NUM', 'Reference #');
define('ORD_TEXT_21_WINDOW_TITLE','Direct Purchase');
define('ORD_TEXT_21_ERROR_NO_VENDOR','No vendor was selected! Either select a vendor from the popup menu or enter the information and select: ' . ORD_ADD_UPDATE);
define('ORD_TEXT_21_NUMBER', 'Payment Number');
define('ORD_TEXT_21_TEXT_REP', 'Buyer');
define('ORD_TEXT_21_ITEM_COLUMN_1','PO Bal');
define('ORD_TEXT_21_ITEM_COLUMN_2','Rcvd');
define('ORD_TEXT_21_NUMBER_OF_ORDERS', TEXT_DISPLAY_NUMBER . 'payments');
*/

// popup specific
define('ORD_POPUP_WINDOW_TITLE_3', 'Forgalmazói árajánlatok');
define('ORD_POPUP_WINDOW_TITLE_4', 'Kimenő rendelések');
define('ORD_POPUP_WINDOW_TITLE_6', 'Vásárlás/Fogadás készlet');
define('ORD_POPUP_WINDOW_TITLE_7', 'Forgalmazói hiteljegyzőkönyv');
define('ORD_POPUP_WINDOW_TITLE_9', 'Árajánlatkérés');
define('ORD_POPUP_WINDOW_TITLE_10', 'Bejövő rendelések');
define('ORD_POPUP_WINDOW_TITLE_12', 'Eladások/Számlák');
define('ORD_POPUP_WINDOW_TITLE_13', 'Hiteljegyzőkönyv');
//define('ORD_POPUP_WINDOW_TITLE_19', 'Point of Sale');
//define('ORD_POPUP_WINDOW_TITLE_21', 'Inventory Direct Purchase');

// recur specific
define('ORD_RECUR_WINDOW_TITLE_3', 'Ismétlődő bejövő árajánlatok');
define('ORD_RECUR_WINDOW_TITLE_4', 'Ismétlődő kimenő rendelések');
define('ORD_RECUR_WINDOW_TITLE_6', 'Recur Purchase/Receive Inventory');
define('ORD_RECUR_WINDOW_TITLE_7', 'Ismétlődő forgalmazói hiteljegyzőkönyv');
define('ORD_RECUR_WINDOW_TITLE_9', 'Ismétlődő árajánlat kérések');
define('ORD_RECUR_WINDOW_TITLE_10', 'Ismétlődő kimenő számlák');
define('ORD_RECUR_WINDOW_TITLE_12', 'Ismétlődő Eladások/Számlák');
define('ORD_RECUR_WINDOW_TITLE_13', 'Ismétlődő hiteljegyzőkönyv');
//define('ORD_RECUR_WINDOW_TITLE_19', 'Recur Point of Sale');
//define('ORD_RECUR_WINDOW_TITLE_21', 'Recur Inventory Direct Purchase');

define('ORD_HEADING_NUMBER_3', 'Ajánlat száma');
define('ORD_HEADING_NUMBER_4', 'Kimenő rendelés száma');
define('ORD_HEADING_NUMBER_6', 'Számla #');
define('ORD_HEADING_NUMBER_7', 'Hiteljegyzőkönyv száma');
define('ORD_HEADING_NUMBER_9', 'Ajánlat száma');
define('ORD_HEADING_NUMBER_10', 'Bejövő rendelés száma');
define('ORD_HEADING_NUMBER_12', 'Számla #');
define('ORD_HEADING_NUMBER_13', 'Hiteljegyzőkönyv száma');
//define('ORD_HEADING_NUMBER_19', 'Receipt Number');
//define('ORD_HEADING_NUMBER_21', 'Payment Number');

define('ORD_HEADING_STATUS_3', ORD_CLOSED);
define('ORD_HEADING_STATUS_4', ORD_CLOSED);
define('ORD_HEADING_STATUS_6', ORD_WAITING);
define('ORD_HEADING_STATUS_7', ORD_WAITING);
define('ORD_HEADING_STATUS_9', ORD_CLOSED);
define('ORD_HEADING_STATUS_10', ORD_CLOSED);
define('ORD_HEADING_STATUS_12', TEXT_STATUS);
define('ORD_HEADING_STATUS_13', TEXT_STATUS);
//define('ORD_HEADING_STATUS_19', ORD_CLOSED);
//define('ORD_HEADING_STATUS_21', ORD_CLOSED);

define('ORD_HEADING_NAME_3',ORD_VENDOR_NAME);
define('ORD_HEADING_NAME_4',ORD_VENDOR_NAME);
define('ORD_HEADING_NAME_6',ORD_VENDOR_NAME);
define('ORD_HEADING_NAME_7',ORD_VENDOR_NAME);
define('ORD_HEADING_NAME_9',ORD_CUSTOMER_NAME);
define('ORD_HEADING_NAME_10',ORD_CUSTOMER_NAME);
define('ORD_HEADING_NAME_12',ORD_CUSTOMER_NAME);
define('ORD_HEADING_NAME_13',ORD_CUSTOMER_NAME);
//define('ORD_HEADING_NAME_19',ORD_CUSTOMER_NAME);
//define('ORD_HEADING_NAME_21',ORD_VENDOR_NAME);
?>
