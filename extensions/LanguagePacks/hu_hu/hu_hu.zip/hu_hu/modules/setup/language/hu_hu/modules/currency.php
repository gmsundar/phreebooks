<?php
// +-----------------------------------------------------------------+
// |                   PhreeBooks Open Source ERP                    |
// +-----------------------------------------------------------------+
// | Copyright (c) 2007 PhreeSoft, LLC                               |
// | http://www.PhreeSoft.com                                        |
// +-----------------------------------------------------------------+
// | This program is free software: you can redistribute it and/or   |
// | modify it under the terms of the GNU General Public License as  |
// | published by the Free Software Foundation, either version 3 of  |
// | the License, or any later version.                              |
// |                                                                 |
// | This program is distributed in the hope that it will be useful, |
// | but WITHOUT ANY WARRANTY; without even the implied warranty of  |
// | MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the   |
// | GNU General Public License for more details.                    |
// |                                                                 |
// | The license that is bundled with this package is located in the |
// | file: /doc/manual/ch01-Introduction/license.html.               |
// | If not, see http://www.gnu.org/licenses/                        |
// +-----------------------------------------------------------------+
//  Path: /modules/setup/language/hu_hu/modules/currency.php
//

define('SETUP_TITLE_CURRENCIES', 'Pénznemek');
define('SETUP_CURRENCY_NAME', 'Pénznem');
define('SETUP_CURRENCY_CODES', 'Kód');
define('SETUP_UPDATE_EXC_RATE','Átváltási arányok frissítése');

define('SETUP_CURR_EDIT_INTRO', 'Végezz el minden szükséges változtatást');
define('SETUP_INFO_CURRENCY_TITLE', 'Megnevezés:');
define('SETUP_INFO_CURRENCY_CODE', 'Kód:');
define('SETUP_INFO_CURRENCY_SYMBOL_LEFT', 'Bal oldali szimbólum:');
define('SETUP_INFO_CURRENCY_SYMBOL_RIGHT', 'Jobb oldali szimbólum:');
define('SETUP_INFO_CURRENCY_DECIMAL_POINT', 'Tizedes pont:');
define('SETUP_INFO_CURRENCY_THOUSANDS_POINT', 'Ezresek elválasztója:');
define('SETUP_INFO_CURRENCY_DECIMAL_PLACES', 'Tizedeshelyek:');
define('SETUP_INFO_CURRENCY_VALUE', 'Érték:');
define('SETUP_INFO_CURRENCY_EXAMPLE', 'Példa kimenet:');
define('SETUP_CURR_INSERT_INTRO', 'Add meg az új pénznemet az adataival együtt');
define('SETUP_CURR_DELETE_INTRO', 'Biztosan törölni akarod a pénznemet?');
define('SETUP_INFO_HEADING_NEW_CURRENCY', 'Új pénznem');
define('SETUP_INFO_HEADING_EDIT_CURRENCY', 'Pénznem szerkesztése');
define('SETUP_INFO_HEADING_DELETE_CURRENCY', 'Pénznem törlése');
define('SETUP_SET_DEFAULT', 'Legyen alapértelmezett');
define('SETUP_INFO_SET_AS_DEFAULT', SETUP_SET_DEFAULT . ' (manuális átváltási arány frissítést igényel)');
define('SETUP_INFO_CURRENCY_UPDATED', '%s Átváltási aránya (%s) sikeresen megtörtént a(z) %s szerverről.');

define('SETUP_ERROR_REMOVE_DEFAULT_CURRENCY', 'Hiba: Az alapértelmezett pénznemet nem lehet eltávolítani. Előbb válassz másik pénznemet alapértelmezettnek, majd próbáld újra.');
define('SETUP_ERROR_CURRENCY_INVALID', 'Hiba: %s átváltási aránya (%s) sikertelen volt a(z) %s szerverről. Érvényes a megadott pénznem kód?');
define('SETUP_WARN_PRIMARY_SERVER_FAILED', 'Figyelmeztetés: Az átváltási arányok letöltése nem sikerült (%s) ennél a pénznemnél: %s (%s) - megpróbálom letölteni a másodlagosról.');
define('TEXT_DISPLAY_NUMBER_OF_CURRENCIES', TEXT_DISPLAY_NUMBER . 'pénznemek');
define('SETUP_LOG_CURRENCY','Pénznemek - ');

?>
