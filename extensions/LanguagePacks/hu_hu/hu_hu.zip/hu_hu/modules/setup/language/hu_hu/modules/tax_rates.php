<?php
// +-----------------------------------------------------------------+
// |                   PhreeBooks Open Source ERP                    |
// +-----------------------------------------------------------------+
// | Copyright (c) 2007 PhreeSoft, LLC                               |
// | http://www.PhreeSoft.com                                        |
// +-----------------------------------------------------------------+
// | This program is free software: you can redistribute it and/or   |
// | modify it under the terms of the GNU General Public License as  |
// | published by the Free Software Foundation, either version 3 of  |
// | the License, or any later version.                              |
// |                                                                 |
// | This program is distributed in the hope that it will be useful, |
// | but WITHOUT ANY WARRANTY; without even the implied warranty of  |
// | MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the   |
// | GNU General Public License for more details.                    |
// |                                                                 |
// | The license that is bundled with this package is located in the |
// | file: /doc/manual/ch01-Introduction/license.html.               |
// | If not, see http://www.gnu.org/licenses/                        |
// +-----------------------------------------------------------------+
//  Path: /modules/setup/language/hu_hu/modules/tax_rates.php
//

define('SETUP_TAX_DESC_SHORT', 'Rövid név');
define('SETUP_TITLE_TAX_RATES', 'Eladási adókulcsok');
define('SETUP_HEADING_TAX_FREIGHT', 'Szállítási adó');
define('SETUP_HEADING_TOTAL_TAX', 'Teljes adó (százalék)');

define('SETUP_INFO_DESC_SHORT', 'Rövid név (max 15 karakter)');
define('SETUP_INFO_DESC_LONG', 'Hosszú leírás (max 64 karakter)');
define('SETUP_TAX_EDIT_INTRO', 'Végezz el minden szükséges változtatást');
define('SETUP_INFO_TAX_AUTHORITIES', 'Adóhatóságok');
define('SETUP_INFO_TAX_AUTH_ADD', 'Válassz adóhatóságot felvételhez');
define('SETUP_INFO_TAX_AUTH_DELETE', 'Válaszd ki az eltávolítandó adóhatóságot');
define('SETUP_INFO_FREIGHT_TAXABLE', 'Szállítás adózik');
define('SETUP_TAX_INSERT_INTRO', 'Add meg az új adókulcsot a tulajdonságaival együtt');
define('SETUP_TAX_DELETE_INTRO', 'Biztosan törölni akarod az adókulcsot?');
define('SETUP_HEADING_NEW_TAX_RATE', 'Új adókulcs');
define('SETUP_HEADING_EDIT_TAX_RATE', 'Adókulcs szerkesztése');
define('SETUP_HEADING_DELETE_TAX_RATE', 'Adókulcs törlése');
define('SETUP_DISPLAY_NUMBER_OF_TAX_RATES', TEXT_DISPLAY_NUMBER . 'adókulcsok');
define('SETUP_TAX_RATE_SUCCESS','Sikeres eladási adókulcs felvétel/módosítás.');
define('SETUP_TAX_RATES_LOG','Adókulcsok - ');

?>
