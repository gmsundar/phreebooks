<?php
// +-----------------------------------------------------------------+
// |                   PhreeBooks Open Source ERP                    |
// +-----------------------------------------------------------------+
// | Copyright (c) 2007 PhreeSoft, LLC                               |
// | http://www.PhreeSoft.com                                        |
// +-----------------------------------------------------------------+
// | This program is free software: you can redistribute it and/or   |
// | modify it under the terms of the GNU General Public License as  |
// | published by the Free Software Foundation, either version 3 of  |
// | the License, or any later version.                              |
// |                                                                 |
// | This program is distributed in the hope that it will be useful, |
// | but WITHOUT ANY WARRANTY; without even the implied warranty of  |
// | MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the   |
// | GNU General Public License for more details.                    |
// |                                                                 |
// | The license that is bundled with this package is located in the |
// | file: /doc/manual/ch01-Introduction/license.html.               |
// | If not, see http://www.gnu.org/licenses/                        |
// +-----------------------------------------------------------------+
//  Path: /modules/install/includes/languages/hu_hu/database_setup.php
//
// +---------------------------------------+
// | Hungarian translation/Magyar fordítás |
// +---------------------------------------+
// | Hungarian translation: Zsolt Győri    |
// | Hungarian bookkeeping: Tímea Tiszai   |
// | E-mail: gyori.zsolt@gmail.com         |
// | If you have any questions or comment  |
// | do not hesitate to contact us!        |
// +---------------------------------------+
// | Magyar fordítás: Győri Zsolt          |
// | Magyar könyvelés: Tiszai Tímea        |
// | E-mail: gyori.zsolt@gmail.com         |
// | Ha bármi kérdésed vagy észrevételed   |
// | van, ne habozz írni!                  |
// +---------------------------------------+

  define('SAVE_DATABASE_SETTINGS', 'Adatbázis beállítások mentése');//this comes before TEXT_MAIN
  define('TEXT_MAIN', "Most az adatbázis beállításokkal kapcsolatban fogok néhány kérdést feltenni.  Kérlek adj meg minden adatot figyelmesen a megfelelő szövegdobozban, majd kattints az <em>".SAVE_DATABASE_SETTINGS.'</em> gombra a folytatáshoz.');
  define('TEXT_PAGE_HEADING', 'PhreeBooks&trade; Telepítő - Adatbázis beállítás');
  define('DATABASE_INFORMATION', 'Adatbázis információ');
  define('DATABASE_TYPE', 'Adatbázis típusa');
  define('DATABASE_TYPE_INSTRUCTION', 'Válaszd ki az adatbázis típusát.');
  define('DATABASE_HOST', 'Adatbázis kiszolgáló');
  define('DATABASE_HOST_INSTRUCTION', 'Mi az adatbázis kiszolgáló?  Az adatbázis kiszolgálót megadhatod annak nevével, mint \'db1.sajatszerver.hu\', vagy IP-címével, mint \'192.168.0.1\'.');
  define('DATABASE_USERNAME', 'Adatbázis felhasználónév');
  define('DATABASE_USERNAME_INSTRUCTION', 'Mi az adatbázis kapcsolódáshoz használt felhasználónév? Egy példa felhasználónév a \'root\'.');
  define('DATABASE_PASSWORD', 'Adatbázis jelszó');
  define('DATABASE_PASSWORD_INSTRUCTION', 'Mi az adatbázis kapcsolódáshoz használt jelszó?  A jelszó a felhasználónévvel együtt használatos, amely páros megadja az adatbázis felhasználói fiókot.');
  define('DATABASE_NAME', 'Cég adatbázisának neve');
  define('DATABASE_NAME_INSTRUCTION', 'Mi a cég adatait tároló adatbázis neve? Például lehet rövidített cégnév, mint \'sajatcegem\'. Szóközt vagy különleges karaktereket NEM tartalmazhat. <!-- Ha nem található ilyen nevű adatbázis, akkor létrehozom.-->');
  define('DATABASE_PREFIX', 'Adatbázis előtag');
  define('DATABASE_PREFIX_INSTRUCTION', 'Milyen előtagot szeretnél használni az adatbázis táblákhoz?  Például: pb_ Hagyd üresen, ha nincs szükséged előtagra.');
  define('DATABASE_CREATE', 'Adatbázis létrehozása?');
  define('DATABASE_CREATE_INSTRUCTION', 'Szeretnéd, hogy létrehozzam az adatbázist?');
  define('DATABASE_CONNECTION', 'Állandó kapcsolat');
  define('DATABASE_CONNECTION_INSTRUCTION', 'Engedélyezed az állandó adatbázis kapcsolatot?  Válaszolj \'nemmel\', ha bizonytalan vagy.');
  define('DATABASE_SESSION', 'Adatbázis sessionök');
  define('DATABASE_SESSION_INSTRUCTION', 'A sessionöket az adatbázisban szeretnéd tárolni?  Válaszolj \'igennel\' ha bizonytalan vagy.');
  define('CACHE_TYPE', 'SQL Cache módszer');
  define('CACHE_TYPE_INSTRUCTION', 'Válaszd ki az SQL-hez használt cache módszert.');
  define('SQL_CACHE', 'Session/SQL cache könyvtár');
  define('SQL_CACHE_INSTRUCTION', 'Fájl alapú SQL cache esetén add meg a használandó könyvtárt.');



  define('REASON_TABLE_ALREADY_EXISTS','Nem tudom létrehozni a(z) %s táblát, mert már létezik');
  define('REASON_TABLE_DOESNT_EXIST','Nem tudom törölni a(z) %s táblát, mert nem létezik.');
  define('REASON_CONFIG_KEY_ALREADY_EXISTS','Cannot insert configuration_key "%s" because it already exists');
  define('REASON_COLUMN_ALREADY_EXISTS','Cannot ADD column %s because it already exists.');
  define('REASON_COLUMN_DOESNT_EXIST_TO_DROP','Cannot DROP column %s because it does not exist.');
  define('REASON_COLUMN_DOESNT_EXIST_TO_CHANGE','Cannot CHANGE column %s because it does not exist.');
  define('REASON_PRODUCT_TYPE_LAYOUT_KEY_ALREADY_EXISTS','Cannot insert prod-type-layout configuration_key "%s" because it already exists');
  define('REASON_INDEX_DOESNT_EXIST_TO_DROP','Cannot drop index %s on table %s because it does not exist.');
  define('REASON_PRIMARY_KEY_DOESNT_EXIST_TO_DROP','Cannot drop primary key on table %s because it does not exist.');
  define('REASON_INDEX_ALREADY_EXISTS','Cannot add index %s to table %s because it already exists.');
  define('REASON_PRIMARY_KEY_ALREADY_EXISTS','Cannot add primary key to table %s because a primary key already exists.');
  define('REASON_NO_PRIVILEGES','%s@%s felhasználónak nincs %s joga az adatbázishoz.');

?>
