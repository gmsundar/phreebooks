<?php
// +--------------------------------------------------------+
// |               PhreeBooks Open Source ERP               |
// +--------------------------------------------------------+
// | Copyright (c) 2007 PhreeSoft, LLC                      |
// | http://www.phreesoft.com                               |
// | Portions Copyright (c) 2003 osCommerce, 2005 ZenCart   |
// +--------------------------------------------------------+
// | This source file is subject to version 2.0 of the GPL  |
// | license that is bundled with this package in the file: |
// | /doc/manual/ch01-Introduction/license.html             |
// +--------------------------------------------------------+
//  Path: /modules/install/includes/languages/hu_hu/store_setup.php
//
// +---------------------------------------+
// | Hungarian translation/Magyar fordítás |
// +---------------------------------------+
// | Hungarian translation: Zsolt Győri    |
// | Hungarian bookkeeping: Tímea Tiszai   |
// | E-mail: gyori.zsolt@gmail.com         |
// | If you have any questions or comment  |
// | do not hesitate to contact us!        |
// +---------------------------------------+
// | Magyar fordítás: Győri Zsolt          |
// | Magyar könyvelés: Tiszai Tímea        |
// | E-mail: gyori.zsolt@gmail.com         |
// | Ha bármi kérdésed vagy észrevételed   |
// | van, ne habozz írni!                  |
// +---------------------------------------+

  define('SAVE_STORE_SETTINGS', 'Cég beállításainak elmentése'); //this comes before TEXT_MAIN
  define('TEXT_MAIN', "A PhreeBooks&trade; telepítő ezen része segít beállítani az alapvető céges adatokat.  Később megváltoztathatod ezeket az értékeket a cég menüpont alól.  Adj meg minden adatot figyelmesen, majd kattints a <em>".SAVE_STORE_SETTINGS.'</em> gombra a folytatáshoz.');
  define('TEXT_PAGE_HEADING', 'PhreeBooks&trade; Telepítő - Cég beállításainak megadása');
  define('STORE_INFORMATION', 'Cég információ');
  define('STORE_ID', 'Cég azonosító');
  define('STORE_ID_INSTRUCTION', 'Enter a short abbreviation of your store name (or branch) to use for pull down menus?');
  define('STORE_NAME', 'Cég neve');
  define('STORE_NAME_INSTRUCTION', 'Mi a céged neve?');
  define('STORE_CITY_TOWN', 'Cég székhelyének települése');
  define('STORE_CITY_TOWN_INSTRUCTION', 'Mi a céged telephelyének településneve?');
  define('STORE_POSTAL_CODE', 'Cég székhelyének irányítószáma');
  define('STORE_POSTAL_CODE_INSTRUCTION', 'Mi az irányítószámod?');
  define('STORE_OWNER_EMAIL', 'Cég e-mail címe');
  define('STORE_OWNER_EMAIL_INSTRUCTION', 'Mi a cég fő e-mail címe?');
  define('STORE_WEBSITE', 'Cég weboldala');
  define('STORE_WEBSITE_INSTRUCTION', 'Mi a cég weboldalának címe? (a http:// rész nélkül)');
  define('STORE_TELEPHONE1', 'Cég fő telefonszáma');
  define('STORE_TELEPHONE1_INSTRUCTION', 'Mi a cég fő telefonszáma?');
  define('STORE_TELEPHONE2', 'Cég másodlagos telefonszáma');
  define('STORE_TELEPHONE2_INSTRUCTION', 'Mi a cég másodlagos telefonszáma?');
  define('STORE_FAX', 'Cég fax száma');
  define('STORE_FAX_INSTRUCTION', 'Mi a cég fax száma?');
  define('STORE_COUNTRY', 'Cég telephelyének országa');
  define('STORE_COUNTRY_INSTRUCTION', 'Melyik országban található a céged?');
  define('STORE_ZONE', 'Cég telephelyének megyéje/régiója');
  define('STORE_ZONE_INSTRUCTION', 'Melyik megyében/régióban található a céged?');
  define('STORE_ADDRESS1', 'Cég címsor 1');
  define('STORE_ADDRESS1_INSTRUCTION', 'What is the main mailing street address of your company? First of two lines allowed.');
  define('STORE_ADDRESS2', 'Cég címsor 2');
  define('STORE_ADDRESS2_INSTRUCTION', 'What is the main mailing street address of your company? Second of two lines allowed.');
  define('STORE_DEFAULT_CURRENCY', 'Alapértelmezett pénznem');
  define('STORE_DEFAULT_CURRENCY_INSTRUCTION', 'Válaszd ki melyik pénznemet szeretnéd alapértelmezettként használni?');
  define('DEMO_INFORMATION', 'Demo információ');
  define('DEMO_INSTALL', 'Cég demo');
  define('DEMO_INSTALL_INSTRUCTION', 'Szeretnéd telepíteni a PhreeBooks demo termékeket, forgalmazó és ügyfél fiókokat?');
?>
