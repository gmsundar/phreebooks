<?php
// +-----------------------------------------------------------------+
// |                   PhreeBooks Open Source ERP                    |
// +-----------------------------------------------------------------+
// | Copyright (c) 2007 PhreeSoft, LLC                               |
// | http://www.PhreeSoft.com                                        |
// +-----------------------------------------------------------------+
// | This program is free software: you can redistribute it and/or   |
// | modify it under the terms of the GNU General Public License as  |
// | published by the Free Software Foundation, either version 3 of  |
// | the License, or any later version.                              |
// |                                                                 |
// | This program is distributed in the hope that it will be useful, |
// | but WITHOUT ANY WARRANTY; without even the implied warranty of  |
// | MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the   |
// | GNU General Public License for more details.                    |
// |                                                                 |
// | The license that is bundled with this package is located in the |
// | file: /doc/manual/ch01-Introduction/license.html.               |
// | If not, see http://www.gnu.org/licenses/                        |
// +-----------------------------------------------------------------+
//  Path: /modules/install/includes/languages/hu_hu/config_data.php
//
// +---------------------------------------+
// | Hungarian translation/Magyar fordítás |
// +---------------------------------------+
// | Hungarian translation: Zsolt Győri    |
// | Hungarian bookkeeping: Tímea Tiszai   |
// | E-mail: gyori.zsolt@gmail.com         |
// | If you have any questions or comment  |
// | do not hesitate to contact us!        |
// +---------------------------------------+
// | Magyar fordítás: Győri Zsolt          |
// | Magyar könyvelés: Tiszai Tímea        |
// | E-mail: gyori.zsolt@gmail.com         |
// | Ha bármi kérdésed vagy észrevételed   |
// | van, ne habozz írni!                  |
// +---------------------------------------+
//
/*
This file sets the configuration variables for PhreeBooks it is installed as part of the installation script.
It can be modified for translations but must be copied and relocated into the appropriate language directory.
If the language file is not found, english is used.


FOR LANGUAGE TRANSLATION ONLY MODIFY THE VALUES FOR INDEXES configuration_title AND configuration_description

The available fields and format are:
$config_data[] = array(
  'configuration_title' => 'Title',		// title used in the configuration listing (default \')
  'configuration_key' => 'CONSTANT',	// key used throughout PhreeBooks (default \')
  'configuration_value' => 'value',		// constant value user configurable (default \')
  'configuration_description' => 'Description', // description used in the configuration when editing (default \')
  'configuration_group_id' => 1, 		// group id for configuration organization (default 0)
  'sort_order' => 1,		// Megjelenítési sorrend in the configuration listing (default NULL)
  'last_modified' => '',	// date last modified, usually left blank (default NULL)
  'date_added' => '',		// date added, should set to today (default NULL)
  'use_function' => '',		// function to used when reading value (default NULL)
  'set_function' => ''		// function to use when setting value (default NULL)
  );

*/
$today = date('Y-m-d H:i:s', time());
/*********************************************************************************************************
									Configuration Groups
/*********************************************************************************************************/
$config_groups = array();

$config_groups[] = array(
  'configuration_group_title' => 'Cégem',
  'configuration_group_description' => 'Általános információk a cégemről',
  'sort_order' => 1,
  'visible' => 1);

$config_groups[] = array(
  'configuration_group_title' => 'Ügyfél - alapértelmezett',
  'configuration_group_description' => 'Alapértelmezett ügyfél fiók beállítások',
  'sort_order' => 2,
  'visible' => 1);

$config_groups[] = array(
  'configuration_group_title' => 'Beszállító - alapértelmezett',
  'configuration_group_description' => 'Alapértelmezett beszállító fiók beállítások',
  'sort_order' => 3,
  'visible' => 1);

$config_groups[] = array(
  'configuration_group_title' => 'Alkalmazott - alapértelmezett',
  'configuration_group_description' => 'Alapértelmezett alkalmazott beállítások',
  'sort_order' => 4,
  'visible' => 1);

$config_groups[] = array(
  'configuration_group_title' => 'Készlet - alapértelmezett',
  'configuration_group_description' => 'Alapértelmezett készlet beállítások',
  'sort_order' => 5,
  'visible' => 1);

$config_groups[] = array(
  'configuration_group_title' => 'Főkönyv - alapértelmezett',
  'configuration_group_description' => 'Alapértelmezett általános főkönyvi beállítások',
  'sort_order' => 6,
  'visible' => 1);

$config_groups[] = array(
  'configuration_group_title' => 'Felhasználó - alapértelmezett',
  'configuration_group_description' => 'Alapértelmezett felhasználói fiók beállítások',
  'sort_order' => 7,
  'visible' => 1);

$config_groups[] = array(
  'configuration_group_title' => 'Általános beállítások',
  'configuration_group_description' => 'Általános program beállítások',
  'sort_order' => 8,
  'visible' => 1);

$config_groups[] = array(
  'configuration_group_title' => 'Import / Export beállítások',
  'configuration_group_description' => 'Import / export alapértelmezett beállítások',
  'sort_order' => 9,
  'visible' => 1);

$config_groups[] = array(
  'configuration_group_title' => 'Szállítás - alapértelmezett',
  'configuration_group_description' => 'Alapértelmezett szállítás/fuvarköltség beállítások',
  'sort_order' => 10,
  'visible' => 1);

$config_groups[] = array(
  'configuration_group_title' => 'Címjegyzék - alapértelmezett',
  'configuration_group_description' => 'Alapértelmezett címjegyzék beállítások',
  'sort_order' => 11,
  'visible' => 1);

$config_groups[] = array(
  'configuration_group_title' => 'E-Mail beállítások',
  'configuration_group_description' => 'Általános e-mail küldési és HTML e-mail beállítások',
  'sort_order' => 12,
  'visible' => 1);

$config_groups[] = array(
  'configuration_group_title' => 'Sessions',
  'configuration_group_description' => 'Session beállítások',
  'sort_order' => 15,
  'visible' => 1);

$config_groups[] = array(
  'configuration_group_title' => 'Hitelkártyák',
  'configuration_group_description' => 'Elfogadott hitelkártyák',
  'sort_order' => 17,
  'visible' => 1);

$config_groups[] = array(
  'configuration_group_title' => 'Kinézeti beállítások',
  'configuration_group_description' => 'Kinézeti beállítások',
  'sort_order' => 19,
  'visible' => 1);

$config_groups[] = array(
  'configuration_group_title' => 'Weboldal karbantartás',
  'configuration_group_description' => 'Weboldal karbantartás beállításai',
  'sort_order' => 20,
  'visible' => 1);

$config_groups[] = array(
  'configuration_group_title' => 'Modul - alapértelmezett',
  'configuration_group_description' => 'Alapértelmezett modul beállítások (felhasználó elől rejtve)',
  'sort_order' => 99,
  'visible' => 0);

/*********************************************************************************************************
									Configuration Data
/*********************************************************************************************************/
$config_data = array();
/************************** Group ID 0 (System set constants) ***********************************************/
$config_data[] = array(
  'configuration_title' => 'Jelenlegi számlázási időszak',
  'configuration_key' => 'CURRENT_ACCOUNTING_PERIOD',
  'configuration_value' => '1',
  'configuration_description' => 'Ez az érték definiálja az aktuális számlázási időszakot. A RENDSZER ÁLLÍTJA BE.',
  'configuration_group_id' => 0, 
  'sort_order' => 1,
  'date_added' => $today);

$config_data[] = array(
  'configuration_title' => 'Aktuális számlázási időszak - Kezdő dátum',
  'configuration_key' => 'CURRENT_ACCOUNTING_PERIOD_START',
  'configuration_value' => '',
  'configuration_description' => 'Ez az érték definiálja az aktuális számlázási időszak kezdetét. A RENDSZER ÁLLÍTJA BE.',
  'configuration_group_id' => 0, 
  'sort_order' => 2,
  'date_added' => $today);

$config_data[] = array(
  'configuration_title' => 'Aktuális számlázási időszak - Befejező dátum',
  'configuration_key' => 'CURRENT_ACCOUNTING_PERIOD_END',
  'configuration_value' => '',
  'configuration_description' => 'Ez az érték definiálja az aktuális számlázási időszak végét. A RENDSZER ÁLLÍTJA BE.',
  'configuration_group_id' => 0, 
  'sort_order' => 3,
  'date_added' => $today);

$config_data[] = array(
  'configuration_title' => 'Telepített modulok',
  'configuration_key' => 'MODULE_SHIPPING_INSTALLED',
  'configuration_value' => 'freeshipper.php;flat.php',
  'configuration_description' => 'Szállítási modulok filenevének listája, pontosvesszővel elválasztva. Automatikusan frissített érték. Nem szükséges szerkeszteni. (Pl.: ups.php;flat.php;item.php)',
  'configuration_group_id' => 0, 
  'sort_order' => 4,
  'date_added' => $today);

/************************** Group ID 1 (My Company) ***********************************************/
$config_data[] = array(
  'configuration_title' => 'Cég neve',
  'configuration_key' => 'COMPANY_NAME',
  'configuration_value' => '',
  'configuration_description' => 'A cégem neve',
  'configuration_group_id' => 1, 
  'sort_order' => 1,
  'date_added' => $today);

$config_data[] = array(
  'configuration_title' => 'Receivables Contact Name',
  'configuration_key' => 'AR_CONTACT_NAME',
  'configuration_value' => '',
  'configuration_description' => 'The default name or identifier to use for all receivable operations.',
  'configuration_group_id' => 1, 
  'sort_order' => 2,
  'date_added' => $today);

$config_data[] = array(
  'configuration_title' => 'Payables Contact Name',
  'configuration_key' => 'AP_CONTACT_NAME',
  'configuration_value' => '',
  'configuration_description' => 'The default name or identifier to use for all payable operations.',
  'configuration_group_id' => 1, 
  'sort_order' => 3,
  'date_added' => $today);

$config_data[] = array(
  'configuration_title' => 'Címsor 1',
  'configuration_key' => 'COMPANY_ADDRESS1',
  'configuration_value' => '',
  'configuration_description' => 'Cím első sora',
  'configuration_group_id' => 1, 
  'sort_order' => 4,
  'date_added' => $today);

$config_data[] = array(
  'configuration_title' => 'Címsor 2',
  'configuration_key' => 'COMPANY_ADDRESS2',
  'configuration_value' => '',
  'configuration_description' => 'Cím második sora',
  'configuration_group_id' => 1, 
  'sort_order' => 5,
  'date_added' => $today);

$config_data[] = array(
  'configuration_title' => 'Település',
  'configuration_key' => 'COMPANY_CITY_TOWN',
  'configuration_value' => '',
  'configuration_description' => 'A cég székhelyének településneve',
  'configuration_group_id' => 1, 
  'sort_order' => 6,
  'date_added' => $today);

$config_data[] = array(
  'configuration_title' => 'Megye vagy régió',
  'configuration_key' => 'COMPANY_ZONE',
  'configuration_value' => '',
  'configuration_description' => 'A megye vagy régió neve, ahol a cég székhelye található',
  'configuration_group_id' => 1, 
  'sort_order' => 7,
  'date_added' => $today,
  'use_function' => 'cfg_get_zone_name',
  'set_function' => 'cfg_pull_down_zone_list(');

$config_data[] = array(
  'configuration_title' => 'Irányítószám',
  'configuration_key' => 'COMPANY_POSTAL_CODE',
  'configuration_value' => '',
  'configuration_description' => 'A település irányítószáma, ahol a cég székhelye található',
  'configuration_group_id' => 1, 
  'sort_order' => 8,
  'date_added' => $today);

$config_data[] = array(
  'configuration_title' => 'Ország',
  'configuration_key' => 'COMPANY_COUNTRY',
  'configuration_value' => 'USA',
  'configuration_description' => 'Az ország, ahol a cég székhelye található<br /><br /><strong>Megjegyzés: Ne felejtsd el frissíteni a cég megyéjét/régióját.</strong>',
  'configuration_group_id' => 1, 
  'sort_order' => 9,
  'date_added' => $today,
  'use_function' => 'cfg_get_country_name',
  'set_function' => 'cfg_pull_down_country_list(');

$config_data[] = array(
  'configuration_title' => 'Elsődleges telefonszám',
  'configuration_key' => 'COMPANY_TELEPHONE1',
  'configuration_value' => '',
  'configuration_description' => 'Add meg a cég elsődleges telefonszámát',
  'configuration_group_id' => 1, 
  'sort_order' => 10,
  'date_added' => $today);

$config_data[] = array(
  'configuration_title' => 'Másodlagos telefonszám',
  'configuration_key' => 'COMPANY_TELEPHONE2',
  'configuration_value' => '',
  'configuration_description' => 'Másodlagos telefonszám (ingyenesen hívható szám is lehet)',
  'configuration_group_id' => 1, 
  'sort_order' => 11,
  'date_added' => $today);

$config_data[] = array(
  'configuration_title' => 'Fax szám',
  'configuration_key' => 'COMPANY_FAX',
  'configuration_value' => '',
  'configuration_description' => 'Add meg a cég fax számát',
  'configuration_group_id' => 1, 
  'sort_order' => 12,
  'date_added' => $today);

$config_data[] = array(
  'configuration_title' => 'Cég e-mail címe',
  'configuration_key' => 'COMPANY_EMAIL',
  'configuration_value' => '',
  'configuration_description' => 'Add meg a cég általános e-mail címét',
  'configuration_group_id' => 1, 
  'sort_order' => 13,
  'date_added' => $today);

$config_data[] = array(
  'configuration_title' => 'Cég weboldala',
  'configuration_key' => 'COMPANY_WEBSITE',
  'configuration_value' => '',
  'configuration_description' => 'Add meg a cég weboldalát (http:// nélkül)',
  'configuration_group_id' => 1, 
  'sort_order' => 14,
  'date_added' => $today);

$config_data[] = array(
  'configuration_title' => 'Cég adóazonosító száma',
  'configuration_key' => 'TAX_ID',
  'configuration_value' => '',
  'configuration_description' => 'Add meg a cég adóazonosító számát',
  'configuration_group_id' => 1, 
  'sort_order' => 15,
  'date_added' => $today);

$config_data[] = array(
  'configuration_title' => 'Cég azonosító',
  'configuration_key' => 'COMPANY_ID',
  'configuration_value' => '',
  'configuration_description' => 'Add meg a cég azonosító számát. Ez a szám tesz különbséget a helyi illetve az importált/exportált tranzakciók között.',
  'configuration_group_id' => 1, 
  'sort_order' => 16,
  'date_added' => $today);

$config_data[] = array(
  'configuration_title' => 'Váltás a nyelv alapértelmezett pénznemére',
  'configuration_key' => 'USE_DEFAULT_LANGUAGE_CURRENCY',
  'configuration_value' => 'False',
  'configuration_description' => 'Automatikus váltás a nyelv pénznemére nyelvváltáskor',
  'configuration_group_id' => 1, 
  'sort_order' => 20,
  'date_added' => $today,
  'set_function' => 'cfg_select_option(array(\'Igen\', \'Nem\'), ');

/************************** Group ID 2 (Customer Defaults) ***********************************************/
$config_data[] = array(
  'configuration_title' => 'Default Account - Accounts Receivable',
  'configuration_key' => 'AR_DEFAULT_GL_ACCT',
  'configuration_value' => '',
  'configuration_description' => 'Default Accounts Receivable Account',
  'configuration_group_id' => 2, 
  'sort_order' => 1,
  'date_added' => $today,
  'set_function' => 'cfg_pull_down_gl_acct_list(');

$config_data[] = array(
  'configuration_title' => 'Default GL Sales Account',
  'configuration_key' => 'AR_DEF_GL_SALES_ACCT',
  'configuration_value' => '',
  'configuration_description' => 'Default general ledger account for sales transactions',
  'configuration_group_id' => 2, 
  'sort_order' => 2,
  'date_added' => $today,
  'set_function' => 'cfg_pull_down_gl_acct_list(');

$config_data[] = array(
  'configuration_title' => 'Default GL Cash Receipts Account',
  'configuration_key' => 'AR_SALES_RECEIPTS_ACCOUNT',
  'configuration_value' => '',
  'configuration_description' => 'General ledger account to apply receipts to when customers pay invoices.',
  'configuration_group_id' => 2, 
  'sort_order' => 3,
  'date_added' => $today,
  'set_function' => 'cfg_pull_down_gl_acct_list(');

$config_data[] = array(
  'configuration_title' => 'Default GL Discount Account',
  'configuration_key' => 'AR_DISCOUNT_SALES_ACCOUNT',
  'configuration_value' => '',
  'configuration_description' => 'General ledger account to apply discounts to when customers pay on early schedule with a discount applied.',
  'configuration_group_id' => 2, 
  'sort_order' => 4,
  'date_added' => $today,
  'set_function' => 'cfg_pull_down_gl_acct_list(');

$config_data[] = array(
  'configuration_title' => 'Default Freight Account',
  'configuration_key' => 'AR_DEF_FREIGHT_ACCT',
  'configuration_value' => '',
  'configuration_description' => 'Default account to record feight charges',
  'configuration_group_id' => 2, 
  'sort_order' => 5,
  'date_added' => $today,
  'set_function' => 'cfg_pull_down_gl_acct_list(');

$config_data[] = array(
  'configuration_title' => 'Fizetési feltételek',
  'configuration_key' => 'AR_PAYMENT_TERMS',
  'configuration_value' => '1',
  'configuration_description' => 'Fizetési feltételek kiválasztása',
  'configuration_group_id' => 2, 
  'sort_order' => 10,
  'date_added' => $today);

$config_data[] = array(
  'configuration_title' => 'Hitelkeret használata',
  'configuration_key' => 'AR_USE_CREDIT_LIMIT',
  'configuration_value' => '1',
  'configuration_description' => 'Hitelkeret felhasználása a rendelések feldolgozása során',
  'configuration_group_id' => 2, 
  'sort_order' => 11,
  'date_added' => $today);

$config_data[] = array(
  'configuration_title' => 'Hitelkeret mértéke',
  'configuration_key' => 'AR_CREDIT_LIMIT_AMOUNT',
  'configuration_value' => '10000.00',
  'configuration_description' => 'Ügyfél hitelkeret alapértelmezett értéke.',
  'configuration_group_id' => 2, 
  'sort_order' => 12,
  'date_added' => $today);

$config_data[] = array(
  'configuration_title' => 'Num Days Due',
  'configuration_key' => 'AR_NUM_DAYS_DUE',
  'configuration_value' => '30',
  'configuration_description' => 'The number of days payment is due for use when terms are accepted (due in # of days, dus on day)',
  'configuration_group_id' => 2, 
  'sort_order' => 13,
  'date_added' => $today);

$config_data[] = array(
  'configuration_title' => 'Prepayment Discount Number of Days',
  'configuration_key' => 'AR_PREPAYMENT_DISCOUNT_DAYS',
  'configuration_value' => '0',
  'configuration_description' => 'Number of days to use for prepayment discount. Use in conjunction with Prepayment Discount below. Enter 0 for no prepayment discount.',
  'configuration_group_id' => 2, 
  'sort_order' => 14,
  'date_added' => $today);

$config_data[] = array(
  'configuration_title' => 'Prepayment Discount Percent',
  'configuration_key' => 'AR_PREPAYMENT_DISCOUNT_PERCENT',
  'configuration_value' => '0',
  'configuration_description' => 'Percent discount for early payment. Not used unless Prepayment Discount Number of Days is equal to zero.',
  'configuration_group_id' => 2, 
  'sort_order' => 15,
  'date_added' => $today);

$config_data[] = array(
  'configuration_title' => 'Account Aging Calculation Start Date',
  'configuration_key' => 'AR_ACCOUNT_AGING_START',
  'configuration_value' => '0',
  'configuration_description' => 'Sets the start time for account aging. Choices are:<br>0 - Invoice Date or 1 - Due Date',
  'configuration_group_id' => 2, 
  'sort_order' => 16,
  'date_added' => $today,
  'set_function' => 'cfg_select_option(array(\'0\', \'1\'), ');

$config_data[] = array(
  'configuration_title' => 'Account Aging Period 1',
  'configuration_key' => 'AR_AGING_PERIOD_1',
  'configuration_value' => '30',
  'configuration_description' => 'Determines the number of days for the first warning of past due invoices. The period starts from the Account Aging Start Date Field.',
  'configuration_group_id' => 2, 
  'sort_order' => 17,
  'date_added' => $today);

$config_data[] = array(
  'configuration_title' => 'Account Aging Period 2',
  'configuration_key' => 'AR_AGING_PERIOD_2',
  'configuration_value' => '60',
  'configuration_description' => 'Determines the number of days for the first warning of past due invoices. The period starts from the Account Aging Start Date Field.',
  'configuration_group_id' => 2, 
  'sort_order' => 18,
  'date_added' => $today);

$config_data[] = array(
  'configuration_title' => 'Account Aging Period 3',
  'configuration_key' => 'AR_AGING_PERIOD_3',
  'configuration_value' => '90',
  'configuration_description' => 'Determines the number of days for the first warning of past due invoices. The period starts from the Account Aging Start Date Field.',
  'configuration_group_id' => 2, 
  'sort_order' => 19,
  'date_added' => $today);

$config_data[] = array(
  'configuration_title' => 'Account Aging Heading 1',
  'configuration_key' => 'AR_AGING_HEADING_1',
  'configuration_value' => '0-30',
  'configuration_description' => 'This is the heading used on reports to show account aging for due date number 1.',
  'configuration_group_id' => 2, 
  'sort_order' => 20,
  'date_added' => $today);

$config_data[] = array(
  'configuration_title' => 'Account Aging Heading 2',
  'configuration_key' => 'AR_AGING_HEADING_2',
  'configuration_value' => '31-60',
  'configuration_description' => 'This is the heading used on reports to show account aging for due date number 2.',
  'configuration_group_id' => 2, 
  'sort_order' => 21,
  'date_added' => $today);

$config_data[] = array(
  'configuration_title' => 'Account Aging Heading 3',
  'configuration_key' => 'AR_AGING_HEADING_3',
  'configuration_value' => '61-90',
  'configuration_description' => 'This is the heading used on reports to show account aging for due date number 3.',
  'configuration_group_id' => 2, 
  'sort_order' => 22,
  'date_added' => $today);

$config_data[] = array(
  'configuration_title' => 'Account Aging Heading 4',
  'configuration_key' => 'AR_AGING_HEADING_4',
  'configuration_value' => 'Over 90',
  'configuration_description' => 'This is the heading used on reports to show account aging for due date number 4.',
  'configuration_group_id' => 2, 
  'sort_order' => 23,
  'date_added' => $today);

$config_data[] = array(
  'configuration_title' => 'Calculate Finance Charge',
  'configuration_key' => 'AR_CALCULATE_FINANCE_CHARGE',
  'configuration_value' => '0',
  'configuration_description' => 'Determines whether or not to calculate finance charges on past due invoices.',
  'configuration_group_id' => 2, 
  'sort_order' => 24,
  'date_added' => $today);

/************************** Group ID 3 (Vendor Defaults) ***********************************************/
$config_data[] = array(
  'configuration_title' => 'Default Item Purchase Account',
  'configuration_key' => 'AP_DEFAULT_INVENTORY_ACCOUNT',
  'configuration_value' => '',
  'configuration_description' => 'The default account for all items unless specified in the individual item record.',
  'configuration_group_id' => 3, 
  'sort_order' => 1,
  'date_added' => $today,
  'set_function' => 'cfg_pull_down_gl_acct_list(');

$config_data[] = array(
  'configuration_title' => 'Default GL Purchase Account',
  'configuration_key' => 'AP_DEFAULT_PURCHASE_ACCOUNT',
  'configuration_value' => '',
  'configuration_description' => 'The default account for all purchases unless specified in the individual vendor record.',
  'configuration_group_id' => 3, 
  'sort_order' => 2,
  'date_added' => $today,
  'set_function' => 'cfg_pull_down_gl_acct_list(');

$config_data[] = array(
  'configuration_title' => 'Default GL Cash Payments Account',
  'configuration_key' => 'AP_PURCHASE_INVOICE_ACCOUNT',
  'configuration_value' => '',
  'configuration_description' => 'General ledger account to apply payments to when vendor invoices are paid.',
  'configuration_group_id' => 3, 
  'sort_order' => 3,
  'date_added' => $today,
  'set_function' => 'cfg_pull_down_gl_acct_list(');

$config_data[] = array(
  'configuration_title' => 'Vendor Default Freight Account (Freight in)',
  'configuration_key' => 'AP_DEF_FREIGHT_ACCT',
  'configuration_value' => '',
  'configuration_description' => 'Default account to record feight charges for shipments from vendors',
  'configuration_group_id' => 3, 
  'sort_order' => 4,
  'date_added' => $today,
  'set_function' => 'cfg_pull_down_gl_acct_list(');

$config_data[] = array(
  'configuration_title' => 'Discount Purchase Account',
  'configuration_key' => 'AP_DISCOUNT_PURCHASE_ACCOUNT',
  'configuration_value' => '',
  'configuration_description' => 'The discount account for purchase paid with early discount payment terms',
  'configuration_group_id' => 3, 
  'sort_order' => 5,
  'date_added' => $today,
  'set_function' => 'cfg_pull_down_gl_acct_list(');

$config_data[] = array(
  'configuration_title' => 'Default Vendor Credit Limit',
  'configuration_key' => 'AP_CREDIT_LIMIT_AMOUNT',
  'configuration_value' => '5000.00',
  'configuration_description' => 'The default credit limit for the vendor unless over-ridden in the specific verdor account',
  'configuration_group_id' => 3, 
  'sort_order' => 10,
  'date_added' => $today);

$config_data[] = array(
  'configuration_title' => 'Beszállítói feltételek',
  'configuration_key' => 'AP_DEFAULT_TERMS',
  'configuration_value' => '0',
  'configuration_description' => 'Default terms for payment',
  'configuration_group_id' => 3, 
  'sort_order' => 11,
  'date_added' => $today);

$config_data[] = array(
  'configuration_title' => 'Payment Terms Number of Days',
  'configuration_key' => 'AP_NUM_DAYS_DUE',
  'configuration_value' => '30',
  'configuration_description' => 'The number of days the payment is due (only used for due in # of days and due on day settings)',
  'configuration_group_id' => 3, 
  'sort_order' => 12,
  'date_added' => $today);

$config_data[] = array(
  'configuration_title' => 'Early Payment Discount Percent',
  'configuration_key' => 'AP_PREPAYMENT_DISCOUNT_PERCENT',
  'configuration_value' => '0',
  'configuration_description' => 'Discount percent for early payment. Used with Early Payment Numer of Days',
  'configuration_group_id' => 3, 
  'sort_order' => 13,
  'date_added' => $today);

$config_data[] = array(
  'configuration_title' => 'Discount Payment Number of Days',
  'configuration_key' => 'AP_PREPAYMENT_DISCOUNT_DAYS',
  'configuration_value' => '10',
  'configuration_description' => 'Number of days the early payment discount applies',
  'configuration_group_id' => 3, 
  'sort_order' => 14,
  'date_added' => $today);

$config_data[] = array(
  'configuration_title' => 'Payables Aging Start Date',
  'configuration_key' => 'AP_AGING_START_DATE',
  'configuration_value' => '0',
  'configuration_description' => 'The start date used for payables aging<br />0= Invoice Date 1= Due Date',
  'configuration_group_id' => 3, 
  'sort_order' => 15,
  'date_added' => $today,
  'set_function' => 'cfg_select_option(array(\'0\', \'1\'), ');

$config_data[] = array(
  'configuration_title' => 'Account Aging Day Count 1',
  'configuration_key' => 'AP_AGING_DATE_1',
  'configuration_value' => '30',
  'configuration_description' => 'Number of days from the aging start date for the warning number 1',
  'configuration_group_id' => 3, 
  'sort_order' => 16,
  'date_added' => $today);

$config_data[] = array(
  'configuration_title' => 'Account Aging Day Count 2',
  'configuration_key' => 'AP_AGING_DATE_2',
  'configuration_value' => '60',
  'configuration_description' => 'Number of days from the aging start date for the warning number 2',
  'configuration_group_id' => 3, 
  'sort_order' => 17,
  'date_added' => $today);

$config_data[] = array(
  'configuration_title' => 'Account Aging Day Count 3',
  'configuration_key' => 'AP_AGING_DATE_3',
  'configuration_value' => '90',
  'configuration_description' => 'Number of days from the aging start date for the warning number 3',
  'configuration_group_id' => 3, 
  'sort_order' => 18,
  'date_added' => $today);

$config_data[] = array(
  'configuration_title' => 'Account Aging Heading 1',
  'configuration_key' => 'AP_AGING_HEADING_1',
  'configuration_value' => '0-30',
  'configuration_description' => 'The heading used in reports for account aging date 1',
  'configuration_group_id' => 3, 
  'sort_order' => 19,
  'date_added' => $today);

$config_data[] = array(
  'configuration_title' => 'Account Aging Heading 2',
  'configuration_key' => 'AP_AGING_HEADING_2',
  'configuration_value' => '31-60',
  'configuration_description' => 'The heading used in reports for account aging date 2',
  'configuration_group_id' => 3, 
  'sort_order' => 20,
  'date_added' => $today);

$config_data[] = array(
  'configuration_title' => 'Account Aging Heading 3',
  'configuration_key' => 'AP_AGING_HEADING_3',
  'configuration_value' => '61-90',
  'configuration_description' => 'The heading used in reports for account aging date 3',
  'configuration_group_id' => 3, 
  'sort_order' => 21,
  'date_added' => $today);

$config_data[] = array(
  'configuration_title' => 'Account Aging Heading 4',
  'configuration_key' => 'AP_AGING_HEADING_4',
  'configuration_value' => 'Over 90',
  'configuration_description' => 'The heading used in reports for account aging date 4',
  'configuration_group_id' => 3, 
  'sort_order' => 22,
  'date_added' => $today);

/************************** Group ID 4 (Employee Defaults) ***********************************************/


/************************** Group ID 5 (Inventory Defaults) ***********************************************/
$config_data[] = array(
  'configuration_title' => 'Stock Item GL Sales/Income Default Account',
  'configuration_key' => 'INV_STOCK_DEFAULT_SALES',
  'configuration_value' => '',
  'configuration_description' => 'Default general ledger sales/income account for inventory of type: Stock Items',
  'configuration_group_id' => 5, 
  'sort_order' => 1,
  'date_added' => $today,
  'set_function' => 'cfg_pull_down_gl_acct_list(');

$config_data[] = array(
  'configuration_title' => 'Stock Item GL Inventory Default Account',
  'configuration_key' => 'INV_STOCK_DEFAULT_INVENTORY',
  'configuration_value' => '',
  'configuration_description' => 'Default general ledger inventory account for inventory of type: Stock Items',
  'configuration_group_id' => 5, 
  'sort_order' => 2,
  'date_added' => $today,
  'set_function' => 'cfg_pull_down_gl_acct_list(');

$config_data[] = array(
  'configuration_title' => 'Stock Item GL Cost of Sales Default Account',
  'configuration_key' => 'INV_STOCK_DEFAULT_COS',
  'configuration_value' => '',
  'configuration_description' => 'Default general ledger cost of sales account for inventory of type: Stock Items',
  'configuration_group_id' => 5, 
  'sort_order' => 3,
  'date_added' => $today,
  'set_function' => 'cfg_pull_down_gl_acct_list(');

$config_data[] = array(
  'configuration_title' => 'Stock Item GL Costing Method Default',
  'configuration_key' => 'INV_STOCK_DEFAULT_COSTING',
  'configuration_value' => 'f',
  'configuration_description' => 'Default costing method for inventory of type: Stock Items<br />f - FIFO, l - LIFO, a - Average',
  'configuration_group_id' => 5, 
  'sort_order' => 4,
  'date_added' => $today,
  'set_function' => 'cfg_select_option(array(\'a\', \'f\', \'l\'), ');

$config_data[] = array(
  'configuration_title' => 'Master Stock Item GL Sales/Income Default Account',
  'configuration_key' => 'INV_MASTER_STOCK_DEFAULT_SALES',
  'configuration_value' => '',
  'configuration_description' => 'Default general ledger sales/income account for inventory of type: Master Stock Items',
  'configuration_group_id' => 5, 
  'sort_order' => 5,
  'date_added' => $today,
  'set_function' => 'cfg_pull_down_gl_acct_list(');

$config_data[] = array(
  'configuration_title' => 'Master Stock Item GL Inventory Default Account',
  'configuration_key' => 'INV_MASTER_STOCK_DEFAULT_INVENTORY',
  'configuration_value' => '',
  'configuration_description' => 'Default general ledger inventory account for inventory of type: Master Stock Items',
  'configuration_group_id' => 5, 
  'sort_order' => 6,
  'date_added' => $today,
  'set_function' => 'cfg_pull_down_gl_acct_list(');

$config_data[] = array(
  'configuration_title' => 'Master Stock Item GL Cost of Sales Default Account',
  'configuration_key' => 'INV_MASTER_STOCK_DEFAULT_COS',
  'configuration_value' => '',
  'configuration_description' => 'Default general ledger cost of sales account for inventory of type: Master Stock Items',
  'configuration_group_id' => 5, 
  'sort_order' => 7,
  'date_added' => $today,
  'set_function' => 'cfg_pull_down_gl_acct_list(');

$config_data[] = array(
  'configuration_title' => 'Master Stock Item GL Costing Method Default',
  'configuration_key' => 'INV_MASTER_STOCK_DEFAULT_COSTING',
  'configuration_value' => 'f',
  'configuration_description' => 'Default costing method for inventory of type: Master Stock Items<br />f - FIFO, l - LIFO, a - Average',
  'configuration_group_id' => 5, 
  'sort_order' => 8,
  'date_added' => $today,
  'set_function' => 'cfg_select_option(array(\'a\', \'f\', \'l\'), ');

$config_data[] = array(
  'configuration_title' => 'Assembly Item GL Sales/Income Default Account',
  'configuration_key' => 'INV_ASSY_DEFAULT_SALES',
  'configuration_value' => '',
  'configuration_description' => 'Default general ledger sales/income account for inventory of type: Assembly Items',
  'configuration_group_id' => 5, 
  'sort_order' => 11,
  'date_added' => $today,
  'set_function' => 'cfg_pull_down_gl_acct_list(');

$config_data[] = array(
  'configuration_title' => 'Assembly Item GL Inventory Default Account',
  'configuration_key' => 'INV_ASSY_DEFAULT_INVENTORY',
  'configuration_value' => '',
  'configuration_description' => 'Default general ledger inventory account for inventory of type: Assembly Items',
  'configuration_group_id' => 5, 
  'sort_order' => 12,
  'date_added' => $today,
  'set_function' => 'cfg_pull_down_gl_acct_list(');

$config_data[] = array(
  'configuration_title' => 'Assembly Item GL Cost of Sales Default Account',
  'configuration_key' => 'INV_ASSY_DEFAULT_COS',
  'configuration_value' => '',
  'configuration_description' => 'Default general ledger cost of sales account for inventory of type: Assmebly Items',
  'configuration_group_id' => 5, 
  'sort_order' => 13,
  'date_added' => $today,
  'set_function' => 'cfg_pull_down_gl_acct_list(');

$config_data[] = array(
  'configuration_title' => 'Assembly Item GL Costing Method Default',
  'configuration_key' => 'INV_ASSY_DEFAULT_COSTING',
  'configuration_value' => 'f',
  'configuration_description' => 'Default costing method for inventory of type: Assembly Items<br />f - FIFO, l - LIFO, a - Average',
  'configuration_group_id' => 5, 
  'sort_order' => 14,
  'date_added' => $today,
  'set_function' => 'cfg_select_option(array(\'a\', \'f\', \'l\'), ');

$config_data[] = array(
  'configuration_title' => 'Serialized Item GL Sales/Income Default Account',
  'configuration_key' => 'INV_SERIALIZE_DEFAULT_SALES',
  'configuration_value' => '',
  'configuration_description' => 'Default general ledger sales/income account for inventory of type: Serialized Items',
  'configuration_group_id' => 5, 
  'sort_order' => 16,
  'date_added' => $today,
  'set_function' => 'cfg_pull_down_gl_acct_list(');

$config_data[] = array(
  'configuration_title' => 'Serialized Item GL Inventory Default Account',
  'configuration_key' => 'INV_SERIALIZE_DEFAULT_INVENTORY',
  'configuration_value' => '',
  'configuration_description' => 'Default general ledger inventory account for inventory of type: Serialized Items',
  'configuration_group_id' => 5, 
  'sort_order' => 17,
  'date_added' => $today,
  'set_function' => 'cfg_pull_down_gl_acct_list(');

$config_data[] = array(
  'configuration_title' => 'Serialized Item GL Cost of Sales Default Account',
  'configuration_key' => 'INV_SERIALIZE_DEFAULT_COS',
  'configuration_value' => '',
  'configuration_description' => 'Default general ledger cost of sales account for inventory of type: Serialized Items',
  'configuration_group_id' => 5, 
  'sort_order' => 18,
  'date_added' => $today,
  'set_function' => 'cfg_pull_down_gl_acct_list(');

$config_data[] = array(
  'configuration_title' => 'Serialized Item GL Costing Method Default',
  'configuration_key' => 'INV_SERIALIZE_DEFAULT_COSTING',
  'configuration_value' => 'f',
  'configuration_description' => 'Default costing method for inventory of type: Serialized Items<br />f - FIFO, l - LIFO, a - Average',
  'configuration_group_id' => 5, 
  'sort_order' => 19,
  'date_added' => $today,
  'set_function' => 'cfg_select_option(array(\'a\', \'f\', \'l\'), ');

$config_data[] = array(
  'configuration_title' => 'Non-Stock Item GL Sales/Income Default Account',
  'configuration_key' => 'INV_NON_STOCK_DEFAULT_SALES',
  'configuration_value' => '',
  'configuration_description' => 'Default general ledger sales/income account for inventory of type: Non-Stock Items',
  'configuration_group_id' => 5, 
  'sort_order' => 21,
  'date_added' => $today,
  'set_function' => 'cfg_pull_down_gl_acct_list(');

$config_data[] = array(
  'configuration_title' => 'Non-Stock Item GL Inventory Default Account',
  'configuration_key' => 'INV_NON_STOCK_DEFAULT_INVENTORY',
  'configuration_value' => '',
  'configuration_description' => 'Default general ledger inventory account for inventory of type: Non-Stock Items',
  'configuration_group_id' => 5, 
  'sort_order' => 22,
  'date_added' => $today,
  'set_function' => 'cfg_pull_down_gl_acct_list(');

$config_data[] = array(
  'configuration_title' => 'Non-Stock Item GL Cost of Sales Default Account',
  'configuration_key' => 'INV_NON_STOCK_DEFAULT_COS',
  'configuration_value' => '',
  'configuration_description' => 'Default general ledger cost of sales account for inventory of type: Non-Stock Items',
  'configuration_group_id' => 5, 
  'sort_order' => 23,
  'date_added' => $today,
  'set_function' => 'cfg_pull_down_gl_acct_list(');

$config_data[] = array(
  'configuration_title' => 'Service Item GL Sales/Income Default Account',
  'configuration_key' => 'INV_SERVICE_DEFAULT_SALES',
  'configuration_value' => '',
  'configuration_description' => 'Default general ledger sales/income account for inventory of type: Service Items',
  'configuration_group_id' => 5, 
  'sort_order' => 31,
  'date_added' => $today,
  'set_function' => 'cfg_pull_down_gl_acct_list(');

$config_data[] = array(
  'configuration_title' => 'Service Item GL Inventory Default Account',
  'configuration_key' => 'INV_SERVICE_DEFAULT_INVENTORY',
  'configuration_value' => '',
  'configuration_description' => 'Default general ledger inventory account for inventory of type: Service Items',
  'configuration_group_id' => 5, 
  'sort_order' => 32,
  'date_added' => $today,
  'set_function' => 'cfg_pull_down_gl_acct_list(');

$config_data[] = array(
  'configuration_title' => 'Service Item GL Cost of Sales Default Account',
  'configuration_key' => 'INV_SERVICE_DEFAULT_COS',
  'configuration_value' => '',
  'configuration_description' => 'Default general ledger cost of sales account for inventory of type: Service Items',
  'configuration_group_id' => 5, 
  'sort_order' => 33,
  'date_added' => $today,
  'set_function' => 'cfg_pull_down_gl_acct_list(');

$config_data[] = array(
  'configuration_title' => 'Labor Item GL Inventory Default Account',
  'configuration_key' => 'INV_LABOR_DEFAULT_INVENTORY',
  'configuration_value' => '',
  'configuration_description' => 'Default general ledger inventory account for inventory of type: Labor Items',
  'configuration_group_id' => 5, 
  'sort_order' => 37,
  'date_added' => $today,
  'set_function' => 'cfg_pull_down_gl_acct_list(');

$config_data[] = array(
  'configuration_title' => 'Labor Item GL Cost of Sales Default Account',
  'configuration_key' => 'INV_LABOR_DEFAULT_COS',
  'configuration_value' => '',
  'configuration_description' => 'Default general ledger cost of sales account for inventory of type: Labor Items',
  'configuration_group_id' => 5, 
  'sort_order' => 38,
  'date_added' => $today,
  'set_function' => 'cfg_pull_down_gl_acct_list(');

$config_data[] = array(
  'configuration_title' => 'Labor Item GL Sales/Income Default Account',
  'configuration_key' => 'INV_LABOR_DEFAULT_SALES',
  'configuration_value' => '',
  'configuration_description' => 'Default general ledger sales/income account for inventory of type: Labor Items',
  'configuration_group_id' => 5, 
  'sort_order' => 36,
  'date_added' => $today,
  'set_function' => 'cfg_pull_down_gl_acct_list(');

$config_data[] = array(
  'configuration_title' => 'Activity Item GL Sales/Income Default Account',
  'configuration_key' => 'INV_ACTIVITY_DEFAULT_SALES',
  'configuration_value' => '',
  'configuration_description' => 'Default general ledger sales/income account for inventory of type: Activity Items',
  'configuration_group_id' => 5, 
  'sort_order' => 41,
  'date_added' => $today,
  'set_function' => 'cfg_pull_down_gl_acct_list(');

$config_data[] = array(
  'configuration_title' => 'Charge Item GL Sales/Income Default Account',
  'configuration_key' => 'INV_CHARGE_DEFAULT_SALES',
  'configuration_value' => '',
  'configuration_description' => 'Default general ledger sales/income account for inventory of type: Charge Items',
  'configuration_group_id' => 5, 
  'sort_order' => 42,
  'date_added' => $today,
  'set_function' => 'cfg_pull_down_gl_acct_list(');

/************************** Group ID 6 (Special Cases (Payment, Shippping, Price Sheets) **************/
$config_data[] = array(
  'configuration_title' => 'Csekkes/Készpénzes rendelési modul engedélyezése',
  'configuration_key' => 'MODULE_PAYMENT_MONEYORDER_STATUS',
  'configuration_value' => 'True',
  'configuration_description' => 'Elfogadsz csekkes/készpénzes fizetéseket?',
  'configuration_group_id' => 6, 
  'sort_order' => 1,
  'date_added' => $today,
  'set_function' => 'cfg_select_option(array(\'Igen\', \'Nem\'), ');

$config_data[] = array(
  'configuration_title' => 'Kedvezményezett:',
  'configuration_key' => 'MODULE_PAYMENT_MONEYORDER_PAYTO',
  'configuration_value' => '',
  'configuration_description' => 'Ki legyen a kifizetések kedvezményezettje?',
  'configuration_group_id' => 6, 
  'sort_order' => 1,
  'date_added' => $today);

$config_data[] = array(
  'configuration_title' => 'Megjelenítés sorrendje.',
  'configuration_key' => 'MODULE_PAYMENT_MONEYORDER_SORT_ORDER',
  'configuration_value' => '3',
  'configuration_description' => 'Megjelenítés sorrendje. Növekvő sorrendben.',
  'configuration_group_id' => 6, 
  'sort_order' => 0,
  'date_added' => $today);

$config_data[] = array(
  'configuration_title' => 'Utánvétes fizetési modul engedélyezése',
  'configuration_key' => 'MODULE_PAYMENT_COD_STATUS',
  'configuration_value' => 'True',
  'configuration_description' => 'Elfogadsz átvételkori fizetést?',
  'configuration_group_id' => 6, 
  'sort_order' => 1,
  'date_added' => $today,
  'set_function' => 'cfg_select_option(array(\'Igen\', \'Nem\'), ');

$config_data[] = array(
  'configuration_title' => 'Megjelenítés sorrendje.',
  'configuration_key' => 'MODULE_PAYMENT_COD_SORT_ORDER',
  'configuration_value' => '2',
  'configuration_description' => 'Megjelenítés sorrendje. Növekvő sorrendben.',
  'configuration_group_id' => 6, 
  'sort_order' => 0,
  'date_added' => $today);

$config_data[] = array(
  'configuration_title' => 'Telepített modulok',
  'configuration_key' => 'MODULE_PAYMENT_INSTALLED',
  'configuration_value' => 'cod.php;moneyorder.php',
  'configuration_description' => 'Elérhető fizetési modulok fájlnevei pontosvesszővel elválasztva. Automatikusan frissített. Nem szükséges szerkeszteni. (Example: cc.php;cod.php;paypal.php)',
  'configuration_group_id' => 6, 
  'sort_order' => 0,
  'date_added' => $today);

$config_data[] = array(
  'configuration_title' => 'Mennyiségen alapuló árlisták engedélyezése',
  'configuration_key' => 'MODULE_PRICE_SHEET_QTY_STATUS',
  'configuration_value' => 'True',
  'configuration_description' => 'Többszintű árazás, amely a rendelt mennyiségek alapul. Engedélyezed?',
  'configuration_group_id' => 6, 
  'sort_order' => 1,
  'date_added' => $today,
  'set_function' => 'cfg_select_option(array(\'Igen\', \'Nem\'), ');

$config_data[] = array(
  'configuration_title' => 'Megjelenítés sorrendje.',
  'configuration_key' => 'MODULE_PRICE_SHEET_QTY_SORT_ORDER',
  'configuration_value' => '0',
  'configuration_description' => 'Megjelenítés sorrendje. Növekvő sorrendben.',
  'configuration_group_id' => 6, 
  'sort_order' => 0,
  'date_added' => $today);

$config_data[] = array(
  'configuration_title' => 'Átalánydíjas szállítási mód engedélyezése',
  'configuration_key' => 'MODULE_SHIPPING_FLAT_STATUS',
  'configuration_value' => 'True',
  'configuration_description' => 'Engedélyezed az átalánydíjas szállítási módot?',
  'configuration_group_id' => 6, 
  'sort_order' => 0,
  'date_added' => $today,
  'set_function' => 'cfg_select_option(array(\'Igen\', \'Nem\'), ');

$config_data[] = array(
  'configuration_title' => 'Átalánydíjas szállítás',
  'configuration_key' => 'MODULE_SHIPPING_FLAT_TITLE',
  'configuration_value' => 'Flat Shipping',
  'configuration_description' => 'Szállítási költség becslőben használt megnevezés (szabadon átírható)',
  'configuration_group_id' => 6, 
  'sort_order' => 0,
  'date_added' => $today);

$config_data[] = array(
  'configuration_title' => 'Szállítási költség',
  'configuration_key' => 'MODULE_SHIPPING_FLAT_COST',
  'configuration_value' => '5.00',
  'configuration_description' => 'Az összes rendelésre ez a szállítási költség mód lesz alkalmazva.',
  'configuration_group_id' => 6, 
  'sort_order' => 0,
  'date_added' => $today);

$config_data[] = array(
  'configuration_title' => 'Megjelenítési sorrend',
  'configuration_key' => 'MODULE_SHIPPING_FLAT_SORT_ORDER',
  'configuration_value' => '2',
  'configuration_description' => 'Megjelenítés sorrendje.',
  'configuration_group_id' => 6, 
  'sort_order' => 0,
  'date_added' => $today);

$config_data[] = array(
  'configuration_title' => 'Ingyenes szállítás engedélyezése',
  'configuration_key' => 'MODULE_SHIPPING_FREESHIPPER_STATUS',
  'configuration_value' => 'True',
  'configuration_description' => 'Biztosítasz ingyenes kiszállítást?',
  'configuration_group_id' => 6, 
  'sort_order' => 0,
  'date_added' => $today,
  'set_function' => 'cfg_select_option(array(\'Igen\', \'Nem\'), ');

$config_data[] = array(
  'configuration_title' => 'Ingyenes szállítás',
  'configuration_key' => 'MODULE_SHIPPING_FREESHIPPER_TITLE',
  'configuration_value' => 'Ingyenes szállítás',
  'configuration_description' => 'Szállítási költség becslőnél használt cím (bármire átírhatod)',
  'configuration_group_id' => 6, 
  'sort_order' => 0,
  'date_added' => $today);

$config_data[] = array(
  'configuration_title' => 'Szállítási költség nélkül',
  'configuration_key' => 'MODULE_SHIPPING_FREESHIPPER_COST',
  'configuration_value' => '0.00',
  'configuration_description' => 'Mi a szállítási költség?',
  'configuration_group_id' => 6, 
  'sort_order' => 6,
  'date_added' => $today);

$config_data[] = array(
  'configuration_title' => 'Kezelési költség',
  'configuration_key' => 'MODULE_SHIPPING_FREESHIPPER_HANDLING',
  'configuration_value' => '0.00',
  'configuration_description' => 'Ennek a szállítási módnak a kezelési költsége.',
  'configuration_group_id' => 6, 
  'sort_order' => 0,
  'date_added' => $today);

$config_data[] = array(
  'configuration_title' => 'Megjelenítési sorrend',
  'configuration_key' => 'MODULE_SHIPPING_FREESHIPPER_SORT_ORDER',
  'configuration_value' => '1',
  'configuration_description' => 'Megjelenítés sorrendje.',
  'configuration_group_id' => 6, 
  'sort_order' => 0,
  'date_added' => $today);

$config_data[] = array(
  'configuration_title' => 'Telepített modulok',
  'configuration_key' => 'MODULE_PRICE_SHEETS_INSTALLED',
  'configuration_value' => 'quantity.php',
  'configuration_description' => 'Automatikusan frissített. Nem szükséges szerkeszteni.',
  'configuration_group_id' => 6, 
  'sort_order' => 0,
  'date_added' => $today);

$config_data[] = array(
  'configuration_title' => 'Telepített modulok',
  'configuration_key' => 'MODULE_ZENCART_INSTALLED',
  'configuration_value' => '',
  'configuration_description' => 'Automatikusan frissített. Nem szükséges szerkeszteni.',
  'configuration_group_id' => 6, 
  'sort_order' => 0,
  'date_added' => $today);

/************************** Group ID 7 (User Account Defaults) ***********************************************/
$config_data[] = array(
  'configuration_title' => 'Kapcsolattartó megadása szükséges?',
  'configuration_key' => 'ADDRESS_BOOK_CONTACT_REQUIRED',
  'configuration_value' => '0',
  'configuration_description' => 'Fiók beállításoknál a Kapcsolattartó mező kitöltése kötelező? (beszállítók, ügyfelek, alkalmazottak)',
  'configuration_group_id' => 7, 
  'sort_order' => 2,
  'date_added' => $today,
  'set_function' => 'cfg_keyed_select_option(array(0 =>\'Nem\', 1=> \'Igen\'),');

$config_data[] = array(
  'configuration_title' => 'Címsor 1 megadása szükséges?',
  'configuration_key' => 'ADDRESS_BOOK_ADDRESS1_REQUIRED',
  'configuration_value' => '1',
  'configuration_description' => 'Fiók beállításoknál a Címsor 1 mező kitöltése kötelező? (beszállítók, ügyfelek, alkalmazottak)',
  'configuration_group_id' => 7, 
  'sort_order' => 3,
  'date_added' => $today,
  'set_function' => 'cfg_keyed_select_option(array(0 =>\'Nem\', 1=> \'Igen\'),');

$config_data[] = array(
  'configuration_title' => 'Címsor 2 megadása szükséges?',
  'configuration_key' => 'ADDRESS_BOOK_ADDRESS2_REQUIRED',
  'configuration_value' => '0',
  'configuration_description' => 'Fiók beállításoknál a Címsor 2 mező kitöltése kötelező? (beszállítók, ügyfelek, alkalmazottak)',
  'configuration_group_id' => 7, 
  'sort_order' => 4,
  'date_added' => $today,
  'set_function' => 'cfg_keyed_select_option(array(0 =>\'Nem\', 1=> \'Igen\'),');

$config_data[] = array(
  'configuration_title' => 'Település megadása szükséges?',
  'configuration_key' => 'ADDRESS_BOOK_CITY_TOWN_REQUIRED',
  'configuration_value' => '1',
  'configuration_description' => 'Fiók beállításoknál a Település mező kitöltése kötelező? (beszállítók, ügyfelek, alkalmazottak)',
  'configuration_group_id' => 7, 
  'sort_order' => 5,
  'date_added' => $today,
  'set_function' => 'cfg_keyed_select_option(array(0 =>\'Nem\', 1=> \'Igen\'),');

$config_data[] = array(
  'configuration_title' => 'Megye/Régió megadása szükséges?',
  'configuration_key' => 'ADDRESS_BOOK_STATE_PROVINCE_REQUIRED',
  'configuration_value' => '1',
  'configuration_description' => 'Fiók beállításoknál a Megye/Régió mező kitöltése kötelező? (beszállítók, ügyfelek, alkalmazottak)',
  'configuration_group_id' => 7, 
  'sort_order' => 6,
  'date_added' => $today,
  'set_function' => 'cfg_keyed_select_option(array(0 =>\'Nem\', 1=> \'Igen\'),');

$config_data[] = array(
  'configuration_title' => 'Irányítószám megadása szükséges?',
  'configuration_key' => 'ADDRESS_BOOK_POSTAL_CODE_REQUIRED',
  'configuration_value' => '1',
  'configuration_description' => 'Fiók beállításoknál az Irányítószám mező kitöltése kötelező? (beszállítók, ügyfelek, alkalmazottak)',
  'configuration_group_id' => 7, 
  'sort_order' => 7,
  'date_added' => $today,
  'set_function' => 'cfg_keyed_select_option(array(0 =>\'Nem\', 1=> \'Igen\'),');

$config_data[] = array(
  'configuration_title' => 'Telefon 1 megadása szükséges?',
  'configuration_key' => 'ADDRESS_BOOK_TELEPHONE1_REQUIRED',
  'configuration_value' => '0',
  'configuration_description' => 'Fiók beállításoknál a Telefon 1 mező kitöltése kötelező? (beszállítók, ügyfelek, alkalmazottak)',
  'configuration_group_id' => 7, 
  'sort_order' => 8,
  'date_added' => $today,
  'set_function' => 'cfg_keyed_select_option(array(0 =>\'Nem\', 1=> \'Igen\'),');

$config_data[] = array(
  'configuration_title' => 'E-mail megadása szükséges?',
  'configuration_key' => 'ADDRESS_BOOK_EMAIL_REQUIRED',
  'configuration_value' => '0',
  'configuration_description' => 'Fiók beállításoknál a E-mail mező kitöltése kötelező? (beszállítók, ügyfelek, alkalmazottak)',
  'configuration_group_id' => 7, 
  'sort_order' => 9,
  'date_added' => $today,
  'set_function' => 'cfg_keyed_select_option(array(0 =>\'Nem\', 1=> \'Igen\'),');

$config_data[] = array(
  'configuration_title' => 'Jelszó',
  'configuration_key' => 'ENTRY_PASSWORD_MIN_LENGTH',
  'configuration_value' => '5',
  'configuration_description' => 'Jelszó minimum hossza',
  'configuration_group_id' => 7, 
  'sort_order' => 10,
  'date_added' => $today);

/************************** Group ID 8 (General Settings) ***********************************************/
$config_data[] = array(
  'configuration_title' => 'Keresési találatok maximum száma oldalanként',
  'configuration_key' => 'MAX_DISPLAY_SEARCH_RESULTS',
  'configuration_value' => '20',
  'configuration_description' => 'Megjeleníthető keresési találatok száma oldalanként',
  'configuration_group_id' => 8, 
  'sort_order' => 1,
  'date_added' => $today);

$config_data[] = array(
  'configuration_title' => 'Program frissítések automatikus keresése',
  'configuration_key' => 'CFG_AUTO_UPDATE_CHECK',
  'configuration_value' => '1',
  'configuration_description' => 'Program frissítések keresése automatikusan a PhreeBooks-ba való belépéskor.',
  'configuration_group_id' => 8, 
  'sort_order' => 3,
  'date_added' => $today,
  'set_function' => 'cfg_keyed_select_option(array(0 =>\'Nem\', 1=> \'Igen\'),');

/************************** Group ID 9 (Import/Export Settings) ***********************************************/
$config_data[] = array(
  'configuration_title' => 'Jelentés/Űrlap Export beállítások',
  'configuration_key' => 'IE_RW_EXPORT_PREFERENCE',
  'configuration_value' => 'Download',
  'configuration_description' => 'Specifies the export preference when exporting reports and forms. A "helyi" a webszervered könyvtárában található /my_files/reports könyvtárba fogja menteni. "Letölt" esetén pedig a böngésző letölti mentéshez vagy nyomtatáshoz a helyi gépedre.',
  'configuration_group_id' => 9, 
  'sort_order' => 1,
  'date_added' => $today,
  'set_function' => 'cfg_select_option(array(\'Helyi\', \'Letölt\'), ');

/************************** Group ID 10 (Shipping Defaults) ***********************************************/
$config_data[] = array(
  'configuration_title' => 'Alapértelmezett tömeg mértékegység',
  'configuration_key' => 'SHIPPING_DEFAULT_WEIGHT_UNIT',
  'configuration_value' => 'KGS',
  'configuration_description' => 'Beállítja az alapértelmezett mértékegységet az összes csomaghoz. Érvényes értékek:<br>LBS - Font<br>KG - Kilogramm',
  'configuration_group_id' => 10, 
  'sort_order' => 1,
  'date_added' => $today,
  'set_function' => 'html_pull_down_menu(\'configuration_value\', gen_build_pull_down($shipping_defaults[\'weight_unit\']),');

$config_data[] = array(
  'configuration_title' => 'Szállítások esetén használt alapértelmezett pénznem',
  'configuration_key' => 'SHIPPING_DEFAULT_CURRENCY',
  'configuration_value' => 'HUF',
  'configuration_description' => 'Érvényes értékek:<br>USD - Amerikai dollár<br>EUR - Euro<br>HUF Magyar forint',
  'configuration_group_id' => 10, 
  'sort_order' => 2,
  'date_added' => $today,
  'set_function' => 'html_pull_down_menu(\'configuration_value\', gen_get_currency_array(),');

$config_data[] = array(
  'configuration_title' => 'Csomag méretének alapértelmezett mértékegysége',
  'configuration_key' => 'SHIPPING_DEFAULT_PKG_DIM_UNIT',
  'configuration_value' => 'CM',
  'configuration_description' => 'Csomag méretének mértékegysége. Érvényes értékek:<br>IN - Inch<br>CM - Centiméter',
  'configuration_group_id' => 10, 
  'sort_order' => 3,
  'date_added' => $today,
  'set_function' => 'html_pull_down_menu(\'configuration_value\', gen_build_pull_down($shipping_defaults[\'dimension_unit\']),');

$config_data[] = array(
  'configuration_title' => 'Pre-selects the Residential address checkbox',
  'configuration_key' => 'SHIPPING_DEFAULT_RESIDENTIAL',
  'configuration_value' => '1',
  'configuration_description' => '0 - Sets the default residential ship box to unchecked (commercial address)<br>1 - Sets the default residential ship box to checked (residential address)',
  'configuration_group_id' => 10, 
  'sort_order' => 4,
  'date_added' => $today,
  'set_function' => 'cfg_keyed_select_option(array(0 =>\'nincs kiválasztva\', 1=> \'kiválasztva\'),');

$config_data[] = array(
  'configuration_title' => 'Megadja az alapértelmezett csomag típust',
  'configuration_key' => 'SHIPPING_DEFAULT_PACKAGE_TYPE',
  'configuration_value' => '02',
  'configuration_description' => 'Megadja a szállításkor használt alapértelmezett csomagolás típusát.',
  'configuration_group_id' => 10, 
  'sort_order' => 5,
  'date_added' => $today,
  'set_function' => 'html_pull_down_menu(\'configuration_value\', gen_build_pull_down($shipping_defaults[\'package_type\']),');

$config_data[] = array(
  'configuration_title' => 'Default package pickup service',
  'configuration_key' => 'SHIPPING_DEFAULT_PICKUP_SERVICE',
  'configuration_value' => '01',
  'configuration_description' => 'Specify the default type of pickup service for your package service.',
  'configuration_group_id' => 10, 
  'sort_order' => 6,
  'date_added' => $today,
  'set_function' => 'html_pull_down_menu(\'configuration_value\', gen_build_pull_down($shipping_defaults[\'pickup_service\']),');

$config_data[] = array(
  'configuration_title' => 'Beállítja az alapértelmezett csomag hosszúságot',
  'configuration_key' => 'SHIPPING_DEFAULT_LENGTH',
  'configuration_value' => '8',
  'configuration_description' => 'Add meg az alapértelmezett csomag hosszúságot egy általános szállítmány esetén.',
  'configuration_group_id' => 10, 
  'sort_order' => 7,
  'date_added' => $today);

$config_data[] = array(
  'configuration_title' => 'Beállítja az alapértelmezett csomag szélességet',
  'configuration_key' => 'SHIPPING_DEFAULT_WIDTH',
  'configuration_value' => '6',
  'configuration_description' => 'Add meg az alapértelmezett csomag szélességet egy általános szállítmány esetén.',
  'configuration_group_id' => 10, 
  'sort_order' => 8,
  'date_added' => $today);

$config_data[] = array(
  'configuration_title' => 'Beállítja az alapértelmezett csomag magasságot',
  'configuration_key' => 'SHIPPING_DEFAULT_HEIGHT',
  'configuration_value' => '4',
  'configuration_description' => 'Add meg az alapértelmezett csomag magasságot egy általános szállítmány esetén.',
  'configuration_group_id' => 10, 
  'sort_order' => 9,
  'date_added' => $today);

$config_data[] = array(
  'configuration_title' => 'Plusz kezelési költség jelölőnégyzet megjelenítése',
  'configuration_key' => 'SHIPPING_DEFAULT_ADDITIONAL_HANDLING_SHOW',
  'configuration_value' => '1',
  'configuration_description' => 'Plusz kezelési költség jelölőnégyzet megjelenítése',
  'configuration_group_id' => 10, 
  'sort_order' => 10,
  'date_added' => $today,
  'set_function' => 'cfg_keyed_select_option(array(0 =>\'elrejt\', 1=> \'megjelenít\'),');

$config_data[] = array(
  'configuration_title' => 'Előválasztja a plusz kezelési költség jelölőnégyzetet',
  'configuration_key' => 'SHIPPING_DEFAULT_ADDITIONAL_HANDLING_CHECKED',
  'configuration_value' => '0',
  'configuration_description' => 'Előválasztja a plusz kezelési költség jelölőnégyzetet',
  'configuration_group_id' => 10, 
  'sort_order' => 12,
  'date_added' => $today,
  'set_function' => 'cfg_keyed_select_option(array(0 =>\'nincs kiválasztva\', 1=> \'kiválasztva\'),');

$config_data[] = array(
  'configuration_title' => 'Biztosítás kiválasztásának megjelenítése',
  'configuration_key' => 'SHIPPING_DEFAULT_INSURANCE_SHOW',
  'configuration_value' => '1',
  'configuration_description' => 'Megjeleníti a biztosítás kiválasztásának lehetőségét.',
  'configuration_group_id' => 10, 
  'sort_order' => 14,
  'date_added' => $today,
  'set_function' => 'cfg_keyed_select_option(array(0 =>\'elrejt\', 1=> \'megjelenít\'),');

$config_data[] = array(
  'configuration_title' => 'Előválasztja a biztosítási beállítások jelölőnégyzetet',
  'configuration_key' => 'SHIPPING_DEFAULT_INSURANCE_CHECKED',
  'configuration_value' => '0',
  'configuration_description' => 'Előválasztja a biztosítási beállítások jelölőnégyzetet.',
  'configuration_group_id' => 10, 
  'sort_order' => 16,
  'date_added' => $today,
  'set_function' => 'cfg_keyed_select_option(array(0 =>\'nincs kiválasztva\', 1=> \'kiválasztva\'),');

$config_data[] = array(
  'configuration_title' => 'Alapértelmezett csomag biztosítási érték',
  'configuration_key' => 'SHIPPING_DEFAULT_INSURANCE_VALUE',
  'configuration_value' => '100.00',
  'configuration_description' => 'Specifies the default monetary value (based onthe currency used) to add for insurance. This value will be typically over-ridden by the calling application with the sales/purchase value when the shipping estimator is invoked.',
  'configuration_group_id' => 10, 
  'sort_order' => 18,
  'date_added' => $today);

$config_data[] = array(
  'configuration_title' => 'Nagy csomag szétbontása jelölőnégyzet megjelenítése',
  'configuration_key' => 'SHIPPING_DEFAULT_SPLIT_LARGE_SHIPMENTS_SHOW',
  'configuration_value' => '1',
  'configuration_description' => 'Nagy csomag szétbontása jelölőnégyzet megjelenítése, a nagy tömegű csomagok kisebbekre való bontásának engedélyezéséhez, a könnyebb szállíthatóság miatt.',
  'configuration_group_id' => 10, 
  'sort_order' => 20,
  'date_added' => $today,
  'set_function' => 'cfg_keyed_select_option(array(0 =>\'elrejt\', 1=> \'megjelenít\'),');

$config_data[] = array(
  'configuration_title' => 'Előválasztja a nagy csomag szétbontása jelölőnégyzetet',
  'configuration_key' => 'SHIPPING_DEFAULT_SPLIT_LARGE_SHIPMENTS_CHECKED',
  'configuration_value' => '1',
  'configuration_description' => 'Előválasztja a nagy csomag jelölőnégyzetet. Ez a tulajdonság szétszedi a nagy csomagot kisebbekre (felhasználó által választható tömeg szerint), hogy kis csomagszállítók is tudják szállítani, mint pl.. UPS, FedEx, DHL, stb.',
  'configuration_group_id' => 10, 
  'sort_order' => 22,
  'date_added' => $today,
  'set_function' => 'cfg_keyed_select_option(array(0 =>\'nincs kiválasztva\', 1=> \'kiválasztva\'),');

$config_data[] = array(
  'configuration_title' => 'Nagy szállítmányok kisebbekre bontása tömeg szerint',
  'configuration_key' => 'SHIPPING_DEFAULT_SPLIT_LARGE_SHIPMENTS_VALUE',
  'configuration_value' => '75',
  'configuration_description' => 'Alapértelmezett tömeg, amely meghaladása esetén a szállítmányt kisebb csomagokra kell bontani.',
  'configuration_group_id' => 10, 
  'sort_order' => 24,
  'date_added' => $today);

$config_data[] = array(
  'configuration_title' => 'Szállítás megerősítése jelölőnégyzet megjelenítése',
  'configuration_key' => 'SHIPPING_DEFAULT_DELIVERY_COMFIRMATION_SHOW',
  'configuration_value' => '1',
  'configuration_description' => 'Szállítás megerősítése jelölőnégyzet megjelenítése',
  'configuration_group_id' => 10, 
  'sort_order' => 26,
  'date_added' => $today,
  'set_function' => 'cfg_keyed_select_option(array(0 =>\'elrejt\', 1=> \'megjelenít\'),');

$config_data[] = array(
  'configuration_title' => 'Előválasztja a szállítás megerősítése jelölőnégyzetet.',
  'configuration_key' => 'SHIPPING_DEFAULT_DELIVERY_COMFIRMATION_CHECKED',
  'configuration_value' => '0',
  'configuration_description' => 'Előválasztja a szállítás megerősítése jelölőnégyzetet. Érvényes értékek:<br>0 - Nincs kiválasztva<br>1 - Kiválasztva',
  'configuration_group_id' => 10, 
  'sort_order' => 28,
  'date_added' => $today,
  'set_function' => 'cfg_keyed_select_option(array(0 =>\'nincs kiválasztva\', 1=> \'kiválasztva\'),');

$config_data[] = array(
  'configuration_title' => 'Szállítás megerősítése szükséges?.',
  'configuration_key' => 'SHIPPING_DEFAULT_DELIVERY_COMFIRMATION_TYPE',
  'configuration_value' => '2',
  'configuration_description' => 'Alapértelmezettként a csomag átvételénél aláírás szükséges?',
  'configuration_group_id' => 10, 
  'sort_order' => 30,
  'date_added' => $today,
  'set_function' => 'html_pull_down_menu(\'configuration_value\', gen_build_pull_down($shipping_defaults[\'delivery_confirmation\']),');

$config_data[] = array(
  'configuration_title' => 'Kezelési költség jelölőnégyzet megjelenítése',
  'configuration_key' => 'SHIPPING_DEFAULT_HANDLING_CHARGE_SHOW',
  'configuration_value' => '1',
  'configuration_description' => 'Kezelési költség jelölőnégyzet megjelenítése.',
  'configuration_group_id' => 10, 
  'sort_order' => 32,
  'date_added' => $today,
  'set_function' => 'cfg_keyed_select_option(array(0 =>\'elrejt\', 1=> \'megjelenít\'),');

$config_data[] = array(
  'configuration_title' => 'Utánvétes szállítás beállításai',
  'configuration_key' => 'SHIPPING_DEFAULT_COD_SHOW',
  'configuration_value' => '1',
  'configuration_description' => 'Utánvétes fizetés jelölőnégyzet és beállításai engedélyezése',
  'configuration_group_id' => 10, 
  'sort_order' => 38,
  'date_added' => $today,
  'set_function' => 'cfg_keyed_select_option(array(0 =>\'elrejt\', 1=> \'megjelenít\'),');

$config_data[] = array(
  'configuration_title' => 'Utánvétes fizetés jelölőnégyzet előválasztása',
  'configuration_key' => 'SHIPPING_DEFAULT_COD_CHECKED',
  'configuration_value' => '0',
  'configuration_description' => 'Utánvétes fizetés jelölőnégyzet előválasztása',
  'configuration_group_id' => 10, 
  'sort_order' => 40,
  'date_added' => $today,
  'set_function' => 'cfg_keyed_select_option(array(0 =>\'nincs kiválasztva\', 1=> \'kiválasztva\'),');

$config_data[] = array(
  'configuration_title' => 'Alapértelmezett fizetési típus',
  'configuration_key' => 'SHIPPING_DEFAULT_PAYMENT_TYPE',
  'configuration_value' => '1',
  'configuration_description' => 'Alapértelmezettként elfogadott fizetési típus',
  'configuration_group_id' => 10, 
  'sort_order' => 42,
  'date_added' => $today,
  'set_function' => 'html_pull_down_menu(\'configuration_value\', gen_build_pull_down($shipping_defaults[\'cod_funds_code\']),');

$config_data[] = array(
  'configuration_title' => 'Show Saturday pickup checkbox',
  'configuration_key' => 'SHIPPING_DEFAULT_SATURDAY_PICKUP_SHOW',
  'configuration_value' => '1',
  'configuration_description' => 'Show the checkbox for Saturday pickup',
  'configuration_group_id' => 10, 
  'sort_order' => 44,
  'date_added' => $today,
  'set_function' => 'cfg_keyed_select_option(array(0 =>\'elrejt\', 1=> \'megjelenít\'),');

$config_data[] = array(
  'configuration_title' => 'Pre-select the Saturday pickup checkbox',
  'configuration_key' => 'SHIPPING_DEFAULT_SATURDAY_PICKUP_CHECKED',
  'configuration_value' => '0',
  'configuration_description' => 'Pre-select the Saturday pickup checkbox',
  'configuration_group_id' => 10, 
  'sort_order' => 46,
  'date_added' => $today,
  'set_function' => 'cfg_keyed_select_option(array(0 =>\'nincs kiválasztva\', 1=> \'kiválasztva\'),');

$config_data[] = array(
  'configuration_title' => 'Vasárnapi kiszállítás jelölőnégyzet megjelenítése',
  'configuration_key' => 'SHIPPING_DEFAULT_SATURDAY_DELIVERY_SHOW',
  'configuration_value' => '1',
  'configuration_description' => 'Vasárnapi kiszállítás jelölőnégyzet megjelenítése',
  'configuration_group_id' => 10, 
  'sort_order' => 48,
  'date_added' => $today,
  'set_function' => 'cfg_keyed_select_option(array(0 =>\'elrejt\', 1=> \'megjelenít\'),');

$config_data[] = array(
  'configuration_title' => 'Előválasztja a vasárnapi kiszállítás jelölőnégyzetet',
  'configuration_key' => 'SHIPPING_DEFAULT_SATURDAY_DELIVERY_CHECKED',
  'configuration_value' => '0',
  'configuration_description' => 'Előválasztja a vasárnapi kiszállítás jelölőnégyzetet',
  'configuration_group_id' => 10, 
  'sort_order' => 50,
  'date_added' => $today,
  'set_function' => 'cfg_keyed_select_option(array(0 =>\'nincs kiválasztva\', 1=> \'kiválasztva\'),');

$config_data[] = array(
  'configuration_title' => 'Veszélyes anyag jelölőnégyzet megjelenítése',
  'configuration_key' => 'SHIPPING_DEFAULT_HAZARDOUS_SHOW',
  'configuration_value' => '1',
  'configuration_description' => 'Veszélyes anyag jelölőnégyzet megjelenítése',
  'configuration_group_id' => 10, 
  'sort_order' => 52,
  'date_added' => $today,
  'set_function' => 'cfg_keyed_select_option(array(0 =>\'elrejt\', 1=> \'megjelenít\'),');

$config_data[] = array(
  'configuration_title' => 'Előválasztja a veszélyes anyag jelölőnégyzetet',
  'configuration_key' => 'SHIPPING_DEFAULT_HAZARDOUS_MATERIAL_CHECKED',
  'configuration_value' => '0',
  'configuration_description' => 'Előválasztja a veszélyes anyag jelölőnégyzetet',
  'configuration_group_id' => 10, 
  'sort_order' => 54,
  'date_added' => $today,
  'set_function' => 'cfg_keyed_select_option(array(0 =>\'nincs kiválasztva\', 1=> \'kiválasztva\'),');

$config_data[] = array(
  'configuration_title' => 'Szárazjég jelölőnégyzet megjelenítése',
  'configuration_key' => 'SHIPPING_DEFAULT_DRY_ICE_SHOW',
  'configuration_value' => '1',
  'configuration_description' => 'Szárazjég jelölőnégyzet megjelenítése',
  'configuration_group_id' => 10, 
  'sort_order' => 56,
  'date_added' => $today,
  'set_function' => 'cfg_keyed_select_option(array(0 =>\'elrejt\', 1=> \'megjelenít\'),');

$config_data[] = array(
  'configuration_title' => 'Előválasztja a szárazjég jelölőnégyzetet',
  'configuration_key' => 'SHIPPING_DEFAULT_DRY_ICE_CHECKED',
  'configuration_value' => '0',
  'configuration_description' => 'Előválasztja a szárazjég jelölőnégyzetet',
  'configuration_group_id' => 10, 
  'sort_order' => 58,
  'date_added' => $today,
  'set_function' => 'cfg_keyed_select_option(array(0 =>\'nincs kiválasztva\', 1=> \'kiválasztva\'),');

$config_data[] = array(
  'configuration_title' => 'Show return services checkbox',
  'configuration_key' => 'SHIPPING_DEFAULT_RETURN_SERVICE_SHOW',
  'configuration_value' => '1',
  'configuration_description' => 'Show return services checkbox',
  'configuration_group_id' => 10, 
  'sort_order' => 60,
  'date_added' => $today,
  'set_function' => 'cfg_keyed_select_option(array(0 =>\'elrejt\', 1=> \'megjelenít\'),');

$config_data[] = array(
  'configuration_title' => 'Pre-selects the return services checkbox',
  'configuration_key' => 'SHIPPING_DEFAULT_RETURN_SERVICE_CHECKED',
  'configuration_value' => '0',
  'configuration_description' => 'Pre-selects the return services checkbox',
  'configuration_group_id' => 10, 
  'sort_order' => 62,
  'date_added' => $today,
  'set_function' => 'cfg_keyed_select_option(array(0 =>\'nincs kiválasztva\', 1=> \'kiválasztva\'),');

$config_data[] = array(
  'configuration_title' => 'Default selection for return services (call tags)',
  'configuration_key' => 'SHIPPING_DEFAULT_RETURN_SERVICE',
  'configuration_value' => '2',
  'configuration_description' => 'Select the default to use if the return services checkbos is selected.',
  'configuration_group_id' => 10, 
  'sort_order' => 64,
  'date_added' => $today,
  'set_function' => 'html_pull_down_menu(\'configuration_value\', gen_build_pull_down($shipping_defaults[\'return_label\']),');

$config_data[] = array(
  'configuration_title' => 'Előválasztja a kezelési költséget szállításnál',
  'configuration_key' => 'SHIPPING_DEFAULT_HANDLING_CHARGE_CHECKED',
  'configuration_value' => '0',
  'configuration_description' => 'Előválasztja a kezelési költséget szállításnál.',
  'configuration_group_id' => 10, 
  'sort_order' => 34,
  'date_added' => $today,
  'set_function' => 'cfg_keyed_select_option(array(0 =>\'nincs kiválasztva\', 1=> \'kiválasztva\'),');

$config_data[] = array(
  'configuration_title' => 'Alapértelmezett szállítási kezelési költség',
  'configuration_key' => 'SHIPPING_DEFAULT_HANDLING_CHARGE_VALUE',
  'configuration_value' => '0.00',
  'configuration_description' => 'Sets the default handling charge for a shipment based on the currency unit of measure ',
  'configuration_group_id' => 10, 
  'sort_order' => 36,
  'date_added' => $today);

/************************** Group ID 11 (Address Book Defaults) ***********************************************/

/************************** Group ID 12 (E-mail Settings) ***********************************************/
$config_data[] = array(
  'configuration_title' => 'E-mail küldés módja',
  'configuration_key' => 'EMAIL_TRANSPORT',
  'configuration_value' => 'PHP',
  'configuration_description' => 'E-mail küldés módját definiálja.<br /><strong>PHP</strong> az alapértelmezett, és beépített PHP csomagolókat használ a feldolgozás során.<br />Windows és MacOS szerverek esetén <strong>SMTP</strong> az ajánlott.<br /><br /><strong>SMTPAUTH</strong> használata csak akkor szükséges, ha a kiszolgáló SMTP hitelesítést igényel levélküldéshez. Ekkor az SMTPAUTH beállítások megfelelő mezőit is szerkesztened kell az admin felületen.<br /><br /><strong>sendmail</strong> egy levélküldő linux/unix kiszolgálokra.<br /><strong>"sendmail-f"</strong> kapcsoló csak azokon a szervereken szükséges, amelyek levélküldéshez igénylik. Ez egy gyakran használt biztonsági beállítás hamis e-mail küldésének megelőzésére. Hibát fog okozni, ha a kiszolgáló nincs beállítva a használatára.<br /><br /><strong>Qmail</strong> linux/unix kiszolgálókon használatos levélküldő. A Qmail egy csomagoló segítségével fut, amely elérése alapértelmezettként: /var/qmail/bin/sendmail.',
  'configuration_group_id' => 12, 
  'sort_order' => 1,
  'date_added' => $today,
  'set_function' => 'cfg_select_option(array(\'PHP\', \'sendmail\', \'sendmail-f\', \'smtp\', \'smtpauth\', \'Qmail\'),');

$config_data[] = array(
  'configuration_title' => 'E-mail soremelés',
  'configuration_key' => 'EMAIL_LINEFEED',
  'configuration_value' => 'LF',
  'configuration_description' => 'Sor végi elválasztókarakter megadása.',
  'configuration_group_id' => 12, 
  'sort_order' => 2,
  'date_added' => $today,
  'set_function' => 'cfg_select_option(array(\'LF\', \'CRLF\'),');

$config_data[] = array(
  'configuration_title' => 'E-mailek küldése',
  'configuration_key' => 'SEND_EMAILS',
  'configuration_value' => 'true',
  'configuration_description' => 'E-mail küldés engedélyezése',
  'configuration_group_id' => 12, 
  'sort_order' => 3,
  'date_added' => $today,
  'set_function' => 'cfg_select_option(array(\'igen\', \'nem\'), ');

$config_data[] = array(
  'configuration_title' => 'MIME HTML használata e-mail küldésnél',
  'configuration_key' => 'EMAIL_USE_HTML',
  'configuration_value' => 'false',
  'configuration_description' => 'E-mailek küldése HTML formátumban',
  'configuration_group_id' => 12, 
  'sort_order' => 4,
  'date_added' => $today,
  'set_function' => 'cfg_select_option(array(\'igen\', \'nem\'),');

$config_data[] = array(
  'configuration_title' => 'E-mail címek ellenőrzése DNS-en keresztül',
  'configuration_key' => 'ENTRY_EMAIL_ADDRESS_CHECK',
  'configuration_value' => 'false',
  'configuration_description' => 'E-mail cím ellenőrzése DNS-szerver segítségével',
  'configuration_group_id' => 12, 
  'sort_order' => 5,
  'date_added' => $today,
  'set_function' => 'cfg_select_option(array(\'igen\', \'nem\'), ');

$config_data[] = array(
  'configuration_title' => 'E-mail archiválás aktív?',
  'configuration_key' => 'EMAIL_ARCHIVE',
  'configuration_value' => 'false',
  'configuration_description' => 'Ha szeretnéd, hogy az elküldött levelek archiválva legyenek, állítsd igenre.',
  'configuration_group_id' => 12, 
  'sort_order' => 6,
  'date_added' => $today,
  'set_function' => 'cfg_select_option(array(\'igen\', \'nem\'),');

$config_data[] = array(
  'configuration_title' => 'E-mail felhasználóbarát hibák',
  'configuration_key' => 'EMAIL_FRIENDLY_ERRORS',
  'configuration_value' => 'false',
  'configuration_description' => 'Felhasználóbarát hibaüzenetek használata e-mail hiba esetén?  "Nem" esetén PHP hibaüzeneteket kap a felhasználó és lehetséges, hogy a szkript futásában is hibát okoz. Csak hibakeresés idejére ajánlott tiltani, éles rendszeren pedig ajánlott az engedélyezése.',
  'configuration_group_id' => 12, 
  'sort_order' => 7,
  'date_added' => $today,
  'set_function' => 'cfg_select_option(array(\'igen\', \'nem\'),');

$config_data[] = array(
  'configuration_title' => 'E-mail címek (Displayed to Contact you)',
  'configuration_key' => 'STORE_OWNER_EMAIL_ADDRESS',
  'configuration_value' => '',
  'configuration_description' => 'Áruház tulajdonosának e-mail címe.  Csak információközlés a kapcsolat felvételének módjáról.',
  'configuration_group_id' => 12, 
  'sort_order' => 10,
  'date_added' => $today);

$config_data[] = array(
  'configuration_title' => 'E-mail címek (feladó)',
  'configuration_key' => 'EMAIL_FROM',
  'configuration_value' => '',
  'configuration_description' => 'Alapértelmezett e-mail feladó. Levélírásnál más is megadható az admin modulokban.',
  'configuration_group_id' => 12, 
  'sort_order' => 11,
  'date_added' => $today);

$config_data[] = array(
  'configuration_title' => 'E-mail küldése csak ismert domainről?',
  'configuration_key' => 'EMAIL_SEND_MUST_BE_STORE',
  'configuration_value' => 'No',
  'configuration_description' => 'Does your mailserver require that all outgoing emails have their "from" address match a known domain that exists on your webserver?<br /><br />This is often set in order to prevent spoofing and spam broadcasts.  Igenre állítva, this will cause the email address (FELADÓ) to be used as the "from" address on all outgoing mail.',
  'configuration_group_id' => 12, 
  'sort_order' => 12,
  'date_added' => $today,
  'set_function' => 'cfg_select_option(array(\'Nem\', \'Igen\'), ');

$config_data[] = array(
  'configuration_title' => 'E-mail admin formátum?',
  'configuration_key' => 'ADMIN_EXTRA_EMAIL_FORMAT',
  'configuration_value' => 'TEXT',
  'configuration_description' => 'Válaszd ki a rendszergazda e-mail formátumát',
  'configuration_group_id' => 12, 
  'sort_order' => 15,
  'date_added' => $today,
  'set_function' => 'cfg_select_option(array(\'TEXT\', \'HTML\'), ');

$config_data[] = array(
  'configuration_title' => '"Kapcsolat" legördülő menü',
  'configuration_key' => 'CONTACT_US_LIST',
  'configuration_value' => '',
  'configuration_description' => 'A "Kapcsolat" oldalon megadja a legördülő menüből választható e-mail címeket a következő formátumban: Név 1 &lt;email@cim1&gt;, Név 2 &lt;email@cim2&gt;',
  'configuration_group_id' => 12, 
  'sort_order' => 40,
  'date_added' => $today,
  'set_function' => 'cfg_textarea(');

$config_data[] = array(
  'configuration_title' => 'Kapcsolat - Áruház nevének és címének megjelenítése',
  'configuration_key' => 'CONTACT_US_STORE_NAME_ADDRESS',
  'configuration_value' => '1',
  'configuration_description' => 'Include Store Name and Address<br />0= ki 1= be',
  'configuration_group_id' => 12, 
  'sort_order' => 50,
  'date_added' => $today,
  'set_function' => 'cfg_select_option(array(\'0\', \'1\'), ');

$config_data[] = array(
  'configuration_title' => 'SMTP e-mail fiók Mailbox',
  'configuration_key' => 'EMAIL_SMTPAUTH_MAILBOX',
  'configuration_value' => '',
  'configuration_description' => 'Add meg a szolgáltatód által biztosított levelezési fiók nevét (en@sajatdomain.hu). Ezt a fiók nevet kéri a kiszolgáló SMTP hitelesítésnél.<br />Csak akkor szükséges, ha SMTP hitelesítés szükséges a levelezéshez.',
  'configuration_group_id' => 12, 
  'sort_order' => 100,
  'date_added' => $today);

$config_data[] = array(
  'configuration_title' => 'SMTP e-mail fiók jelszó',
  'configuration_key' => 'EMAIL_SMTPAUTH_PASSWORD',
  'configuration_value' => '',
  'configuration_description' => 'Add meg a jelszavad az SMTP fiókhoz. <br />Csak akkor szükséges, ha SMTP hitelesítés szükséges a levelezéshez.',
  'configuration_group_id' => 12, 
  'sort_order' => 101,
  'date_added' => $today);

$config_data[] = array(
  'configuration_title' => 'SMTP e-mail kiszolgáló',
  'configuration_key' => 'EMAIL_SMTPAUTH_MAIL_SERVER',
  'configuration_value' => '',
  'configuration_description' => 'Add meg SMTP kiszolgálód nevét vagy IP-címét.<br />pl.: mail.sajatdomain.hu<br />vagy 55.66.77.88<br />Csak akkor szükséges, ha SMTP hitelesítés szükséges a levelezéshez.',
  'configuration_group_id' => 12, 
  'sort_order' => 102,
  'date_added' => $today);

$config_data[] = array(
  'configuration_title' => 'SMTP e-mail kiszolgáló port',
  'configuration_key' => 'EMAIL_SMTPAUTH_MAIL_SERVER_PORT',
  'configuration_value' => '25',
  'configuration_description' => 'Add meg melyik porton üzemel az SMTP kiszolgálód.<br />Csak akkor szükséges, ha SMTP hitelesítés szükséges a levelezéshez.',
  'configuration_group_id' => 12, 
  'sort_order' => 103,
  'date_added' => $today);

$config_data[] = array(
  'configuration_title' => 'Pénznemek konvertálása szöveges e-mailek esetén',
  'configuration_key' => 'CURRENCIES_TRANSLATIONS',
  'configuration_value' => '&pound;,Ł:&euro;,€',
  'configuration_description' => 'Milyen pénznem konvertálásra van szükséged a szöveges e-mailekhez?<br />Default = &amp;pound;,Ł:&amp;euro;,€',
  'configuration_group_id' => 12, 
  'sort_order' => 120,
  'date_added' => $today,
  'set_function' => 'cfg_textarea_small(');

/************************** Group ID 15 (Sessions Settings) ***********************************************/
$config_data[] = array(
  'configuration_title' => 'Session időtúllépés másodpercben',
  'configuration_key' => 'SESSION_TIMEOUT_ADMIN',
  'configuration_value' => '3600',
  'configuration_description' => 'Add meg az időt másodpercben. Alapértelmezett=3600<br />Például: 3600= 1 óra<br /><br />Megjegyzés: Ha túl kicsi értéket adsz meg, az időtúllépéshez vezethet termékek felvételénél/szerkesztésénél',
  'configuration_group_id' => 15, 
  'sort_order' => 1,
  'date_added' => $today);

/************************** Group ID 17 (Credit Card Settings) ***********************************************/
$config_data[] = array(
  'configuration_title' => 'Hitelkártya tulajdonos nevének minimum hossza',
  'configuration_key' => 'CC_OWNER_MIN_LENGTH',
  'configuration_value' => '4',
  'configuration_description' => 'Add meg a hitelkártya tulajdonos nevének minimum hosszát.',
  'configuration_group_id' => 17, 
  'sort_order' => 1,
  'date_added' => $today);

$config_data[] = array(
  'configuration_title' => 'Hitelkártya számának minimum hossza',
  'configuration_key' => 'CC_NUMBER_MIN_LENGTH',
  'configuration_value' => '15',
  'configuration_description' => 'Add meg a hitelkártya számának minimum hosszát.',
  'configuration_group_id' => 17, 
  'sort_order' => 2,
  'date_added' => $today);

$config_data[] = array(
  'configuration_title' => 'Visa hitelkártyák engedélyezése',
  'configuration_key' => 'CC_ENABLED_VISA',
  'configuration_value' => '1',
  'configuration_description' => 'Visa hitelkártyák engedélyezése.',
  'configuration_group_id' => 17, 
  'sort_order' => 3,
  'date_added' => $today,
  'set_function' => 'cfg_keyed_select_option(array(0 =>\'Nem\', 1=> \'Igen\'),');

$config_data[] = array(
  'configuration_title' => 'Master Card hitelkártyák engedélyezése',
  'configuration_key' => 'CC_ENABLED_MC',
  'configuration_value' => '1',
  'configuration_description' => 'Master Card hitelkártyák engedélyezése.',
  'configuration_group_id' => 17, 
  'sort_order' => 4,
  'date_added' => $today,
  'set_function' => 'cfg_keyed_select_option(array(0 =>\'Nem\', 1=> \'Igen\'),');

$config_data[] = array(
  'configuration_title' => 'American Express hitelkártyák engedélyezése',
  'configuration_key' => 'CC_ENABLED_AMEX',
  'configuration_value' => '0',
  'configuration_description' => 'American Express hitelkártyák engedélyezése.',
  'configuration_group_id' => 17, 
  'sort_order' => 5,
  'date_added' => $today,
  'set_function' => 'cfg_keyed_select_option(array(0 =>\'Nem\', 1=> \'Igen\'),');

$config_data[] = array(
  'configuration_title' => 'Discover hitelkártyák engedélyezése',
  'configuration_key' => 'CC_ENABLED_DISCOVER',
  'configuration_value' => '0',
  'configuration_description' => 'Discover hitelkártyák engedélyezése.',
  'configuration_group_id' => 17, 
  'sort_order' => 6,
  'date_added' => $today,
  'set_function' => 'cfg_keyed_select_option(array(0 =>\'Nem\', 1=> \'Igen\'),');

$config_data[] = array(
  'configuration_title' => 'Diners Club hitelkártyák engedélyezése',
  'configuration_key' => 'CC_ENABLED_DINERS_CLUB',
  'configuration_value' => '0',
  'configuration_description' => 'Diners Club hitelkártyák engedélyezése.',
  'configuration_group_id' => 17, 
  'sort_order' => 7,
  'date_added' => $today,
  'set_function' => 'cfg_keyed_select_option(array(0 =>\'Nem\', 1=> \'Igen\'),');

$config_data[] = array(
  'configuration_title' => 'JCB hitelkártyák engedélyezése',
  'configuration_key' => 'CC_ENABLED_JCB',
  'configuration_value' => '0',
  'configuration_description' => 'JCB hitelkártyák engedélyezése.',
  'configuration_group_id' => 17, 
  'sort_order' => 8,
  'date_added' => $today,
  'set_function' => 'cfg_keyed_select_option(array(0 =>\'Nem\', 1=> \'Igen\'),');

$config_data[] = array(
  'configuration_title' => 'Australian Bankcard engedélyezése',
  'configuration_key' => 'CC_ENABLED_AUSTRALIAN_BANKCARD',
  'configuration_value' => '0',
  'configuration_description' => 'Australian Bankcard engedélyezése.',
  'configuration_group_id' => 17, 
  'sort_order' => 9,
  'date_added' => $today,
  'set_function' => 'cfg_keyed_select_option(array(0 =>\'Nem\', 1=> \'Igen\'),');

/************************** Group ID 19 (Layout Settings) ***********************************************/

/************************** Group ID 20 (Website Maintenence) ***********************************************/

/************************** Group ID 99 (Alternate (non-displayed Settings) *********************************/
$config_data[] = array(
  'configuration_title' => 'Alapértelmezett pénznem',
  'configuration_key' => 'DEFAULT_CURRENCY',
  'configuration_value' => 'USD',
  'configuration_description' => 'Alapértelmezett pénznem (ISO kód)',
  'configuration_group_id' => 99, 
  'sort_order' => 1,
  'date_added' => $today);

$config_data[] = array(
  'configuration_title' => 'Alapértelmezett nyelv',
  'configuration_key' => 'DEFAULT_LANGUAGE',
  'configuration_value' => 'en',
  'configuration_description' => 'Alapértelmezett nyelv',
  'configuration_group_id' => 99, 
  'sort_order' => 2,
  'date_added' => $today);

?>
