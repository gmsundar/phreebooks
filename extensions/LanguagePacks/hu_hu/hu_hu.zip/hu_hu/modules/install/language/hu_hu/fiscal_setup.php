<?php
// +-----------------------------------------------------------------+
// |                   PhreeBooks Open Source ERP                    |
// +-----------------------------------------------------------------+
// | Copyright (c) 2007 PhreeSoft, LLC                               |
// | http://www.PhreeSoft.com                                        |
// +-----------------------------------------------------------------+
// | This program is free software: you can redistribute it and/or   |
// | modify it under the terms of the GNU General Public License as  |
// | published by the Free Software Foundation, either version 3 of  |
// | the License, or any later version.                              |
// |                                                                 |
// | This program is distributed in the hope that it will be useful, |
// | but WITHOUT ANY WARRANTY; without even the implied warranty of  |
// | MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the   |
// | GNU General Public License for more details.                    |
// |                                                                 |
// | The license that is bundled with this package is located in the |
// | file: /doc/manual/ch01-Introduction/license.html.               |
// | If not, see http://www.gnu.org/licenses/                        |
// +-----------------------------------------------------------------+
//  Path: /modules/install/includes/languages/hu_hu/fiscal_setup.php
//
// +---------------------------------------+
// | Hungarian translation/Magyar fordítás |
// +---------------------------------------+
// | Hungarian translation: Zsolt Győri    |
// | Hungarian bookkeeping: Tímea Tiszai   |
// | E-mail: gyori.zsolt@gmail.com         |
// | If you have any questions or comment  |
// | do not hesitate to contact us!        |
// +---------------------------------------+
// | Magyar fordítás: Győri Zsolt          |
// | Magyar könyvelés: Tiszai Tímea        |
// | E-mail: gyori.zsolt@gmail.com         |
// | Ha bármi kérdésed vagy észrevételed   |
// | van, ne habozz írni!                  |
// +---------------------------------------+

  define('SAVE_STORE_SETTINGS', 'Pénzügyi év beállításainak mentése'); //this comes before TEXT_MAIN
  define('SKIP_STORE_SETTINGS', 'Fiscal Year Exists - Skip'); //this comes before TEXT_MAIN
  define('TEXT_MAIN', "This section of the PhreeBooks&trade; setup tool will help you set up your company's fiscal year. You will be able to change any of these settings later using the General Ledger menu.  Please make your selections and press <em>".SAVE_STORE_SETTINGS."</em> to continue. If a fiscal year already exists in the db, the button <em>".SKIP_STORE_SETTINGS."</em> will appear instead. Press this button to bypass this step.");
  define('TEXT_FISCAL_YEAR_EXISTS','Fiscal years from <b>%d</b> to <b>%d</b> are already in the database, Please press <em>' . SKIP_STORE_SETTINGS . '</em> to continue.');
  define('TEXT_PAGE_HEADING', 'PhreeBooks&trade; Telepítő - Pénzügyi év beállítása');
  define('STORE_INFORMATION', 'Pénzügyi év adatai');

  define('STORE_DEFAULT_PERIOD', 'First Accounting Period');
  define('STORE_DEFAULT_PERIOD_INSTRUCTION', 'Select a starting month to set as your first accounting period. PhreeBooks will initially set the start at the first day of the selected month as period 1.');

  define('STORE_DEFAULT_FY', 'Pénzügyi év');
  define('STORE_DEFAULT_FY_INSTRUCTION', 'Select a starting year to set as your first fiscal year. The month selected above and this year selection will be the earliest date that journal entries can be made.');

  $period_values = array();
  $period_values[] = array('id' => '01', 'text' => 'Január');
  $period_values[] = array('id' => '02', 'text' => 'Február');
  $period_values[] = array('id' => '03', 'text' => 'Március');
  $period_values[] = array('id' => '04', 'text' => 'Április');
  $period_values[] = array('id' => '05', 'text' => 'Május');
  $period_values[] = array('id' => '06', 'text' => 'Június');
  $period_values[] = array('id' => '07', 'text' => 'Július');
  $period_values[] = array('id' => '08', 'text' => 'Augusztus');
  $period_values[] = array('id' => '09', 'text' => 'Szeptember');
  $period_values[] = array('id' => '10', 'text' => 'Október');
  $period_values[] = array('id' => '11', 'text' => 'November');
  $period_values[] = array('id' => '12', 'text' => 'December');

  $fiscal_years = array();
  $fiscal_years[] = array('id' => '2005', 'text' => '2005');
  $fiscal_years[] = array('id' => '2006', 'text' => '2006');
  $fiscal_years[] = array('id' => '2007', 'text' => '2007');
  $fiscal_years[] = array('id' => '2008', 'text' => '2008');
  $fiscal_years[] = array('id' => '2009', 'text' => '2009');
  $fiscal_years[] = array('id' => '2010', 'text' => '2010');
  $fiscal_years[] = array('id' => '2011', 'text' => '2011');
  $fiscal_years[] = array('id' => '2012', 'text' => '2012');
?>
