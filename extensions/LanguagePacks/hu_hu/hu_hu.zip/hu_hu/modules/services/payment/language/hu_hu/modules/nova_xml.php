<?php
// +-----------------------------------------------------------------+
// |                   PhreeBooks Open Source ERP                    |
// +-----------------------------------------------------------------+
// | Copyright (c) 2007 PhreeSoft, LLC                               |
// | http://www.PhreeSoft.com                                        |
// +-----------------------------------------------------------------+
// | This program is free software: you can redistribute it and/or   |
// | modify it under the terms of the GNU General Public License as  |
// | published by the Free Software Foundation, either version 3 of  |
// | the License, or any later version.                              |
// |                                                                 |
// | This program is distributed in the hope that it will be useful, |
// | but WITHOUT ANY WARRANTY; without even the implied warranty of  |
// | MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the   |
// | GNU General Public License for more details.                    |
// |                                                                 |
// | The license that is bundled with this package is located in the |
// | file: /doc/manual/ch01-Introduction/license.html.               |
// | If not, see http://www.gnu.org/licenses/                        |
// +-----------------------------------------------------------------+
//  Path: /modules/services/payment/language/hu_hu/modules/nova_xml.php
//
// +---------------------------------------+
// | Hungarian translation/Magyar fordítás |
// +---------------------------------------+
// | Hungarian translation: Zsolt Győri    |
// | Hungarian bookkeeping: Tímea Tiszai   |
// | E-mail: gyori.zsolt@gmail.com         |
// | If you have any questions or comment  |
// | do not hesitate to contact us!        |
// +---------------------------------------+
// | Magyar fordítás: Győri Zsolt          |
// | Magyar könyvelés: Tiszai Tímea        |
// | E-mail: gyori.zsolt@gmail.com         |
// | Ha bármi kérdésed vagy észrevételed   |
// | van, ne habozz írni!                  |
// +---------------------------------------+

// Admin Configuration Items
  define('MODULE_PAYMENT_NOVA_XML_TEXT_TITLE', 'Nova (Virtuális kereskedő)'); // Payment option title as displayed in the admin
  define('MODULE_PAYMENT_NOVA_XML_TEXT_DESCRIPTION', 'Teszt módban a kártyák sikeres kódot adnak vissza, de nem lesznek feldolgozva<br /><br />');

// Catalog Items
  define('MODULE_PAYMENT_NOVA_XML_TEXT_CATALOG_TITLE', 'Hitelkártya');  // Payment option title as displayed to the customer
  define('MODULE_PAYMENT_NOVA_XML_TEXT_CREDIT_CARD_TYPE', 'Hitelkártya típusa:');
  define('MODULE_PAYMENT_NOVA_XML_TEXT_CREDIT_CARD_OWNER', 'Hitelkártya tulajdonosa:');
  define('MODULE_PAYMENT_NOVA_XML_TEXT_CREDIT_CARD_NUMBER', 'Hitelkártya száma:');
  define('MODULE_PAYMENT_NOVA_XML_TEXT_CREDIT_CARD_EXPIRES', 'Hitelkártya lejárata:');
  define('MODULE_PAYMENT_NOVA_XML_TEXT_CVV', 'CVV Number (<a href="javascript:popupWindow(\'' . html_href_link(FILENAME_POPUP_CVV_HELP) . '\')">' . 'Több infó' . '</a>)');
  define('MODULE_PAYMENT_NOVA_XML_TEXT_JS_CC_OWNER', '* A hitelkártya tulajdonosának neve legalább ' . CC_OWNER_MIN_LENGTH . ' karakternek kell lennie.\n');
  define('MODULE_PAYMENT_NOVA_XML_TEXT_JS_CC_NUMBER', '* A hitelkártyaszám hosszának legalább ' . CC_NUMBER_MIN_LENGTH . ' kell lennie.\n');
  define('MODULE_PAYMENT_NOVA_XML_TEXT_JS_CC_CVV', '* A 3 vagy 4 jegyű kártya ellenőrzési érték a hitelkártya hátulján található.\n');
  define('MODULE_PAYMENT_NOVA_XML_TEXT_DECLINED_MESSAGE', 'A hitelkártya tranzakció feldolgozása sikertelen. Ha nincs megadva ok, akkor a kártyát letiltotta a bank.');
  define('MODULE_PAYMENT_NOVA_XML_NO_DUPS','Nem dolgoztam fel a hitelkártyát, mert már feldolgozása már megtörtént. To recharge a credit card, the credit card must be valid and not contain any * characters.');
  define('MODULE_PAYMENT_NOVA_XML_TEXT_ERROR', 'Hitelkártya hiba!');
?>
