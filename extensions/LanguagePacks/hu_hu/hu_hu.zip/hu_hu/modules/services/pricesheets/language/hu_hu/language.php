<?php
// +-----------------------------------------------------------------+
// |                   PhreeBooks Open Source ERP                    |
// +-----------------------------------------------------------------+
// | Copyright (c) 2007 PhreeSoft, LLC                               |
// | http://www.PhreeSoft.com                                        |
// +-----------------------------------------------------------------+
// | This program is free software: you can redistribute it and/or   |
// | modify it under the terms of the GNU General Public License as  |
// | published by the Free Software Foundation, either version 3 of  |
// | the License, or any later version.                              |
// |                                                                 |
// | This program is distributed in the hope that it will be useful, |
// | but WITHOUT ANY WARRANTY; without even the implied warranty of  |
// | MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the   |
// | GNU General Public License for more details.                    |
// |                                                                 |
// | The license that is bundled with this package is located in the |
// | file: /doc/manual/ch01-Introduction/license.html.               |
// | If not, see http://www.gnu.org/licenses/                        |
// +-----------------------------------------------------------------+
//  Path: /modules/services/pricesheets/language/hu_hu/language.php
//
// +---------------------------------------+
// | Hungarian translation/Magyar fordítás |
// +---------------------------------------+
// | Hungarian translation: Zsolt Győri    |
// | Hungarian bookkeeping: Tímea Tiszai   |
// | E-mail: gyori.zsolt@gmail.com         |
// | If you have any questions or comment  |
// | do not hesitate to contact us!        |
// +---------------------------------------+
// | Magyar fordítás: Győri Zsolt          |
// | Magyar könyvelés: Tiszai Tímea        |
// | E-mail: gyori.zsolt@gmail.com         |
// | Ha bármi kérdésed vagy észrevételed   |
// | van, ne habozz írni!                  |
// +---------------------------------------+

define('HEADING_TITLE_MODULES_PRICE_SHEETS','Árlista szolgáltatások');
define('PRICE_SHEET_HEADING_TITLE', 'Árlista kezelő');
define('PRICE_SHEET_NEW_TITLE','Új árlista');
define('PRICE_SHEET_EDIT_TITLE','Árlista szerkesztése - ');

define('PRICE_SHEET_NAME','Árlista neve');
define('TEXT_USE_AS_DEFAULT','Alapértelmezettként');
define('TEXT_PRICE_SHEETS','Árlisták');
define('TEXT_SHEET_NAME','Lista neve');
define('TEXT_REVISE','Új kiadás');
define('TEXT_REVISION','Kiadás szint');
define('TEXT_EFFECTIVE_DATE','Érvényes');
define('TEXT_EXPIRATION_DATE','Lejárat');
define('TEXT_BULK_EDIT','Tétel árazás betöltése');
define('TEXT_SPECIAL_PRICING','Különleges ár');
define('TEXT_BULK_SKU_ENTRY','Árképző');
define('PRICE_SHEET_MSG_DELETE','Biztosan törölni akarod az árlistát?');

// audit log messages
define('PRICE_SHEETS_LOG','Árlista - ');
define('PRICE_SHEETS_LOG_BULK','Árképző - ');

// Error messages
define('SRVCS_DUPLICATE_SHEET_NAME','A név már létezik. Kérlek válassz másik nevet.');
define('JS_ERROR_NO_SHEET_NAME','Add meg az árlista nevét.');
?>
