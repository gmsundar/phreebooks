<?php
// +-----------------------------------------------------------------+
// |                   PhreeBooks Open Source ERP                    |
// +-----------------------------------------------------------------+
// | Copyright (c) 2007 PhreeSoft, LLC                               |
// | http://www.PhreeSoft.com                                        |
// +-----------------------------------------------------------------+
// | This program is free software: you can redistribute it and/or   |
// | modify it under the terms of the GNU General Public License as  |
// | published by the Free Software Foundation, either version 3 of  |
// | the License, or any later version.                              |
// |                                                                 |
// | This program is distributed in the hope that it will be useful, |
// | but WITHOUT ANY WARRANTY; without even the implied warranty of  |
// | MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the   |
// | GNU General Public License for more details.                    |
// |                                                                 |
// | The license that is bundled with this package is located in the |
// | file: /doc/manual/ch01-Introduction/license.html.               |
// | If not, see http://www.gnu.org/licenses/                        |
// +-----------------------------------------------------------------+
//  Path: /modules/banking/language/hu_hu/language.php
//
// +---------------------------------------+
// | Hungarian translation/Magyar fordítás |
// +---------------------------------------+
// | Hungarian translation: Zsolt Győri    |
// | Hungarian bookkeeping: Tímea Tiszai   |
// | E-mail: gyori.zsolt@gmail.com         |
// | If you have any questions or comment  |
// | do not hesitate to contact us!        |
// +---------------------------------------+
// | Magyar fordítás: Győri Zsolt          |
// | Magyar könyvelés: Tiszai Tímea        |
// | E-mail: gyori.zsolt@gmail.com         |
// | Ha bármi kérdésed vagy észrevételed   |
// | van, ne habozz írni!                  |
// +---------------------------------------+

// general
define('BNK_CASH_ACCOUNT','Készpénzszámla');
define('BNK_DISCOUNT_ACCOUNT','Kedvezményszámla');
define('BNK_AMOUNT_DUE','Összeg');
define('BNK_DUE_DATE','Esedékes');
define('BNK_INVOICE_NUM','Számla #');
define('BNK_REPOST_PAYMENT','Az oldalt frissítetted! Ez az előző kifizetést megismételheti!!');
define('TEXT_CCVAL_ERROR_INVALID_DATE', 'A hitelkártya lejárata érvénytelen. Ellenőrizd a dátumot és próbáld újra.');
define('TEXT_CCVAL_ERROR_INVALID_NUMBER', 'A megadott hitelkártyaszám érvénytelen. Ellenőrizd a számot és próbáld újra.');
define('TEXT_CCVAL_ERROR_UNKNOWN_CARD', '%s kezdődő hitelkártyaszám nem helyes, vagy nem fogadjuk el ezt a fajta  kártyát. Próbáld újra vagy használj másik kártyát.');
define('BNK_TEXT_DEPOSIT_ID','Letétjegy azonosító');
define('BNK_TEXT_PAYMENT_ID','Fizetési hivatkozás #');

// Audit Log Messages
define('BNK_LOG_ACCT_RECON','Számlaegyeztetés, időszak: ');

// Cash receipts specific definitions
define('BNK_18_ERROR_NO_VENDOR','Nincs kiválasztott ügyfél!');
define('BNK_18_ENTER_BILLS','Készpénzes elismervény felvitele');
define('BNK_18_DELETE_BILLS','Készpénzes elismervény törlése');
define('BNK_18_C_WINDOW_TITLE','Ügyfél elismervények');
define('BNK_18_V_WINDOW_TITLE','Beszerzői elismervények');
define('BNK_18_BILL_TO','Feladó:');
define('BNK_18_POST_SUCCESSFUL','Sikeresen elküldött elismervény # ');
define('BNK_18_POST_DELETED','Elismervény sikeresen törölve # ');
define('BNK_18_AMOUNT_PAID','Fogadott mennyiség');
define('BNK_18_DELETE_ALERT','Biztosan törölni akarod az elismervényt?');
define('BNK_18_NEGATIVE_TOTAL','Az elismervény mennyisége nem lehet 0-nál kisebb!');

/*
// Point of Sale specific definitions
define('BNK_19_ERROR_NO_VENDOR','Nincs kiválasztott ügyfél!');
define('BNK_19_ENTER_BILLS','Enter Point of Sale Payments');
define('BNK_19_DELETE_BILLS','Delete Point of Sale Receipts');
define('BNK_19_WINDOW_TITLE','Elismervények');
define('BNK_19_BILL_TO','Feladó:');
define('BNK_19_POST_SUCCESSFUL','Successfully posted receipt # ');
define('BNK_19_POST_DELETED','Elismervény sikereset törölve # ');
define('BNK_19_AMOUNT_PAID','Fogadott mennyiség');
define('BNK_19_DELETE_ALERT','Biztosan törölni akarod az elismervényt?');
*/
// Cash Distribution specific definitions
define('BNK_20_ERROR_NO_VENDOR','Nincs kiválasztott forgalmazó!');
define('BNK_20_ENTER_BILLS','Készpénzes fizetés megadása');
define('BNK_20_DELETE_BILLS','Készpénzes fizetés törlése');
define('BNK_20_V_WINDOW_TITLE','Forgalmazó kifizetések');
define('BNK_20_C_WINDOW_TITLE','Ügyfél kifizetések');
define('BNK_20_BILL_TO','Kedvezményezett:');
define('BNK_20_POST_SUCCESSFUL','Sikeresen elküldött kifizetés # ');
define('BNK_20_POST_DELETED','Sikeresen töröld kifizetés száma: # ');
define('BNK_20_AMOUNT_PAID','Kifizetett mennyiség');
define('BNK_20_DELETE_ALERT','Biztosan törölni akarod a kifizetést?');
define('BNK_20_NEGATIVE_TOTAL','A kifizetés összege nem lehet 0-nál kisebb!');
/*
// Point of Purchase (Write Checks) specific definitions
define('BNK_21_ERROR_NO_VENDOR','Nincs kiválasztott forgalmazó!');
define('BNK_21_ENTER_BILLS','Enter Point of Purchase Payment');
define('BNK_21_DELETE_BILLS','Delete Point of Purchase Payment');
define('BNK_21_WINDOW_TITLE','Kifizetések');
define('BNK_21_BILL_TO','Kedvezményezett:');
define('BNK_21_POST_SUCCESSFUL','Successfully posted payment # ');
define('BNK_21_POST_DELETED','Sikeresen törölt kifizetés # ');
define('BNK_21_AMOUNT_PAID','Kifizetett mennyiség');
define('BNK_21_DELETE_ALERT','Biztos törölni akarod a kifizetést?');
*/
// account reconciliation
define('BANKING_HEADING_RECONCILIATION','Számlaegyeztetés');
define('BNK_START_BALANCE','Zárómérleg kimutatás');
define('BNK_OPEN_CHECKS','- Beváltatlan csekkek');
define('BNK_OPEN_DEPOSITS','+ Deposits in Transit');
define('BNK_GL_BALANCE','- Főkönyvi mérleg');
define('BNK_END_BALANCE','Egyeztetett különbség');
define('BNK_DEPOSIT_CREDIT','Letét/HitelCredit');
define('BNK_CHECK_PAYMENT','Csekk/Fizetés');
define('TEXT_MULTIPLE_DEPOSITS','Ügyfél letétek');
define('TEXT_MULTIPLE_PAYMENTS','Forgalmazói fizetések');
define('TEXT_CASH_ACCOUNT','Készpénzszámla');
define('BNK_ERROR_PERIOD_NOT_ALL','Accounting period selected cannot be \'all\' for account reconciliation operation.');

// Bank account register
define('BANKING_HEADING_REGISTER','Készpénz számlanyilvántartás');
define('TEXT_BEGINNING_BALANCE','Mérleg kezdete');
define('TEXT_ENDING_BALANCE','Mérleg vége');
define('TEXT_DEPOSIT','Letét');

?>
