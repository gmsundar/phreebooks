<?php
// +-----------------------------------------------------------------+
// |                   PhreeBooks Open Source ERP                    |
// +-----------------------------------------------------------------+
// | Copyright (c) 2007 PhreeSoft, LLC                               |
// | http://www.PhreeSoft.com                                        |
// +-----------------------------------------------------------------+
// | This program is free software: you can redistribute it and/or   |
// | modify it under the terms of the GNU General Public License as  |
// | published by the Free Software Foundation, either version 3 of  |
// | the License, or any later version.                              |
// |                                                                 |
// | This program is distributed in the hope that it will be useful, |
// | but WITHOUT ANY WARRANTY; without even the implied warranty of  |
// | MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the   |
// | GNU General Public License for more details.                    |
// |                                                                 |
// | The license that is bundled with this package is located in the |
// | file: /doc/manual/ch01-Introduction/license.html.               |
// | If not, see http://www.gnu.org/licenses/                        |
// +-----------------------------------------------------------------+
//  Path: /modules/inventory/language/hu_hu/language.php
//
// +---------------------------------------+
// | Hungarian translation/Magyar fordítás |
// +---------------------------------------+
// | Hungarian translation: Zsolt Győri    |
// | Hungarian bookkeeping: Tímea Tiszai   |
// | E-mail: gyori.zsolt@gmail.com         |
// | If you have any questions or comment  |
// | do not hesitate to contact us!        |
// +---------------------------------------+
// | Magyar fordítás: Győri Zsolt          |
// | Magyar könyvelés: Tiszai Tímea        |
// | E-mail: gyori.zsolt@gmail.com         |
// | Ha bármi kérdésed vagy észrevételed   |
// | van, ne habozz írni!                  |
// +---------------------------------------+

define('MAX_INVENTORY_SKU_LENGTH',15);

define('INV_ASSY_HEADING_TITLE', 'Összeszerelés/Szétszerelés Inventory');
define('INV_FIELD_HEADING_TITLE', 'Készlet mező kezelő');
define('INV_POPUP_WINDOW_TITLE', 'Készlet tételek');
define('INV_POPUP_PRICE_MGR_WINDOW_TITLE','Készlet árkezelő');
define('INV_POPUP_ADJ_WINDOW_TITLE','Készlet beállítások');

define('INV_HEADING_QTY_ON_HAND', 'Készleten');
define('INV_QTY_ON_HAND', 'Készleten');
define('INV_HEADING_SERIAL_NUMBER', 'Sorozatszám');
define('INV_HEADING_QTY_TO_ASSY', 'Összeszerelendő mennyiség');
define('INV_HEADING_QTY_ON_ORDER', 'Mennyiség rendelve');
define('INV_HEADING_QTY_IN_STOCK', 'Mennyiség raktáron');
define('INV_HEADING_QTY_ON_SO', 'Mennyiség bejövő rendelésen');
define('INV_QTY_ON_SALES_ORDER', 'Mennyiség a bejövő rendelésen');
define('INV_HEADING_PREFERRED_VENDOR', 'Preferált forgalmazó');
define('INV_HEADING_LEAD_TIME', 'Átfutási idő (nap)');
define('INV_QTY_ON_ORDER', 'Mennyiség a kimenő rendelésen');
define('INV_ASSY_PARTS_REQUIRED','Összeszereléshez szükséges alkatrészek');

define('INV_ADJ_QUANTITY','Mennyiségi módosítás');
define('INV_REASON_FOR_ADJUSTMENT','Módosítás oka');
define('INV_ADJ_VALUE', 'Módosítási érték');
define('INV_ROUNDING', 'Kerekítés');
define('INV_RND_VALUE', 'Kerekítési érték');
define('INV_BOM','Anyagjegyzék');
define('INV_ADJ_DELETE_ALERT', 'Biztos törölni akarod a leltári módosítást?');
define('INV_MSG_DELETE_INV_ITEM', 'Biztos törölni akarod ezt a leltári tételt?');

define('INV_HEADING_NEW_ITEM', 'Új leltári tétel'); 
define('INV_HEADING_FIELD_INFO', 'Leltár mező információ');
define('INV_HEADING_FIELD_PROPERTIES', 'Mező típusa és tulajdonságok (Válassz egyet)');
define('INV_ENTER_SKU','Add meg a cikkszámot, tétel típusát és a költségszámítás módszerét.<br>Maximum cikkszám hossz ' . MAX_INVENTORY_SKU_LENGTH . ' karakter (' . (MAX_INVENTORY_SKU_LENGTH - 5) . ' Master Stock esetén)');
define('INV_MS_ATTRIBUTES','Master Stock tulajdonságok');
define('INV_TEXT_ATTRIBUTE_1','Tulajdonság 1');
define('INV_TEXT_ATTRIBUTE_2','Tulajdonság 2');
define('INV_TEXT_ATTRIBUTES','Tulajdonságok');
define('INV_MS_CREATED_SKUS','A következő cikkszámok lesznek létrehozva');

define('INV_ENTRY_INVENTORY_TYPE', 'Típus');
define('INV_ENTRY_INVENTORY_DESC_SHORT', 'Rövid leírás');
define('INV_ENTRY_INVENTORY_DESC_PURCHASE', 'Bővebb leírás');
define('INV_ENTRY_IMAGE_PATH','Relatív kép útvonal');
define('INV_ENTRY_SELECT_IMAGE','Válassz képet');
define('INV_ENTRY_ACCT_SALES', 'Eladás/Jövedelem számla');
define('INV_ENTRY_ACCT_INV', 'Készlet/Bér számla');
define('INV_ENTRY_ACCT_COS', 'ELÁBÉ számla');
define('INV_ENTRY_INV_ITEM_COST','Ár');
define('INV_ENTRY_FULL_PRICE', 'Teljes ár');
define('INV_ENTRY_ITEM_WEIGHT', 'Tömeg');
define('INV_ENTRY_ITEM_TAXABLE', 'Adó');
define('INV_ENTRY_ITEM_MINIMUM_STOCK', 'Minimum készlet');
define('INV_ENTRY_ITEM_REORDER_QUANTITY', 'Újrarendelési mennyiség');
define('INV_ENTRY_INVENTORY_COST_METHOD', 'Költségszámítási módszer');
define('INV_ENTRY_INVENTORY_SERIALIZE', 'Sorszámozott termék');
define('INV_MASTER_STOCK_ATTRIB_ID','ID (Max 2 karakter)');

define('INV_DATE_ACCOUNT_CREATION', 'Létrehozva');
define('INV_DATE_LAST_UPDATE', 'Utolsó frissítés');
define('INV_DATE_LAST_JOURNAL_DATE', 'Útolsó belépés');

define('INV_MSG_COPY_INTRO', 'Add meg a cél cikkszámot:');
define('INV_MSG_RENAME_INTRO', 'Add meg az új cikkszámot ehhez a cikkszámhoz:');
define('INV_ERROR_DUPLICATE_SKU','Nem tudom létrehozni az új leltári tételt, mert a cikkszám már használatban van.');
define('INV_ERROR_CANNOT_DELETE','Nem tudom törölni a leltári tételt, mert naplóbejegyzések hivatkoznak erre a cikkszámra.');
define('INV_ERROR_BAD_SKU','Hiba a tétel összeszerelési listában. Ellenőrizd a cikkszámokat és a mennyiségeket. A hibát okozó cikkszám: ');
define('INV_ERROR_SKU_INVALID','Érvénytelen cikkszám. Ellenőrizd a cikkszámot és a készlet számlát.');
define('INV_ERROR_SKU_BLANK','A cikkszám mező üres. Add meg és próbáld újra.');
define('INV_ERROR_FIELD_BLANK','A mezőnév üres. Add meg és próbáld újra.');
define('INV_ERROR_FIELD_DUPLICATE','A megadott mezőnév már létezik.');
define('INV_ERROR_NEGATIVE_BALANCE','Error unbuilding inventory, not enough stock on hand to unbuild the requested quantity!');
define('TEXT_DISPLAY_NUMBER_OF_ITEMS', 'Megjelenítve <b>%d</b> - <b>%d</b> (összesen <b>%d</b> tétel)');
define('TEXT_DISPLAY_NUMBER_OF_FIELDS', 'Megjelenítve <b>%d</b> - <b>%d</b> (összesen <b>%d</b> mező)');
define('INV_CATEGORY_MEMBER', 'Kategória tag:');
define('INV_FIELD_NAME', 'Mezőnév: ');
define('INV_DESCRIPTION', 'Leírás: ');
define('TEXT_USE_DEFAULT_PRICE_SHEET','Alapértelmezett árlista beállítások használata');
define('INV_ERROR_ASSY_CANNOT_DELETE','Nem tudom törölni az összeszerelést. Naplóbejegyzés hivatkozik rá!');
define('INV_POST_SUCCESS','Sikeresen elküldött készlet módosítási szám # ');
define('INV_POST_ASSEMBLY_SUCCESS','Sikeresen összeszerelt cikkszám: ');
define('INV_NO_PRICE_SHEETS','Nincs megadva árlista!');
define('INV_DEFINED_PRICES','Cikkszámhoz definiált árak: ');

define('INV_LABEL_DEFAULT_TEXT_VALUE', 'Alapértelmezett érték: ');
define('INV_LABEL_MAX_NUM_CHARS', 'Maximum karakter (hossz)');
define('INV_LABEL_FIXED_255_CHARS', 'Maximum 255 karakter lehet');
define('INV_LABEL_MAX_255', '(256 karakternél rövidebb esetén)');
define('INV_LABEL_CHOICES', 'Szűrő megadása');
define('INV_LABEL_TEXT_FIELD', 'Szöveg mező');
define('INV_LABEL_HTML_TEXT_FIELD', 'HTML kód');
define('INV_LABEL_HYPERLINK', 'Hyperhivatkozás');
define('INV_LABEL_IMAGE_LINK', 'Képfájl neve');
define('INV_LABEL_INVENTORY_LINK', 'Készlet link (Link pointing to another inventory item (URL)');
define('INV_LABEL_INTEGER_FIELD', 'Egész szám');
define('INV_LABEL_INTEGER_RANGE', 'Egész intervallum');
define('INV_LABEL_DECIMAL_FIELD', 'Decimális szám');
define('INV_LABEL_DECIMAL_RANGE', 'Decimális intervallum');
define('INV_LABEL_DEFAULT_DISPLAY_VALUE', 'Megjelenítési formátum (Max,Decimális)');
define('INV_LABEL_DROP_DOWN_FIELD', 'Legördülő lista');
define('INV_LABEL_RADIO_FIELD', 'Radiógomb kiválasztó <br>Add meg a lehetőségeket vesszővel elválasztva pl:<br>value1:desc1:def1,value2:desc2:def2<br><u>Key:</u><br>value = Az adatbázisba helyezendő érték<br>desc = Lehetőség szöveges leírása<br>def = Alapértelmezett 0 vagy 1, 1 az alapértelmezett választás<br>Megjegyzés: csak egy alapértelmezett lehet listánként');
define('INV_LABEL_DATE_TIME_FIELD', 'Dátum és idő');
define('INV_LABEL_CHECK_BOX_FIELD', 'Checkbox (Igen vagy Nem választás)');
define('INV_LABEL_TIME_STAMP_FIELD', 'Időbélyeg');
define('INV_LABEL_TIME_STAMP_VALUE', 'System field to track the last date and time a change to a particular inventory item was made.');

define('INV_FIELD_NAME_RULES','A mezőnevek nem tartalmazhatnak szóközöket vagy különleges <br>karaktereket és maximum 64 karakter lehet');
define('INV_DELETE_INTRO_INV_FIELDS', 'Biztosan törölni akarod ezt a leltári mezőt?\nMINDEN ADAT EL FOG VESZNI!');
define('INV_INFO_HEADING_DELETE_INVENTORY', 'Leltár mező törlése');
define('INV_CATEGORY_CANNOT_DELETE','Nem tudom törölni a kategóriát. Ez a mező használja: ');
define('INV_CANNOT_DELETE_SYSTEM','A rendszer kategóriákban lévő mezőket nem lehet törölni!');
define('INV_IMAGE_PATH_ERROR','Hiba a feltöltendő kép elérési útvonalában!');
define('INV_IMAGE_FILE_TYPE_ERROR','Hiba a feltöltött képfájlban. Nem elfogadható fájltípus.');
define('INV_IMAGE_FILE_WRITE_ERROR','Hiba történt a képfájl megadott könyvtárba történő írása során.');
define('INV_FIELD_RESERVED_WORD','A megadott mezőnév fentartott szó. Válassz más mezőnevet.');

// java script errors
define('JS_SKU_BLANK', '* Adj meg cikkszámot vagy univerzális termékkódot az új tételnek\n');
define('JS_COGS_AUTO_CALC','Az egységárat a rendszer kiszámolja.');
define('JS_NO_SKU_ENTERED','Cikkszám megadása szükséges.\n');
define('JS_ADJ_VALUE_ZERO','Nem 0 módosító érték szükséges.\n');
define('JS_ASSY_VALUE_ZERO','Nem 0 összeszerelési mennyiség szükséges.\n');
define('JS_NOT_ENOUGH_PARTS','Nincs elég raktárkészlet a kért mennyiség összeszereléséhez');
define('JS_MS_INVALID_ENTRY','Mind az azonosító, mind a leírás mező szükséges. Add meg mind a két értéket és nyomj OK-t.');

// audit log messages
define('INV_LOG_ADJ','Készlet módosítás - ');
define('INV_LOG_ASSY','Készlet összeszerelés - ');
define('INV_LOG_FIELDS','Készlet mezők - ');
define('INV_LOG_INVENTORY','Leltári tétel - ');
define('INV_LOG_PRICE_MGR','Készlet árkezelő - ');

// the inventory type indexes should not be changed or the inventory module won't work.
// system generated types (not to be displayed are: ai - assembly item, mi - master stock with attributes)
$inventory_types = array(
	'si' => 'Egyszerű raktári tétel',
	'sr' => 'Sorszámozott tétel',
	'ms' => 'Tulajdonsággal megkülönböztetett tétel',
	'as' => 'Szerelt termék',
	'ns' => 'Saját eszköz',
	'lb' => 'Munkadíj',
	'sv' => 'Szolgáltatás',
	'ci' => 'Egyéb költség',
	'ai' => 'Tevékenység',
	'ds' => 'Leírás');

// used for identifying inventory types in reports and forms that are not selectable by the user
$inventory_types_plus = $inventory_types;
$inventory_types_plus['ai'] = 'Tétel összeszerelési alkatrész';
$inventory_types_plus['mi'] = 'Master Stock Sub Item';

$cost_methods = array(
	'f' => 'FIFO',		// First-in, First-out
	'l' => 'LIFO',		// Last-in, First-out
	'a' => 'Átlag');	// Average Costing

$integer_lengths = array(
	'0' => '-127 to 127',
	'1' => '-32,768 to 32,768',
	'2' => '-8,388,608 to 8,388,607',
	'3' => '-2,147,483,648 to 2,147,483,647',
	'4' => 'Nagyobb mint 2,147,483,648');

$decimal_lengths = array(
	'0' => 'Szimpla pontosság',
	'1' => 'Dupla pontosság');

$check_box_choices = array(
	'0' => 'Nem', 
	'1' => 'Igen');

$price_mgr_sources = array(
	'0' => 'Nem használt',	// Do not remove this selection, leave as first entry
	'1' => 'Direct Entry',
	'2' => 'Egységár',
	'3' => 'Kisker ár',
// Price Level 1 needs to always be at the end (it is pulled from the first row to avoid a circular reference)
// The index can change but must be matched with the javascript to update the price source values.
	'4' => 'Árszint 1');	

$price_mgr_adjustments = array(
	'0' => TEXT_NONE,
	'1' => 'Csökkent (mennyiség)',
	'2' => 'Csökkent (%)',
	'3' => 'Növel (mennyiség)',
	'4' => 'Növel (%)');

$price_mgr_rounding = array(
	'0' => TEXT_NONE,
	'1' => 'Következő forint',
	'2' => 'Fillérek is');

?>
