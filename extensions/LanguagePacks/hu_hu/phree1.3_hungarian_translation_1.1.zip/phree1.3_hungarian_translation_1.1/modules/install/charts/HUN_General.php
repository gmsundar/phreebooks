<?php
// +-----------------------------------------------------------------+
// |                   PhreeBooks Open Source ERP                    |
// +-----------------------------------------------------------------+
// | Copyright (c) 2007 PhreeSoft, LLC                               |
// | http://www.PhreeSoft.com                                        |
// +-----------------------------------------------------------------+
// | This program is free software: you can redistribute it and/or   |
// | modify it under the terms of the GNU General Public License as  |
// | published by the Free Software Foundation, either version 3 of  |
// | the License, or any later version.                              |
// |                                                                 |
// | This program is distributed in the hope that it will be useful, |
// | but WITHOUT ANY WARRANTY; without even the implied warranty of  |
// | MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the   |
// | GNU General Public License for more details.                    |
// |                                                                 |
// | The license that is bundled with this package is located in the |
// | file: /doc/manual/ch01-Introduction/license.html.               |
// | If not, see http://www.gnu.org/licenses/                        |
// +-----------------------------------------------------------------+
//  Path: /modules/install/charts/HUN_General.php
//
// +---------------------------------------+
// | Hungarian translation/Magyar fordítás |
// +---------------------------------------+
// | Hungarian translation: Zsolt Győri    |
// | Hungarian bookkeeping: Tímea Tiszai   |
// | E-mail: gyori.zsolt@gmail.com         |
// | If you have any questions or comment  |
// | do not hesitate to contact us!        |
// +---------------------------------------+
// | Magyar fordítás: Győri Zsolt          |
// | Magyar könyvelés: Tiszai Tímea        |
// | E-mail: gyori.zsolt@gmail.com         |
// | Ha bármi kérdésed vagy észrevételed   |
// | van, ne habozz írni!                  |
// +---------------------------------------+

// Chart of Accounts for HUN simple General company
$chart_description = "HU - Magyar ajánlott számlakeret";
$chart_array = array();

$chart_array[] = array('11','Immateriális javak','0');
$chart_array[] = array('111','Alapítás-átszervezés aktivált értéke','0');
$chart_array[] = array('112','Kísérleti fejlesztés aktivált értéke','2');
$chart_array[] = array('113','Vagyoni értékű jogok','2');
$chart_array[] = array('114','Szellemi termékek','4');
$chart_array[] = array('12','Tárgyi eszközök','4');
$chart_array[] = array('121','Ingatlanok és a kapcsolódó vagyoni értékű
jogok','8');
$chart_array[] = array('131','Műszaki berendezések, gépek, járművek','8');
$chart_array[] = array('141','Egyéb berendezések, felszerelések,
járművek','8');
$chart_array[] = array('151','Tenyészállatok','8');
$chart_array[] = array('161','Beruházások, felújítások','8');
$chart_array[] = array('351','Beruházásokra adott előlegek','20');
$chart_array[] = array('171','Tárgyi eszközök értékhelyesbítése','22');
$chart_array[] = array('190','Befektetett pénzügyi eszközök','22');
$chart_array[] = array('191','Tartós részesedés kapcsolt
vállalkozásban','22');
$chart_array[] = array('192','Tartósan adott kölcsön  kapcsolt
vállalkozásban','22');
$chart_array[] = array('193','Egyéb tartós részesedés','22');
$chart_array[] = array('194','Tartósan adott kölcsön egyéb részesedési
viszonyban álló vállalkozásban','22');
$chart_array[] = array('195','Egyéb tartósan adott kölcsön','22');
$chart_array[] = array('196','Tartós hitelviszonyt megtestesítő
értékpapír','22');
$chart_array[] = array('197','Befektetett pénzügyi eszközök
értékhelyesbítése','22');
$chart_array[] = array('198','Befektetett pénzügyi eszközök értékelési
különbözete','22');
$chart_array[] = array('260','Készletek','22');
$chart_array[] = array('261','Anyagok','22');
$chart_array[] = array('262','Befejezetlen termelés és félkész
termékek','22');
$chart_array[] = array('265','Növendék-, hízó- és egyéb állatok','22');
$chart_array[] = array('266','Késztermékek','22');
$chart_array[] = array('263','Áruk','22');
$chart_array[] = array('353','Készletekre adott előlegek','22');
$chart_array[] = array('271','Közvetített szolgáltatások','22');
$chart_array[] = array('310','Követelések','24');
$chart_array[] = array('311','Követelések áruszállításból és
szolgáltatásból (vevők)','24');
$chart_array[] = array('312','Követelések kapcsolt vállalkozással
szemben','24');
$chart_array[] = array('313','Követelések egyéb részesedési viszonyban
lévő vállalkozással szemben','24');
$chart_array[] = array('314','Váltókövetelések','30');
$chart_array[] = array('315','Egyéb követelések','30');
$chart_array[] = array('316','Követelések értékelési különbözete','30');
$chart_array[] = array('317','Származékos ügyletek pozitív értékelési
különbözete','30');
$chart_array[] = array('370','Értékpapírok','30');
$chart_array[] = array('371','Részesedés kapcsolt vállalkozásban','32');
$chart_array[] = array('372','Egyéb részesedés','32');
$chart_array[] = array('373','Saját részvények, saját üzletrészek','34');
$chart_array[] = array('374','Forgatási célú hitelviszonyt megtestesítő
értékpapírok','34');
$chart_array[] = array('375','Értékpapírok értékelési különbözete','34');
$chart_array[] = array('000','Pénzeszközök','34');
$chart_array[] = array('381','Pénztár, csekkek','34');
$chart_array[] = array('384','Bankbetétek','34');
$chart_array[] = array('391','Bevételek aktív időbeli elhatárolása','34');
$chart_array[] = array('392','Költségek, ráfordítások aktív időbeli
elhatárolása','34');
$chart_array[] = array('393','Halasztott ráfordítások','34');
$chart_array[] = array('411','Jegyzett tőke','34');
$chart_array[] = array('4110','Jegyzett, de még be nem fizetett tőke
(-)','34');
$chart_array[] = array('412','Tőketartalék','34');
$chart_array[] = array('413','Eredménytartalék','34');
$chart_array[] = array('414','Lekötött tartalék','34');
$chart_array[] = array('417','Értékelési tartalék','34');
$chart_array[] = array('419','Mérleg szerinti eredmény','34');
$chart_array[] = array('421','Céltartalék a várható
kötelezettségekre','34');
$chart_array[] = array('422','Céltartalék a jövőbeni költségekre','34');
$chart_array[] = array('423','Egyéb céltartalék','34');
$chart_array[] = array('430','Hátrasorolt kötelezettségek','34');
$chart_array[] = array('431','Hátrasorolt kötelezettségek kapcsolt
vállalkozással szemben','34');
$chart_array[] = array('432','Hátrasorolt kötelezettségek egyéb
részesedési viszonyban lévő vállalkozással
szemben','34');
$chart_array[] = array('433','Hátrasorolt kötelezettségek egyéb
gazdálkodóval szemben','34');
$chart_array[] = array('440','Hosszú lejáratú kötelezettségek','34');
$chart_array[] = array('441','Hosszú lejáratra kapott kölcsönök','34');
$chart_array[] = array('442','Átváltoztatható kötvények','34');
$chart_array[] = array('443','Tartozások kötvénykibocsátásból','34');
$chart_array[] = array('444','Beruházási és fejlesztési hitelek','34');
$chart_array[] = array('445','Egyéb hosszú lejáratú hitelek','34');
$chart_array[] = array('446','Tartós kötelezettségek kapcsolt
vállalkozással szemben','34');
$chart_array[] = array('447','Tartós kötelezettségek egyéb részesedési
viszonyban lévő vállalkozással szemben','34');
$chart_array[] = array('448','Egyéb hosszú lejáratú kötelezettségek','34');
$chart_array[] = array('450','Rövid lejáratú kötelezettségek','34');
$chart_array[] = array('451','Rövid lejáratú kölcsönök','34');
$chart_array[] = array('452','Rövid lejáratú hitelek','34');
$chart_array[] = array('453','Vevőktől kapott előlegek','34');
$chart_array[] = array('454','Kötelezettségek áruszállításból és
szolgáltatásból (szállítók)','34');
$chart_array[] = array('455','Váltótartozások','34');
$chart_array[] = array('456','Rövid lejáratú kötelezettségek kapcsolt
vállalkozással szemben','34');
$chart_array[] = array('457','Rövid lejáratú kötelezettségek egyéb
részesedési viszonyban lévő vállalkozással szemben','34');
$chart_array[] = array('46','Egyéb rövid lejáratú kötelezettségek','34');
$chart_array[] = array('4591','Kötelezettségek értékelési
különbözete','34');
$chart_array[] = array('4592','Származékos ügyletek negatív értékelési
különbözete','34');
$chart_array[] = array('481','Bevételek passzív időbeli elhatárolása','34');
$chart_array[] = array('482','Költségek, ráfordítások passzív időbeli
elhatárolása','34');
$chart_array[] = array('483','Halasztott bevételek','34');
$chart_array[] = array('491','Nyitómérleg számla','34');
$chart_array[] = array('492','Zárómérleg számla','34');
$chart_array[] = array('493','Eredmény számla','34');
?>
