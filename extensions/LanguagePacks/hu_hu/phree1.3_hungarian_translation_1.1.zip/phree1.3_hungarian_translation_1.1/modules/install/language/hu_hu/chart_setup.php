<?php
// +-----------------------------------------------------------------+
// |                   PhreeBooks Open Source ERP                    |
// +-----------------------------------------------------------------+
// | Copyright (c) 2007 PhreeSoft, LLC                               |
// | http://www.PhreeSoft.com                                        |
// +-----------------------------------------------------------------+
// | This program is free software: you can redistribute it and/or   |
// | modify it under the terms of the GNU General Public License as  |
// | published by the Free Software Foundation, either version 3 of  |
// | the License, or any later version.                              |
// |                                                                 |
// | This program is distributed in the hope that it will be useful, |
// | but WITHOUT ANY WARRANTY; without even the implied warranty of  |
// | MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the   |
// | GNU General Public License for more details.                    |
// |                                                                 |
// | The license that is bundled with this package is located in the |
// | file: /doc/manual/ch01-Introduction/license.html.               |
// | If not, see http://www.gnu.org/licenses/                        |
// +-----------------------------------------------------------------+
//  Path: /modules/install/includes/languages/hu_hu/chart_setup.php
//
// +---------------------------------------+
// | Hungarian translation/Magyar fordítás |
// +---------------------------------------+
// | Hungarian translation: Zsolt Győri    |
// | Hungarian bookkeeping: Tímea Tiszai   |
// | E-mail: gyori.zsolt@gmail.com         |
// | If you have any questions or comment  |
// | do not hesitate to contact us!        |
// +---------------------------------------+
// | Magyar fordítás: Győri Zsolt          |
// | Magyar könyvelés: Tiszai Tímea        |
// | E-mail: gyori.zsolt@gmail.com         |
// | Ha bármi kérdésed vagy észrevételed   |
// | van, ne habozz írni!                  |
// +---------------------------------------+

  define('SAVE_STORE_SETTINGS', 'Általános számlakeret mentése'); //this comes before TEXT_MAIN
  define('TEXT_MAIN', "This section of the PhreeBooks&trade; setup tool will help you set up your company chart of accounts.  PhreeBooks includes several sample chart of accounts for you to choose from. You will be able to change any of these settings later using the General Ledger menu.  Please select a chart of accounts type and press <em>".SAVE_STORE_SETTINGS.'</em> to continue.<br><br>NOTE: IF you plan to install the demo data, use the chart titled \'US - Retail store simple Chart of Accounts\' to assure the cost accounts align properly. Failure to do so will require the customer/vendor accounts and inventory charge accounts to be corrected with the proper gl accounts.');
  define('TEXT_PAGE_HEADING', 'PhreeBooks&trade; Telepítő - Számlakeret beállítása');
  define('STORE_INFORMATION', 'Számlakeret információ');

  define('STORE_DEFAULT_COA', 'Elérhető számlakeretek');
  define('STORE_DEFAULT_COA_INSTRUCTION', 'Choose the template that you would like for your default chart of accounts? A későbbiekben a Főkönyv menüpont alól vehetsz fel vagy törölhetsz számlákat.');
?>
