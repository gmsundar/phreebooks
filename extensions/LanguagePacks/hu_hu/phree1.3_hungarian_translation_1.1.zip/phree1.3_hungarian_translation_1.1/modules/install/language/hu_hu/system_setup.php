<?php
// +-----------------------------------------------------------------+
// |                   PhreeBooks Open Source ERP                    |
// +-----------------------------------------------------------------+
// | Copyright (c) 2007 PhreeSoft, LLC                               |
// | http://www.PhreeSoft.com                                        |
// +-----------------------------------------------------------------+
// | This program is free software: you can redistribute it and/or   |
// | modify it under the terms of the GNU General Public License as  |
// | published by the Free Software Foundation, either version 3 of  |
// | the License, or any later version.                              |
// |                                                                 |
// | This program is distributed in the hope that it will be useful, |
// | but WITHOUT ANY WARRANTY; without even the implied warranty of  |
// | MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the   |
// | GNU General Public License for more details.                    |
// |                                                                 |
// | The license that is bundled with this package is located in the |
// | file: /doc/manual/ch01-Introduction/license.html.               |
// | If not, see http://www.gnu.org/licenses/                        |
// +-----------------------------------------------------------------+
//  Path: /modules/install/includes/languages/hu_hu/system_setup.php
//
// +---------------------------------------+
// | Hungarian translation/Magyar fordítás |
// +---------------------------------------+
// | Hungarian translation: Zsolt Győri    |
// | Hungarian bookkeeping: Tímea Tiszai   |
// | E-mail: gyori.zsolt@gmail.com         |
// | If you have any questions or comment  |
// | do not hesitate to contact us!        |
// +---------------------------------------+
// | Magyar fordítás: Győri Zsolt          |
// | Magyar könyvelés: Tiszai Tímea        |
// | E-mail: gyori.zsolt@gmail.com         |
// | Ha bármi kérdésed vagy észrevételed   |
// | van, ne habozz írni!                  |
// +---------------------------------------+

  define('SAVE_SYSTEM_SETTINGS', 'Rendszerbeállítások mentése'); //this comes before TEXT_MAIN
  define('TEXT_MAIN', "Most beállítjuk a PhreeBooks&trade; rendszer környezetet.  Kérlek figyelmesen nézz át minden beállítást, és ha szükséges módosítsd, hogy megfeleljen a könyvtárszerkezetednek. Majd kattints a <em>".SAVE_SYSTEM_SETTINGS.'</em> gombra.');
  define('TEXT_PAGE_HEADING', 'PhreeBooks&trade; Beállítás - Rendszerbeállítások');
  define('SERVER_SETTINGS', 'Szerver beállítások');
  define('PHYSICAL_PATH', 'Fizikai elérési út');
  define('PHYSICAL_PATH_INSTRUCTION', 'PhreeBooks könyvtár<br />fizikai elérési útvonala.<br />A végén ne hagyj / jelet.');
  define('VIRTUAL_HTTP_PATH', 'Virtuális HTTP elérési út');
  define('VIRTUAL_HTTP_PATH_INSTRUCTION', 'PhreeBooks könyvtár<br />virtuális elérési útvonala.<br />A végén ne hagyj / jelet.');
  define('VIRTUAL_HTTPS_PATH', 'Virtuális HTTPS elérési út');
  define('VIRTUAL_HTTPS_PATH_INSTRUCTION', 'Biztonságos Phreebooks könyvtár<br />virtuális elérési útvonala.<br />A végén ne hagyj / jelet.');
  define('VIRTUAL_HTTPS_SERVER', 'Virtuális HTTPS Szerver');
  define('VIRTUAL_HTTPS_SERVER_INSTRUCTION', 'Biztonságos PhreeBooks könyvtár<br />virtuális elérési útvonala.<br />A végén ne hagyj / jelet.');
  define('ENABLE_SSL', 'SSL Engedélyezése');
  define('ENABLE_SSL_INSTRUCTION', 'Engedélyezed a Secure Sockets Layer használatát?<br />Csak akkor engedélyezd, ha biztos vagy benne, hogy az SSL működik.');
?>
