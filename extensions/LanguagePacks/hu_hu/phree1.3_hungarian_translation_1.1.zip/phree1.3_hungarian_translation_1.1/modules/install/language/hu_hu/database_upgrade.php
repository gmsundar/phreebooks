<?php
// +-----------------------------------------------------------------+
// |                   PhreeBooks Open Source ERP                    |
// +-----------------------------------------------------------------+
// | Copyright (c) 2007 PhreeSoft, LLC                               |
// | http://www.PhreeSoft.com                                        |
// +-----------------------------------------------------------------+
// | This program is free software: you can redistribute it and/or   |
// | modify it under the terms of the GNU General Public License as  |
// | published by the Free Software Foundation, either version 3 of  |
// | the License, or any later version.                              |
// |                                                                 |
// | This program is distributed in the hope that it will be useful, |
// | but WITHOUT ANY WARRANTY; without even the implied warranty of  |
// | MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the   |
// | GNU General Public License for more details.                    |
// |                                                                 |
// | The license that is bundled with this package is located in the |
// | file: /doc/manual/ch01-Introduction/license.html.               |
// | If not, see http://www.gnu.org/licenses/                        |
// +-----------------------------------------------------------------+
//  Path: /modules/install/includes/languages/hu_hu/database_upgrade.php
//
// +---------------------------------------+
// | Hungarian translation/Magyar fordítás |
// +---------------------------------------+
// | Hungarian translation: Zsolt Győri    |
// | Hungarian bookkeeping: Tímea Tiszai   |
// | E-mail: gyori.zsolt@gmail.com         |
// | If you have any questions or comment  |
// | do not hesitate to contact us!        |
// +---------------------------------------+
// | Magyar fordítás: Győri Zsolt          |
// | Magyar könyvelés: Tiszai Tímea        |
// | E-mail: gyori.zsolt@gmail.com         |
// | Ha bármi kérdésed vagy észrevételed   |
// | van, ne habozz írni!                  |
// +---------------------------------------+

  define('PAGE_HEADING', 'PhreeBooks&trade; Setup - Database Upgrade');
  define('UPDATE_DATABASE_NOW','Update Database Now');//this comes before TEXT_MAIN
  define('TEXT_MAIN', '<em>Warning: </em> This script should ONLY be used to upgrade your PhreeBooks database schema through the versions listed below.  ' .
                      '<span class="emphasis"><strong>We HIGHLY RECOMMEND doing a full backup of your database prior to performing any upgrades on it!</strong></span>');
  define('TEXT_MAIN_2','<span class="emphasis">Please check the details below very carefully</span>. This information is taken from your configure.php settings.<br />' .
                      'Do not proceed unless you\'re sure they\'re correct, or else you risk corruption to your database.');

  define('DATABASE_INFORMATION', 'Database Information');
  define('DATABASE_TYPE', 'Database Type');
  define('DATABASE_HOST', 'Database Host');
  define('DATABASE_USERNAME', 'Database Username');
  define('DATABASE_PASSWORD', 'Database Password');
  define('DATABASE_NAME', 'Database Name');
  define('DATABASE_PREFIX', 'Database Table-Prefix');
  define('DATABASE_PRIVILEGES', 'Database Privileges');

  define('SNIFFER_PREDICTS','<em>Upgrade Sniffer</em> predicts: ');
  define('CHOOSE_UPGRADES','Please confirm your desired upgrade steps');
  define('TITLE_DATABASE_PREFIX_CHANGE','Change Database Table-Prefix');
  define('ERROR_PREFIX_CHANGE_NEEDED','<span class="errors">We were unable to locate the PhreeBooks tables in your database.<br />Perhaps your database table-prefix has been specified incorrectly?</span><br />If modifying table prefixes doesn\'t solve your problem, you will need to manually compare your configure.php settings with your actual database, perhaps through phpMyAdmin or your webserver control panel.');
  define('TEXT_DATABASE_PREFIX_CHANGE','If you wish to change the database table prefixes, enter the new prefix below. <span class="emphasis">NOTE: please verify that the prefix name is not already used in your database</span>, as we do not check for such duplication. Using an already-existing table prefix will corrupt your database.');
  define('TEXT_DATABASE_PREFIX_CHANGE_WARNING','<span class="errors"><strong>WARNING: DO NOT ATTEMPT TO CHANGE TABLE PREFIXES IF YOU DO NOT HAVE A FULL AND DEPENDABLE RECENT BACKUP OF YOUR DATABASE CONTENTS. If something goes wrong in the process, you will need to recover from your backup. If this is cause for concern or uncertainty for you, then DO NOT attempt to rename your tables.</strong></span>');
  define('DATABASE_OLD_PREFIX','Old Table-Prefix');
  define('DATABASE_OLD_PREFIX_INSTRUCTION','Enter the OLD Table-Prefix');
  define('ENTRY_NEW_PREFIX','New Table-Prefix ');
  define('DATABASE_NEW_PREFIX_INSTRUCTION','Enter the NEW Table-Prefix');
  define('ENTRY_ADMIN_ID','Admin Username (from PhreeBooks Admin area)');
  define('ENTRY_ADMIN_PASSWORD','Password');
  define('ADMIN_PASSSWORD_INSTRUCTION','Your Administrator username/password (the one that you use to access your shop Admin area) are required in order to make database changes. <em>(This is NOT your MySQL password)</em>');
  define('TITLE_SECURITY','Database Security');

  define('UPDATE_DATABASE_WARNING_DO_NOT_INTERRUPT','<span class="emphasis">After clicking below, DO NOT INTERRUPT. Please be patient during upgrade.</span>');
  define('SKIP_UPDATES','Skip Updates');


  define('REASON_TABLE_ALREADY_EXISTS','Cannot create table %s because it already exists');
  define('REASON_TABLE_DOESNT_EXIST','Cannot drop table %s because it does not exist.');
  define('REASON_CONFIG_KEY_ALREADY_EXISTS','Cannot insert configuration_key "%s" because it already exists');
  define('REASON_COLUMN_ALREADY_EXISTS','Cannot ADD column %s because it already exists.');
  define('REASON_COLUMN_DOESNT_EXIST_TO_DROP','Cannot DROP column %s because it does not exist.');
  define('REASON_COLUMN_DOESNT_EXIST_TO_CHANGE','Cannot CHANGE column %s because it does not exist.');
  define('REASON_PRODUCT_TYPE_LAYOUT_KEY_ALREADY_EXISTS','Cannot insert prod-type-layout configuration_key "%s" because it already exists');
  define('REASON_INDEX_DOESNT_EXIST_TO_DROP','Cannot drop index %s on table %s because it does not exist.');
  define('REASON_PRIMARY_KEY_DOESNT_EXIST_TO_DROP','Cannot drop primary key on table %s because it does not exist.');
  define('REASON_INDEX_ALREADY_EXISTS','Cannot add index %s to table %s because it already exists.');
  define('REASON_PRIMARY_KEY_ALREADY_EXISTS','Cannot add primary key to table %s because a primary key already exists.');
  define('REASON_NO_PRIVILEGES','User %s@%s does not have %s privileges to database.');

?>
