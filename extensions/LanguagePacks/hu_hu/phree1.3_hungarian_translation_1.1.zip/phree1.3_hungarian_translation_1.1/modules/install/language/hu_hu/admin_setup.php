<?php
// +-----------------------------------------------------------------+
// |                   PhreeBooks Open Source ERP                    |
// +-----------------------------------------------------------------+
// | Copyright (c) 2007 PhreeSoft, LLC                               |
// | http://www.PhreeSoft.com                                        |
// +-----------------------------------------------------------------+
// | This program is free software: you can redistribute it and/or   |
// | modify it under the terms of the GNU General Public License as  |
// | published by the Free Software Foundation, either version 3 of  |
// | the License, or any later version.                              |
// |                                                                 |
// | This program is distributed in the hope that it will be useful, |
// | but WITHOUT ANY WARRANTY; without even the implied warranty of  |
// | MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the   |
// | GNU General Public License for more details.                    |
// |                                                                 |
// | The license that is bundled with this package is located in the |
// | file: /doc/manual/ch01-Introduction/license.html.               |
// | If not, see http://www.gnu.org/licenses/                        |
// +-----------------------------------------------------------------+
//  Path: /modules/install/includes/languages/hu_hu/admin_setup.php
//
// +---------------------------------------+
// | Hungarian translation/Magyar fordítás |
// +---------------------------------------+
// | Hungarian translation: Zsolt Győri    |
// | Hungarian bookkeeping: Tímea Tiszai   |
// | E-mail: gyori.zsolt@gmail.com         |
// | If you have any questions or comment  |
// | do not hesitate to contact us!        |
// +---------------------------------------+
// | Magyar fordítás: Győri Zsolt          |
// | Magyar könyvelés: Tiszai Tímea        |
// | E-mail: gyori.zsolt@gmail.com         |
// | Ha bármi kérdésed vagy észrevételed   |
// | van, ne habozz írni!                  |
// +---------------------------------------+

  define('TEXT_PAGE_HEADING', 'PhreeBooks&trade; Beállítás - Rendszergazda fiók létrehozása');
  define('SAVE_ADMIN_SETTINGS', 'Rendszergazda beállítások mentése');//this comes before TEXT_MAIN
  define('TEXT_MAIN', "PhreeBooks&trade; üzlet beállításainak módosításához szükséged lesz egy rendszergazdai fiókra.  Válassz rendszergazda nevet és jelszót, majd add meg az e-mail címed, ahová az elfelejtett jelszót küldhetem.  Töltsd ki figyelmesen az adatokat, majd ha kész vagy, kattints a <em>".SAVE_ADMIN_SETTINGS.'</em> gombra a folytatáshoz.');
  define('ADMIN_INFORMATION', 'Rendszergazda adatai');
  define('ADMIN_USERNAME', 'Rendszergazda felhasználóneve');
  define('ADMIN_USERNAME_INSTRUCTION', 'Add meg a PhreeBooks rendszergazda felhasználónevét.');
  define('ADMIN_PASS', 'Rendszergazda jelszó');
  define('ADMIN_PASS_INSTRUCTION', 'Add meg a PhreeBooks rendszergazda jelszót.');
  define('ADMIN_PASS_CONFIRM', 'Rendszergazda jelszó megerősítése');
  define('ADMIN_PASS_CONFIRM_INSTRUCTION', 'PhreeBooks rendszergazda jelszó megerősítése.');
  define('ADMIN_EMAIL', 'Rendszergazda e-mail címe');
  define('ADMIN_EMAIL_INSTRUCTION', 'PhreeBooks rendszergazdai fiók e-mail címe.');
  define('UPGRADE_DETECTION','Frissítés keresés');
  define('UPGRADE_INSTRUCTION_TITLE','PhreeBooks&trade; frissítések keresése rendszergazdaként való belépéskor');
  define('UPGRADE_INSTRUCTION_TEXT','This will attempt to talk to the live PhreeBooks&trade; versioning server to determine if an upgrade is available or not. If an update is available, a message will appear in admin.  Automatikusan NEM fog frissíteni semmit.<br />Később megváltoztathatod ezt a beállítást az >Config->My Store->Check if version update is available.');

?>
