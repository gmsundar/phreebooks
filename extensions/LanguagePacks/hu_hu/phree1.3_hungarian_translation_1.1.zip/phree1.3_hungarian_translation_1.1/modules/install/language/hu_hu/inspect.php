<?php
// +-----------------------------------------------------------------+
// |                   PhreeBooks Open Source ERP                    |
// +-----------------------------------------------------------------+
// | Copyright (c) 2007 PhreeSoft, LLC                               |
// | http://www.PhreeSoft.com                                        |
// +-----------------------------------------------------------------+
// | This program is free software: you can redistribute it and/or   |
// | modify it under the terms of the GNU General Public License as  |
// | published by the Free Software Foundation, either version 3 of  |
// | the License, or any later version.                              |
// |                                                                 |
// | This program is distributed in the hope that it will be useful, |
// | but WITHOUT ANY WARRANTY; without even the implied warranty of  |
// | MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the   |
// | GNU General Public License for more details.                    |
// |                                                                 |
// | The license that is bundled with this package is located in the |
// | file: /doc/manual/ch01-Introduction/license.html.               |
// | If not, see http://www.gnu.org/licenses/                        |
// +-----------------------------------------------------------------+
//  Path: /modules/install/includes/languages/hu_hu/inspect.php
//
// +---------------------------------------+
// | Hungarian translation/Magyar fordítás |
// +---------------------------------------+
// | Hungarian translation: Zsolt Győri    |
// | Hungarian bookkeeping: Tímea Tiszai   |
// | E-mail: gyori.zsolt@gmail.com         |
// | If you have any questions or comment  |
// | do not hesitate to contact us!        |
// +---------------------------------------+
// | Magyar fordítás: Győri Zsolt          |
// | Magyar könyvelés: Tiszai Tímea        |
// | E-mail: gyori.zsolt@gmail.com         |
// | Ha bármi kérdésed vagy észrevételed   |
// | van, ne habozz írni!                  |
// +---------------------------------------+

  define('TEXT_PAGE_HEADING', 'PhreeBooks&trade; Beállítás - Rendszer vizsgálat');
  define('INSTALL_BUTTON', ' Telepítés '); // this comes before TEXT_MAIN
  define('UPGRADE_BUTTON', 'Frissítés'); // this comes before TEXT_MAIN
  define('DB_UPGRADE_BUTTON', 'Adatbázis frissítés'); // this comes before TEXT_MAIN
  define('REFRESH_BUTTON', 'Újra ellenőriz');
//Button meanings: (to be made into help-text for future version):
// "Install" = make new configure.php files, regardless of existing contents.  Load new database by dropping old tables.
// "Upgrade" = read old configure.php files, and write new ones using new structure. Upgrade database, instead of wiping and new install
// "Database Upgrade" = don't write the configure.php files -- simply jump to the database-upgrade page. Only displayed if detected database version is new enough to not require configure.php file updates.

  define('TEXT_MAIN', 'Szánj néhány percet a beállításaid ellenőrzésére. Ezzel meggyőződhetsz róla, hogy webszervered minden a Phreebooks&trade által szükséges dolgot támogat-et. &nbsp;Kérlek javíts minden hibát és figyelmeztetést, mielőtt folytatnád. &nbsp;Majd kattints a <em>'.INSTALL_BUTTON.'&nbsp;</em> gombra a folytatáshoz.');
  define('SYSTEM_INSPECTION_RESULTS', 'Rendszer vizsgálat eredménye');
  define('OTHER_INFORMATION', 'Egyéb rendszer információ (Csak tájékoztatás céljából)');
  define('OTHER_INFORMATION_DESCRIPTION', 'A következő információ nem jelent szükségszerűen hibát vagy rossz beállítást. Csak tájékoztató jellegű.');

  define('NOT_EXIST','NEM TALÁLHATó');
  define('WRITABLE','Írható');
  define('UNWRITABLE',"<span class='errors'>Nem írható</span>");
  define('UNKNOWN','Ismeretlen');

  define('UPGRADE_DETECTION','Frissítés mód elérhető');
  define('LABEL_PREVIOUS_INSTALL_FOUND','Előző PhreeBooks telepítést találtam');
  define('LABEL_PREVIOUS_VERSION_NUMBER','Database appears to be PhreeBooks v%s');
  define('LABEL_PREVIOUS_VERSION_NUMBER_UNKNOWN','<em>However, the version level of your database cannot be determined, usually resulting from wrong table prefixes, or other database settings mismatches. <br /><br />CAUTION: Only use the Upgrade option if you are sure your configure.php settings are correct.</em>');

  define('DISPLAY_PHP_INFO','PHP infó hivatkozás: ');
  define('VIEW_PHP_INFO_LINK_TEXT','PHPINFO megtekintése a szervereden');
  define('LABEL_WEBSERVER','Webszerver');
  define('LABEL_MYSQL_AVAILABLE','MySQL támogatás');
  define('LABEL_MYSQL_VER','MySQL verzió');
  define('LABEL_DB_PRIVS','Adatbázis jogok');
  define('LABEL_POSTGRES_AVAILABLE','PostgreSQL támogatás');
  define('LABEL_PHP_VER','PHP verzió');
  define('LABEL_REGISTER_GLOBALS','Register Globals');
  define('LABEL_SET_TIME_LIMIT','PHP Max futási idő oldalanként');
  define('LABEL_DISABLED_FUNCTIONS','Letiltott PHP függvények');
  define('LABEL_SAFE_MODE','PHP biztonságos mód');
  define('LABEL_CURRENT_CACHE_PATH','Jelenlegi SQL cache könyvtár');
  define('LABEL_SUGGESTED_CACHE_PATH','Javasolt SQL cache könyvtár');
  define('LABEL_HTTP_HOST','HTTP kiszolgáló');
  define('LABEL_PATH_TRANLSATED','Elérési útvonal');
  define('LABEL_PHP_API_MODE','PHP API Mode');
  define('LABEL_PHP_MODULES','PHP Modules Active');
  define('LABEL_PHP_EXT_SESSIONS','PHP Sessions Support');
  define('LABEL_PHP_SESSION_AUTOSTART','PHP Session.AutoStart');
  define('LABEL_PHP_EXT_SAVE_PATH','PHP Session.Save_Path');
  define('LABEL_PHP_EXT_FTP','PHP FTP támogatás');
  define('LABEL_PHP_EXT_CURL','PHP cURL támogatás');
  define('LABEL_PHP_MAG_QT_RUN','PHP magic_quotes_runtime setting');
  define('LABEL_PHP_EXT_GD','PHP GD támogatás');
  define('LABEL_PHP_EXT_OPENSSL','PHP OpenSSL támogatás');
  define('LABEL_PHP_UPLOAD_STATUS','PHP feltöltés támogatás');
  define('LABEL_PHP_EXT_PFPRO','PHP Payflow Pro támogatás');
  define('LABEL_PHP_EXT_ZLIB','PHP ZLIB tömörítés támogatás');
  define('LABEL_PHP_SESSION_TRANS_SID','PHP session.use_trans_sid');
  define('LABEL_DISK_FREE_SPACE','Szerver szabad hely');
  define('LABEL_XML_SUPPORT','PHP XML támogatás');
  define('LABEL_OPEN_BASEDIR','PHP open_basedir megszorítások');
  define('LABEL_UPLOAD_TMP_DIR','PHP feltöltés TMP könyvtár');
  define('LABEL_SENDMAIL_FROM','PHP sendmail \'feladó\'');
  define('LABEL_SENDMAIL_PATH','PHP sendmail elérési út');
  define('LABEL_SMTP_MAIL','PHP SMTP elérhetőség');
  define('LABEL_CONFIG_WRITEABLE','/includes könyvtár írható');
  define('LABEL_MY_FILES_CREATE','/my_files könyvtár írható');
  define('LABEL_CRITICAL','Kritikus tételek');
  define('LABEL_RECOMMENDED','Javasolt tételek');
  define('LABEL_OPTIONAL','Opcionális tételek');
  define('LABEL_UPGRADE_PERMISSION','Permission to Update/Upgrade');

  define('LABEL_EXPLAIN','&nbsp;Kattints ide még több információért');
  define('LABEL_FOLDER_PERMISSIONS','Fájl és könyvtár jogosultságok');
  define('LABEL_WRITABLE_FOLDER_INFO','Néhány adminisztratív illetve napi munkához szükséges, hogy több könyvtárat/fájlt írhatóvá tegyél. Az írható-olvasható könyvtárak listáját az ajánlott CHMOD beállítással lentebb találhatod. Kérlek javítsd a hibákat a folytatás előtt.
Frissítsd a böngésződ az értékek újraellenőrzéséhez.<br /><br >Néhány kiszolgáló nem engedi a CHMOD 777 beállítást, csak a 666-ot. Először próbáld a nagyobb értéket, majd ha nem megy, a kisebbet.');

?>
