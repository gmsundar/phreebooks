<?php
// +-----------------------------------------------------------------+
// |                   PhreeBooks Open Source ERP                    |
// +-----------------------------------------------------------------+
// | Copyright (c) 2007 PhreeSoft, LLC                               |
// | http://www.PhreeSoft.com                                        |
// +-----------------------------------------------------------------+
// | This program is free software: you can redistribute it and/or   |
// | modify it under the terms of the GNU General Public License as  |
// | published by the Free Software Foundation, either version 3 of  |
// | the License, or any later version.                              |
// |                                                                 |
// | This program is distributed in the hope that it will be useful, |
// | but WITHOUT ANY WARRANTY; without even the implied warranty of  |
// | MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the   |
// | GNU General Public License for more details.                    |
// |                                                                 |
// | The license that is bundled with this package is located in the |
// | file: /doc/manual/ch01-Introduction/license.html.               |
// | If not, see http://www.gnu.org/licenses/                        |
// +-----------------------------------------------------------------+
//  Path: /modules/gen_ledger/language/hu_hu/language.php
//
// +---------------------------------------+
// | Hungarian translation/Magyar fordítás |
// +---------------------------------------+
// | Hungarian translation: Zsolt Győri    |
// | Hungarian bookkeeping: Tímea Tiszai   |
// | E-mail: gyori.zsolt@gmail.com         |
// | If you have any questions or comment  |
// | do not hesitate to contact us!        |
// +---------------------------------------+
// | Magyar fordítás: Győri Zsolt          |
// | Magyar könyvelés: Tiszai Tímea        |
// | E-mail: gyori.zsolt@gmail.com         |
// | Ha bármi kérdésed vagy észrevételed   |
// | van, ne habozz írni!                  |
// +---------------------------------------+

// General
define('TEXT_START_DATE','Kezdés dátuma');
define('TEXT_END_DATE','Befejezés dátuma');
define('TEXT_SELECT_FILE','Importálandó file: ');

// Titles and headings
define('GL_ENTRY_TITLE','Általános napló');
define('GL_HEADING_BEGINNING_BALANCES','Számlakeret - Kezdőmérlegek');
define('GL_HEADING_IMPORT_BEG_BALANCES','Kezdőmérlegek importálása');

// Audit Log Messages
define('GL_LOG_ADD_JOURNAL','Általános napló - ');
define('GL_LOG_FY_UPDATE','Általános napló a pénzügyi évről - ');
define('GL_LOG_PERIOD_CHANGE','Számlázási időszak - Változtat');
define('GL_LOG_PURGE_DB','Általános napló - Adatbázis megsemmisítése');

// Special buttons
define('GL_BTN_PURGE_DB','Naplóbejegyzések megsemmisítése');
define('GL_BTN_BEG_BAL','Add meg a kezdőmérleget');
define('GL_BTN_IMP_BEG_BALANCES','Raktárkészlet, Kötelezettségek számla, Követelések számla, Kezdőmérlegek importálása');
define('GL_BTN_CHG_ACCT_PERIOD', 'Aktuális számlázási időszak megváltoztatása');
define('GL_BTN_NEW_FY', 'Új pénzügyi év generálása');
define('GL_BTN_UPDATE_FY', 'Pénzügyi év változásainak frissítése');
define('GL_BB_IMPORT_INVENTORY','Készlet importálása');
define('GL_BB_IMPORT_PAYABLES','Kötelezettség számlák importálása');
define('GL_BB_IMPORT_RECEIVABLES','Követelés számlák importálása');
define('GL_BB_IMPORT_SALES_ORDERS','Bejövő rendelések importálása');
define('GL_BB_IMPORT_PURCH_ORDERS','Kimenő rendelések importálása');
define('GL_BB_IMPORT_HELP_MSG','További formátum beállításokért nézd meg a súgót.');

// GL Utilities
define('GL_UTIL_HEADING_TITLE', 'Általános napló karbantartás, beállítások');
define('GL_UTIL_PERIOD_LEGEND','Számlázási időszakok és Pénzügyi év');
define('GL_UTIL_BEG_BAL_LEGEND','Általános napló - Nyitómérlegek');
define('GL_UTIL_PURGE_ALL','Minden napló tranzakció törlése (újraindít)');
define('GL_FISCAL_YEAR','Pénzügyi év');
define('GL_UTIL_FISCAL_YEAR_TEXT','A pénzügyi időszak naptári idejét itt változtathatod. A pénzügyi év dátumait nem változtathatod bármilyen időszakra. Ezen időszak kezdetét leghamarabb az utolsó pénzügyi év után állíthatod.');
define('GL_UTIL_BEG_BAL_TEXT','Kezdő beállítások más számlázó rendszerbőlm.');
define('GL_UTIL_PURGE_DB','Összes naplóbejegyzés törlése (írd be \'purge\' a szövegdobozba és nyomd meg a töröl gombot)<br>');
define('GL_UTIL_PURGE_DB_CONFIRM','Biztos törölni akarod az összes naplóbejegyzést?');
define('GL_UTIL_PURGE_CONFIRM','Minden naplóbejegyzés törölve az adatbázisból.');
define('GL_UTIL_PURGE_FAIL','Nem lesz hatással a naplóbejegyzésekre!');
define('GL_CURRENT_PERIOD','Aktuális számlázási időszak: ');
define('GL_WARN_ADD_FISCAL_YEAR','Biztos fel akarod venni a pénzügyi évet: ');
define('GL_ERROR_FISCAL_YEAR_SEQ','A módosított pénzügyi év utolsó időszaka nem egyezik a következő pénzügyi év kezdetével. A következő pénzügyi év kezdődátumát módosítottam, vizsgáld felül.');
define('GL_WARN_CHANGE_ACCT_PERIOD','Add meg az aktuális számlázási időszakot:');
define('GL_ERROR_BAD_ACCT_PERIOD','A választott számlázási időszak nincs beállítva. Add meg újra az időszakot, vagy vegyél fel pénzügyi évet a folytatáshoz.');
define('GL_ERROR_NO_BALANCE','Nem lehet frissíteni a nyitómérleget, mert a letétek és a hitelek nem egyeznek!');
define('GL_ERROR_UPDATE_COA_HISTORY','Hiba a számlakeret történet frissítése közben, a nyitómérlegek beállítása után!');
define('GL_BEG_BAL_ERROR_0',' megtaláltam ebben a sorban ');
define('GL_BEG_BAL_ERROR_1','Érvénytelen számlakeret azonosítót találtam ebben a sorban ');
define('GL_BEG_BAL_ERROR_2A','Nem találtam számlaszámot ebben a sorban ');
define('GL_BEG_BAL_ERROR_2B','. Megjelölve, mint fizetésre vár!');
define('GL_BEG_BAL_ERROR_3','Kilépés az importálásból. Nem találtam számlaszámot a sorban ');
define('GL_BEG_BAL_ERROR_4A','Kilépek a scriptből. Hibás dátumformátumot találtam ebben a sorban ');
define('GL_BEG_BAL_ERROR_4B','. Ilyen formát várok ');
define('GL_BEG_BAL_ERROR_5','Sor kihagyása. 0 teljes mennyiséget találtam ebben a sorban ');
define('GL_BEG_BAL_ERROR_6','Érvénytelen számlakeret azonosítót találtam ebben a sorban ');
define('GL_BEG_BAL_ERROR_7','Raktári tétel kihagyása. 0 mennyiséget találtam ebben a sorban ');
define('GL_BEG_BAL_ERROR_8A','Sikertelen cikkszám frissítés # ');
define('GL_BEG_BAL_ERROR_8B',', a feldolgozás megszakítva.');
define('GL_BEG_BAL_ERROR_9A','Nem sikerült frissíteni a fiókot: # ');

// GL popup
define('TEXT_DISPLAY_NUMBER_OF_ACCTS', 'Megjelenítve <b>%d</b> - <b>%d</b> (<b>%d</b> főkönyvi számlák)');

// General Ledger Translations
define('GL_ERROR_JOURNAL_BAD_ACCT','Nem találom a főkönyvi számla számát!');
define('GL_ERROR_OUT_OF_BALANCE','Az űrlapot nem lehet elküldeni, mert tartozik és a követel oldal nem egyezik!');
define('GL_ERROR_BAD_ACCOUNT','Egy vagy több főkönyvi számla szám érvénytelen. Javítsd és próbáld újra.');
define('GL_ERROR_NO_ITEMS','Nincs elküldött tétel. Tétel felvételekor a mennyiség nem lehet üres.');
define('GL_ERROR_NO_POST','Hiba történt a feldolgozás közben, az űrlapot nem küldtem el.');
define('GL_ERROR_NO_DELETE','Hiba történt a feldolgozás közben, nem töröltem a rekordot.');
define('GL_ERROR_CANNOT_FIND_NEXT_ID','Nem tudom olvasni a következő rendelés/számla számot a táblából: ' . TABLE_CURRENT_STATUS);
define('GL_ERROR_CANNOT_DELETE_MAIN','Naplóbejegyzés törlése sikertelen # ');
define('GL_ERROR_CANNOT_DELETE_ITEM','Naplóbejegyzés törlése sikertelen # %d. Nem található sor!');
define('GL_ERROR_NEVER_POSTED','Nem tudom törölni a bejegyzést, mert soha nem lett elküldve.');
define('GL_DELETE_GL_ROW','Biztos törölni akarod ezt a napló sort?');
define('GL_DELETE_ALERT','Biztos törölni akarod a naplóbejegyzést?');
define('GL_ERROR_DIED_CREATING_RECORD','Sikertelen naplóbejegyzés létrehozás a következő azonosítóval = ');
define('GL_ERROR_POSTING_CHART_BALANCES','Hiba történt a keretszámla mérlegek küldése közben erre a számlaazonosítóra: ');
define('GL_ERROR_OUT_OF_BALANCE_A','Próbamérleg egyenlege negatív. Tartozás: ');
define('GL_ERROR_OUT_OF_BALANCE_B',' és hitelek: ');
define('GL_ERROR_OUT_OF_BALANCE_C',' időszakban ');
define('GL_ERROR_NO_GL_ACCT_NUMBER','Nincs megadva számlaszám a /gen_ledger.php függvényben: ');
define('GL_ERROR_UPDATING_ACCOUNT_HISTORY','Hiba történt a ügyfél/forgalmazó számlatörténetének frissítése közben.');
define('GL_ERROR_DELETING_ACCOUNT_HISTORY','Hiba történt a ügyfél/forgalmazó számlatörténetének törlése közben.');
define('GL_ERROR_UPDATING_INVENTORY_STATUS','Készlet frissítéséhez a cikkszámnak szerepelnie kell az adatbázisban. A hibát okozó cikkszám: ');
define('GL_ERROR_CALCULATING_COGS','ELÁBÉ kiszámításához a cikkszámnak szerepelnie kell az adatbázisban. A folyamat leállt.');
define('GL_ERROR_POSTING_INV_HISTORY','Készlet történet küldése sikertelen.');
define('GL_ERROR_UNPOSTING_COGS','ELÁBÉ visszagörgetése sikertelen.');
define('GL_ERROR_BAD_SKU_ENTERED','A cikkszám nem található. Nem történt művelet.');
define('GL_ERROR_SKU_NOT_ASSY','Nem lehet összeszerelni olyan tételt, amelynek nincsenek alkatrészei. Cikkszám: ');
define('GL_ERROR_NOT_ENOUGH_PARTS','Nincs elég alkatrész a kért mennyiség összeszereléséhez. Cikkszám: ');
define('GL_ERROR_POSTING_NEG_INVENTORY','Hiba az ELÁBÉ forgalmazói hitel felé küldése közben. Készlet negatív lesz és nem lehet ELÁBÉ-t számolni. Cikkszám: ');
define('GL_ERROR_SERIALIZE_QUANTITY','Hiba az ELÁBÉ számítása közben sorszámozott termék esetén. A mennyiség minden sorban egy legyen.');
define('GL_ERROR_SERIALIZE_EMPTY','Hiba az ELÁBÉ számítása közben sorszámozott termék esetén. A sorszám mező üres maradt!');
define('GL_ERROR_SERIALIZE_COGS','ELÁBÉ hiba. Nem találtam a sorszámot, vagy több terméket is találtam ezzel a sorszámmal.');
define('GL_ERROR_NO_RETAINED_EARNINGS_ACCOUNT','0 vagy több mint 1 visszatartott nyereség számlát találtam. Pontosan egy ilyen számla lehet a hibátlan működéshez!');

define('GL_DISPLAY_NUMBER_OF_ENTRIES', TEXT_DISPLAY_NUMBER . ' főkönyvi bejegyzések');
define('GL_TOTALS','Összesen:');
define('GL_OUT_OF_BALANCE','Negatív mérleg:');
define('GL_ACCOUNT_INCREASED','Számla növelve lesz');
define('GL_ACCOUNT_DECREASED','Számla csökkentve lesz');

define('GL_JOURNAL_ENTRY_COGS','Eladott áruk beszerzési értéke');

// Journal Entries
define('GENERAL_JOURNAL_0_DESC','Importált készlet nyitómérlegek');
define('GL_MSG_IMPORT_0_SUCCESS','Készlet nyitómérlegek importálása sikeresen megtörtént. Importált rekordok száma: ');
define('GL_MSG_IMPORT_0','Importált készlet nyitómérlegek');

define('GENERAL_JOURNAL_3_DESC','Beszerzési árajánlat');
define('GENERAL_JOURNAL_3_ERROR_2','PQ - A megadott kimenő rendelés szám már létezik, adj meg újat!');
define('GENERAL_JOURNAL_3_ERROR_5','PQ - Hiba történt a kimenő árajánlat számának növelésénél!');
define('GENERAL_JOURNAL_3_LEDGER_FREIGHT','Kimenő árajánlat fuvarköltsége');
define('GENERAL_JOURNAL_3_LEDGER_HEADING','Kimenő árajánlat összesen');

define('GENERAL_JOURNAL_4_DESC','Kimenő rendelés');
define('GENERAL_JOURNAL_4_ERROR_2','PO - A megadott kimenő rendelés száma már létezik, adj meg újat!');
define('GENERAL_JOURNAL_4_ERROR_5','PO - Hiba történt a kimenő rendelés számának növelésénél!');
define('GENERAL_JOURNAL_4_ERROR_6','PO - Nem törölhető a kimenő rendelés, ha már történt árufogadás!');
define('GENERAL_JOURNAL_4_LEDGER_FREIGHT','Kimenő rendelés fuvarköltsége');
define('GENERAL_JOURNAL_4_LEDGER_HEADING','Kimenő rendelés összesen');
define('GL_MSG_IMPORT_4_SUCCESS','Kimenő rendelések sikeresen importálva. Importált rekordok száma: ');
define('GL_MSG_IMPORT_4','Importált kimenő számlák');

define('GENERAL_JOURNAL_6_DESC','Beszerzés/Fogadás');
define('GENERAL_JOURNAL_6_ERROR_2','P/R - A megadott számla szám már létezik, adj meg újat!');
define('GENERAL_JOURNAL_6_ERROR_6','P/R - Nem lehet törölni a beszerzést, ha hiteljegyzőkönyv készült vagy kifizetés történt vele kapcsolatban!');
define('GENERAL_JOURNAL_6_LEDGER_FREIGHT','Beszerzés/Fogadás Fuvarköltség');
define('GENERAL_JOURNAL_6_LEDGER_HEADING','Beszerzés/Fogadás Készlet összesen');
define('GL_MSG_IMPORT_6_SUCCESS','Kötelezettség számla bejegyzések sikeresen importálva. Importált rekordok száma: ');
define('GL_MSG_IMPORT_6','Importált kötelezettség számlák');

define('GENERAL_JOURNAL_7_DESC','Forgalmazói hiteljegyzőkönyv bejegyzés');
define('GENERAL_JOURNAL_7_ERROR_2','VCM - A megadott hiteljegyzőkönyv szám már létezik, adj meg újat!');
define('GENERAL_JOURNAL_7_ERROR_5','VCM - Hiba történt a hiteljegyzőkönyv számának növelésénél!');
define('GENERAL_JOURNAL_7_ERROR_6','VCM - Nem lehet törölni a hiteljegyzőkönyvet, ha kifizetés történt vele kapcsolatban!');
define('GENERAL_JOURNAL_7_LEDGER_FREIGHT','Forgalmazói hiteljegyzőkönyv fuvarköltség');
define('GENERAL_JOURNAL_7_LEDGER_HEADING','Forgalmazói hiteljegyzőkönyv összesen');

define('GENERAL_JOURNAL_9_DESC','Eladási árajánlat');
define('GENERAL_JOURNAL_9_ERROR_2','SQ - Az árajánlat szám már létezik, adj meg újat!');
define('GENERAL_JOURNAL_9_ERROR_5','SQ - Hiba történt az árajánlat számának növelésénél!');
define('GENERAL_JOURNAL_9_LEDGER_FREIGHT','Árajánlat szállítási költség');
define('GENERAL_JOURNAL_9_LEDGER_HEADING','Árajánlat összesen');

define('GENERAL_JOURNAL_10_DESC','Bejövő rendelés megadása');
define('GENERAL_JOURNAL_10_ERROR_2','Bejövő rendelés - A megadott bejövő rendelés szám már létezik, adj meg újat!');
define('GENERAL_JOURNAL_10_ERROR_5','Bejövő rendelés - Sikertelen bejövő rendelés sorszám növelés!');
define('GENERAL_JOURNAL_10_ERROR_6','Bejövő rendelés - Nem lehet törölni a bejövő rendelést, ha már kiszállítás történt vele kapcsolatban!');
define('GENERAL_JOURNAL_10_LEDGER_FREIGHT','Bejövő rendelés szállítási költség');
define('GENERAL_JOURNAL_10_LEDGER_HEADING','Bejövő rendelések összesen');
define('GL_MSG_IMPORT_10_SUCCESS','Bejövő rendelések sikeresen importálva. Importált rekordok száma: ');
define('GL_MSG_IMPORT_10','Importált bejövő rendelések');

define('GENERAL_JOURNAL_12_DESC','Eladások/Számla megadás');
define('GENERAL_JOURNAL_12_ERROR_2','S/I - A megadott számlaszám már létezik, adj meg újat!');
define('GENERAL_JOURNAL_12_ERROR_5','S/I - Sikertelen számla sorszám növelés!');
define('GENERAL_JOURNAL_12_ERROR_6','S/I - Nem lehet törölni a számlát, ha már hiteljegyzőkönyv készült vagy kifizetés történt vele kapcsolatban!');
define('GENERAL_JOURNAL_12_LEDGER_FREIGHT','Forgalom/Számla Fuvarköltség');
define('GENERAL_JOURNAL_12_LEDGER_HEADING','Forgalom/Számla összesen');
define('GL_MSG_IMPORT_12','Importált követelés számla');
define('GL_MSG_IMPORT_12_SUCCESS','Követelések számla sikeresen importálva. Importált sorok száma: ');
define('GL_MSG_IMPORT_12','Importált számlák');

define('GENERAL_JOURNAL_13_DESC','Ügyfél hiteljegyzék');
define('GENERAL_JOURNAL_13_ERROR_2','CCM - A megadott hiteljegyzőkönyv szám már létezik, adj meg újat!');
define('GENERAL_JOURNAL_13_ERROR_5','CCM - Nem sikerült növelni a hiteljegyzőkönyv számot!');
define('GENERAL_JOURNAL_13_ERROR_6','CCM - Nem törölheted a hiteljegyzőkönyvet, ha már kifizetés történt vele kapcsolatban!');
define('GENERAL_JOURNAL_13_LEDGER_FREIGHT','Ügyfél hiteljegyzőkönyv Szállítási költség');
define('GENERAL_JOURNAL_13_LEDGER_HEADING','Ügyfél hiteljegyzőkönyv összesen');

define('GENERAL_JOURNAL_14_DESC','Alkatrész összeszerelés');

define('GENERAL_JOURNAL_16_DESC','Készlet módosítás');

define('GENERAL_JOURNAL_18_DESC','Ügyfél elismervények');
define('GENERAL_JOURNAL_18_ERROR_2','S/I - A megadott elismervény szám már létezik, adj meg újat!');
define('GENERAL_JOURNAL_18_ERROR_5','S/I - Sikertelen elismervény szám növelés!');
define('GENERAL_JOURNAL_18_ERROR_6','S/I - Nem törölheted az elismervényt, ha már kifizetés történt vele kapcsolatban!');
define('GENERAL_JOURNAL_18_DISCOUNT_HEADING','Ügyfél elismervény engedmények');
define('GENERAL_JOURNAL_18_LEDGER_HEADING','Ügyfél elismervények összesen');

/*
define('GENERAL_JOURNAL_19_DESC','Point of Sale Entry');
define('GENERAL_JOURNAL_19_ERROR_2','S/I - The receipt number you enterd is a duplicate, please enter a new receipt number!');
define('GENERAL_JOURNAL_19_ERROR_5','S/I - Failed incrementing the receipt number!');
define('GENERAL_JOURNAL_19_ERROR_6','S/I - An receipt cannot be deleted if there has been a payment applied!');
define('GENERAL_JOURNAL_19_LEDGER_FREIGHT','Point of Sale Freight Amount');
define('GENERAL_JOURNAL_19_DISCOUNT_HEADING','Customer Receipt Discount');
define('GENERAL_JOURNAL_19_LEDGER_HEADING','Point of Sale Total');
*/

define('GENERAL_JOURNAL_20_DESC','Forgalmazó fizetési bejegyzés');
define('GENERAL_JOURNAL_20_ERROR_2','P/R - A megadott csekkszám már létezik, adj meg újat!');
define('GENERAL_JOURNAL_20_ERROR_5','P/R - Nem sikerült növelni a fizetési számot!');
define('GENERAL_JOURNAL_20_ERROR_6','P/R - Nem lehet törölni a kifizetést, ha már ki lett egyenlítve!');
define('GENERAL_JOURNAL_20_DISCOUNT_HEADING','Forgalmazó kifizetések kedvezménye');
define('GENERAL_JOURNAL_20_LEDGER_HEADING','Forgalmazó kifizetések összesen');

/*
define('GENERAL_JOURNAL_21_DESC','Purchase Entry');
define('GENERAL_JOURNAL_21_ERROR_2','P/R - The check number you enterd is a duplicate, please enter a new check number!');
define('GENERAL_JOURNAL_21_ERROR_6','P/R - A purchase cannot be deleted if there has been a payment applied!');
define('GENERAL_JOURNAL_21_LEDGER_FREIGHT','Purchase Freight Amount');
define('GENERAL_JOURNAL_21_DISCOUNT_HEADING','Purchase Discount');
define('GENERAL_JOURNAL_21_LEDGER_HEADING','Purchase Total');
*/
?>
