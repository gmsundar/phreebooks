<?php
// +-----------------------------------------------------------------+
// |                   PhreeBooks Open Source ERP                    |
// +-----------------------------------------------------------------+
// | Copyright (c) 2007 PhreeSoft, LLC                               |
// | http://www.PhreeSoft.com                                        |
// +-----------------------------------------------------------------+
// | This program is free software: you can redistribute it and/or   |
// | modify it under the terms of the GNU General Public License as  |
// | published by the Free Software Foundation, either version 3 of  |
// | the License, or any later version.                              |
// |                                                                 |
// | This program is distributed in the hope that it will be useful, |
// | but WITHOUT ANY WARRANTY; without even the implied warranty of  |
// | MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the   |
// | GNU General Public License for more details.                    |
// |                                                                 |
// | The license that is bundled with this package is located in the |
// | file: /doc/manual/ch01-Introduction/license.html.               |
// | If not, see http://www.gnu.org/licenses/                        |
// +-----------------------------------------------------------------+
//  Path: /modules/reportwriter/language/hu_hu/language.php
//
// +---------------------------------------+
// | Hungarian translation/Magyar fordítás |
// +---------------------------------------+
// | Hungarian translation: Zsolt Győri    |
// | Hungarian bookkeeping: Tímea Tiszai   |
// | E-mail: gyori.zsolt@gmail.com         |
// | If you have any questions or comment  |
// | do not hesitate to contact us!        |
// +---------------------------------------+
// | Magyar fordítás: Győri Zsolt          |
// | Magyar könyvelés: Tiszai Tímea        |
// | E-mail: gyori.zsolt@gmail.com         |
// | Ha bármi kérdésed vagy észrevételed   |
// | van, ne habozz írni!                  |
// +---------------------------------------+

// Headings
define('RW_HEADING_TITLE','Kimutatások és Űrlapok');

// Report and Form page title definitions
define('RW_TITLE_RPTFRM','Kimutatás/Űrlap: ');
define('RW_TITLE_RPRBLDR','Kimutatás és űrlap készítő - ');
define('RW_TITLE_STEP1','Menü');
define('RW_TITLE_STEP2','Lépés 2');
define('RW_TITLE_STEP3','Lépés 3');
define('RW_TITLE_STEP4','Lépés 4');
define('RW_TITLE_STEP5','Lépés 5');
define('RW_TITLE_STEP6','Lépés 6');
define('RW_TITLE_MENU','Kimutatások menü');
define('RW_TITLE_CRITERIA','Feltételek beállítása');
define('RW_TITLE_PAGESAVE','Kimutatás mentése');
define('RW_TITLE_PAGESETUP','Kimutatás oldal beállítása');
define('RW_TITLE_SECURITY','Biztonsági beállítások');

// Javascript messages
define('RW_JS_SELECT_REPORT','Válassz kimutatást vagy űrlapot!');
define('RW_JS_ENTER_EXPORT_NAME','Adj meg nevet a definícióhoz');
define('RW_JS_ENTER_DESCRIPTION','Adj meg leírást a definícióhoz');

// General 
define('TEXT_CONTINUED','Folytatva');
define('TEXT_PAGE_SETUP','Oldalbeállítás');
define('TEXT_DB_LINKS','Adatbázis kapcsolatok');
define('TEXT_FIELD_SETUP','Mező beállítások');
define('TEXT_CRITERIA','Szűrési feltételek');
define('GL_CURRENT_PERIOD','Aktuális időszak');
define('TEXT_USE_ACCOUNTING_PERIODS','Számlázási időszakok használata (mező: időszak)');
define('TEXT_ALL_USERS','Engedélyezés minden felhasználónak');
define('TEXT_ALL_EMPLOYEES','Engedélyezés minden alkalmazottnak');
define('TEXT_ALL_DEPTS','Minden osztály számára enged');
define('TEXT_FORM_FIELD','Űrlap mező: ');
define('RW_NARRATIVE_DETAIL','Részletes leírás (max 255 karakter)');

// Paper Size Definitions
define('TEXT_PAPER','Papírméret:');
define('TEXT_ORIEN','Fekvés:');
define('TEXT_MM','mm');
define('TEXT_A3','A3');
define('TEXT_A4','A4');
define('TEXT_A5','A5');
define('TEXT_LEGAL','Legal');
define('TEXT_LETTER','Levél');
define('TEXT_PORTRAIT','Álló');
define('TEXT_LANDSCAPE','Fekvő');

// Font Names
define('TEXT_COURIER','Courier');
define('TEXT_HELVETICA','Helvetica');
define('TEXT_TIMES','Times');

// General Number Definitions
define('TEXT_1','1');
define('TEXT_2','2');
define('TEXT_3','3');
define('TEXT_4','4');
define('TEXT_5','5');
define('TEXT_6','6');
define('TEXT_7','7');
define('TEXT_8','8');
define('TEXT_9','9');
define('TEXT_10','10');
define('TEXT_12','12');
define('TEXT_14','14');
define('TEXT_16','16');
define('TEXT_18','18');
define('TEXT_20','20');
define('TEXT_24','24');
define('TEXT_28','28');
define('TEXT_32','32');
define('TEXT_36','36');
define('TEXT_40','40');
define('TEXT_50','50');

// Color definitions
define('TEXT_BLACK','Fekete');
define('TEXT_BROWN','Barna');
define('TEXT_RED','Piros');
define('TEXT_ORANGE','Narancs');
define('TEXT_YELLOW','Sárga');
define('TEXT_GREEN','Zöld');
define('TEXT_BLUE','Kék');
define('TEXT_VIOLET','Lila');
define('TEXT_GRAY','Szürke');
define('TEXT_WHITE','Fehér');

// Definitions for date selection dropdown list
define('TEXT_TODAY','Ma');
define('TEXT_WEEK','Ez a hét');
define('TEXT_WTD','Week to date');
define('TEXT_MONTH','Ebben a hónapban');
define('TEXT_MTD','Month To Date');
define('TEXT_QUARTER','Ez a negyedév');
define('TEXT_QTD','Quarter To Date');
define('TEXT_YEAR','Ez az év');
define('TEXT_YTD','Year To Date');

// definitions for db tables
define('TEXT_TABLE1','Tábla 1');
define('TEXT_TABLE2','Tábla 2');
define('TEXT_TABLE3','Tábla 3');
define('TEXT_TABLE4','Tábla 4');
define('TEXT_TABLE5','Tábla 5');
define('TEXT_TABLE6','Tábla 6');

// Message definitions
define('RW_RPT_SAVEDEF','A megadott név egy alapértelmezett kimutatás. Adj meg új nevet a kimutatásnak.');
define('RW_RPT_SAVEDUP','A kimutatás név már létezik! Kattints a cserére a felülíráshoz, vagy adj meg új nevet és kattints a folytatás gombra.');
define('RW_RPT_DUPDB','Hiba az adatbázis kiválasztásban. Ellenőrizd az adatbázis neveket.');
define('RW_RPT_BADFLD','Hiba az adatbázis mezőben vagy a leírásban. Ellenőrizd és próbáld újra.');
define('RW_RPT_BADDATA','Hiba az egyik adatmezőben. Ellenőrizd és próbáld újra.');
define('RW_RPT_FUNC_NOT_FOUND','Egy speciális függvény szükséges, de nem található. A hivatkozott speciális függvény: ');
define('RW_RPT_EMPTYFIELD','A következő sorszámú adatmező üresen maradt: ');
define('RW_RPT_EMPTYTABLE','An original data table entry was not found to create a duplicate of in sequence number: ');
define('RW_RPT_NO_SPECIAL_REPORT','Nincs megadva függvénynév. Vagy vedd ki a pipát vagy adj meg függvénynevet!');
define('RW_RPT_NO_TABLE_DATA','A kimutatás nem adott vissza sort. A tábla üres vagy hiba a linkben!');
define('RW_RPT_DEFDEL','Ha kicseréled ezt a kimutatást/űrlapot az eredeti kimutatás/űrlap törlődik!');
define('RW_RPT_NODATA','Nincs a feltételnek megfelelő találat!');
define('RW_RPT_NOROWS','A szűrési feltételeknek megfelelő kimutatás/űrlap nem tartalmaz adatot!');
define('RW_RPT_WASSAVED',' mentve és másolva a kimutatásba: ');
define('RW_RPT_UPDATED','A kimutatás neve frissítve!');
define('RW_FRM_NORPT','Nincs kiválasztott űrlap a művelethez.');
define('RW_RPT_NORPT','Nincs kiválasztott kimutatás a művelethez.');
define('RW_RPT_NORPTTYPE','Kimutatás vagy űrlap típust kell választanod!');
define('RW_RPT_REPDUP','A megadott név már használatban van. Adj meg új kimutatás nevet!');
define('RW_RPT_REPDEL','Kattints az OK-ra a kimutatás törléséhez.');
define('RW_RPT_REPOVER','Kattints az OK-ra a kimutatás felülírásához.');
define('RW_RPT_NOSHOW','Nincs megjeleníthető kimutatás!');
define('RW_RPT_NOFIELD','Nincs megjeleníthető mező!');
define('RW_FRM_RPTENTER','Add meg az űrlap nevét.');
define('RW_RPT_RPTENTER','Add meg a kimutatás nevét.');
define('RW_RPT_RPTNOENTER','(Importfile-ból származó kimutatásnév meghagyásához hagyd üresen)');
define('RW_RPT_MAX30','(maximum 30 karakter)');
define('RW_FRM_RPTGRP','Add meg az űrlap csoportját:');
define('RW_RPT_RPTGRP','Add meg a kimutatás csoportját:');
define('RW_RPT_DEFIMP','Válassz importálandó alapértelmezett kimutatást.');
define('RW_RPT_RPTBROWSE','Vagy tölts fel kimutatást.');
define('RW_RPT_SPECIAL_REPORT','Különleges kimutatás (Csak programozóknak)');
define('RW_RPT_CANNOT_EDIT','Ez egy beépített kimutatás, ezért a változtatásokat nem lehet menteni! Előbb másold át a jelentést egyéni jelentésnek, hogy módosíthasd.');
define('RW_FRM_NO_SELECTION','Válassz kimutatást vagy űrlapot!');
define('RW_RPT_EXPORT_SUCCESS','A kimutatás/űrlap sikeresen exportálva.');
define('RW_RPT_EXPORT_FAILED','A kimutatás/űrlap nincs exportálva!');

// Report  Specific
define('RW_RPT_RPTFILTER','Kimutatás szűrők: ');
define('RW_RPT_GROUPBY','Csoportosít:');
define('RW_RPT_SORTBY','Rendez:');
define('RW_RPT_DATERANGE','Időszak:');
define('RW_RPT_CRITBY','Szűrők:');
define('RW_RPT_ADMIN','Adminisztrátor oldal');
define('RW_RPT_BRDRLINE','Határvonal');
define('RW_RPT_BOXDIM','Single Line Outline Dimensions (mm)');
define('RW_RPT_COL1W','Oszlop 1');
define('RW_RPT_COL2W','Oszlop 2');
define('RW_RPT_COL3W','Oszlop 3');
define('RW_RPT_COL4W','Oszlop 4');
define('RW_RPT_COL5W','Oszlop 5');
define('RW_RPT_COL6W','Oszlop 6');
define('RW_RPT_COL7W','Oszlop 7');
define('RW_RPT_COL8W','Oszlop 8');
define('RW_RPT_CRITTYPE','Feltétel típusa');
define('RW_RPT_TYPECREATE','Válassz létrehozandó kimutatás vagy űrlap típust:');
define('RW_RPT_CWDEF','Oszlopszélesség - mm (0 for same as prior Oszlop)');
define('RW_RPT_CUSTRPT','Egyedi kimutatások');
define('RW_RPT_DATEDEF','Alapértelmezett dátum');
define('RW_RPT_DATEFNAME','Dátum mezőnév (tábla.mezőnév)');
define('RW_RPT_DATEINFO','Kimutatás dátuma');
define('RW_RPT_DATEINST','Uncheck all boxes for date independent reports; dátum mezőt hagyd üresen');
define('RW_RPT_DATELIST','Date Field List<br>(check all that apply)');
define('RW_RPT_DEFRPT','Alapértelmezett kimutatások');
define('RW_RPT_ENDPOS','End Position (mm)');
define('RW_RPT_ENTRFLD','Új mező megadása');
define('RW_RPT_FLDLIST','Mezőlista');
define('RW_RPT_FORMOUTPUT','Válassz űrlapot');
define('RW_RPT_FORMSELECT','Űrlapválasztás');
define('RW_RPT_GRPLIST','Lista csoportosítása');
define('RW_RPT_IMAGECUR','Jelenlegi kép');
define('RW_RPT_IMAGEUPLOAD','Kép feltöltése');
define('RW_RPT_IMAGESEL','Képválasztás');
define('RW_RPT_IMAGESTORED','Tárolt képből');
define('RW_RPT_IMAGEDIM','Kép méretei (mm)');
define('RW_RPT_LINEATTRIB','Sor tulajdonságok');
define('RW_RPT_LINEWIDTH','Sorszélesség (pts)');
define('RW_RPT_LINKEQ','Link Equation (Megjegyzés alul)');
define('RW_RPT_DB_LINK_HELP','The link equations must be in SQL snytax. Tables may be identified either by the table name from the db (as they appear in the drop-down menu), or better, by an alias [tablex] (x = 1 through 6) enclosed in brackets []. tablex is a reference to the table selected in the Table Name list dropdown. For example, [table1].id = [table2].ref_id would link the id field of the table selected in pull down Table 1 to the ref_id field from the table selected in the pull down Table 2. Using the alias will allow portability of the reports/forms to support database table prefixes, if used. After entering each line, reportwriter will verify the equation will make a valid SQL statement.');
define('RW_RPT_MYRPT','Kimutatásaim');
define('RW_RPT_NOBRDR','Nincs szegély');
define('RW_RPT_NOFILL','Nincs kitöltés');
define('RW_RPT_DISPNAME','Megjelenítendő név');
define('RW_RPT_PGFILDESC','Kimutatás szűrő leírás');
define('RW_RPT_PGHEADER','Fejléc információ / Formázás');
define('RW_RPT_PGLAYOUT','Oldalkinézet');
define('RW_RPT_PGMARGIN','Oldalszegély');
define('RW_RPT_RNRPT','Kimutatás átnevezése');
define('RW_RPT_PGTITL1','Kimutatás cím 1');
define('RW_RPT_PGTITL2','Kimutatás cím 2');
define('RW_RPT_RPTDATA','Kimutatás fejléce');
define('RW_RPT_RPTID','Kimutatás/Űrlap azonosítás');
define('RW_RPT_RPTIMPORT','Kimutatás importálása');
define('RW_RPT_SORTLIST','Rendező információ');
define('RW_RPT_STARTPOS','Kezdő pozíció (Bal felső sarok, mm-ben)');
define('RW_RPT_TBLNAME','Táblanév');
define('RW_RPT_TEXTATTRIB','Szöveg tulajdonságok');
define('RW_RPT_TEXTDISP','Megjelenítendő szöveg');
define('RW_RPT_TEXTPROC','Szöveg feldolgozás');
define('RW_RPT_TBLFNAME','Mezőnév');
define('RW_RPT_TOTALS','Kimutatás összesen');
define('RW_RPT_FLDTOTAL','Enter fields to total (Tábla.Mezőnév)');

// Form Group Definitions
define('RW_FRM_BANKCHK','Bank csekkek');
define('RW_FRM_BANKDEPSLIP','Bank terhelési értesítő');
define('RW_FRM_COLLECTLTR','Felszólítások');
define('RW_FRM_CUSTLBL','Címkék - Ügyfelek');
define('RW_FRM_CUSTQUOTE','Ügyfél árajánlatok');
define('RW_FRM_VENDQUOTE','Forgalmazó árajánlatok');
define('RW_FRM_CUSTSTATE','Ügyfél kimutatások');
define('RW_FRM_INVPKGSLIP','Számlák és Csomagoló címkék');
define('RW_FRM_CRDMEMO','Hiteljegyzőkönyvek - Ügyfelek');
define('RW_FRM_PURCHORD','Kimenő rendelések');
define('RW_FRM_SALESORD','Bejövő rendelések');
define('RW_FRM_SALESREC','Eladási elismervények');
define('RW_FRM_VENDLBL','Címkék - Forgalmazó');
define('RW_FRM_VENDOR_CRDMEMO','Hitel emélkeztetők - Forgalmazó');

// Form Processing Definitions
define('RW_FRM_CNVTDLR','Dollár konvertálás');
define('RW_FRM_CNVTEURO','Euro konvertálás');
define('RW_FRM_COMMA','Vessző - ,');
define('RW_FRM_COMMASP','Vessző-Szóköz');
define('RW_FRM_COYBLOCK','Cég adatblokk');
define('RW_FRM_COYDATA','Cég adatsor');
define('RW_FRM_DATABLOCK','Adatblokk');
define('RW_FRM_DATALINE','Adatsor');
define('RW_FRM_DATATABLE','Adattábla');
define('RW_FRM_DATATABLEDUP','Adattábla másolata');
define('RW_FRM_DATATOTAL','Adat összesen');
define('RW_FRM_DATE','Formázott dátum');
define('RW_FRM_DATE_TIME', 'Datum/Idő');
define('RW_FRM_FIXEDTXT','Fix szövegmező');
define('RW_FRM_IMAGE','Kép - JPG vagy PNG');
define('RW_FRM_LINE','Sor');
define('RW_FRM_LOWERCASE','Kisbetűs');
define('RW_FRM_NEGATE','Negál');
define('RW_FRM_NEWLINE','Sortörés');
define('RW_FRM_NOIMAGE','Nincs kép');
define('RW_FRM_NULLDLR','Null ha 0 - Dollár');
define('RW_FRM_NUM_2_WORDS','Number to Words');
define('RW_FRM_PAGENUM','Oldalszám');
define('RW_FRM_QUOTE_SINGLE', 'Egyszeres idézőjel - \'');
define('RW_FRM_QUOTE_DOUBLE', 'Dupla idézőjel - "');
define('RW_FRM_RECTANGLE','Téglalap');
define('RW_FRM_RNDR2','Kerekít (2 tizedesjegy)');
define('RW_FRM_SEMISP','Pontosvessző-szóköz');
define('RW_FRM_DELNL','Üres sor kihagyása');
define('RW_FRM_SPACE1','Egy szóköz');
define('RW_FRM_SPACE2','Dupla szóköz');
define('RW_FRM_TAB', 'Tab - \t');
define('RW_FRM_TERMS_TO_LANG','Nyelvi feltételek');
define('RW_FRM_UPPERCASE','Nagybetűs');
define('RW_FRM_ORDR_QTY','Rendelt mennyiség');
define('RW_BRANCH_ID','Kirendeltség azonosító');
define('RW_REP_ID','Felhasználónév');

/********************** DO NOT EDIT BELOW THIS LINE **********************************/

// Sets the default groups for forms, index max 4 chars
$ReportGroups = array (
	'ar' => TEXT_RECEIVABLES,
	'ap' => TEXT_PAYABLES,
	'inv' => TEXT_INVENTORY,
	'hr' => TEXT_HR,
	'man' => TEXT_MANUFAC,
	'bnk' => TEXT_BANKING,
	'gl' => TEXT_GL,
	'misc' => TEXT_MISC);  // do not delete misc category

// This array is imploded with the first entry = number of text boxes to build (0, 1 or 2), 
// the remaining is the dropdown menu listings
$CritChoices = array(
	0 => '2:' . TEXT_ALL . ':' . TEXT_RANGE,
	1 => '0:' . TEXT_YES . ':' . TEXT_NO,
	2 => '0:' . TEXT_ALL . ':' . TEXT_YES . ':' . TEXT_NO,
	3 => '0:' . TEXT_ALL . ':' . TEXT_ACTIVE . ':' . TEXT_INACTIVE,
	4 => '0:' . TEXT_ALL . ':' . TEXT_PRINTED . ':' . TEXT_UNPRINTED,
//	5 => NOT_USED_AVAILABLE,
	6 => '1:' . TEXT_EQUAL,
	7 => '2:' . TEXT_RANGE,
	8 => '1:' . TEXT_NOT_EQUAL,
	9 => '1:' . TEXT_IN_LIST);

// Paper orientation
$PaperOrientation = array (
	'P' => TEXT_PORTRAIT,
	'L' => TEXT_LANDSCAPE);
	
// Paper sizes supported in fpdf class, includes dimensions width, length in mm for page setup
$PaperSizes = array (
	'A3:297:420' => TEXT_A3,
	'A4:210:297' => TEXT_A4,
	'A5:148:210' => TEXT_A5,
	'Legal:216:357' => TEXT_LEGAL,
	'Letter:216:282' => TEXT_LETTER);

// Fonts (defaults for FPDF)
$Fonts = array (
	'helvetica' => TEXT_HELVETICA,
	'courier' => TEXT_COURIER,
	'times' => TEXT_TIMES);

// Available font sizes in units: points
$FontSizes = array (
	'8' => TEXT_8, 
	'10' => TEXT_10, 
	'12' => TEXT_12, 
	'14' => TEXT_14, 
	'16' => TEXT_16, 
	'18' => TEXT_18, 
	'20' => TEXT_20, 
	'24' => TEXT_24, 
	'28' => TEXT_28, 
	'32' => TEXT_32, 
	'36' => TEXT_36, 
	'40' => TEXT_40, 
	'50' => TEXT_50);

// Available font sizes in units: points
$LineSizes = array (
	'1' => TEXT_1, 
	'2' => TEXT_2, 
	'3' => TEXT_3, 
	'4' => TEXT_4, 
	'5' => TEXT_5, 
	'6' => TEXT_6, 
	'7' => TEXT_7, 
	'8' => TEXT_8, 
	'9' => TEXT_9, 
	'10' => TEXT_10);

// Font colors keyed by color Red:Green:Blue
$FontColors = array (
	'0:0:0' => TEXT_BLACK, // Leave black first as it is typically the default value
	'0:0:255' => TEXT_BLUE,
	'255:0:0' => TEXT_RED,
	'255:128:0' => TEXT_ORANGE,
	'255:255:0' => TEXT_YELLOW,
	'0:255:0' => TEXT_GREEN);

$FontAlign = array (
	'L' => TEXT_LEFT,
	'R' => TEXT_RIGHT,
	'C' => TEXT_CENTER);

$TotalLevels = array(
	'0' => TEXT_NO,
	'1' => TEXT_YES);

$DateChoices = array(
	'a' => TEXT_ALL,
	'b' => TEXT_RANGE,
	'c' => TEXT_TODAY,
	'd' => TEXT_WEEK,
	'e' => TEXT_WTD,
	'l' => GL_CURRENT_PERIOD,
	'f' => TEXT_MONTH,
	'g' => TEXT_MTD,
	'h' => TEXT_QUARTER,
	'i' => TEXT_QTD,
	'j' => TEXT_YEAR,
	'k' => TEXT_YTD);

/*********************************************************************************************
Form unique defaults
**********************************************************************************************/ 
// Sets the groupings for forms indexed to a specific report (top level) grouping, 
// index is of the form ReportGroup[index]:FormGroup[index], each have a max of 4 chars
// This array is linked to the ReportGroups array by using the index values of ReportGroup
// the first value must match an index value of ReportGroup.
$FormGroups = array (
	'gl:deps' => RW_FRM_BANKDEPSLIP,
	'ap:quot' => RW_FRM_VENDQUOTE,
	'ap:po' => RW_FRM_PURCHORD,
	'ap:chk' => RW_FRM_BANKCHK,	// Bank checks grouped with the ap (accounts payable report group
	'ap:cm' => RW_FRM_VENDOR_CRDMEMO,
	'ap:lblv' => RW_FRM_VENDLBL,
	'ar:quot' => RW_FRM_CUSTQUOTE,
	'ar:so' => RW_FRM_SALESORD,
	'ar:inv' => RW_FRM_INVPKGSLIP,
	'ar:cm' => RW_FRM_CRDMEMO,
	'ar:lblc' => RW_FRM_CUSTLBL,
	'ar:rcpt' => RW_FRM_SALESREC,
	'ar:cust' => RW_FRM_CUSTSTATE,
	'ar:col' => RW_FRM_COLLECTLTR,
	'misc:misc' => TEXT_MISC);  // do not delete misc category

// DataTypes
// A corresponding class function needs to be generated for each new function added.
// The index code is also used to identify the form to include to set the properties.
$FormEntries = array(
	'Data' => RW_FRM_DATALINE,
	'TBlk' => RW_FRM_DATABLOCK,
	'Tbl' => RW_FRM_DATATABLE,
	'TDup' => RW_FRM_DATATABLEDUP,
	'Ttl' => RW_FRM_DATATOTAL,
	'Text' => RW_FRM_FIXEDTXT,
	'Img' => RW_FRM_IMAGE,
	'Rect' => RW_FRM_RECTANGLE,
	'Line' => RW_FRM_LINE,
	'CDta' => RW_FRM_COYDATA,
	'CBlk' => RW_FRM_COYBLOCK,
	'PgNum' => RW_FRM_PAGENUM);

// The function to process these values is: ProcessData
// A case statement needs to be generated to process each new value
$FormProcessing = array(
	'' => TEXT_NONE,
	'uc' => RW_FRM_UPPERCASE,
	'lc' => RW_FRM_LOWERCASE,
	'neg' => RW_FRM_NEGATE,
	'rnd2d' => RW_FRM_RNDR2,
	'dlr' => RW_FRM_CNVTDLR,
	'null-dlr' => RW_FRM_NULLDLR,
	'euro' => RW_FRM_CNVTEURO,
	'date' => RW_FRM_DATE,
	'n2wrd'=> RW_FRM_NUM_2_WORDS,
	'terms' => RW_FRM_TERMS_TO_LANG,
	'ordr_qty' => RW_FRM_ORDR_QTY,
	'branch' => RW_BRANCH_ID,
	'rep_id' => RW_REP_ID);

// Defines special classes to use to gather form data for tables
$FormTblSpecialFuncs = array(
	'0' => TEXT_NONE,	// default for no class used
	'entry_builder' => 'Számlarészletek');

// The function to process these values is: AddSep
// A case statement needs to be generated to process each new value
$TextProcessing = array(
	'' => TEXT_NONE,
	'sp' => RW_FRM_SPACE1,
	'2sp' => RW_FRM_SPACE2,
	'comma' => RW_FRM_COMMA,
	'com-sp' => RW_FRM_COMMASP,
	'nl' => RW_FRM_NEWLINE,
	'semi-sp' => RW_FRM_SEMISP,
	'del-nl' => RW_FRM_DELNL);

?>
