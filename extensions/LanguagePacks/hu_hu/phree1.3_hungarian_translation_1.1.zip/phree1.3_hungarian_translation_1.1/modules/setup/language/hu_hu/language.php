<?php
// +-----------------------------------------------------------------+
// |                   PhreeBooks Open Source ERP                    |
// +-----------------------------------------------------------------+
// | Copyright (c) 2007 PhreeSoft, LLC                               |
// | http://www.PhreeSoft.com                                        |
// +-----------------------------------------------------------------+
// | This program is free software: you can redistribute it and/or   |
// | modify it under the terms of the GNU General Public License as  |
// | published by the Free Software Foundation, either version 3 of  |
// | the License, or any later version.                              |
// |                                                                 |
// | This program is distributed in the hope that it will be useful, |
// | but WITHOUT ANY WARRANTY; without even the implied warranty of  |
// | MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the   |
// | GNU General Public License for more details.                    |
// |                                                                 |
// | The license that is bundled with this package is located in the |
// | file: /doc/manual/ch01-Introduction/license.html.               |
// | If not, see http://www.gnu.org/licenses/                        |
// +-----------------------------------------------------------------+
//  Path: /modules/setup/language/hu_hu/language.php
//

// configuration
define('SETUP_CONFIG_EDIT_INTRO', 'Végezz el minden szükséges változtatást');
define('SETUP_INFO_DATE_ADDED', 'Felvéve:');
define('SETUP_INFO_LAST_MODIFIED', 'Módosítva:');
define('SETUP_NO_MODULE_NAME','A beállító szkriptnek szüksége van egy modul névre!');

// company manager
define('SETUP_CO_MGR_COPY_CO','Cég másolása');
define('SETUP_CO_MGR_COPY_HDR','Add meg az új cég adatbázisának nevét. (Meg kell felelned mind a mysql mind a file-rendszered elnevezési megkötéseinek. Ez tipikusan 8-12 karaktert jelent.) Ezt a nevet az adatbázison kívül egy könyvtár kapja a my_files könyvtáron belül. Ebben kapnak helyet majd a céggel kapcsolatos adatok. Ha nincs jogosultságod az adatbázis létrehozásához, kérd meg a rendszergazdát, hogy hozza létre a cég elkészítése előtt.');
define('SETUP_CO_MGR_DB_NAME','Adatbázis neve ');
define('SETUP_CO_MGR_DB_USER','Adatbázis felhasználónév ');
define('SETUP_CO_MGR_DB_PW','Adatbázis jelszó ');
define('SETUP_CO_MGR_CO_NAME','Cég teljes neve ');
define('SETUP_CO_MGR_SELECT_OPTIONS','Válaszd ki az új céghez másolandó táblákat.');
define('SETUP_CO_MGR_OPTION_1','Egész adatbázis másolása.');
define('SETUP_CO_MGR_OPTION_2','Számlatükör másolása.');
define('SETUP_CO_MGR_OPTION_3','Kimutatások/Űrlapok másolása.');
define('SETUP_CO_MGR_OPTION_4','Készlet másolása.');
define('SETUP_CO_MGR_OPTION_5','Ügyfelek másolása.');
define('SETUP_CO_MGR_OPTION_6','Forgalmazók másolása.');
define('SETUP_CO_MGR_OPTION_7','Alkalmazottak másolása.');
define('SETUP_CO_MGR_OPTION_8','Felhasználók másolása.');
define('SETUP_CO_MGR_ERROR_EMPTY_FIELD','Nem adtad meg az adatbázis és/vagy a cég nevét!');
define('SETUP_CO_MGR_NO_DB','Hiba az adatbázis létrehozása közben. Ellenőrizd a jogosultságokat és az adatbázis nevét. Lehet, hogy a rendszergazdának kell létrehoznia az adatbázist.');
define('SETUP_CO_MGR_DUP_DB_NAME','Hiba - Az adatbázis neve nem lehet ugyanaz, mint a jelenlegi!');
define('SETUP_CO_MGR_CANNOT_CONNECT','Hiba az új adatbázishoz való kapcsolódás közben. Ellenőrizd a felhasználónevet jelszót.');
define('SETUP_CO_MGR_Hiba_1','Hiba a táblák létrehozása közben.');
define('SETUP_CO_MGR_Hiba_2','Hiba a táblák adatokkal való feltöltése közben.');
define('SETUP_CO_MGR_Hiba_3','Hiba a cég könyvtárainak létrehozása közben.');
define('SETUP_CO_MGR_Hiba_4','Hiba a cég konfigurációs file-jának létrehozása közben.');
define('SETUP_CO_MGR_Hiba_5A','Hiba a tábla eldobásánál ');
define('SETUP_CO_MGR_Hiba_5B','. Adatbázis Hiba # ');
define('SETUP_CO_MGR_Hiba_6','Hiba a tábla másolása közben ');
define('SETUP_CO_MGR_Hiba_7','Hiba a demo adatok betöltése közben.');
define('SETUP_CO_MGR_CREATE_SUCCESS','Az új cég sikeresen létrehozva');
define('SETUP_CO_MGR_DELETE_SUCCESS','A cég sikeresen törölve!');
define('SETUP_CO_MGR_LOG','Cégkezelő - ');

define('SETUP_CO_MGR_ADD_NEW_CO','Új cég létrehozása');
define('SETUP_CO_MGR_ADD_NEW_DEMO','Adatbázis feltöltése demo adatokkal.');

define('SETUP_CO_MGR_DEL_CO','Cég törlése');
define('SETUP_CO_MGR_SELECT_DELETE','Válaszd ki a törlendő céget.');
define('SETUP_CO_MGR_DELETE_CONFIRM','FIGYELMEZTETÉS: EZ TÖRÖLNI FOGJA AZ ADATBÁZIST ÉS MINDEN A CÉGGEL KAPCSOLATOS FILE-T! MINDEN ADAT EL FOG VESZNI!');
define('SETUP_CO_MGR_JS_DELETE_CONFIRM','Biztosan törölni akarod a céget?');

?>
