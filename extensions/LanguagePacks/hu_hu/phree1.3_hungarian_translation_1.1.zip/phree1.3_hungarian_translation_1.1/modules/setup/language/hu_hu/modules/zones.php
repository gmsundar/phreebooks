<?php
// +-----------------------------------------------------------------+
// |                   PhreeBooks Open Source ERP                    |
// +-----------------------------------------------------------------+
// | Copyright (c) 2007 PhreeSoft, LLC                               |
// | http://www.PhreeSoft.com                                        |
// +-----------------------------------------------------------------+
// | This program is free software: you can redistribute it and/or   |
// | modify it under the terms of the GNU General Public License as  |
// | published by the Free Software Foundation, either version 3 of  |
// | the License, or any later version.                              |
// |                                                                 |
// | This program is distributed in the hope that it will be useful, |
// | but WITHOUT ANY WARRANTY; without even the implied warranty of  |
// | MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the   |
// | GNU General Public License for more details.                    |
// |                                                                 |
// | The license that is bundled with this package is located in the |
// | file: /doc/manual/ch01-Introduction/license.html.               |
// | If not, see http://www.gnu.org/licenses/                        |
// +-----------------------------------------------------------------+
//  Path: /modules/setup/language/hu_hu/modules/zones.php
//

define('SETUP_TITLE_ZONES', 'Megyék/Régiók');
define('SETUP_HEADING_NEW_ZONE', 'Új Megye/Régió');
define('SETUP_HEADING_EDIT_ZONE', 'Megye/Régió szerkesztése');
define('SETUP_INFO_HEADING_DELETE_ZONE', 'Megye/Régió törlése');
define('SETUP_HEADING_ZONE_CODE', 'Kód');
define('SETUP_ZONES_EDIT_INTRO', 'Végezz el minden szükséges változtatást');
define('SETUP_INFO_ZONES_NAME', 'Megye/Régió neve:');
define('SETUP_INFO_ZONES_CODE', 'Megye/Régió kódja:');
define('SETUP_ZONES_INSERT_INTRO', 'Add meg az új megyét/régiót az adataival együtt');
define('SETUP_ZONES_DELETE_INTRO', 'Biztos törölni akarod a megyét/régiót?');
define('TEXT_DISPLAY_NUMBER_OF_ZONES', TEXT_DISPLAY_NUMBER . 'megyék/régiók');
define('SETUP_ZONES_LOG','Megyék/Régiók - ');

?>
