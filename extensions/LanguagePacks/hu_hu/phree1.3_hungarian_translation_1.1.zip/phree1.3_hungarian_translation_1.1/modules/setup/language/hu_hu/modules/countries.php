<?php
// +-----------------------------------------------------------------+
// |                   PhreeBooks Open Source ERP                    |
// +-----------------------------------------------------------------+
// | Copyright (c) 2007 PhreeSoft, LLC                               |
// | http://www.PhreeSoft.com                                        |
// +-----------------------------------------------------------------+
// | This program is free software: you can redistribute it and/or   |
// | modify it under the terms of the GNU General Public License as  |
// | published by the Free Software Foundation, either version 3 of  |
// | the License, or any later version.                              |
// |                                                                 |
// | This program is distributed in the hope that it will be useful, |
// | but WITHOUT ANY WARRANTY; without even the implied warranty of  |
// | MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the   |
// | GNU General Public License for more details.                    |
// |                                                                 |
// | The license that is bundled with this package is located in the |
// | file: /doc/manual/ch01-Introduction/license.html.               |
// | If not, see http://www.gnu.org/licenses/                        |
// +-----------------------------------------------------------------+
//  Path: /modules/setup/language/hu_hu/modules/countries.php
//

define('SETUP_TITLE_COUNTRIES', 'Országok');
define('SETUP_COUNTRY_CODE_CODES', 'ISO kódok');
define('SETUP_COUNTRY_EDIT_INTRO', 'Végezz el minden szükséges változtatást');
define('SETUP_INFO_COUNTRY_NAME', 'Ország neve');
define('SETUP_INFO_COUNTRY_CODE_2', 'ISO kód (2)');
define('SETUP_INFO_COUNTRY_CODE_3', 'ISO kód (3)');
define('SETUP_INFO_ADDRESS_FORMAT', 'Címformátum:');
define('SETUP_COUNTRY_INSERT_INTRO', 'Add meg az új országot az adataival együtt');
define('SETUP_COUNTRY_DELETE_INTRO', 'Biztosan törölni akarod ezt az országot?');
define('SETUP_INFO_HEADING_NEW_COUNTRY', 'Új ország');
define('SETUP_INFO_HEADING_EDIT_COUNTRY', 'Ország szerkesztése');
define('SETUP_INFO_HEADING_DELETE_COUNTRY', 'Ország törlése');
define('TEXT_DISPLAY_NUMBER_OF_COUNTRIES', TEXT_DISPLAY_NUMBER . 'országok');
define('SETUP_LOG_COUNTRIES','Országok - ');

?>
