<?php
// +-----------------------------------------------------------------+
// |                   PhreeBooks Open Source ERP                    |
// +-----------------------------------------------------------------+
// | Copyright (c) 2007 PhreeSoft, LLC                               |
// | http://www.PhreeSoft.com                                        |
// +-----------------------------------------------------------------+
// | This program is free software: you can redistribute it and/or   |
// | modify it under the terms of the GNU General Public License as  |
// | published by the Free Software Foundation, either version 3 of  |
// | the License, or any later version.                              |
// |                                                                 |
// | This program is distributed in the hope that it will be useful, |
// | but WITHOUT ANY WARRANTY; without even the implied warranty of  |
// | MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the   |
// | GNU General Public License for more details.                    |
// |                                                                 |
// | The license that is bundled with this package is located in the |
// | file: /doc/manual/ch01-Introduction/license.html.               |
// | If not, see http://www.gnu.org/licenses/                        |
// +-----------------------------------------------------------------+
//  Path: /modules/setup/language/hu_hu/modules/tax_auths.php
//

define('SETUP_TITLE_TAX_AUTHS', 'Adóhatóság - eladás');

define('SETUP_TAX_DESC_SHORT', 'Rövid név');
define('SETUP_TAX_GL_ACCT', 'Főkönyvi azonosító');
define('SETUP_TAX_RATE', 'Adókulcs (százalék)');

define('SETUP_TAX_AUTH_EDIT_INTRO', 'Végezz el minden szükséges változtatást');
define('SETUP_INFO_DESC_SHORT', 'Rövid név (max 15 karakter)');
define('SETUP_INFO_DESC_LONG', 'Hosszú név (max 64 karakter)');
define('SETUP_INFO_GL_ACCOUNT', 'Főkönyv az adó rögzítésére:');
define('SETUP_INFO_VENDOR_ID', 'Vendor to submit funds to:');
define('SETUP_INFO_TAX_RATE', 'Adókulcs (százalékban)');
define('SETUP_TAX_AUTH_INSERT_INTRO', 'Add meg az új adóhatóságot a tulajdonságaival együtt');
define('SETUP_TAX_AUTH_DELETE_INTRO', 'Biztosan törölni akarod ezt az adóhatóságot?');
define('SETUP_TAX_AUTHS_DELETE_ERROR','Nem lehet törölni az adóhatóságot, naplóbejegyzés használja.');
define('SETUP_INFO_HEADING_NEW_TAX_AUTH', 'Új adóhatóság');
define('SETUP_INFO_HEADING_EDIT_TAX_AUTH', 'Adóhatóság szerkesztése');
define('SETUP_INFO_HEADING_DELETE_TAX_AUTH', 'Adóhatóság törlése');
define('SETUP_TAX_AUTHS_LOG','Tax Authorities - ');

define('SETUP_DISPLAY_NUMBER_OF_TAX_AUTH', TEXT_DISPLAY_NUMBER . 'adóhatóságok');

?>
