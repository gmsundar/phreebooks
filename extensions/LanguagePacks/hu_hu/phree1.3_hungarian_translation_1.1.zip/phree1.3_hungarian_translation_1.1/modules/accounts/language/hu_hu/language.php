<?php
// +-----------------------------------------------------------------+
// |                   PhreeBooks Open Source ERP                    |
// +-----------------------------------------------------------------+
// | Copyright (c) 2007 PhreeSoft, LLC                               |
// | http://www.PhreeSoft.com                                        |
// +-----------------------------------------------------------------+
// | This program is free software: you can redistribute it and/or   |
// | modify it under the terms of the GNU General Public License as  |
// | published by the Free Software Foundation, either version 3 of  |
// | the License, or any later version.                              |
// |                                                                 |
// | This program is distributed in the hope that it will be useful, |
// | but WITHOUT ANY WARRANTY; without even the implied warranty of  |
// | MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the   |
// | GNU General Public License for more details.                    |
// |                                                                 |
// | The license that is bundled with this package is located in the |
// | file: /doc/manual/ch01-Introduction/license.html.               |
// | If not, see http://www.gnu.org/licenses/                        |
// +-----------------------------------------------------------------+
//  Path: /modules/accounts/language/hu_hu/language.php
//
// +---------------------------------------+
// | Hungarian translation/Magyar fordítás |
// +---------------------------------------+
// | Hungarian translation: Zsolt Győri    |
// | Hungarian bookkeeping: Tímea Tiszai   |
// | E-mail: gyori.zsolt@gmail.com         |
// | If you have any questions or comment  |
// | do not hesitate to contact us!        |
// +---------------------------------------+
// | Magyar fordítás: Győri Zsolt          |
// | Magyar könyvelés: Tiszai Tímea        |
// | E-mail: gyori.zsolt@gmail.com         |
// | Ha bármi kérdésed vagy észrevételed   |
// | van, ne habozz írni!                  |
// +---------------------------------------+

// Targeted defines (to differentiate wording differences for different account types)
switch ($_GET['type']) {
  case 'v': // Text specific to Vendor accounts
  	define('ACT_TYPE_NAME','Forgalmazók');
	define('ACT_HEADING_TITLE', 'Forgalmazók');
	define('ACT_SHORT_NAME', 'Forgalmazó azonosító');
	define('ACT_GL_ACCOUNT_TYPE','Beszerzési főkönyv számla');
	define('ACT_ID_NUMBER','Munkáltatói azonosító');
	define('ACT_REP_ID','Beszerzési raktár azonosító');
	define('ACT_ACCOUNT_NUMBER','Számlaszám');
	define('ACT_FIRST_DATE','Forgalmazónk');
	define('ACT_LAST_DATE1','Utolsó számlázás ideje');
	define('ACT_LAST_DATE2','Utolsó fizetés ideje');
	define('ACT_PAGE_TITLE_EDIT','Forgalmazó szerkesztése');
	break;
  case 'e': // Text specific to Employee accounts
	define('ACT_TYPE_NAME','Alkalmazottak');
	define('ACT_HEADING_TITLE', 'Alkalmazottak');
	define('ACT_SHORT_NAME', 'Alkalmazott azonosító');
	define('ACT_GL_ACCOUNT_TYPE','Munkakör');
	define('ACT_ID_NUMBER','TAJ szám');
	define('ACT_REP_ID','Osztály azonosító');
	define('ACT_ACCOUNT_NUMBER','Nem használt');
	define('ACT_FIRST_DATE','Bérlés dátuma');
	define('ACT_LAST_DATE1','Utolsó fizetésemelés');
	define('ACT_LAST_DATE2','Munkaviszony vége');
	define('ACT_PAGE_TITLE_EDIT','Alkalmazott szerkesztése');
	break;
  case 'b': // Text specific to branch accounts			képviselet???
	define('ACT_TYPE_NAME','Részleg');
	define('ACT_HEADING_TITLE', 'Részlegek');
	define('ACT_SHORT_NAME', 'Részleg azonosító');
	define('ACT_GL_ACCOUNT_TYPE','Nem használt');
	define('ACT_ID_NUMBER','Nem használt');
	define('ACT_REP_ID','Nem használt');
	define('ACT_ACCOUNT_NUMBER','Nem használt');
	define('ACT_FIRST_DATE','Létrehozva');
	define('ACT_LAST_DATE1','Nem használt');
	define('ACT_LAST_DATE2','Nem használt');
	define('ACT_PAGE_TITLE_EDIT','Részleg szerkesztése');
	break;
  case 'c': // Text specific to Customer accounts (default)
  default:
	define('ACT_TYPE_NAME','Ügyfelek');
	define('ACT_HEADING_TITLE', 'Ügyfelekk');
	define('ACT_SHORT_NAME', 'Ügyfél azonosító');
	define('ACT_GL_ACCOUNT_TYPE','Eladási főkönyv');
	define('ACT_ID_NUMBER','Viszonteladói engedélyszám');
	define('ACT_REP_ID','Értékesítő azonosítója');
	define('ACT_ACCOUNT_NUMBER','Számlaszám');
	define('ACT_FIRST_DATE','Ügyfelünk');
	define('ACT_LAST_DATE1','Utolsó számla dátuma');
	define('ACT_LAST_DATE2','Utolsó fizetés dátuma');
	define('ACT_PAGE_TITLE_EDIT','Ügyfél szerkesztése');
} // End of targeted defines

// Category headings
define('ACT_CATEGORY_CONTACT','Kapcsolati információk');
define('ACT_CATEGORY_MAIN_ADDRESS','Levelezési cím');
define('ACT_CATEGORY_INFORMATION','Fiók információk');
define('ACT_CATEGORY_SHIPPING_ADDRESS','Szállítási címek');
define('ACT_CATEGORY_PAYMENT_TERMS','Fizetési feltételek');
define('ACT_CATEGORY_BILLING_ADDRESS','Számlázási címek');

// Account Terms (used in several modules)
define('ACT_SPECIAL_TERMS','Különleges feltételek');
define('ACT_TERMS_DUE','Feltételek (esedékesség)');
define('ACT_TERMS_DEFAULT','Alapértelmezett: ');
define('ACT_TERMS_USE_DEFAULTS', 'Alapértelmezett feltételek használata');
define('ACT_COD_SHORT','Utánvétes fizetés');
define('ACT_COD_LONG','Fizetés átvételkor');
define('ACT_PREPAID','Előre fizetett');
define('ACT_SPECIAL_TERMS', 'Különleges feltételek');
define('ACT_END_OF_MONTH','Lejárat hónapban');
define('ACT_DAY_NEXT_MONTH','Esedékesség a megadott napon');
define('ACT_DUE_ON', 'Esedékesség: ');
define('ACT_DISCOUNT', 'Engedmény ');
define('ACT_EARLY_DISCOUNT', ' százalék. ');
define('ACT_EARLY_DISCOUNT_SHORT', '% ');
define('ACT_DUE_IN','Fizetési határidő ');
define('ACT_TERMS_EARLY_DAYS', ' nap. ');
define('ACT_TERMS_NET','Net ');
define('ACT_TERMS_STANDARD_DAYS', ' nap. ');
define('ACT_TERMS_CREDIT_LIMIT', 'Hitelkeret: ');

// Account table fields - common to all account types
define('ACT_POPUP_WINDOW_TITLE', 'Fiók keresése');
define('ACT_POPUP_TERMS_WINDOW_TITLE', 'Fizetési feltételek');

// misc information messages
define('ACT_DISPLAY_NUMBER_OF_ACCOUNTS', 'Megjelenítve <b>%d</b> - <b>%d</b> (<b>%d</b> ' . ACT_TYPE_NAME . ')');
define('ACT_WARN_DELETE_ADDRESS','Biztosan törölni akarod ezt a címet?');
define('ACT_WARN_DELETE_ACCOUNT', 'Biztosan törölni akarod a fiókot?');
define('ACT_ERROR_CANNOT_DELETE','Nem tudom törölni ezt a fiókot a journal record contains this account');
define('ACT_ERROR_DUPLICATE_ACCOUNT','Ez a fiókazonosító már létezik a rendszerben, adj meg újat.');
define('ACT_ERROR_NO_ACCOUNT_ID','Ügyfél/Forgalmazó felvételekor meg kell adnod egy egyedi azonosítót.');
define('ACT_BILLING_MESSAGE','Ezek a mezők nem szükségesek, kivéve számlázási cím felvétele esetén.');
define('ACT_SHIPPING_MESSAGE','Ezek a mezők nem szükségesek, kivéve szállítási cím felvétele esetén.');

define('ACT_LIST_OPEN_ORDERS','Nyitott rendelések');
define('ACT_LIST_OPEN_INVOICES','Nyitot számlák');

// java script errors
define('ACT_JS_SHORT_NAME', '* A \'Ügyfél azonosító\' mező nem lehet üres.\n');

// Audit log messages
define('ACT_LOG_ADD_ACCOUNT','Fiók felvéve - ');
define('ACT_LOG_UPDATE_ACCOUNT','Fiók frissítve - ');
define('ACT_LOG_DELETE_ACCOUNT','Fiók törölve - ');

?>
