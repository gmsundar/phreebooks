<?php
// +-----------------------------------------------------------------+
// |                   PhreeBooks Open Source ERP                    |
// +-----------------------------------------------------------------+
// | Copyright (c) 2007 PhreeSoft, LLC                               |
// | http://www.PhreeSoft.com                                        |
// +-----------------------------------------------------------------+
// | This program is free software: you can redistribute it and/or   |
// | modify it under the terms of the GNU General Public License as  |
// | published by the Free Software Foundation, either version 3 of  |
// | the License, or any later version.                              |
// |                                                                 |
// | This program is distributed in the hope that it will be useful, |
// | but WITHOUT ANY WARRANTY; without even the implied warranty of  |
// | MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the   |
// | GNU General Public License for more details.                    |
// |                                                                 |
// | The license that is bundled with this package is located in the |
// | file: /doc/manual/ch01-Introduction/license.html.               |
// | If not, see http://www.gnu.org/licenses/                        |
// +-----------------------------------------------------------------+
//  Path: /modules/general/language/hu_hu/language.php
//
// +---------------------------------------+
// | Hungarian translation/Magyar fordítás |
// +---------------------------------------+
// | Hungarian translation: Zsolt Győri    |
// | Hungarian bookkeeping: Tímea Tiszai   |
// | E-mail: gyori.zsolt@gmail.com         |
// | If you have any questions or comment  |
// | do not hesitate to contact us!        |
// +---------------------------------------+
// | Magyar fordítás: Győri Zsolt          |
// | Magyar könyvelés: Tiszai Tímea        |
// | E-mail: gyori.zsolt@gmail.com         |
// | Ha bármi kérdésed vagy észrevételed   |
// | van, ne habozz írni!                  |
// +---------------------------------------+

define('LANGUAGE','MAGYAR&nbsp; (HU)');

// look in your $PATH_LOCALE/locale directory for available locales.
// on RedHat6.0 I used 'en_US'
// on FreeBSD 4.0 I use 'en_US.ISO_8859-1'
// this may not work under win32 environments..
setlocale(LC_TIME, 'hu_HU.ISO_8859-2');

define('DATE_FORMAT', 'Y/m/d'); // this is used for date()
define('DATE_TIME_FORMAT', DATE_FORMAT . ' %H:%M:%S');
define('DATE_FORMAT_SPIFFYCAL', 'yyyy/MM/dd');  //Use only 'dd', 'MM' and 'yyyy' here in any order
define('MAX_NUM_PRICE_LEVELS', 5);
define('MAX_NUM_ADDRESSES', 5); // *****  For Import/Export Module, set the maximum number of addresses *****

// Global entries for the <html> tag
define('HTML_PARAMS','dir="ltr" lang="hu"');

// charset for web pages and emails
define('CHARSET', 'utf-8');

// Meta-tags: page title
define('TITLE', 'PhreeBooks');

// header text in includes/header.php
define('HEADER_TITLE_TOP', 'Főoldal');
define('HEADER_TITLE_LOGOFF', 'Kilépés');

// Menu heading translations
define('MENU_HEADING_CUSTOMERS', 'Ügyfelek');
define('MENU_HEADING_VENDORS', 'Forgalmazók');
define('MENU_HEADING_INVENTORY', 'Készlet');
define('MENU_HEADING_BANKING', 'Bankműveletek');
define('MENU_HEADING_GL', 'Főkönyv');
define('MENU_HEADING_EMPLOYEES', 'Alkalmazottak');
define('MENU_HEADING_SETUP', 'Beállítások');
define('MENU_HEADING_TOOLS', 'Eszközök');
define('MENU_HEADING_QUALITY','Minőség');
define('MENU_HEADING_REPORTS', 'Kimutatások');
define('MENU_HEADING_COMPANY','Cég');

// Report Group Definitions (import/export tabs, reports/forms)
define('TEXT_RECEIVABLES','Követelések');
define('TEXT_PAYABLES','Kötelezettségek');
define('TEXT_INVENTORY','Készlet');
define('TEXT_HR','Humán erőforrás');
define('TEXT_MANUFAC','Gyártás');
define('TEXT_BANKING','Bankműveletek');
define('TEXT_GL','Főkönyv');
define('TEXT_MISC','Egyéb');

// General Ledger Menu Labels
define('BOX_GL_JOURNAL_ENTRY', 'Napló');
define('BOX_GL_ACCOUNTS', 'Számlakeret');
define('BOX_GL_UTILITIES', 'Általános napló beállítások');

// Accounts Menu Labels
define('BOX_ACCOUNTS_NEW_CUSTOMER', 'Új ügyfél');
define('BOX_ACCOUNTS_MAINTAIN_CUSTOMERS', 'Ügyfelek karbantartása');
define('BOX_ACCOUNTS_NEW_EMPLOYEE', 'Új alkalmazott');
define('BOX_ACCOUNTS_MAINTAIN_EMPLOYEES', 'Alkalmazottak karbantartása');
define('BOX_ACCOUNTS_NEW_VENDOR', 'Új forgalmazó');
define('BOX_ACCOUNTS_MAINTAIN_VENDORS', 'Forgalmazók karbantartása');
define('BOX_ACCOUNTS_NEW_BRANCH', 'Új képviselet');
define('BOX_ACCOUNTS_MAINTAIN_BRANCHES', 'Képviseletek karbantartása');

// Banking Menu Labels
define('BOX_BANKING_CUSTOMER_RECEIPTS', 'Ügyfél elismervények');
define('BOX_BANKING_CUSTOMER_PAYMENTS', 'Ügyfél kifizetések');
define('BOX_BANKING_PAY_BILLS', 'Számlák fizetése');
define('BOX_BANKING_VENDOR_RECEIPTS', 'Beszállítói elismervények');
define('BOX_BANKING_SELECT_FOR_PAYMENT', 'Select for Payment');
define('BOX_BANKING_BANK_ACCOUNT_REGISTER', 'Bankszámlanyilvántartás');
define('BOX_BANKING_ACCOUNT_RECONCILIATION', 'Számlaegyeztetés');
define('BOX_BANKING_VOID_CHECKS', 'Üres csekkek');

// HR Menu Labels
define('BOX_HR_MAINTAIN', 'Alkalmazottak karbantartása');
define('BOX_HR_MAINTAIN_REPS', 'Eladási raktár karbantartása');
define('BOX_HR_PAYROLL_ENTRY', 'Bérjegyzék');
define('BOX_HR_DEPARTMENTS', 'Osztályok');
define('BOX_HR_DEPT_TYPES', 'Osztály típusok');

// Inventory Menu labels
define('BOX_INV_MAINTAIN', 'Szerkeszt/Karbantart');
define('BOX_INV_PURCHASE_RECEIVE', 'Vásárol/Fogad');
define('BOX_INV_ADJUSTMENTS', 'Beállítások');
define('BOX_INV_ASSEMBLIES', 'Összeszerelések');
define('BOX_INV_DEFAULTS', 'Készlet alapértelmezett beállítások');
define('BOX_INV_REPORTS', 'Kimutatások');
define('BOX_INV_CATEGORIES', 'Raktár mező kategóriák beállítása');
define('BOX_INV_FIELDS', 'Raktár mezők beállítás');

// Payables Menu Labels
define('BOX_AP_PURCHASE_ORDER', 'Kimenő rendelések');
define('BOX_AP_CREDIT_MEMO', 'Forgalmazói hitel emlékeztetők');
define('BOX_AP_DEFAULTS', 'Forgalmazók alapbeállításai');
define('BOX_AP_REPORTS', 'Kimutatások');
define('BOX_AP_REQUEST_QUOTE', 'Árajánlatkérés');
define('BOX_AP_RECEIVE_INVENTORY', 'Vásárlás/Fogadás');
define('BOX_AP_ORDER_STATUS', 'Kimenő rendelés kezelése');
//define('BOX_AP_WRITE_CHECK', 'Csekkek írása');

// Receivables Menu Labels
define('BOX_AR_SALES_ORDER', 'Bejövő rendelések');
define('BOX_AR_QUOTE', 'Árajánlatok');
define('BOX_AR_INVOICE', 'Eladások/Számlák');
define('BOX_AR_CREDIT_MEMO', 'Ügyfél hiteljegyzőkönyvek');
define('BOX_AR_SHIPMENTS', 'Szállítások');
define('BOX_AR_ORDER_STATUS', 'Bejövő rendelés kezelő');
define('BOX_AR_DEFAULTS', 'Ügyfél alapértelmezett beállítások');
//define('BOX_AR_POINT_OF_SALE','Értékesítési hely');
define('BOX_AR_INVOICE_MGR', 'Számlakezelő');

// Setup/Misc Menu Labels
define('BOX_TAX_AUTH', 'Adóhatóság - eladás');
define('BOX_TAX_RATES', 'Adókulcs - eladás');
define('BOX_TAXES_COUNTRIES', 'Országok');
define('BOX_TAXES_ZONES', 'Megye/Régió');
define('BOX_CURRENCIES', 'Pénznemek');
define('BOX_LANGUAGES', 'Nyelvek');

// Configuration and defaults menu
define('BOX_HEADING_SEARCH','Keresés');
define('BOX_HEADING_USERS','Felhasználók');
define('BOX_COMPANY_CONFIG','Beállítások');

// Tools Menu Labels
define('BOX_IMPORT_EXPORT', 'Import/Export');
define('BOX_SHIPPING_MANAGER', 'Szállításkezelő');
define('BOX_COMPANY_MANAGER', 'Cégkezelő');

// Services Menu Labels
define('BOX_SHIPPING', 'Szállítási beállítások');
define('BOX_PAYMENTS', 'Fizetési beállítások');
define('BOX_PRICE_SHEETS', 'Árlista beállítások');
define('BOX_PRICE_SHEET_MANAGER', 'Árlista kezelő');

// Quality Menu Labels
define('BOX_QUALITY_HOME','Minőség főoldal');

// General Headings
define('GEN_HEADING_PLEASE_SELECT','Kérlek válassz...');

// User Manager
define('HEADING_TITLE_USERS','Felhasználók');
define('HEADING_TITLE_USER_INFORMATION','Felhasználói adatok');

// Address/contact identifiers
define('GEN_PRIMARY_NAME', 'Elsődleges/Cég név');
define('GEN_EMPLOYEE_NAME', 'Alkalmazott neve');
define('GEN_CONTACT', 'Figyelem');
define('GEN_ADDRESS1', 'Címsor 1');
define('GEN_ADDRESS2', 'Címsor 2');
define('GEN_CITY_TOWN', 'Város');
define('GEN_STATE_PROVINCE', 'Megye');
define('GEN_POSTAL_CODE', 'Irányítószám');
define('GEN_COUNTRY', 'Ország');
define('GEN_COUNTRY_CODE', 'ISO kód');

define('GEN_FIRST_NAME','Családi név');
define('GEN_MIDDLE_NAME','Középső név');
define('GEN_LAST_NAME','Keresztnév');
define('GEN_TELEPHONE1', 'Telefon');
define('GEN_TELEPHONE2', 'Telefon2');
define('GEN_FAX','Fax');

define('GEN_USERNAME','Felhasználónév');
define('GEN_DISPLAY_NAME','Megjelenített név');
define('GEN_ACCOUNT_ID', 'Fiók azonosító');
define('GEN_CUSTOMER_ID', 'Ügyfél azonosító:');
define('GEN_STORE_ID', 'Raktár azonosító');
define('GEN_VENDOR_ID', 'Forgalmazó azonosító:');
define('GEN_EMAIL_ADDRESS','E-mail');
define('GEN_WEBSITE','Weboldal');
define('GEN_ACCOUNT_LINK','Link az alkalmazott fiókjához');

// General definitions
define('TEXT_ABSCISSA','X tengely');
define('TEXT_ACCOUNT_TYPE', 'Fiók típusa');
define('TEXT_ACCOUNTS', 'Fiókok');
define('TEXT_ACCT_DESCRIPTION', 'Fiók leírása');
define('TEXT_ACTIVE','Aktív');
define('TEXT_ACTION','Művelet');
define('TEXT_ADD','Felvesz');
define('TEXT_ADJUSTMENT','Beállítások');
define('TEXT_ALL','Mind');
define('TEXT_ALIGN','Igazít');
define('TEXT_AMOUNT','Mennyiség');
define('TEXT_AND','és');
define('TEXT_BACK','Vissza');
define('TEXT_BALANCE','Egyenleg');
define('TEXT_BOTTOM','Le');
define('TEXT_BREAK','Megszakít');
define('TEXT_CANCEL','Mégsem');
define('TEXT_CARRIER','Szállítóeszköz');
define('TEXT_CATEGORY_NAME', 'Kategórianév');
define('TEXT_CAUTION','Figyelem');
define('TEXT_CENTER','Közép');
define('TEXT_CHANGE','Változtat');
define('TEXT_CLEAR','Töröl');
define('TEXT_CLOSE','Bezár');
define('TEXT_COLLAPSE','Bezár');
define('TEXT_COLLAPSE_ALL','Bezár mind');
define('TEXT_COLOR','Szín');
define('TEXT_COLUMN','Oszlop');
define('TEXT_COPY','Másol');
define('TEXT_COPY_TO','Másol ide');
define('TEXT_CONFIRM_PASSWORD','Jelszó megerősítése');
define('TEXT_CONTINUE','Folytat');
define('TEXT_CREDIT_AMOUNT','Hitelkeret');
define('TEXT_CRITERIA','Feltétel');
define('TEXT_CUSTCOLOR','Egyéni szín (0-255)');
define('TEXT_CURRENT','Aktuális');
define('TEXT_CUSTOM','Egyedi');
define('TEXT_DATE','Dátum');
define('TEXT_DEBIT_AMOUNT','Tartozás mértéke');
define('TEXT_DELETE','Töröl');
define('TEXT_DEFAULT','Alapértelmezett');
define('TEXT_DEPARTMENT','Kirendeltség');
define('TEXT_DESCRIPTION','Leírás');
define('TEXT_DISCOUNT','Engedmény');
define('TEXT_DOWN','Le');
define('TEXT_EDIT','Szerkeszt');
define('TEXT_ENTER_NEW', 'Adj meg új ...');
define('TEXT_ERROR','Hiba');
define('TEXT_EQUAL','Megegyezik');
define('TEXT_ESTIMATE','Becsül');
define('TEXT_EXPAND','Kinyit');
define('TEXT_EXPAND_ALL','Kinyit mind');
define('TEXT_EXPORT','Export');
define('TEXT_EXPORT_CSV','Exportál CSV-be');
define('TEXT_EXPORT_PDF','Exportál PDF-be');
define('TEXT_FALSE','Hamis');
define('TEXT_FIELD', 'Mező: ');
define('TEXT_FIELDS','Mezők');
define('TEXT_FILE_UPLOAD','File feltöltés');
define('TEXT_FILL','Kitölt');
define('TEXT_FILTER','Szűr');
define('TEXT_FINISH','Befejez');
define('TEXT_FORM','Űrlap');
define('TEXT_FORMS','Űrlapok');
define('TEXT_FLDNAME','Mező neve');
define('TEXT_FONT','Font');
define('TEXT_FROM','Feladó');
define('TEXT_FULL','Teljes');
define('TEXT_GET_RATES','Átváltási arányok letöltése');
define('TEXT_GL_ACCOUNT','Főkönyv');
define('TEXT_GROUP','Csoport');
define('TEXT_HEIGHT','Magasság');
define('TEXT_HELP', 'Súgó');
define('TEXT_HORIZONTAL','Vízszintes');
define('TEXT_IMPORT','Importál');
define('TEXT_INACTIVE','Inaktív');
define('TEXT_INFO', 'Infó'); // Information
define('TEXT_INSERT', 'Beszúr');
define('TEXT_INSTALL', 'Telepít');
define('TEXT_INVOICE', 'Számla');
define('TEXT_INVOICES', 'Számlák');
define('TEXT_IN_LIST', 'Listában (csv)');
define('TEXT_ITEMS', 'Tételek');
define('TEXT_LEFT','Bal');
define('TEXT_LENGTH','Hossz');
define('TEXT_LEVEL','Szint');
define('TEXT_MOVE','Mozgat');
define('TEXT_NO','Nem');
define('TEXT_NONE', '--Nincs--');
define('TEXT_NOTES', 'Megjegyzések');
define('TEXT_NEW', 'Új');
define('TEXT_NOT_EQUAL','Nem egyenlő');
define('TEXT_NUM_AVAILABLE', '# Elérhető');
define('TEXT_NUM_REQUIRED', '# Szükséges');
define('TEXT_OF','of');
define('TEXT_OPEN','Megnyit');
define('TEXT_OPTIONS','Beállítások');
define('TEXT_ORDER','Rendel');
define('TEXT_ORDINATE','Függőleges tengely');
define('TEXT_PAGE','Oldal');
define('TEXT_PASSWORD','Jelszó');
define('TEXT_PAY','Fizet');
define('TEXT_PAYMENT','Kifizetés');
define('TEXT_PAYMENT_METHOD','Fizetési mód');
define('TEXT_PAYMENTS','Kifizetések');
define('TEXT_PERIOD','Időszak');
define('TEXT_PGCOYNM','Cég neve');
define('TEXT_POST_DATE', 'Elküldve');
define('TEXT_PRICE', 'Ár');
define('TEXT_PRICE_MANAGER', 'Árlisták');
define('TEXT_PRINT','Nyomtat');
define('TEXT_PRINTED','Nyomtatva');
define('TEXT_PROCESSING', 'Feldolgozás alatt');
define('TEXT_PROPERTIES','Tulajdonságok');
define('TEXT_PO_NUMBER', 'Kimenő rendelés #');
define('TEXT_QUANTITY','Mennyiség');
define('TEXT_RANGE','Tartomány');
define('TEXT_READ_ONLY','Csak olvasható');
define('TEXT_RECEIVE','Fogad');
define('TEXT_RECEIVE_ALL','Összes fogadása');
define('TEXT_RECEIPTS','Elismervények');
define('TEXT_RECUR','Ismétlődő');
define('TEXT_REFERENCE','Hivatkozás');
define('TEXT_REMOVE','Eltávolít');
define('TEXT_RENAME','Átnevez');
define('TEXT_REPLACE','Helyettesít');
define('TEXT_REPORT','Kimutatás');
define('TEXT_REPORTS','Kimutatások');
define('TEXT_RESET','Visszaállít');
define('TEXT_REVISE','Módosít');
define('TEXT_RIGHT','Jobb');
define('TEXT_SAVE', 'Ment');
define('TEXT_SAVE_AS', 'Mentés másként');
define('TEXT_SEARCH', 'Keresés');
define('TEXT_SECURITY','Biztonság');
define('TEXT_SECURITY_SETTINGS','Biztonsági beállítások');
define('TEXT_SELECT','Válassz');
define('TEXT_SEPARATOR','Elválasztó');
define('TEXT_SERIAL_NUMBER','Sorozatszám');
define('TEXT_SERVICE_NAME','Szolgáltatás neve');
define('TEXT_SEQUENCE', 'Sorozat');
define('TEXT_SHIP','Szállít');
define('TEXT_SHIP_ALL','Szállít mind');
define('TEXT_SHOW','Megjelenít');
define('TEXT_SLCTFIELD','Válassz mezőt...');
define('TEXT_SEQ','Sorrend');
define('TEXT_SIZE','Méret');
define('TEXT_SKU','Cikkszám');
define('TEXT_SORT','Rendez');
define('TEXT_SORT_ORDER','Rendezési sorrend');
define('TEXT_SOURCE', 'Forrás');
define('TEXT_STATUS','Státusz');
define('TEXT_STATISTICS','Statisztika');
define('TEXT_STDCOLOR','Alap szín');
define('TEXT_SUCCESS','Sikeres');
define('TEXT_SYSTEM', 'Rendszer');
define('TEXT_TIME', 'Idő');
define('TEXT_TITLE', 'Megnevezés');
define('TEXT_TO','Címzett');
define('TEXT_TOP','Fel');
define('TEXT_TOTAL','Összesen');
define('TEXT_TRIM', 'Trim');
define('TEXT_TRUE','Igaz');
define('TEXT_TRUNCATE','Csonkít');
define('TEXT_TRUNC','Hosszú leírások levágása');
define('TEXT_TYPE','Típus');
define('TEXT_UNIT_PRICE','Egységár');
define('TEXT_UNPRINTED','Nincs nyomtatva');
define('TEXT_UP','Fel');
define('TEXT_UPDATE','Frissít');
define('TEXT_URL','URL');
define('TEXT_USERS','Felhasználók');
define('TEXT_UTILITIES','Eszközök');
define('TEXT_VALUE', 'Érték');
define('TEXT_VERTICAL','Függőleges');
define('TEXT_VIEW','Megtekint');
define('TEXT_WEIGHT','Tömeg');
define('TEXT_WIDTH','Szélesség');
define('TEXT_YES','Igen');

// javascript messages
define('JS_ERROR', 'Hiba történt az űrlapod feldolgozása közben!\nKérlek javítsd a következőket:\n\n');

// Audit log messages
define('GEN_LOG_LOGIN','Belépés -> ');
define('GEN_LOG_LOGIN_FAILED','Hibás belépés - azonosító -> ');
define('GEN_LOG_LOGOFF','Kilépés -> ');
define('GEN_LOG_RESEND_PW','Jelszó elküldve ide -> ');
define('GEN_LOG_USER_ADD','Felhasználó karbantartás - Felvett felhasználónév -> ');
define('GEN_LOG_USER_COPY','Felhasználó karbantartás - Másolás');
define('GEN_MSG_COPY_INTRO','Add meg az új felhasználónevet.');
define('GEN_ERROR_DUPLICATE_ID','A felhasználónév már foglalt. Válassz másik nevet.');
define('GEN_MSG_COPY_SUCCESS','Felhasználó másolása megtörtént. Állítsd be a jelszót és egyéb tulajdonságait a felhasználónak.');
define('GEN_LOG_USER_UPDATE','Felhasználó karbantartás - Frissített felhasználónév -> ');
define('GEN_LOG_USER_DELETE','Felhasználó karbantartás - Törölt felhasználónév -> ');

// constants for use in prev_next_display function
define('TEXT_RESULT_PAGE', 'Oldal %s / %d');
define('TEXT_GO_FIRST','Ugrás az első oldalra');
define('TEXT_GO_PREVIOUS','Előző oldal');
define('TEXT_GO_NEXT','Következő oldal');
define('TEXT_GO_LAST','Ugrás az utolsó oldalra');
define('TEXT_DISPLAY_NUMBER', 'Megjelenítve <b>%d</b> - <b>%d</b> (<b>%d</b>) ');
define('PREVNEXT_BUTTON_PREV', '&lt;&lt;');
define('PREVNEXT_BUTTON_NEXT', '&gt;&gt;');
define('TEXT_FIELD_REQUIRED', '&nbsp;<span class="fieldRequired">*</span>');

// misc error messages
define('GEN_ERRMSG_NO_DATA','Egy szükséges mezőt üresen hagytál. Neve: ');
define('ERROR_MSG_BAD_POST_DATE','Figyelem! Az elküldés ideje kívül esik a jelenlegi számlázási időszakon!');
define('ERROR_MSG_POST_DATE_NOT_IN_FISCAL_YEAR','Az elküldés ideje nem esik bele egyik jelenleg definiált pénzügyi évbe sem. Vagy változtasd meg az elküldés dátumát, vagy vedd fel a szükséges pénzügyi évet.');
define('ERROR_NO_PERMISSION','Nincs jogosultságod a kért művelet végrehajtásához. Lépj kapcsolatba a rendszergazdával a hozzáférési jogok megszerzéséhez.');
define('ERROR_NO_DEFAULT_CURRENCY_DEFINED', 'Hiba: Jelenleg nincs alapértelmezett pénznem. Kérlek állíts be egyet: Beállítások->Pénznemek');

// search filters
define('TEXT_ASC','+');
define('TEXT_DESC','-');
define('TEXT_INFO_SEARCH_DETAIL_FILTER','Keresési szűrő: ');
define('TEXT_INFO_SEARCH_PERIOD_FILTER','Számlázási időszak: ');
define('HEADING_TITLE_SEARCH_DETAIL','Keres: ');

// Version Check notices
define('TEXT_VERSION_CHECK_NEW_VER','Új PhreeBooks elérhető. Telepített verzió: <b>%s.</b> Letölthető verzió = <b>%s.</b>');

// control panel defines
define('CP_ADD_REMOVE_BOXES','Profildoboz felvétele/eltávolítása');
define('CP_CHANGE_PROFILE','Profil változtatás...');

// Defines for login screen
define('HEADING_TITLE', 'PhreeBooks belépés');
define('TEXT_LOGIN_NAME', 'Felhasználónév: ');
define('TEXT_LOGIN_PASS', 'Jelszó: ');
define('TEXT_LOGIN_COMPANY','Válassz céget: ');
define('TEXT_LOGIN_LANGUAGE','Válassz nyelvet: ');
define('TEXT_LOGIN_THEME','Válassz témát: ');
define('TEXT_LOGIN_BUTTON','Belépés');
define('ERROR_WRONG_LOGIN', 'Rossz felhasználónevet vagy jelszót adtál meg.');
define('TEXT_PASSWORD_FORGOTTEN', 'Jelszó újraküldése');

// Defines for users.php
define('ENTRY_PASSWORD_NEW_ERROR_NOT_MATCHING', 'A jelszó és a jelszó megerősítése nem egyezik.');
define('ENTRY_PASSWORD_NEW_ERROR', 'Az új jelszavadnak legalább ' . ENTRY_PASSWORD_MIN_LENGTH . ' karakter hosszúnak kell lennie.');
define('TEXT_DELETE_INTRO_USERS', 'Biztosan törölni akarod a felhasználói fiókot?');
define('TEXT_DELETE_ENTRY', 'Biztosan törölni akarod a bejegyzést?');

// defines for password forgotten
define('LOST_HEADING_TITLE', 'Jelszó újraküldése');
define('TEXT_ADMIN_EMAIL', 'E-mail cím: ');
define('ERROR_WRONG_EMAIL', '<p>Rossz e-mail címet adtál meg.</p>');
define('ERROR_WRONG_EMAIL_NULL', '<p>Szép próbálkozás :-P</p>');
define('SUCCESS_PASSWORD_SENT', '<p>Sikeres: Az új jelszót elküldtem az e-mail címedre.</p>');
define('TEXT_EMAIL_SUBJECT', 'A kért változtatás');
define('TEXT_EMAIL_FROM', EMAIL_FROM);
define('TEXT_EMAIL_MESSAGE', 'Az új jelszó iránti kérelem a(z) ' . $_SESSION['REMOTE_ADDR'] . 'címről érkezett.' . "\n\n" . 'Az új jelszavad a(z) \'' . STORE_NAME . '\' nevű cég adatbázisába való belépéshez:' . "\n\n" . '   %s' . "\n\n");

// Error messages for importing reports, forms and import/export functions
define('TEXT_IMP_ERMSG1','A file mérete nagyobb, mint a php.ini beállításokban definiált upload_max_filesize változó értéke.');
define('TEXT_IMP_ERMSG2','A file mérete nagyobb, mint a beállításokban megengedett MAX_FLE_SIZE változóban definiált.');
define('TEXT_IMP_ERMSG3','Nem sikerült a teljes file-t feltölteni. Kérlek próbáld újra.');
define('TEXT_IMP_ERMSG4','Nincs feltöltésre kiválasztott file.');
define('TEXT_IMP_ERMSG5','Ismeretlen php feltöltési hiba. Hiba php kódja:r # ');
define('TEXT_IMP_ERMSG6','A szerver szerint ez nem szöveges file.');
define('TEXT_IMP_ERMSG7','A feltöltött file nem tartalmaz adatot!');
define('TEXT_IMP_ERMSG8','Nem találtam érvényes importálandó jelentés a feltöltött file-ban!');
define('TEXT_IMP_ERMSG9',' sikeresen importálva!');
define('TEXT_IMP_ERMSG10','Nem várt hiba történt a feltöltés során!');
define('TEXT_IMP_ERMSG11','Sikeresen importáltam a file-t!');
define('TEXT_IMP_ERMSG12','Az export file nem tartalmazott adatot!');
define('TEXT_IMP_ERMSG13','Nem várt hiba a feltöltés során! Nem lett file feltöltve.');
define('TEXT_IMP_ERMSG14','Hiba a bemeneti file-ban. Found more than 2 text qualifiers! A hibás szöveg: ');
define('TEXT_IMP_ERMSG15','The import file needs an index reference value to process the data! Include data and check the \'Show\' box for field name: ');

// Define code used on database for identifying type of employees
$employee_types = array(
	'e' => 'Alkalmazott',
	's' => 'Eladó',
	'b' => 'Mindkettő');

?>
