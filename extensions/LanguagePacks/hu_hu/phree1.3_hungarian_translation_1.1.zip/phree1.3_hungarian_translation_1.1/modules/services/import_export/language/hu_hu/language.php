<?php
// +-----------------------------------------------------------------+
// |                   PhreeBooks Open Source ERP                    |
// +-----------------------------------------------------------------+
// | Copyright (c) 2007 PhreeSoft, LLC                               |
// | http://www.PhreeSoft.com                                        |
// +-----------------------------------------------------------------+
// | This program is free software: you can redistribute it and/or   |
// | modify it under the terms of the GNU General Public License as  |
// | published by the Free Software Foundation, either version 3 of  |
// | the License, or any later version.                              |
// |                                                                 |
// | This program is distributed in the hope that it will be useful, |
// | but WITHOUT ANY WARRANTY; without even the implied warranty of  |
// | MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the   |
// | GNU General Public License for more details.                    |
// |                                                                 |
// | The license that is bundled with this package is located in the |
// | file: /doc/manual/ch01-Introduction/license.html.               |
// | If not, see http://www.gnu.org/licenses/                        |
// +-----------------------------------------------------------------+
//  Path: /modules/services/import_export/language/hu_hu/language.php
//
// +---------------------------------------+
// | Hungarian translation/Magyar fordítás |
// +---------------------------------------+
// | Hungarian translation: Zsolt Győri    |
// | Hungarian bookkeeping: Tímea Tiszai   |
// | E-mail: gyori.zsolt@gmail.com         |
// | If you have any questions or comment  |
// | do not hesitate to contact us!        |
// +---------------------------------------+
// | Magyar fordítás: Győri Zsolt          |
// | Magyar könyvelés: Tiszai Tímea        |
// | E-mail: gyori.zsolt@gmail.com         |
// | Ha bármi kérdésed vagy észrevételed   |
// | van, ne habozz írni!                  |
// +---------------------------------------+

define('IE_HEADING_TITLE', 'Import/Export');
define('IE_HEADING_TITLE_CRITERIA', 'Import/Export kritériumok');
define('IE_POPUP_FIELD_TITLE','Import/Export mező paraméterek');
define('IE_HEADING_FIELDS_IMPORT', 'Import?');
define('IE_HEADING_CRITERIA', 'Export kritérium');

define('IE_CRITERIA_FILTER_FIELD', 'Szűrő mező');
define('IE_CRITERIA_FILTER_ADD_FIELD', 'Új szűrő mező felvétele');

define('IE_INFO_NO_CRITERIA', 'Nincs szűrőfeltétel definiálva!');
define('IE_INFO_DELETE_CONFIRM', 'Biztosan törölni akarod ezt az import/export definíciót?');
define('IE_ERROR_NO_DELETE', 'Ez egy beépített import/export definíció. Nem lehet törölni!');
define('IE_ERROR_NO_NAME', 'Nem adtad meg az Import/Export definíció nevét!');
define('IE_ERROR_DUPLICATE_NAME', 'Már létezik import/export definíció ezen a néven, próbáld újra!');

// Audit log messages
define('IE_LOG_MESSAGE','Import/Export - ');

// General
define('IE_OPTIONS_GENERAL_SETTINGS', 'Általános beállítások');
define('IE_OPTIONS_DELIMITER', 'Elválasztó');
define('IE_OPTIONS_QUALIFIER', 'Szöveg minősítő');
define('IE_OPTIONS_IMPORT_SETTINGS', 'Import beállítások');
define('IE_OPTIONS_IMPORT_PATH', 'Import file elérési útja');
define('IE_OPTIONS_INCLUDE_NAMES', 'Az első sor a mezőneveket tartalmazza');
define('IE_OPTIONS_EXPORT_SETTINGS', 'Export beállítások');
define('IE_OPTIONS_EXPORT_PATH', 'Export file neve');
define('IE_OPTIONS_INCLUDE_FIELD_NAMES', 'Oszlopnevek beszúrása az első sorba');

define('IE_DB_FIELD_NAME','Adatbázis mezőnév: ');
define('IE_FIELD_NAME','Mezőnév');
define('IE_PROCESSING','Feldolgozás alatt');
define('IE_INCLUDE','Benne foglal');

define('SRV_NO_DEF_SELECTED','Nincs kiválasztva Import/Export definíció, kérlek válassz egyet, és próbáld újra.');
define('SRV_DELETE_CRITERIA','Biztos törölni akarod a kritériumot?');
define('SRV_DELETE_CONFIRM','Biztos törölni akarod ezt az Import/Export definíciót?');
define('SRV_JS_DEF_NAME','Add meg a definíció nevét');
define('SRV_JS_DEF_DESC','Add meg a definíció leírását');
define('SRV_JS_SEQ_NUM','Add meg a sorszámot, ahova helyezzem ezt a bejegyzést.');

//************  For Import/Export Module, set the display tabs (DO NOT EDIT)  ********************
$tab_groups = array(
	'ar' => TEXT_RECEIVABLES,
	'ap' => TEXT_PAYABLES,
	'inv' => TEXT_INVENTORY,
	'hr' => TEXT_HR,
	'gl' => TEXT_GL,
	'bnk' => TEXT_BANKING
	);
?>
