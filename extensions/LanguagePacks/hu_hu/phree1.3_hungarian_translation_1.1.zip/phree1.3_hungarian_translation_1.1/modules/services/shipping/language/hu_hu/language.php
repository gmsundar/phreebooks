<?php
// +-----------------------------------------------------------------+
// |                   PhreeBooks Open Source ERP                    |
// +-----------------------------------------------------------------+
// | Copyright (c) 2007 PhreeSoft, LLC                               |
// | http://www.PhreeSoft.com                                        |
// +-----------------------------------------------------------------+
// | This program is free software: you can redistribute it and/or   |
// | modify it under the terms of the GNU General Public License as  |
// | published by the Free Software Foundation, either version 3 of  |
// | the License, or any later version.                              |
// |                                                                 |
// | This program is distributed in the hope that it will be useful, |
// | but WITHOUT ANY WARRANTY; without even the implied warranty of  |
// | MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the   |
// | GNU General Public License for more details.                    |
// |                                                                 |
// | The license that is bundled with this package is located in the |
// | file: /doc/manual/ch01-Introduction/license.html.               |
// | If not, see http://www.gnu.org/licenses/                        |
// +-----------------------------------------------------------------+
//  Path: /modules/services/shipping/language/hu_hu/language.php
//
// +---------------------------------------+
// | Hungarian translation/Magyar fordítás |
// +---------------------------------------+
// | Hungarian translation: Zsolt Győri    |
// | Hungarian bookkeeping: Tímea Tiszai   |
// | E-mail: gyori.zsolt@gmail.com         |
// | If you have any questions or comment  |
// | do not hesitate to contact us!        |
// +---------------------------------------+
// | Magyar fordítás: Győri Zsolt          |
// | Magyar könyvelés: Tiszai Tímea        |
// | E-mail: gyori.zsolt@gmail.com         |
// | Ha bármi kérdésed vagy észrevételed   |
// | van, ne habozz írni!                  |
// +---------------------------------------+

// shipping
define('HEADING_TITLE_MODULES_SHIPPING','Szállítási szolgáltatások');
define('SHIPPING_HEADING_SHIP_MGR','Szállítási modul kezelő');

define('SHIPPING_POPUP_WINDOW_TITLE','Szállítási költség becslő');
define('SHIPPING_POPUP_WINDOW_RATE_TITLE','Költség becslő- Kulcsok');
define('SHIPPING_ESTIMATOR_OPTIONS','Költség becslő - Szállítási beállítások');
define('SHIPPING_TEXT_SHIPPER','Szállító:');
define('SHIPPING_TEXT_SHIPMENT_DATE','Szállítás dátuma');
define('SHIPPING_TEXT_SHIP_FROM_CITY','Innen: ');
define('SHIPPING_TEXT_SHIP_TO_CITY','Ide: ');
define('SHIPPING_RESIDENTIAL_ADDRESS','Lakcím');
define('SHIPPING_TEXT_SHIP_FROM_STATE','Megyéből: ');
define('SHIPPING_TEXT_SHIP_TO_STATE','Megyébe: ');
define('SHIPPING_TEXT_SHIP_FROM_ZIP','Irányítószám: ');
define('SHIPPING_TEXT_SHIP_TO_ZIP','Irányítószám: ');
define('SHIPPING_TEXT_SHIP_FROM_COUNTRY','Országból: ');
define('SHIPPING_TEXT_SHIP_TO_COUNTRY','Országba: ');
define('SHIPPING_TEXT_PACKAGE_INFORMATION','Csomag információ');
define('SHIPPING_TEXT_PACKAGE_TYPE','Csomagolás típusa ');
define('SHIPPING_TEXT_PICKUP_SERVICE','Pickup Service ');
define('SHIPPING_TEXT_DIMENSIONS','Méretek: ');
define('SHIPPING_ADDITIONAL_HANDLING','Plusz kezelés alkalmazása (túlméret)');
define('SHIPPING_INSURANCE_AMOUNT','Biztosítás: Mérték ');
define('SHIPPING_SPLIT_LARGE_SHIPMENTS','Nagy szállítmányok kisebb csomagokra bontása ');
define('SHIPPING_TEXT_PER_BOX',' dobozonként');
define('SHIPPING_TEXT_DELIVERY_CONFIRM','Szállítás megerősítése ');
define('SHIPPING_SPECIAL_OPTIONS','Különleges beállítások');
define('SHIPPING_SERVICE_TYPE','Szolgáltatás típusa');
define('SHIPPING_HANDLING_CHARGE','Kezelési költség: Mértéke ');
define('SHIPPING_COD_AMOUNT','Fizetés átvételkor: Collect ');
define('SHIPPING_SATURDAY_PICKUP','Szombati csomagfelvétel');
define('SHIPPING_SATURDAY_DELIVERY','Szombati kiszállítás');
define('SHIPPING_HAZARDOUS_MATERIALS','Veszélyes anyag');
define('SHIPPING_TEXT_DRY_ICE','Szárazjég');
define('SHIPPING_TEXT_RETURN_SERVICES','Return Services ');
define('SHIPPING_TEXT_METHODS','Szállítási módok');
define('SHIPPING_TOTAL_WEIGHT','Teljes szállítási tömeg');
define('SHIPPING_TOTAL_VALUE','Teljes szállítási érték');
define('SHIPPING_EMAIL_SENDER','E-mail feladó');
define('SHIPPING_EMAIL_RECIPIENT','E-mail címzett');
define('SHIPPING_EMAIL_SENDER_ADD','Feladó e-mail címe');
define('SHIPPING_EMAIL_RECIPIENT_ADD','Címzett e-mail címe');
define('SHIPPING_TEXT_EXCEPTION','Kivétel');
define('SHIPPING_TEXT_DELIVER','Szállít');
define('SHIPPING_PRINT_LABEL','Címke nyomtatása');
define('SHIPPING_BILL_CHARGES_TO','Számlázási név');
define('SHIPPING_THIRD_PARTY','Recpt/Third Party Acct #');
define('SHIPPNIG_SUMMARY','Szállítási összegző');
define('SHIPPING_SHIPMENT_DETAILS','Szállítás részletei');
define('SHIPPING_PACKAGE_DETAILS','Csomag részletei');
define('SHIPPING_VOID_SHIPMENT','Üres szállítás');

define('SHIPPING_TEXT_CARRIER','Szállítóeszköz');
define('SHIPPING_TEXT_SERVICE','Szolgáltatás');
define('SHIPPING_TEXT_FREIGHT_QUOTE','Fuvarozási ajánlat');
define('SHIPPING_TEXT_BOOK_PRICE','Bérlési költség');
define('SHIPPING_TEXT_COST','Költség');
define('SHIPPING_TEXT_NOTES','Megjegyzések');
define('SHIPPING_TEXT_PRINT_LABEL','Címke nyomtatása');
define('SHIPPING_TEXT_CLOSE_DAY','Napi zárás');
define('SHIPPING_TEXT_DELETE_LABEL','Szállítás törlése');
define('SHIPPING_TEXT_SHIPMENT_ID','Szállítási azonosító');
define('SHIPPING_TEXT_REFERENCE_ID','Hivatkozási azonosító');
define('SHIPPING_TEXT_TRACKING_NUM','Követési szám');
define('SHIPPING_TEXT_EXPECTED_DATE','Tervezett szállítás');
define('SHIPPING_TEXT_ACTUAL_DATE','Aktuális szállítási dátum');
define('SHIPPING_TEXT_DOWNLOAD','Download Thermal Label');
define('SHIPPING_THERMAL_INST','<br>The file is pre-formatted for thermal label printers. To print the label:<br><br>
		1. Click the Download button to start the download.<br>
		2. Click on \'Save\' on the confirmation popup to save the file to you local machine.<br>
		3. Copy the file directly to the printer port. (the file must be copied in raw format)');
define('SHIPPING_TEXT_NO_LABEL','No Label Found!');

define('SHIPPING_ERROR_WEIGHT_ZERO','A szállítmány tömege nem lehet 0.');
define('SHIPPING_DELETE_CONFIRM', 'Biztos törölni akarod a csomagot?');
define('SHIPPING_NO_SHIPMENTS', 'Ma nncs szállítás ezen az eszközön!');
define('SHIPPING_ERROR_CONFIGURATION', '<strong>Szállítási beállítás hiba!</strong>');
define('SHIPPING_UPS_CURL_ERROR','cURL hiba: ');
define('SHIPPING_UPS_PACKAGE_ERROR','Died having trouble spliting the shipment into pieces. The shipment weight was: ');
define('SHIPPING_UPS_ERROR_WEIGHT_150','Single shipment weight cannot be greater than 150 lbs to use the UPS module.');
define('SHIPPING_UPS_ERROR_POSTAL_CODE','Postal Code is required to use the UPS module');
define('SHIPPING_FEDEX_ERROR_POSTAL_CODE','Postal Code is required to use the FedEx module');
define('SHIPPING_FEDEX_NO_PACKAGES','Nincs szállítandó csomag, az összes mennyiség vagy tömeg 0.');
define('SHIPPING_FEDEX_DELETE_ERROR','Hiba - Cannot delete the shipment, not enough information provided.');
define('SHIPPING_FEDEX_CANNOT_DELETE','Hiba - Cannot delete a shipment whose label was generated prior to today.');
define('SHIPPING_FEDEX_LABEL_DELETED','FedEx Label - Deleted');
define('SHIPPING_FEDEX_END_OF_DAY','FedEx - End of Day Close');
define('SHIPPING_USPS_ERROR_STATUS', '<strong>Warning:</strong> USPS shipping module is either missing the username, or it is set to TEST rather than PRODUCTION and will not work.<br />If you cannot retrieve USPS Shipping Quotes, contact USPS to activate your Web Tools account on their production server. 1-800-344-7779 or icustomercare@usps.com');

// Audit log messages
define('SHIPPING_LOG_FEDEX_LABEL_PRINTED','FedEx Label - Generated');

// Set up choices for dropdown menus for general shipping methods, not all are used for each method
$shipping_defaults = array();
// enable or disable Time in Travel information/address verification, if false postal code will be used
$shipping_defaults['TnTEnable'] = true;

$shipping_defaults['service_levels'] = array(
		'1DEam'=>'1 Day Early a.m.',
		'1Dam'=>'1 Day a.m.',
		'1Dpm'=>'1 Day p.m.',
		'1DFrt'=>'1 Day Freight',
		'2Dam'=>'2 Day a.m.',
		'2Dpm'=>'2 Day p.m.',
		'2DFrt'=>'2 Day Freight',
		'3Dpm'=>'3 Day',
		'3DFrt'=>'3 Day Freight',
		'GND'=>'Ground',
		'GDR'=>'Ground Residential',
		'GndFrt'=>'Ground LTL Freight',
		'I2DEam'=>'Worldwide Early Express',
		'I2Dam'=>'Worldwide Express',
		'I3D'=>'Worldwide Expedited',
		'IGND'=>'Ground (Canada)');

// Pickup Type Code - conforms to UPS standards per the XML specification
$shipping_defaults['pickup_service'] = array(
	'01' => 'Daily Pickup',
	'03' => 'Carrier Customer Counter',
	'06' => 'Request/One Time Pickup',
	'07' => 'UPS On Call Air',
	'11' => 'UPS Suggested Retail Rates',
	'19' => 'Drop Box/Center',
	'20' => 'Air Service Center');

// Weight Unit of Measure
// Value: char(3), Values "LBS" or "KGS"
$shipping_defaults['weight_unit'] = array(
	'LBS' => 'lbs',
	'KGS' => 'kgs');

// Package Dimensions Unit of Measure
$shipping_defaults['dimension_unit'] = array(
	'IN' => 'in',
	'CM' => 'cm');
	
// Package Type
$shipping_defaults['package_type'] = array(
	'01' => 'Envelope/Letter',
	'02' => 'Customer Supplied',
	'03' => 'Carrier Tube',
	'04' => 'Carrier Pak',
	'21' => 'Carrier  Box',
	'24' => '25kg Box',
	'25' => '10kg Box');

// COD Funds Code
$shipping_defaults['cod_funds_code'] = array(
	'0' => 'Készpénz',
	'1' => 'Csekk',
	'2' => 'Bankcsekk',
	'3' => 'Átutalás',
	'4' => 'Bármely');

// Delivery Confirmation
// Package delivery confirmation only allowed for shipments with US origin/destination combination.
$shipping_defaults['delivery_confirmation'] = array(
//	'0' => 'Nincs szállítási megerősítés',
	'1' => 'Nem szükséges aláírás',
	'2' => 'Aláírás szükséges',
	'3' => 'Nagykorú aláírása szükséges');

// Return label services
$shipping_defaults['return_label'] = array(
	'0' => 'Szállítmány feladó címke',
	'1' => 'Helyi feladó címke nyomtatása',
	'2' => 'Carrier Prints and Mails Return Label');

// Billing options
$shipping_defaults['bill_options'] = array(
	'0' => 'Feladó',
	'1' => 'Címzett',
	'2' => 'Harmadik személy',
	'3' => 'Utánvét');
?>
