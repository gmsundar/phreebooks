<?php
// +-----------------------------------------------------------------+
// |                   PhreeBooks Open Source ERP                    |
// +-----------------------------------------------------------------+
// | Copyright (c) 2007 PhreeSoft, LLC                               |
// | http://www.PhreeSoft.com                                        |
// +-----------------------------------------------------------------+
// | This program is free software: you can redistribute it and/or   |
// | modify it under the terms of the GNU General Public License as  |
// | published by the Free Software Foundation, either version 3 of  |
// | the License, or any later version.                              |
// |                                                                 |
// | This program is distributed in the hope that it will be useful, |
// | but WITHOUT ANY WARRANTY; without even the implied warranty of  |
// | MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the   |
// | GNU General Public License for more details.                    |
// |                                                                 |
// | The license that is bundled with this package is located in the |
// | file: /doc/manual/ch01-Introduction/license.html.               |
// | If not, see http://www.gnu.org/licenses/                        |
// +-----------------------------------------------------------------+
//  Path: /modules/soap/language/hu_hu/language.php
//

define('SOAP_NO_USER_PW','A felhasználónév és jelszó nem található az XML karakterláncban.');
define('SOAP_USER_NOT_FOUND','A felhasználónév nem érvényes.');
define('SOAP_PASSWORD_NOT_FOUND','Érvénytelen jelszó.');
define('SOAP_UNEXPECTED_ERROR','A feldolgozó szerver ismeretlen hibakóddal tért vissza.');
define('SOAP_XML_SUBMITTED_SO','XML által elküldött bejövő rendelés');
define('SOAP_NO_CUSTOMER_ID','A felhasználó azonosító hiányzik vagy érvénytelen.');
define('SOAP_NO_POST_DATE','A küldés dátuma hiányzik vagy érvénytelen.');
define('SOAP_BAD_POST_DATE','Az elküldés dátuma kívül esik a jelenleg definiált pénzügyi éveken.');

define('SOAP_NO_BILLING_PRIMARY_NAME','Ügyfél számlázási név megadása szükséges.');
define('SOAP_NO_BILLING_CONTACT','Ügyfél számlázási kapcsolattartó megadása szükséges.');
define('SOAP_NO_BILLING_ADDRESS1','Ügyfél számlázási címsor 1 megadása szükséges.');
define('SOAP_NO_BILLING_ADDRESS2','Ügyfél számlázási címsor 1 megadása szükséges.');
define('SOAP_NO_BILLING_CITY_TOWN','Ügyfél számlázási város megadása szükséges.');
define('SOAP_NO_BILLING_STATE_PROVINCE','Ügyfél számlázási megye megadása szükséges.');
define('SOAP_NO_BILLING_POSTAL_CODE','Ügyfél számlázási irányítószám megadása szükséges.');
define('SOAP_NO_BILLING_COUNTRY_CODE','Ügyfél számlázási ISO ország kód megadása szükséges (pl.: HU).');
define('SOAP_NO_SHIPPING_PRIMARY_NAME','Ügyfél szállítási név megadása szükséges.');
define('SOAP_NO_SHIPPING_CONTACT','Ügyfél szállítási kapcsolattartó megadása szükséges.');
define('SOAP_NO_SHIPPING_ADDRESS1','Ügyfél szállítási címsor 1 megadása szükséges.');
define('SOAP_NO_SHIPPING_ADDRESS2','Ügyfél szállítási címsor 2 megadása szükséges.');
define('SOAP_NO_SHIPPING_CITY_TOWN','Ügyfél szállítási város megadása szükséges.');
define('SOAP_NO_SHIPPING_STATE_PROVINCE','Ügyfél szállítási megye megadása szükséges.');
define('SOAP_NO_SHIPPING_POSTAL_CODE','Ügyfél szállítási irányítószám megadása szükséges.');
define('SOAP_NO_SHIPPING_COUNTRY_CODE','Ügyfél szállítási ISO ország kód megadása szükséges (pl.: HU).');

define('SOAP_SO_POST_ERROR','Hiba történt a kimenő rendelés elküldése közben. Leírás - ');
define('SOAP_SALES_ORDER_SUCCESS_A','Kimenő rendelés ');
define('SOAP_SALES_ORDER_SUCCESS_B',' sikeresen letöltve.');
define('SOAP_ACCOUNT_PROBLEM','Nem találtam egy létező ügyfél fő címét. Súlyos hiba a cím adatbázisban.');

?>
