<?php
// +-----------------------------------------------------------------+
// |                   PhreeBooks Open Source ERP                    |
// +-----------------------------------------------------------------+
// | Copyright (c) 2008, 2009, 2010 PhreeSoft, LLC                   |
// | http://www.PhreeSoft.com                                        |
// +-----------------------------------------------------------------+
// | This program is free software: you can redistribute it and/or   |
// | modify it under the terms of the GNU General Public License as  |
// | published by the Free Software Foundation, either version 3 of  |
// | the License, or any later version.                              |
// |                                                                 |
// | This program is distributed in the hope that it will be useful, |
// | but WITHOUT ANY WARRANTY; without even the implied warranty of  |
// | MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the   |
// | GNU General Public License for more details.                    |
// |                                                                 |
// | The license that is bundled with this package is located in the |
// | file: /doc/manual/ch01-Introduction/license.html.               |
// | If not, see http://www.gnu.org/licenses/                        |
// +-----------------------------------------------------------------+
//  Path: /modules/banking/language/fr_fr/language.php
//

// **************  Release 1.9 changes  ********************
define('BNK_ERROR_NO_ENCRYPT_KEY', 'Il y a des informations de paiement stockées, mais la clé de chiffrement n&#39;a pas été définie !');

// **************  Release 1.9 changes  ********************
define('BNK_DEP_20_V_WINDOW_TITLE', 'Dépôts en banque fournisseurs');
define('BNK_20_ENTER_DEPOSIT','Entrez le dépôt en banque fournisseur');

// **************  Release 1.8 changes  ********************
define('BNK_DEP_18_C_WINDOW_TITLE', 'Dépôts en banque clients');
define('BNK_18_ENTER_DEPOSIT','Entrez le dépôt en banque client');

// **************  Release 1.7 and earlier  ********************
// general
define('BNK_CASH_ACCOUNT','Compte espèces');
define('BNK_DISCOUNT_ACCOUNT','Compte remise');
define('BNK_AMOUNT_DUE','Mt à payer');
define('BNK_DUE_DATE','Date d&#39;échéance');
define('BNK_INVOICE_NUM','Facture #');
define('BNK_TEXT_CHECK_ALL','Vérifier tout');
define('BNK_TEXT_DEPOSIT_ID','ID ticket de dépôt en banque');
define('BNK_TEXT_PAYMENT_ID','Réf. Paiement #');
define('BNK_TEXT_WITHDRAWAL','Retrait');
define('BNK_TEXT_SAVE_PAYMENT_INFO','Enregistrer les informations de paiement ');

define('BNK_REPOST_PAYMENT','L&#39;enregistrement de paiement a été re-posté, cela peut dupliquer le paiement précédent avec le processeur !');
define('TEXT_CCVAL_ERROR_INVALID_DATE', 'La date d&#39;expiration saisie pour la carte de crédit n&#39;est pas valide. Veuillez vérifier la date et essayer à nouveau.');
define('TEXT_CCVAL_ERROR_INVALID_NUMBER', 'Le numéro de carte de crédit saisi n&#39;est pas valide. Veuillez vérifier le numéro et essayer à nouveau.');
define('TEXT_CCVAL_ERROR_UNKNOWN_CARD', 'Le numéro de carte de crédit commençant avec %s n&#39;a pas été entré correctement, ou nous n&#39;acceptons pas ce genre de carte. Veuillez ré-essayer ou utiliser une autre carte de crédit.');
define('BNK_BULK_PAY_NOT_POSITIVE','Le paiement au vendeur: %s a été ignoré parce que le montant total du paiement est inférieur ou égal à zéro !');
define('BNK_PAYMENT_NOT_SAVED','La boîte &#39;Enregistrer les informations de paiement&#39; a été cochée, mais la clé de chiffrement n&#39;est pas présente. Le reçu a été généré, mais les informations de paiement n&#39;ont pas été enregistrées !');

// Audit Log Messages
define('BNK_LOG_ACCT_RECON','Rapprochement de Compte, période: ');

// Cash receipts specific definitions
define('BNK_18_ERROR_NO_VENDOR','Aucun client n&#39;a été sélectionné !');
define('BNK_18_ENTER_BILLS','Entrez les recettes en espèces');
define('BNK_18_DELETE_BILLS','Supprimez les recettes en espèces');
define('BNK_18_C_WINDOW_TITLE','Recettes client');
define('BNK_18_V_WINDOW_TITLE','Recettes fournisseur');
define('BNK_18_BILL_TO','Recevoir de:');
define('BNK_18_POST_SUCCESSFUL','Reçu posté avec succès # ');
define('BNK_18_POST_DELETED','Reçu effacé avec succès # ');
define('BNK_18_AMOUNT_PAID','Mt reçu');
define('BNK_18_DELETE_ALERT','Êtes-vous sûr(e) de vouloir supprimer ce reçu ?');
define('BNK_18_NEGATIVE_TOTAL','Le montant du reçu ne peut être inférieur à zéro !');

/*
// Point of Sale specific definitions
define('BNK_19_ERROR_NO_VENDOR','Aucun client n&#39;a été sélectionné !');
define('BNK_19_ENTER_BILLS','Entrez les paiements point de vente');
define('BNK_19_DELETE_BILLS','Supprimez les recettes point de vente');
define('BNK_19_WINDOW_TITLE','Reçettes');
define('BNK_19_BILL_TO','Recevoir de:');
define('BNK_19_POST_SUCCESSFUL','Reçu posté avec succès # ');
define('BNK_19_POST_DELETED','Reçu effacé avec succès # ');
define('BNK_19_AMOUNT_PAID','Mt reçu');
define('BNK_19_DELETE_ALERT','Êtes-vous sûr(e) de vouloir supprimer ce reçu ?');
*/
// Cash Distribution specific definitions
define('BNK_20_ERROR_NO_VENDOR','Aucun fournisseur n&#39;a été sélectionné !');
define('BNK_20_ENTER_BILLS','Entrez les débours en espèces');
define('BNK_20_DELETE_BILLS','Supprimez les débours en espèces');
define('BNK_20_V_WINDOW_TITLE','Paiements Fournisseurs');
define('BNK_20_C_WINDOW_TITLE','Paiements Clients');
define('BNK_20_BILL_TO','Payer à:');
define('BNK_20_POST_SUCCESSFUL','Paiement posté avec succès # ');
define('BNK_20_POST_DELETED','Paiement effacé avec succès # ');
define('BNK_20_AMOUNT_PAID','Mt Payé');
define('BNK_20_DELETE_ALERT','Êtes-vous sûr(e) de vouloir supprimer ce paiement ?');
define('BNK_20_NEGATIVE_TOTAL','Le montant du paiement ne peut être inférieur à zéro !');
/*
// Point of Purchase (Write Checks) specific definitions
define('BNK_21_ERROR_NO_VENDOR','Aucun fournisseur n&#39;a été sélectionné !');
define('BNK_21_ENTER_BILLS','Entrez le paiement point d&#39;achat');
define('BNK_21_DELETE_BILLS','Supprimez le paiement point d&#39;achat');
define('BNK_21_WINDOW_TITLE','Paiements');
define('BNK_21_BILL_TO','Payer à:');
define('BNK_21_POST_SUCCESSFUL','Paiement posté avec succès # ');
define('BNK_21_POST_DELETED','Paiement effacé avec succès # ');
define('BNK_21_AMOUNT_PAID','Mt Payé');
define('BNK_21_DELETE_ALERT','Êtes-vous sûr(e) de vouloir supprimer ce paiement ?');
*/

// bulk pay bills
define('BNK_CHECK_DATE','Date de vérification');
define('BNK_TEXT_FIRST_CHECK_NUM','Premier numéro de vérification');
define('BNK_TOTAL_TO_BE_PAID','Total de tous les paiements');
define('BNK_INVOICES_DUE_BY','Factures dues par');
define('BNK_DISCOUNT_LOST_BY','Remises perdues par');
define('BNK_INVOICE_DATE','Date Facture');
define('BNK_VENDOR_NAME','Nom Fournisseur');
define('BNK_ACCOUNT_BALANCE','Balance avant paiements');
define('BNK_BALANCE_AFTER_CHECKS','Balance après paiements');

// account reconciliation
define('BANKING_HEADING_RECONCILIATION','Rapprochement de Compte');
define('BNK_START_BALANCE','État du solde de clôture');
define('BNK_OPEN_CHECKS','- Vérifications en cours');
define('BNK_OPEN_DEPOSITS','+ Dépôts en transit');
define('BNK_GL_BALANCE','- Solde du compte GL');
define('BNK_END_BALANCE','Différence non rapprochée');
define('BNK_DEPOSIT_CREDIT','Dépôt/Crédit');
define('BNK_CHECK_PAYMENT','Chèque/Paiement');
define('TEXT_MULTIPLE_DEPOSITS','Dépôts Clients');
define('TEXT_MULTIPLE_PAYMENTS','Paiements Fournisseurs');
define('TEXT_CASH_ACCOUNT','Compte en espèces');
define('BNK_ERROR_PERIOD_NOT_ALL','La période comptable choisie ne peut être &#39;all&#39; pour l&#39;opération de rapprochement des comptes.');
define('BNK_RECON_POST_SUCCESS','Modifications enregistrées avec succès.');

// Bank account register
define('BANKING_HEADING_REGISTER','Registre de compte en espèces');
define('TEXT_BEGINNING_BALANCE','Solde d&#39;ouverture');
define('TEXT_ENDING_BALANCE','Solde de clôture');
define('TEXT_DEPOSIT','Dépôt');

// Cvv stuff for credit cards
define('HEADING_CVV', 'Qu&#39;est-ce que CVV ?');
define('TEXT_CVV_HELP1', 'Visa, Mastercard, Discover - Numéro de vérification de carte à 3 chiffres<br /><br />
                    Pour votre sécurité, nous vous demandons d&#39;entrer votre numéro de vérification de carte.<br /><br />
                    Le numéro de vérification est un nombre à 3 chiffres imprimé au dos de votre carte.
                    Il apparaît après et à la droite de votre numéro de carte.<br />' .
                    html_image(DIR_WS_IMAGES . 'cvv2visa.gif'));

define('TEXT_CVV_HELP2', 'American Express - Numéro de vérification de carte à 4 chiffres<br /><br />
                    Pour votre sécurité, nous vous demandons d&#39;entrer votre numéro de vérification de carte.<br /><br />
                    Le numéro de vérification American Express est un nombre à 3 chiffres imprimé au recto de votre carte.
                    Il apparaît après et à la droite de votre numéro de carte.<br />' .
                    html_image(DIR_WS_IMAGES . 'cvv2amex.gif'));
?>