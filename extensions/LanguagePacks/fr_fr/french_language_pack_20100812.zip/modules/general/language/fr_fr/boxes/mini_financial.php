<?php
// +-----------------------------------------------------------------+
// |                   PhreeBooks Open Source ERP                    |
// +-----------------------------------------------------------------+
// | Copyright (c) 2008, 2009, 2010 PhreeSoft, LLC                   |
// | http://www.PhreeSoft.com                                        |
// +-----------------------------------------------------------------+
// | This program is free software: you can redistribute it and/or   |
// | modify it under the terms of the GNU General Public License as  |
// | published by the Free Software Foundation, either version 3 of  |
// | the License, or any later version.                              |
// |                                                                 |
// | This program is distributed in the hope that it will be useful, |
// | but WITHOUT ANY WARRANTY; without even the implied warranty of  |
// | MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the   |
// | GNU General Public License for more details.                    |
// |                                                                 |
// | The license that is bundled with this package is located in the |
// | file: /doc/manual/ch01-Introduction/license.html.               |
// | If not, see http://www.gnu.org/licenses/                        |
// +-----------------------------------------------------------------+
//  Path: /modules/general/language/fr_fr/boxes/mini_financial.php
//

define('CP_MINI_FINANCIAL_TITLE','Résumé de la Situation Financière');
define('CP_MINI_FINANCIAL_DESCRIPTION','Liste une version abrégée de votre situation financière.');
define('CP_MINI_FINANCIAL_NO_OPTIONS','Il n&#39;y a aucune option de choix pour cet élément !');
define('RW_FIN_CURRENT_ASSETS','Actifs à court terme');
define('RW_FIN_PROP_EQUIP','Immobilisations corporelles');
define('RW_FIN_HEAD_0', 'Trésorerie');
define('RW_FIN_HEAD_2', 'Effets à recevoir');
define('RW_FIN_HEAD_4', 'Stock');
define('RW_FIN_HEAD_6', 'Autres actifs');
define('RW_FIN_HEAD_8', 'Inutilisé');
define('RW_FIN_HEAD_10','Inutilisé');
define('RW_FIN_HEAD_12','Inutilisé');
define('RW_FIN_HEAD_20','Inutilisé');
define('RW_FIN_HEAD_22','Inutilisé');
define('RW_FIN_HEAD_24','Inutilisé');
define('RW_FIN_HEAD_40','Inutilisé');
define('RW_FIN_HEAD_42','Inutilisé');
define('RW_FIN_HEAD_44','Inutilisé');
define('RW_FIN_ASSETS','Total des actifs');
define('RW_FIN_INCOME','Total revenu');
define('RW_FIN_CUR_LIABILITIES','Passif à court terme');
define('RW_FIN_LT_LIABILITIES','Passif à long terme');
define('RW_FIN_TOTAL_LIABILITIES','Total du passif');
define('RW_FIN_TOTAL_INCOME','Total revenu');
define('RW_FIN_COST_OF_SALES','Coût des ventes');
define('RW_FIN_GROSS_PROFIT','Bénéfice brut');
define('RW_FIN_EXPENSES','Charges');
define('RW_FIN_NET_INCOME','Revenu net');
define('RW_FIN_CAPITAL','Capital');
define('RW_FIN_TOTAL_LIABILITIES_CAPITAL','Total du passif & Capital');

?>