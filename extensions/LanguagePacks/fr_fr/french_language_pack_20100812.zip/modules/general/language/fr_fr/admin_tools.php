<?php
// +-----------------------------------------------------------------+
// |                   PhreeBooks Open Source ERP                    |
// +-----------------------------------------------------------------+
// | Copyright (c) 2008, 2009, 2010 PhreeSoft, LLC                   |
// | http://www.PhreeSoft.com                                        |
// +-----------------------------------------------------------------+
// | This program is free software: you can redistribute it and/or   |
// | modify it under the terms of the GNU General Public License as  |
// | published by the Free Software Foundation, either version 3 of  |
// | the License, or any later version.                              |
// |                                                                 |
// | This program is distributed in the hope that it will be useful, |
// | but WITHOUT ANY WARRANTY; without even the implied warranty of  |
// | MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the   |
// | GNU General Public License for more details.                    |
// |                                                                 |
// | The license that is bundled with this package is located in the |
// | file: /doc/manual/ch01-Introduction/license.html.               |
// | If not, see http://www.gnu.org/licenses/                        |
// +-----------------------------------------------------------------+
//  Path: /modules/general/language/fr_fr/admin_tools.php
//

// ************** Release 2.0 additions ****************************//
define('GEN_DEFAULT_STORE','Boutique par défaut');
define('GEN_DEF_CASH_ACCT','Compte de trésorerie par défaut');
define('GEN_RESTRICT_STORE','Restreindre les entrées dans cette boutique ?');
define('GEN_DEF_AR_ACCT','Compte effets à recevoir (créances) par défaut');
define('GEN_DEF_AP_ACCT','Compte effets à payer (dettes) par défaut');
define('GEN_RESTRICT_PERIOD','Restreindre les envois à la période en cours ?');
define('GEN_ADM_TOOLS_CLEAN_LOG','Sauvegarder et nettoyer les journaux d&#39;audit');
define('GEN_ADM_TOOLS_CLEAN_LOG_DESC','Cette opération crée une sauvegarde downloadée de votre fichier journal d&#39;audit de BDD. Ceci aidera à minimiser la taille de la base de données et à réduire la taille des fichiers de sauvegarde de la société. La sauvegarde de ce journal est recommandée avant de le nettoyer de manière à préserver l&#39;historique des transactions de PhreeBooks. <br />INFORMATION: Nettoyer le journal d&#39;audit laissera les données de l&#39;exercice en cours dans la table de la base de données et supprimera tous les autres enregistrements.');
define('GEN_ADM_TOOLS_CLEAN_LOG_BACKUP','Sauvegarder le journal d&#39;audit');
define('GEN_ADM_TOOLS_CLEAN_LOG_CLEAN','Nettoyer le journal d&#39;audit');
define('GEN_ADM_TOOLS_BTN_CLEAN_CONFIRM','Êtes-vous sûr(e) de vouloir supprimer ces enregistrements du journal d&#39;audit ?');
define('GEN_ADM_TOOLS_BTN_BACKUP','Sauvegarder maintenant !');
define('GEN_ADM_TOOLS_BTN_CLEAN','Nettoyer maintenant !');
define('GEN_AUDIT_DB_DATA_BACKUP','Table du journal d&#39;audit de la base de données sauvegardée');
define('GEN_AUDIT_DB_DATA_CLEAN','Table du journal d&#39;audit de la base de données nettoyée');

// ************** Release 1.8 additions ****************************//
define('HEADING_TITLE_CRASH_TITLE','Trace d&#39;erreur SQL de PhreeBooks');
define('HEADING_TITLE_CRASH_INFORMATION','PhreeBooks a rencontré une erreur inattendue. Cliquez sur le bouton ci-dessous pour downloader le fichier trace d&#39;informations de débogage à envoyer à l&#39;équipe de développement PhreeBooks pour dépannage.');
define('HEADING_TITLE_CRASH_BUTTON','Downloader les informations de débogage');

// ************** Release 1.7 additions ****************************//
define('GEN_ADM_TOOLS_CUSTID','ID Client suivant');
define('GEN_ADM_TOOLS_VENDID','ID Fournisseur suivant');

// Pre-release 1.6 language definitions
define('GEN_ADM_TOOLS_POST_SEQ_SUCCESS','Modifications du numéro courant de commande postées avec succès.');
define('GEN_ADM_TOOLS_AUDIT_LOG_SEQ','État actuel de commande - Mise à jour');
define('GEN_ADM_TOOLS_TITLE','Outils d&#39;Administration et Utilitaires');
define('GEN_ADM_TOOLS_SEQ_HEADING','Modifier divers numéros de séquence');
define('GEN_ADM_TOOLS_SEQ_DESC','Les modifications des numéros de séquence peuvent être faites ici.<br />NOTE 1: PhreeBooks n&#39;autorise pas des numéros de séquence en double, assurez-vous que la nouvelle séquence de départ ne rentre pas en conflit avec les valeurs actuellement affichées.<br />NOTE 2: Le next_deposit_num est généré par le système et utilise la date actuelle.<br />NOTE 3: Le next_check_num peut être défini sur l&#39;écran de paiement avant de poster un paiement et se poursuivra à partir de la valeur entrée.');
define('GEN_ADM_TOOLS_AR','Client/Effets à recevoir');
define('GEN_ADM_TOOLS_AP','Fournisseurs/Effets à payer');
define('GEN_ADM_TOOLS_BNK','Banque');
define('GEN_ADM_TOOLS_OTHER','Autres');
define('GEN_ADM_TOOLS_BTN_SAVE','Enregistrer les modifications');

define('GEN_ADM_TOOLS_ARQ','N° de Devis Client suivant');
define('GEN_ADM_TOOLS_APQ','N° de Devis Fournisseur suivant');
define('GEN_ADM_TOOLS_BNKD','N° de Dépôt en banque suivant');
define('GEN_ADM_TOOLS_ARSO','N° de Commande Client suivant');
define('GEN_ADM_TOOLS_APPO','N° de Commande Fournisseur suivant');
define('GEN_ADM_TOOLS_BNKCK','N° de Chèque suivant');
define('GEN_ADM_TOOLS_ARINV','N° de Ventes/Facture suivant');
define('GEN_ADM_TOOLS_ARCM','N° d&#39;Avoir Client suivant');
define('GEN_ADM_TOOLS_APCM','N° d&#39;Avoir Fournisseur suivant');
define('GEN_ADM_TOOLS_SHIP','N° de Livraison suivant');

define('GEN_ADM_TOOLS_RE_POST_FAILED','Aucun journal de sélectionné pour re-postage, aucune action n&#39;a été prise.');
define('GEN_ADM_TOOLS_RE_POST_SUCCESS','Les journaux sélectionnés ont été re-postés avec succès. Le nombre d&#39;enregistrements re-postés était de: %s');
define('GEN_ADM_TOOLS_AUDIT_LOG_RE_POST','Journaux re-postés: ');
define('GEN_ADM_TOOLS_REPOST_HEADING','Entrées de journaux re-postés');
define('GEN_ADM_TOOLS_REPOST_DESC','<b>SOYEZ SÛR(E) D&#39;AVOIR SAUVEGARDÉ VOS DONNÉES AVANT DE RE-POSTER UN JOURNAL QUELCONQUE !</b><br />NOTE 1: Re-poster des journaux peut prendre un certain temps, vous voudrez peut-être limiter le re-postage en entrant un intervalle de dates plus petit ou un nombre limité de journaux.');
define('GEN_ADM_TOOLS_REPOST_CONFIRM','Êtes-vous sûr(e) de vouloir re-poster les journaux sélectionnés ?\n\nVOUS DEVRIEZ SAUVEGARDER VOTRE SOCIÉTÉ AVANT DE FAIRE CELA !');
define('GEN_ADM_TOOLS_BNK_ETC','Banque/Stock/Autres');
define('GEN_ADM_TOOLS_DATE_RANGE','Intervalle de dates de re-postage');
define('GEN_ADM_TOOLS_START_DATE','Date de début');
define('GEN_ADM_TOOLS_END_DATE','Date de fin');

define('GEN_ADM_TOOLS_BTN_REPOST','Re-poster les Journaux');
define('GEN_ADM_TOOLS_J02','Journal Général(2)');
define('GEN_ADM_TOOLS_J03','Journal Devis Fournisseurs (3)');
define('GEN_ADM_TOOLS_J04','Journal Commandes Fournisseurs (4)');
define('GEN_ADM_TOOLS_J06','Journal Achats (6)');
define('GEN_ADM_TOOLS_J07','Journal Fournisseur CM (7)');
define('GEN_ADM_TOOLS_J08','Journal de Paie (8)');
define('GEN_ADM_TOOLS_J09','Journal Devis Clients (9)');
define('GEN_ADM_TOOLS_J10','Journal Commandes Clients (10)');
define('GEN_ADM_TOOLS_J12','Journal Ventes/Facture (12)');
define('GEN_ADM_TOOLS_J13','Journal Client CM(13)');
define('GEN_ADM_TOOLS_J14','Journal Assemblages de Stock (14)');
define('GEN_ADM_TOOLS_J16','Journal Ajustments de Stock (16)');
define('GEN_ADM_TOOLS_J18','Journal Recettes Espèces (18)');
define('GEN_ADM_TOOLS_J19','Journal Point de Vents (19)');
define('GEN_ADM_TOOLS_J20','Journal Cash Dist(20)');
define('GEN_ADM_TOOLS_J21','Journal Point d&#39;Achat (21)');

define('GEN_ADM_TOOLS_REPAIR_CHART_HISTORY','Valider et réparer les soldes des comptes du Grand Livre');
define('GEN_ADM_TOOLS_REPAIR_CHART_DESC','Cette opération valide et répare les soldes de la liste des comptes. Si la balance avant inventaire ou le bilan ne sont pas équilibrés, il faut commencer par là. Validez d&#39;abord les soldes pour voir s&#39;il y a une erreur et réparez si nécessaire.');
define('GEN_ADM_TOOLS_REPAIR_TEST','Tester les soldes du plan');
define('GEN_ADM_TOOLS_REPAIR_FIX','Fixer les erreurs de soldes du plan');
define('GEN_ADM_TOOLS_BTN_TEST','Tester les soldes du GL');
define('GEN_ADM_TOOLS_BTN_REPAIR','Réparer les erreurs de soldes du GL');
define('GEN_ADM_TOOLS_REPAIR_CONFIRM','Êtes-vous sûr(e) de vouloir réparer les soldes du Grand Livre ?\n\nVOUS DEVRIEZ IMPRIMER LES ÉTATS FINANCIERS ET SAUVEGARDER VOTRE SOCIÉTÉ AVANT DE FAIRE CELA !');
define('GEN_ADM_TOOLS_REPAIR_ERROR_MSG','Il y a une erreur de solde sur la période %s, compte %s, valeurs comparées: %s avec: %s');
define('GEN_ADM_TOOLS_REPAIR_SUCCESS','Vos soldes du plan comptable sont OK.');
define('GEN_ADM_TOOLS_REPAIR_ERROR','Vous devriez réparer les soldes du plan. NOTE: SAUVEGARDEZ AVANT DE RÉPARER LES SOLDES DU PLAN COMPTABLE !');
define('GEN_ADM_TOOLS_REPAIR_COMPLETE','Les soldes du plan ont été réparés.');
define('GEN_ADM_TOOLS_REPAIR_LOG_ENTRY','Soldes du GL réparés');

// Encryption defines
define('GEN_ADM_TOOLS_SET_ENCRYPTION_KEY','Entrez la clé de chiffrement');
define('BOX_HEADING_ENCRYPTION','Service de cryptage de données');
define('GEN_ENCRYPTION_GEN_INFO','Le service de cryptage dépend d&#39;une clé utilisée pour chiffrer les données dans la base de données. NE PERDEZ PAS CETTE CLÉ, sinon les données ne pourront plus être déchiffrées !');
define('GEN_ENCRYPTION_COMP_TYPE','Entrez la clé de chiffrement utilisée pour stocker les données de manière sécurisée.');
define('GEN_ENCRYPTION_KEY','Clé de chiffrement ');
define('GEN_ENCRYPTION_KEY_CONFIRM','Ré-entrez la clé ');
define('ERROR_WRONG_ENCRYPT_KEY_MATCH','Les clés de chiffrement ne correspondent pas !');
define('ERROR_WRONG_ENCRYPT_KEY','La clé de chiffrement que vous avez saisi ne correspond pas à la valeur enregistrée.');
define('GEN_ENCRYPTION_KEY_SET','La clé de chiffrement a été définie.');
define('GEN_ENCRYPTION_KEY_CHANGED','La clé de chiffrement a été modifiée.');

define('GEN_ADM_TOOLS_SET_ENCRYPTION_PW','Créer/Modifier la clé de chiffrement');
define('GEN_ADM_TOOLS_SET_ENCRYPTION_PW_DESC','Définir la clé de chiffrement à utiliser si &#39;Activer le cryptage des informations&#39; est ON. Si elle est définie pour la première fois, l&#39;ancienne clé de chiffrement est vide.');
define('GEN_ADM_TOOLS_ENCRYPT_OLD_PW','Ancienne clé de chiffrement');
define('GEN_ADM_TOOLS_ENCRYPT_PW','Nouvelle clé de chiffrement');
define('GEN_ADM_TOOLS_ENCRYPT_PW_CONFIRM','Ré-entrez la nouvelle clé de chiffrement');
define('ERROR_OLD_ENCRYPT_NOT_CORRECT','L&#39;ancienne clé de chiffrement ne correspond pas à la valeur enregistrée !');

// backup defines
define('BOX_HEADING_RESTORE','Restaurer la société');
define('GEN_BACKUP_ICON_TITLE','Démarrer la sauvegarde');
define('GEN_BACKUP_GEN_INFO','Veuillez choisir ci-dessous le type de compression et les options de la sauvegarde.');
define('GEN_BACKUP_COMP_TYPE','Type de Compression');
define('GEN_COMP_BZ2',' bz2 (Linux)');
define('GEN_COMP_ZIP',' Zip');
define('GEN_COMP_NONE','Aucun (uniquement pour la base de données)');
define('GEN_BACKUP_DB_ONLY',' Uniquement la base de données');
define('GEN_BACKUP_FULL',' Base de données et fichiers de données de la société');
define('GEN_BACKUP_SAVE_LOCAL',' Enregistrer une copie locale dans le répertoire (my_files/backups) du serveur Web');
define('GEN_BACKUP_WARNING','ATTENTION ! Cette opération va supprimer et ré-écrire la base de données. Êtes-vous sûr(e) de vouloir continuer ?');
define('GEN_BACKUP_NO_ZIP_CLASS','La classe zip ne peut être trouvée. PHP a besoin que la bibliothèque zip soit installée pour sauvegarder avec compression zip.');
define('GEN_BACKUP_FILE_ERROR','Le fichier zip ne peut pas être créé. Vérifiez les permissions pour le répertoire: ');
define('GEN_BACKUP_MOVE_ERROR','Impossible d&#39;ouvrir le fichier (%s) en écriture. Vérifiez vos permissions.');
?>