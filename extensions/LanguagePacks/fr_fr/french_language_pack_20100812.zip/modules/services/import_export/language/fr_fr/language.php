<?php
// +-----------------------------------------------------------------+
// |                   PhreeBooks Open Source ERP                    |
// +-----------------------------------------------------------------+
// | Copyright (c) 2008, 2009, 2010 PhreeSoft, LLC                   |
// | http://www.PhreeSoft.com                                        |
// +-----------------------------------------------------------------+
// | This program is free software: you can redistribute it and/or   |
// | modify it under the terms of the GNU General Public License as  |
// | published by the Free Software Foundation, either version 3 of  |
// | the License, or any later version.                              |
// |                                                                 |
// | This program is distributed in the hope that it will be useful, |
// | but WITHOUT ANY WARRANTY; without even the implied warranty of  |
// | MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the   |
// | GNU General Public License for more details.                    |
// |                                                                 |
// | The license that is bundled with this package is located in the |
// | file: /doc/manual/ch01-Introduction/license.html.               |
// | If not, see http://www.gnu.org/licenses/                        |
// +-----------------------------------------------------------------+
//  Path: /modules/services/import_export/language/fr_fr/language.php
//

define('IE_HEADING_TITLE', 'Informations Import/Export');
define('IE_HEADING_TITLE_CRITERIA', 'Critères Import/Export');
define('IE_POPUP_FIELD_TITLE','Paramètres champ Import/Export');
define('IE_HEADING_FIELDS_IMPORT', 'Importer ?');
define('IE_HEADING_CRITERIA', 'Critères d&#39;exportation');

define('IE_CRITERIA_FILTER_FIELD', 'Champ de filtrage');
define('IE_CRITERIA_FILTER_ADD_FIELD', 'Ajouter un nouveau champ de filtrage');

define('IE_INFO_NO_CRITERIA', 'Il n&#39;y a aucun critère de filtrage défini !');
define('IE_INFO_DELETE_CONFIRM', 'Êtes-vous sûr(e) de vouloir supprimer cette définition d&#39;importation/exportation ?');
define('IE_ERROR_NO_DELETE', 'Il s&#39;agit d&#39;une définition standart d&#39;importation/exportation. Elle ne peut pas être supprimée !');
define('IE_ERROR_NO_NAME', 'Le nom de la définition d&#39;importation/exportation ne peut pas être vide !');
define('IE_ERROR_DUPLICATE_NAME', 'Une définition d&#39;importation/exportation avec ce nom existe déjà, veuillez réessayer !');

// Audit log messages
define('IE_LOG_MESSAGE','Importer/Exporter - ');

// General
define('IE_OPTIONS_GENERAL_SETTINGS', 'Paramètres généraux');
define('IE_OPTIONS_DELIMITER', 'Délimiteur');
define('IE_OPTIONS_QUALIFIER', 'Qualificateur du texte');
define('IE_OPTIONS_IMPORT_SETTINGS', 'Paramètres d&#39;importation');
define('IE_OPTIONS_IMPORT_PATH', 'Chemin vers le fichier à importer');
define('IE_OPTIONS_INCLUDE_NAMES', 'La première ligne contient les noms des champs');
define('IE_OPTIONS_EXPORT_SETTINGS', 'Paramètres d&#39;exportation');
define('IE_OPTIONS_EXPORT_PATH', 'Nom du fichier à exporter');
define('IE_OPTIONS_INCLUDE_FIELD_NAMES', 'Inclure les noms des champs sur la première ligne');

define('IE_DB_FIELD_NAME','Nom du champ en base de données: ');
define('IE_FIELD_NAME','Nom du champ');
define('IE_PROCESSING','En traitement');
define('IE_INCLUDE','Inclure');

define('SRV_NO_DEF_SELECTED','Aucune définition d&#39;Importation/Exportation n&#39;a été sélectionnée, veuillez choisir une définition et réessayer.');
define('SRV_DELETE_CRITERIA','Êtes-vous sûr(e) de vouloir supprimer ce critère ?');
define('SRV_DELETE_CONFIRM','Êtes-vous sûr(e) de vouloir supprimer cette définition d&#39;importation/exportation ?');
define('SRV_JS_DEF_NAME','Entrez un nom pour cette définition');
define('SRV_JS_DEF_DESC','Entrez une description de cette définition');
define('SRV_JS_SEQ_NUM','Entrez le numéro de séquence pour déplacer cette entrée vers.');

//************  For Import/Export Module, set the display tabs (DO NOT EDIT)  ********************
$tab_groups = array(
  'ar'  => TEXT_RECEIVABLES,
  'ap'  => TEXT_PAYABLES,
  'inv' => TEXT_INVENTORY,
  'hr'  => TEXT_HR,
  'gl'  => TEXT_GL,
  'bnk' => TEXT_BANKING,
);
?>