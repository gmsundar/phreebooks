<?php
// +-----------------------------------------------------------------+
// |                   PhreeBooks Open Source ERP                    |
// +-----------------------------------------------------------------+
// | Copyright (c) 2008, 2009, 2010 PhreeSoft, LLC                   |
// | http://www.PhreeSoft.com                                        |
// +-----------------------------------------------------------------+
// | This program is free software: you can redistribute it and/or   |
// | modify it under the terms of the GNU General Public License as  |
// | published by the Free Software Foundation, either version 3 of  |
// | the License, or any later version.                              |
// |                                                                 |
// | This program is distributed in the hope that it will be useful, |
// | but WITHOUT ANY WARRANTY; without even the implied warranty of  |
// | MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the   |
// | GNU General Public License for more details.                    |
// |                                                                 |
// | The license that is bundled with this package is located in the |
// | file: /doc/manual/ch01-Introduction/license.html.               |
// | If not, see http://www.gnu.org/licenses/                        |
// +-----------------------------------------------------------------+
//  Path: /modules/services/shipping/language/fr_fr/language.php
//

// shipping
define('HEADING_TITLE_MODULES_SHIPPING','Services de Livraison');
define('SHIPPING_HEADING_SHIP_MGR','Gestion des Livraisons');
define('SHIPPING_BUTTON_CREATE_LOG_ENTRY','Créer une entrée de livraison');
define('SHIPPING_SET_BY_SYSTEM',' (défini par le système)');

define('SHIPPING_POPUP_WINDOW_TITLE','Estimateur des frais livraison');
define('SHIPPING_POPUP_WINDOW_RATE_TITLE','Estimateur de livraison - Frais');
define('SHIPPING_ESTIMATOR_OPTIONS','Estimateur de livraison - Options de livraison');
define('SHIPPING_TEXT_SHIPPER','Expéditeur:');
define('SHIPPING_TEXT_SHIPMENT_DATE','Date d&#39;expédition');
define('SHIPPING_TEXT_SHIP_FROM_CITY','Expédier depuis la ville: ');
define('SHIPPING_TEXT_SHIP_TO_CITY','Expédier vers la ville: ');
define('SHIPPING_RESIDENTIAL_ADDRESS','Adresse de résidence');
define('SHIPPING_TEXT_SHIP_FROM_STATE','Expédier depuis la région\le département: ');
define('SHIPPING_TEXT_SHIP_TO_STATE','Expédier vers la région\le département: ');
define('SHIPPING_TEXT_SHIP_FROM_ZIP','Expédier depuis le code postal: ');
define('SHIPPING_TEXT_SHIP_TO_ZIP','Expédier vers le code postal: ');
define('SHIPPING_TEXT_SHIP_FROM_COUNTRY','Expédier depuis le pays: ');
define('SHIPPING_TEXT_SHIP_TO_COUNTRY','Expédier vers le pays: ');
define('SHIPPING_TEXT_PACKAGE_INFORMATION','Informations sur l&#39;emballage');
define('SHIPPING_TEXT_PACKAGE_TYPE','Type d&#39;emballage ');
define('SHIPPING_TEXT_PICKUP_SERVICE','Service de ramassage ');
define('SHIPPING_TEXT_DIMENSIONS','Dimensions: ');
define('SHIPPING_ADDITIONAL_HANDLING','Frais supplémentaires de manutention (colis encombrants)');
define('SHIPPING_INSURANCE_AMOUNT','Assurance: montant ');
define('SHIPPING_SPLIT_LARGE_SHIPMENTS','Fractionner les gros colis en petits paquets ');
define('SHIPPING_TEXT_PER_BOX',' par boite');
define('SHIPPING_TEXT_DELIVERY_CONFIRM','Confirmation de livraison ');
define('SHIPPING_SPECIAL_OPTIONS','Options spéciales');
define('SHIPPING_SERVICE_TYPE','Type de service');
define('SHIPPING_HANDLING_CHARGE','Frais de manutention: montant ');
define('SHIPPING_COD_AMOUNT','CRBT: collecter ');
define('SHIPPING_SATURDAY_PICKUP','Ramassage le Samedi');
define('SHIPPING_SATURDAY_DELIVERY','Livraison le Samedi');
define('SHIPPING_HAZARDOUS_MATERIALS','Marchandises dangereuses');
define('SHIPPING_TEXT_DRY_ICE','Réfrigéré');
define('SHIPPING_TEXT_RETURN_SERVICES','Service de retour ');
define('SHIPPING_TEXT_METHODS','Méthodes de livraison');
define('SHIPPING_TOTAL_WEIGHT','Poids total expédié');
define('SHIPPING_TOTAL_VALUE','Valeur totale expédiée');
define('SHIPPING_EMAIL_SENDER','Expéditeur e-mail');
define('SHIPPING_EMAIL_RECIPIENT','Destinataire e-mail');
define('SHIPPING_EMAIL_SENDER_ADD','Adresse e-mail expéditeur');
define('SHIPPING_EMAIL_RECIPIENT_ADD','Adresse e-mail destinataire');
define('SHIPPING_TEXT_EXCEPTION','Exception');
define('SHIPPING_TEXT_DELIVER','Livrer');
define('SHIPPING_PRINT_LABEL','Imprimer étiquette');
define('SHIPPING_BILL_CHARGES_TO','Facturer les frais à');
define('SHIPPING_THIRD_PARTY','Compte Recpt/Tierce partie #');
define('SHIPPING_THIRD_PARTY_ZIP','Code postal tierce partie');
define('SHIPPING_LTL_FREIGHT_CLASS','Classe de transport LTL');
define('SHIPPING_DEFAULT_LTL_CLASS','125');
define('SHIPPNIG_SUMMARY','Résumé du colis');
define('SHIPPING_SHIPMENT_DETAILS','Détails du colis');
define('SHIPPING_PACKAGE_DETAILS','Détails de l&#39;emballage');
define('SHIPPING_VOID_SHIPMENT','Annuler l&#39;expédition');

define('SHIPPING_TEXT_CARRIER','Transporteur');
define('SHIPPING_TEXT_SERVICE','Service');
define('SHIPPING_TEXT_FREIGHT_QUOTE','Devis transport');
define('SHIPPING_TEXT_BOOK_PRICE','Prix inscrit');
define('SHIPPING_TEXT_COST','Coût');
define('SHIPPING_TEXT_NOTES','Notes');
define('SHIPPING_TEXT_PRINT_LABEL','Imprimer étiquette');
define('SHIPPING_TEXT_CLOSE_DAY','Fermeture journalière');
define('SHIPPING_TEXT_DELETE_LABEL','Supprimer l&#39;expédition');
define('SHIPPING_TEXT_SHIPMENT_ID','ID Expédition');
define('SHIPPING_TEXT_REFERENCE_ID','ID Référence');
define('SHIPPING_TEXT_TRACKING_NUM','Numéro de suivi');
define('SHIPPING_TEXT_EXPECTED_DATE','Date de livraison attendue');
define('SHIPPING_TEXT_ACTUAL_DATE','Date de livraison véritable');
define('SHIPPING_TEXT_DOWNLOAD','Downloader étiquette thermique');
define('SHIPPING_THERMAL_INST','<br />Le fichier est pré-formatté pour des imprimantes thermiques. Pour imprimer l&#39;étiquette:<br /><br />
		1. Cliquer sur le bouton Download pour débuter le téléchargement.<br />
		2. Cliquer sur &#39;Enregistrer&#39; dans le popup de confirmation pour enregistrer le fichier sur votre machine locale.<br />
		3. Copier le fichier directement sur le port imprimante. (le fichier doit être copié en format raw)');
define('SHIPPING_TEXT_NO_LABEL','Aucune étiquette trouvée !');

define('SHIPPING_ERROR_WEIGHT_ZERO','Le poids expédié ne peut être nul.');
define('SHIPPING_DELETE_CONFIRM', 'Êtes-vous sûr(e) de vouloir supprimer ce colis ?');
define('SHIPPING_NO_SHIPMENTS', 'Aujourd&#39;hui, il n&#39;y a aucune expédition à effectuer selon ce mode de transport !');
define('SHIPPING_ERROR_CONFIGURATION', '<strong>Erreurs de configuration d&#39;expédition !</strong>');
define('SHIPPING_UPS_CURL_ERROR','Erreur cURL: ');
define('SHIPPING_UPS_PACKAGE_ERROR','Arrêté à cause d&#39;un problème en fractionnant l&#39;envoi en petits colis. Le poids expédié était de: ');
define('SHIPPING_UPS_ERROR_WEIGHT_150','Le poids par colis expédié ne peut dépasser 150 lbs pour pouvoir utiliser le module UPS.');
define('SHIPPING_UPS_ERROR_POSTAL_CODE','Le code postal est nécessaire pour pouvoir utiliser le module UPS');
define('SHIPPING_FEDEX_ERROR_POSTAL_CODE','Le code postal est nécessaire pour pouvoir utiliser le module FedEx');
define('SHIPPING_FEDEX_NO_PACKAGES','Il n&#39;y avait aucun colis à expédier, ou la quantité totale ou le poids était nul.');
define('SHIPPING_FEDEX_DELETE_ERROR','Erreur - Impossible de supprimer l&#39;envoi, pas assez d&#39;informations fournies.');
define('SHIPPING_FEDEX_CANNOT_DELETE','Erreur - Impossible de supprimer un envoi dont l&#39;étiquette a été générée avant aujourd&#39;hui.');
define('SHIPPING_FEDEX_LABEL_DELETED','Étiquette FedEx - Supprimée');
define('SHIPPING_FEDEX_END_OF_DAY','FedEx - Fermeture de fin de journée');
define('SHIPPING_USPS_ERROR_STATUS', '<strong>Attention:</strong>Le module d&#39;expédition USPS est en erreur. Soit le nom d&#39;utilisateur manque, soit le module est défini en TEST plutôt qu&#39;en PRODUCTION et ne marchera pas.<br />Si vous ne pouvez retrouver les devis d&#39;expédition USPS, contactez USPS pour activer votre compte Web Tools sur leur serveur de production. 1-800-344-7779 ou icustomercare@usps.com');

// Audit log messages
define('SHIPPING_LOG_FEDEX_LABEL_PRINTED','Étiquette générée');

// shipping options
define('SHIPPING_1DEAM','1 Day Early a.m.');
define('SHIPPING_1DAM','1 Day a.m.');
define('SHIPPING_1DPM','1 Day p.m.');
define('SHIPPING_1DFRT','1 Day Freight');
define('SHIPPING_2DAM','2 Day a.m.');
define('SHIPPING_2DPM','2 Day p.m.');
define('SHIPPING_2DFRT','2 Day Freight');
define('SHIPPING_3DPM','3 Day');
define('SHIPPING_3DFRT','3 Day Freight');
define('SHIPPING_GND','Ground');
define('SHIPPING_GDR','Ground Residential');
define('SHIPPING_GNDFRT','Ground LTL Freight');
define('SHIPPING_I2DEAM','Worldwide Early Express');
define('SHIPPING_I2DAM','Worldwide Express');
define('SHIPPING_I3D','Worldwide Expedited');
define('SHIPPING_IGND','Ground (Canada)');

define('SHIPPING_DAILY','Daily Pickup');
define('SHIPPING_CARRIER','Carrier Customer Counter');
define('SHIPPING_ONE_TIME','Request/One Time Pickup');
define('SHIPPING_ON_CALL','On Call Air');
define('SHIPPING_RETAIL','Suggested Retail Rates');
define('SHIPPING_DROP_BOX','Drop Box/Center');
define('SHIPPING_AIR_SRV','Air Service Center');

define('SHIPPING_TEXT_LBS','lbs');
define('SHIPPING_TEXT_KGS','kgs');

define('SHIPPING_TEXT_IN','in');
define('SHIPPING_TEXT_CM','cm');

define('SHIPPING_ENVENLOPE','Envelope/Letter');
define('SHIPPING_CUST_SUPP','Customer Supplied');
define('SHIPPING_TUBE','Carrier Tube');
define('SHIPPING_PAK','Carrier Pak');
define('SHIPPING_BOX','Carrier  Box');
define('SHIPPING_25KG','25kg Box');
define('SHIPPING_10KG','10kg Box');

define('SHIPPING_CASH','Espèces');
define('SHIPPING_CHECK','Chèque');
define('SHIPPING_CASHIERS','Chèque de Caisse');
define('SHIPPING_MO','Mandat');
define('SHIPPING_ANY','Any');

define('SHIPPING_NO_CONF','Pas de confirmation de livraison');
define('SHIPPING_NO_SIG_RQD','Pas de signature nécessaire');
define('SHIPPING_SIG_REQ','Signature nécessaire');
define('SHIPPING_ADULT_SIG','Signature adulte nécessaire');

define('SHIPPING_RET_CARRIER','Carrier Return Label');
define('SHIPPING_RET_LOCAL','Print Local Return Label');
define('SHIPPING_RET_MAILS','Carrier Prints and Mails Return Label');

define('SHIPPING_SENDER','Expéditeur');
define('SHIPPING_RECEIPIENT','Destinataire');
define('SHIPPING_THIRD_PARTY','Tierce Partie');
define('SHIPPING_COLLECT','Collecter');

// Set up choices for dropdown menus for general shipping methods, not all are used for each method
$shipping_defaults = array();
// enable or disable Time in Travel information/address verification, if false postal code will be used
$shipping_defaults['TnTEnable'] = true;

$shipping_defaults['service_levels'] = array(
	'1DEam'  => SHIPPING_1DEAM,
	'1Dam'   => SHIPPING_1DAM,
	'1Dpm'   => SHIPPING_1DPM,
	'1DFrt'  => SHIPPING_1DFRT,
	'2Dam'   => SHIPPING_2DAM,
	'2Dpm'   => SHIPPING_2DPM,
	'2DFrt'  => SHIPPING_2DFRT,
	'3Dpm'   => SHIPPING_3DPM,
	'3DFrt'  => SHIPPING_3DFRT,
	'GND'    => SHIPPING_GND,
	'GDR'    => SHIPPING_GDR,
	'GndFrt' => SHIPPING_GNDFRT,
	'I2DEam' => SHIPPING_I2DEAM,
	'I2Dam'  => SHIPPING_I2DAM,
	'I3D'    => SHIPPING_I3D,
	'IGND'   => SHIPPING_IGND,
);

// Pickup Type Code - conforms to UPS standards per the XML specification
$shipping_defaults['pickup_service'] = array(
	'01' => SHIPPING_DAILY,
	'03' => SHIPPING_CARRIER,
	'06' => SHIPPING_ONE_TIME,
	'07' => SHIPPING_ON_CALL,
	'11' => SHIPPING_RETAIL,
	'19' => SHIPPING_DROP_BOX,
	'20' => SHIPPING_AIR_SRV,
);

// Weight Unit of Measure
// Value: char(3), Values "LBS" or "KGS"
$shipping_defaults['weight_unit'] = array(
	'LBS' => SHIPPING_TEXT_LBS,
	'KGS' => SHIPPING_TEXT_KGS,
);

// Package Dimensions Unit of Measure
$shipping_defaults['dimension_unit'] = array(
	'IN' => SHIPPING_TEXT_IN,
	'CM' => SHIPPING_TEXT_CM,
);
	
// Package Type
$shipping_defaults['package_type'] = array(
	'01' => SHIPPING_ENVENLOPE,
	'02' => SHIPPING_CUST_SUPP,
	'03' => SHIPPING_TUBE,
	'04' => SHIPPING_PAK,
	'21' => SHIPPING_BOX,
	'24' => SHIPPING_25KG,
	'25' => SHIPPING_10KG,
);

// COD Funds Code
$shipping_defaults['cod_funds_code'] = array(
	'0' => SHIPPING_CASH,
	'1' => SHIPPING_CHECK,
	'2' => SHIPPING_CASHIERS,
	'3' => SHIPPING_MO,
	'4' => SHIPPING_ANY,
);

// Delivery Confirmation
// Package delivery confirmation only allowed for shipments with US origin/destination combination.
$shipping_defaults['delivery_confirmation'] = array(
//	'0' => SHIPPING_NO_CONF,
	'1' => SHIPPING_NO_SIG_RQD,
	'2' => SHIPPING_SIG_REQ,
	'3' => SHIPPING_ADULT_SIG,
);

// Return label services
$shipping_defaults['return_label'] = array(
	'0' => SHIPPING_RET_CARRIER,
	'1' => SHIPPING_RET_LOCAL,
	'2' => SHIPPING_RET_MAILS,
);

// Billing options
$shipping_defaults['bill_options'] = array(
	'0' => SHIPPING_SENDER,
	'1' => SHIPPING_RECEIPIENT,
	'2' => SHIPPING_THIRD_PARTY,
	'3' => SHIPPING_COLLECT,
);

$ltl_classes = array('0' => TEXT_SELECT, '050' => '50', '055' => '55', '060' => '60', '065' => '65', '070' => '70', 
	'077' => '77.5', '085' => '85', '092' => '92.5', '100' => '100', '110' => '110', '125' => '125',
	'150' => '150', '175' => '175', '200' => '200', '250' => '250', '300' => '300');

?>