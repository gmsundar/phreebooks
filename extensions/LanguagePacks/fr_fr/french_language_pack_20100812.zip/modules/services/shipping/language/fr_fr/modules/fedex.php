<?php
// +-----------------------------------------------------------------+
// |                   PhreeBooks Open Source ERP                    |
// +-----------------------------------------------------------------+
// | Copyright (c) 2008, 2009, 2010 PhreeSoft, LLC                   |
// | http://www.PhreeSoft.com                                        |
// +-----------------------------------------------------------------+
// | This program is free software: you can redistribute it and/or   |
// | modify it under the terms of the GNU General Public License as  |
// | published by the Free Software Foundation, either version 3 of  |
// | the License, or any later version.                              |
// |                                                                 |
// | This program is distributed in the hope that it will be useful, |
// | but WITHOUT ANY WARRANTY; without even the implied warranty of  |
// | MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the   |
// | GNU General Public License for more details.                    |
// |                                                                 |
// | The license that is bundled with this package is located in the |
// | file: /doc/manual/ch01-Introduction/license.html.               |
// | If not, see http://www.gnu.org/licenses/                        |
// +-----------------------------------------------------------------+
//  Path: /modules/services/shipping/language/fr_fr/modules/fedex.php
//

define('FEDEX_LTL_RATE_URL','http://www.fedexfreight.fedex.com/XMLLTLRating.jsp');
define('FEDEX_EXPRESS_RATE_URL','https://gateway.fedex.com:443/GatewayDC');
define('FEDEX_EXPRESS_TEST_RATE_URL','https://gatewaybeta.fedex.com:443/GatewayDC');

define('MODULE_SHIPPING_FEDEX_TEXT_TITLE', 'Federal Express');
define('MODULE_SHIPPING_FEDEX_TITLE_SHORT', 'FedEx');
define('MODULE_SHIPPING_FEDEX_TEXT_DESCRIPTION', 'FedEx Express');

define('MODULE_SHIPPING_FEDEX_GND','Ground');
define('MODULE_SHIPPING_FEDEX_GDR','Home Delivery');
define('MODULE_SHIPPING_FEDEX_1DM','First Overnight');
define('MODULE_SHIPPING_FEDEX_1DA','Priority Overnight');
define('MODULE_SHIPPING_FEDEX_1DP','Standard Overnight');
define('MODULE_SHIPPING_FEDEX_2DP','Express 2 Day');
define('MODULE_SHIPPING_FEDEX_3DS','Express Saver');
define('MODULE_SHIPPING_FEDEX_XDM','Int. First');
define('MODULE_SHIPPING_FEDEX_XPR','Int. Priority');
define('MODULE_SHIPPING_FEDEX_XPD','Int. Economy');
define('MODULE_SHIPPING_FEDEX_1DF','1 Day Freight');
define('MODULE_SHIPPING_FEDEX_2DF','2 Day Freight');
define('MODULE_SHIPPING_FEDEX_3DF','3 Day Freight');
define('MODULE_SHIPPING_FEDEX_GDF','Ground LTL Freight');

define('SHIPPING_FEDEX_VIEW_REPORTS','Afficher les éditions pour ');
define('SHIPPING_FEDEX_CLOSE_REPORTS','Clôture éditions');
define('SHIPPING_FEDEX_MULTIWGHT_REPORTS','Édition multipoids');
define('SHIPPING_FEDEX_HAZMAT_REPORTS','Édition matières dangereuses');
define('SHIPPING_FEDEX_SHIPMENTS_ON','Livraisons avec FedEx activées');

define('SHIPPING_FEDEX_RATE_ERROR','FedEx erreur taux de réponse: ');
define('SHIPPING_FEDEX_RATE_CITY_MATCH','La ville ne correspond pas au code postal.');
define('SHIPPING_FEDEX_RATE_TRANSIT',' Jour(s) de transit, arrive ');
define('SHIPPING_FEDEX_TNT_ERROR',' FedEx Erreur temps de transit # ');

// Ship manager Defines
define('SRV_SHIP_FEDEX','Expédier un colis');
define('SRV_CLOSE_FEDEX_SHIP','Fermer les envois FedEx de cette journée');
define('SRV_SHIP_FEDEX_RECP_INFO','Renseignements sur le destinataire');
define('SRV_SHIP_FEDEX_EMAIL_NOTIFY','Notifications par e-mail');
define('SRV_SHIP_FEDEX_BILL_DETAIL','Détails de facturation');
define('SRV_SHIP_FEDEX_LTL_FREIGHT','LTL Transport');
define('SRV_FEDEX_LTL_CLASS','Classe de transport');

?>