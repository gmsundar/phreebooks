<?php
// +-----------------------------------------------------------------+
// |                   PhreeBooks Open Source ERP                    |
// +-----------------------------------------------------------------+
// | Copyright (c) 2008, 2009, 2010 PhreeSoft, LLC                   |
// | http://www.PhreeSoft.com                                        |
// +-----------------------------------------------------------------+
// | This program is free software: you can redistribute it and/or   |
// | modify it under the terms of the GNU General Public License as  |
// | published by the Free Software Foundation, either version 3 of  |
// | the License, or any later version.                              |
// |                                                                 |
// | This program is distributed in the hope that it will be useful, |
// | but WITHOUT ANY WARRANTY; without even the implied warranty of  |
// | MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the   |
// | GNU General Public License for more details.                    |
// |                                                                 |
// | The license that is bundled with this package is located in the |
// | file: /doc/manual/ch01-Introduction/license.html.               |
// | If not, see http://www.gnu.org/licenses/                        |
// +-----------------------------------------------------------------+
//  Path: /modules/accounts/language/fr_fr/language.php
//

// *************  Release 2.1 changes  *********************
define('RECORD_NUM_REF_ONLY','ID de l&#39;enregistrement (uniquement à titre de référence) = ');

// *************  Release 2.0 changes  *********************
define('TEXT_NEW_CONTACT','Nouveau Contact');
define('TEXT_COPY_ADDRESS','Adresse de Transfert');
define('TEXT_CONTACTS','Contacts');
define('TEXT_TITLE','Intitulé');
define('TEXT_LINK_TO','Lien vers:');
define('ACT_CATEGORY_I_ADDRESS','Ajouter/Modifier Contact');
define('ACT_CONTACT_HISTORY','Historique du Contact');
define('ACT_I_SHORT_NAME','Contact');
define('ACT_I_HEADING_TITLE','PhreeCRM');
define('ACT_I_TYPE_NAME','Contacts');
define('ACT_I_PAGE_TITLE_EDIT','Modifier Contact');
define('ACT_SHORT_NAME','ID Contact');
define('ACT_GL_ACCOUNT_TYPE','Catégorie');
define('ACT_ACCOUNT_NUMBER','ID Facebook');
define('ACT_ID_NUMBER','ID Twitter');
define('ACT_REP_ID','Lien vers client/fournisseur');
define('ACT_FIRST_DATE','Date de création');
define('ACT_LAST_DATE1','Dernière mise à jour');
define('ACT_ERROR_DUPLICATE_CONTACT','Cet identifiant de contact existe déjà dans le système, veuillez saisir un nouvel identifiant de contact.');

// *************  Release 1.9 changes  *********************
// Text specific to Projects
define('ACT_J_TYPE_NAME','projets');
define('ACT_J_HEADING_TITLE', 'Projets');
define('ACT_J_SHORT_NAME', 'ID Projet');
define('ACT_J_ID_NUMBER','Référence Commande Fournisseur');
define('ACT_J_REP_ID','ID Représentant');
define('ACT_J_PAGE_TITLE_EDIT','Éditer le projet');
define('ACT_J_ACCOUNT_NUMBER','Casser en phases:');
define('ACT_ID_AUTO_FILL','(Laisser vide pour que l&#39;ID soit généré par le système)');

// *********************************************************
// Targeted defines (to differentiate wording differences for different account types)
// Text specific to Vendor accounts
define('ACT_V_TYPE_NAME','Fournisseurs');
define('ACT_V_HEADING_TITLE', 'Fournisseurs');
define('ACT_V_SHORT_NAME', 'ID Fournisseur');
define('ACT_V_GL_ACCOUNT_TYPE','Compte achat GL');
define('ACT_V_ID_NUMBER','EIN Fédéral');
define('ACT_V_REP_ID','ID Représentant Achat');
define('ACT_V_ACCOUNT_NUMBER','N° de compte');
define('ACT_V_FIRST_DATE','Fournisseur depuis le: ');
define('ACT_V_LAST_DATE1','Date de la dernière facture: ');
define('ACT_V_LAST_DATE2','Date du dernier paiement: ');
define('ACT_V_PAGE_TITLE_EDIT','Éditer Fournisseur');
// Text specific to Employee accounts
define('ACT_E_TYPE_NAME','Employés');
define('ACT_E_HEADING_TITLE', 'Employés');
define('ACT_E_SHORT_NAME', 'ID Employé');
define('ACT_E_GL_ACCOUNT_TYPE','Type Employé');
define('ACT_E_ID_NUMBER','N° Sécurité Sociale');
define('ACT_E_REP_ID','ID Département');
define('ACT_E_ACCOUNT_NUMBER','Inutilisé');
define('ACT_E_FIRST_DATE','Date d&#39;embauche: ');
define('ACT_E_LAST_DATE1','Date de dernière augmentation: ');
define('ACT_E_LAST_DATE2','Date de résiliation: ');
define('ACT_E_PAGE_TITLE_EDIT','Éditer Employé');
// Text specific to branch accounts
define('ACT_B_TYPE_NAME','Succursales');
define('ACT_B_HEADING_TITLE', 'Succursales');
define('ACT_B_SHORT_NAME', 'ID Succursale');
define('ACT_B_GL_ACCOUNT_TYPE','Inutilisé');
define('ACT_B_ID_NUMBER','Inutilisé');
define('ACT_B_REP_ID','Inutilisé');
define('ACT_B_ACCOUNT_NUMBER','Inutilisé');
define('ACT_B_FIRST_DATE','Date de création: ');
define('ACT_B_LAST_DATE1','Inutilisé');
define('ACT_B_LAST_DATE2','Inutilisé');
define('ACT_B_PAGE_TITLE_EDIT','Éditer Succursale');
// Text specific to Customer accounts (default)
define('ACT_C_TYPE_NAME','Clients');
define('ACT_C_HEADING_TITLE', 'Clients');
define('ACT_C_SHORT_NAME', 'ID Client');
define('ACT_C_GL_ACCOUNT_TYPE','Compte GL Ventes');
define('ACT_C_ID_NUMBER','N° Licence de revente');
define('ACT_C_REP_ID','ID Représentant');
define('ACT_C_ACCOUNT_NUMBER','N° Compte');
define('ACT_C_FIRST_DATE','Client depuis: ');
define('ACT_C_LAST_DATE1','Date de la dernière facture: ');
define('ACT_C_LAST_DATE2','Date du dernier paiement: ');
define('ACT_C_PAGE_TITLE_EDIT','Éditer Client');

// Category headings
define('ACT_CATEGORY_CONTACT','Informations sur le contact');
define('ACT_CATEGORY_M_ADDRESS','Adresse postale principale');
define('ACT_CATEGORY_S_ADDRESS','Adresse de livraison');
define('ACT_CATEGORY_B_ADDRESS','Adresse de facturation');
define('ACT_CATEGORY_P_ADDRESS','Informations de paiement par carte de crédit');
define('ACT_CATEGORY_INFORMATION','Informations sur le compte');
define('ACT_CATEGORY_PAYMENT_TERMS','Conditions de paiement');
define('TEXT_ADDRESS_BOOK','Adresses');
define('TEXT_EMPLOYEE_ROLES','Rôles Employé');
define('ACT_ACT_HISTORY','Historique du compte');
define('ACT_ORDER_HISTORY','Historique des commandes');
define('ACT_SO_HIST','Historique commande client (%s plus récents résultats)');
define('ACT_PO_HIST','Historique commande fournisseur (%s plus récents résultats)');
define('ACT_INV_HIST','Historique facture (%s plus récents résultats)');
define('ACT_SO_NUMBER','N° Commande Client');
define('ACT_PO_NUMBER','N° Commande Fournisseur');
define('ACT_INV_NUMBER','N° Facture');
define('ACT_NO_RESULTS','Aucun résultat trouvé');
define('ACT_PAYMENT_MESSAGE','Entrez les informations de paiement à stocker dans PhreeBooks.');
define('ACT_PAYMENT_CREDIT_CARD_NUMBER','Numéro de la carte de crédit');
define('ACT_PAYMENT_CREDIT_CARD_EXPIRES','Date d&#39;expiration de la carte de crédit');
define('ACT_PAYMENT_CREDIT_CARD_CVV2','Code de sécurité');
define('AR_CONTACT_STATUS','Situation du client');
define('AP_CONTACT_STATUS','Situation du fournisseur');

// Account Terms (used in several modules)
define('ACT_SPECIAL_TERMS','Conditons spéciales');
define('ACT_TERMS_DUE','Conditions (exigible le)');
define('ACT_TERMS_DEFAULT','Conditions par défaut: ');
define('ACT_TERMS_USE_DEFAULTS', 'Utiliser les conditions par défaut');
define('ACT_COD_SHORT','CRBT');
define('ACT_COD_LONG','Contre-remboursement');
define('ACT_PREPAID','Payé d&#39;avance');
define('ACT_SPECIAL_TERMS', 'Exigible en nombre de jours');
define('ACT_END_OF_MONTH','Exigible en fin de mois');
define('ACT_DAY_NEXT_MONTH','Exigible à la date spécifiée');
define('ACT_DUE_ON', 'Exigible le: ');
define('ACT_DISCOUNT', 'Remise de ');
define('ACT_EARLY_DISCOUNT', ' %. ');
define('ACT_EARLY_DISCOUNT_SHORT', '% ');
define('ACT_DUE_IN','Payable en ');
define('ACT_TERMS_EARLY_DAYS', ' jour(s). ');
define('ACT_TERMS_NET','Net ');
define('ACT_TERMS_STANDARD_DAYS', ' jour(s). ');
define('ACT_TERMS_CREDIT_LIMIT', 'Limite de crédit: ');
define('ACT_AMT_PAST_DUE','Montant en souffrance: ');
define('ACT_GOOD_STANDING','Compte en règle');
define('ACT_OVER_CREDIT_LIMIT','Compte au-dessus de la limite de crédit');
define('ACT_HAS_PAST_DUE_AMOUNT','Le compte a dépassé le solde dû');

// Account table fields - common to all account types
define('ACT_POPUP_WINDOW_TITLE', 'Recherche de Compte');
define('ACT_POPUP_TERMS_WINDOW_TITLE', 'Conditions de Paiement');

// misc information messages
define('ACT_DISPLAY_NUMBER_OF_ACCOUNTS', 'Affiche <b>%d</b> à <b>%d</b> (sur <b>%d</b> %s)');
define('ACT_WARN_DELETE_ADDRESS','Êtes-vous sûr(e) de vouloir supprimer cette adresse ?');
define('ACT_WARN_DELETE_ACCOUNT', 'Êtes-vous sûr(e) de vouloir supprimer ce compte ?');
define('ACT_WARN_DELETE_PAYMENT', 'Êtes-vous sûr(e) de vouloir supprimer cet enregistrement de paiement ?');
define('ACT_ERROR_CANNOT_DELETE','Impossible de supprimer ce compte car un enregistrement de journal contient ce compte');
define('ACT_ERROR_DUPLICATE_ACCOUNT','L&#39;ID de compte existe déjà dans le système, veuillez saisir un nouvel ID.');
define('ACT_ERROR_NO_ACCOUNT_ID','Lorsque vous ajoutez un nouveau client/fournisseur, le champ ID est nécessaire, veuillez saisir un ID unique.');
define('ACT_ERROR_ACCOUNT_NOT_FOUND','Le compte que vous recherchez est introuvable !');
define('ACT_BILLING_MESSAGE','Ces champs ne sont pas obligatoires, sauf si une adresse de facturation est ajoutée.');
define('ACT_SHIPPING_MESSAGE','Ces champs ne sont pas obligatoires, sauf si une adresse de livraison est ajoutée.');
define('ACT_NO_ENCRYPT_KEY_ENTERED','AVERTISSEMENT: La clé de chiffrement n&#39;a pas été entrée. Les informations de carte de crédit stockées ne seront pas affichées et les valeurs saisies ici ne seront pas enregistrées !');
define('ACT_PAYMENT_REF','Réf. du Paiement');
define('ACT_LIST_OPEN_ORDERS','Ouvrir Commandes');
define('ACT_LIST_OPEN_INVOICES','Ouvrir Factures');
define('ACT_CARDHOLDER_NAME','Nom du possesseur de la carte');
define('ACT_CARD_HINT','Indice de laCarte');
define('ACT_EXP','Expire');

define('ACT_NO_KEY_EXISTS','Un paiement a été spécifié mais la clé de chiffrement n&#39;a pas été saisie. L&#39;adresse de paiement a été enregistrée, mais pas les informations de paiement.');

// java script errors
define('ACT_JS_SHORT_NAME', '* L&#39;entrée &#39;ID&#39; ne peut pas être vide.\n');

// Audit log messages
define('ACT_LOG_ADD_ACCOUNT','Compte créé - ');
define('ACT_LOG_UPDATE_ACCOUNT','Compte mis à jour - ');
define('ACT_LOG_DELETE_ACCOUNT','Compte supprimé - ');
?>