<?php
// +-----------------------------------------------------------------+
// |                   PhreeBooks Open Source ERP                    |
// +-----------------------------------------------------------------+
// | Copyright (c) 2008, 2009, 2010 PhreeSoft, LLC                   |
// | http://www.PhreeSoft.com                                        |
// +-----------------------------------------------------------------+
// | This program is free software: you can redistribute it and/or   |
// | modify it under the terms of the GNU General Public License as  |
// | published by the Free Software Foundation, either version 3 of  |
// | the License, or any later version.                              |
// |                                                                 |
// | This program is distributed in the hope that it will be useful, |
// | but WITHOUT ANY WARRANTY; without even the implied warranty of  |
// | MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the   |
// | GNU General Public License for more details.                    |
// |                                                                 |
// | The license that is bundled with this package is located in the |
// | file: /doc/manual/ch01-Introduction/license.html.               |
// | If not, see http://www.gnu.org/licenses/                        |
// +-----------------------------------------------------------------+
//  Path: /modules/install/language/fr_fr/admin_setup.php
//

  define('TEXT_PAGE_HEADING', 'Installation de PhreeBooks&trade; - Paramètrage du compte Administrateur');
  define('SAVE_ADMIN_SETTINGS', 'Sauvegarder les paramètres Admin');//this comes before TEXT_MAIN
  define('TEXT_MAIN', 'Pour gèrer votre boutique PhreeBooks&trade; , vous aurez besoin d&#39;un compte Administrateur. Veuillez choisir un identifiant d&#39;administrateur, son mot de passe, et entrer une adresse e-mail vers laquelle les éventuelles réinitialisations du mot de passe vous seront envoyées. Vérifiez bien vos informations et cliquez sur <em>'.SAVE_ADMIN_SETTINGS.'</em> lorsque c&#39;est fait.');
  define('ADMIN_INFORMATION', 'Informations Administrateur');
  define('ADMIN_USERNAME', 'Identifiant Administrateur');
  define('ADMIN_USERNAME_INSTRUCTION', 'Entrez le nom d&#39;utilisateur à utiliser pour votre compte Administrateur de PhreeBooks&trade; .');
  define('ADMIN_PASS', 'Mot de passe Administrateur');
  define('ADMIN_PASS_INSTRUCTION', 'Entrez le mode de passe à utiliser pour votre compte Administrateur de PhreeBooks&trade; .');
  define('ADMIN_PASS_CONFIRM', 'Confirmez le mot de passe');
  define('ADMIN_PASS_CONFIRM_INSTRUCTION', 'Confirmez le mot de passe de votre compte Administrateur de PhreeBooks&trade; .');
  define('ADMIN_EMAIL', 'E-mail Administrateur');
  define('ADMIN_EMAIL_INSTRUCTION', 'Entrez l&#39;adresse e-mail à utiliser pour votre compte administrateur de PhreeBooks&trade; .');
  define('UPGRADE_DETECTION','Détection des mises à jour');
  define('UPGRADE_INSTRUCTION_TITLE','Vérifier les mises à jour de PhreeBooks&trade; lors de la connexion à l&#39;espace d&#39;Administration');
  define('UPGRADE_INSTRUCTION_TEXT','Le serveur en ligne de versions de PhreeBooks&trade; sera contacté pour déterminer si une mise à jour est disponible ou non. Si une mise à jour est disponible, un message apparaîtra dans l&#39;administration.  La mise à jour NE s&#39;installe PAS automatiquement.<br />Vous pourrez modifier cette scrutation plus tard par Administration-&gt;Configuration-&gt;Ma boutique-&gt;Vérifier_si_une_mise_à_jour_est_disponible.');

?>