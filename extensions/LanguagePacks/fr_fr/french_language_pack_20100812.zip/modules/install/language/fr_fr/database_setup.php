<?php
// +-----------------------------------------------------------------+
// |                   PhreeBooks Open Source ERP                    |
// +-----------------------------------------------------------------+
// | Copyright (c) 2008, 2009, 2010 PhreeSoft, LLC                   |
// | http://www.PhreeSoft.com                                        |
// +-----------------------------------------------------------------+
// | This program is free software: you can redistribute it and/or   |
// | modify it under the terms of the GNU General Public License as  |
// | published by the Free Software Foundation, either version 3 of  |
// | the License, or any later version.                              |
// |                                                                 |
// | This program is distributed in the hope that it will be useful, |
// | but WITHOUT ANY WARRANTY; without even the implied warranty of  |
// | MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the   |
// | GNU General Public License for more details.                    |
// |                                                                 |
// | The license that is bundled with this package is located in the |
// | file: /doc/manual/ch01-Introduction/license.html.               |
// | If not, see http://www.gnu.org/licenses/                        |
// +-----------------------------------------------------------------+
//  Path: /modules/install/language/fr_fr/database_setup.php
//

  define('SAVE_DATABASE_SETTINGS', 'Sauvegarder la configuration BDD');//this comes before TEXT_MAIN
  define('TEXT_MAIN', 'Ensuite, nous avons besoin de connaître quelques informations sur vos paramètres de base de données. Veuillez entrer soigneusement chaque paramètre dans le champ approprié et cliquez sur <em>' . SAVE_DATABASE_SETTINGS . '</em> pour continuer.');
  define('TEXT_PAGE_HEADING', 'Installation de PhreeBooks&trade; - Paramètrage Base de Données');
  define('DATABASE_INFORMATION', 'Informations sur la base de données');
  define('DATABASE_TYPE', 'Type de la base de données');
  define('DATABASE_TYPE_INSTRUCTION', 'Choisissez le type de base de données que vous utilisez.');
  define('DATABASE_HOST', 'Hôte de la base de données');
  define('DATABASE_HOST_INSTRUCTION', 'Qu&#39;est-ce que l&#39;hôte de la base de données ? L&#39;hôte de la base de données peut être sous la forme d&#39;un nom d&#39;hôte, comme &#39;db1.myserver.com&#39;, ou d&#39;une adresse IP, comme &#39;192.168.0.1&#39;.');
  define('DATABASE_USERNAME', 'Utilisateur de la base de données');
  define('DATABASE_USERNAME_INSTRUCTION', 'Avec quel nom d&#39;utilisateur se connecte t&#39;on à votre base de données ? Un exemple de nom d&#39;utilisateur est &#39;root&#39;.');
  define('DATABASE_PASSWORD', 'Mot de passe de la base de données');
  define('DATABASE_PASSWORD_INSTRUCTION', 'Avec quel mot de passe se connecte t&#39;on à votre base de données ? Le mot de passe va de pair avec le nom d&#39;utilisateur pour former un compte utilisateur de votre base de données.');
  define('DATABASE_NAME', 'Nom de la base de données de la société');
  define('DATABASE_NAME_INSTRUCTION', 'Quel est le nom de la base de données utilisée pour enregistrer toutes vos données ? Un exemple de nom de BDD est &#39;ma_societe&#39;. Les espaces et caratères spéciaux ne sont pas autorisés. <!-- La base de données sera créée si elle n&#39;est pas trouvée. -->');
  define('DATABASE_PREFIX', 'Préfixe des tables');
  define('DATABASE_PREFIX_INSTRUCTION', 'Quel préfixe voulez-vous utiliser pour les tables à créer dans votre base de données ?  Exemple: &#39;pb_&#39;. Laissez vide si vous n&#39;avez pas besoin de préfixe.<br />Vous pouvez utiliser les préfixes pour avoir plusieurs sociétés dans une même base de données.');
  define('DATABASE_CREATE', 'Créer la base de données ?');
  define('DATABASE_CREATE_INSTRUCTION', 'Voulez-vous que PhreeBooks&trade; créée la base de données ?');
  define('DATABASE_CONNECTION', 'Connection permanente');
  define('DATABASE_CONNECTION_INSTRUCTION', 'Voulez-vous activer les connexions permanentes à la base de données ? Cliquez sur &#39;non&#39; si vous n&#39;êtes pas ssûr(e).');
  define('DATABASE_SESSION', 'Sessions en base de données');
  define('DATABASE_SESSION_INSTRUCTION', 'Voulez-vous stocker vos sessions dans votre base de données ? Cliquez sur &#39;oui&#39; si vous n&#39;êtes pas ssûr(e).');
  define('CACHE_TYPE', 'Méthode de cache SQL');
  define('CACHE_TYPE_INSTRUCTION', 'Sélectionnez la méthode à utiliser pour la mise en cache SQL.');
  define('SQL_CACHE', 'Répertoire de cache SQL/Sessions');
  define('SQL_CACHE_INSTRUCTION', 'Entrez le répertoire à utiliser pour la mise en cache basée sur des fichiers.');



  define('REASON_TABLE_ALREADY_EXISTS','CREATE TABLE %s impossible car elle existe déjà');
  define('REASON_TABLE_DOESNT_EXIST','DROP TABLE %s impossible car elle n&#39;existe pas.');
  define('REASON_CONFIG_KEY_ALREADY_EXISTS','INSERT configuration_key "%s" impossible car elle existe déjà');
  define('REASON_COLUMN_ALREADY_EXISTS','ADD COLUMN %s impossible car elle existe déjà.');
  define('REASON_COLUMN_DOESNT_EXIST_TO_DROP','DROP COLUMN %s impossible car elle n&#39;existe pas.');
  define('REASON_COLUMN_DOESNT_EXIST_TO_CHANGE','CHANGE COLUMN %s impossible car elle n&#39;existe pas.');
  define('REASON_PRODUCT_TYPE_LAYOUT_KEY_ALREADY_EXISTS','INSERT prod-type-layout configuration_key "%s" impossible car elle existe déjà');
  define('REASON_INDEX_DOESNT_EXIST_TO_DROP','DROP INDEX %s ON TABLE %s impossible car il n&#39;existe pas.');
  define('REASON_PRIMARY_KEY_DOESNT_EXIST_TO_DROP','DROP PRIMARY KEY ON TABLE %s impossible car elle n&#39;existe pas.');
  define('REASON_INDEX_ALREADY_EXISTS','ADD INDEX %s ON TABLE %s impossible car il existe déjà.');
  define('REASON_PRIMARY_KEY_ALREADY_EXISTS','ADD PRIMARY KEY TO TABLE %s impossible car une clé primaire existe déjà.');
  define('REASON_NO_PRIVILEGES','L&#39;utilisateur %s@%s n&#39;a pas les privilèges %s sur la base de données.');

?>