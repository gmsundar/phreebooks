<?php
// +-----------------------------------------------------------------+
// |                   PhreeBooks Open Source ERP                    |
// +-----------------------------------------------------------------+
// | Copyright (c) 2008, 2009, 2010 PhreeSoft, LLC                   |
// | http://www.PhreeSoft.com                                        |
// +-----------------------------------------------------------------+
// | This program is free software: you can redistribute it and/or   |
// | modify it under the terms of the GNU General Public License as  |
// | published by the Free Software Foundation, either version 3 of  |
// | the License, or any later version.                              |
// |                                                                 |
// | This program is distributed in the hope that it will be useful, |
// | but WITHOUT ANY WARRANTY; without even the implied warranty of  |
// | MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the   |
// | GNU General Public License for more details.                    |
// |                                                                 |
// | The license that is bundled with this package is located in the |
// | file: /doc/manual/ch01-Introduction/license.html.               |
// | If not, see http://www.gnu.org/licenses/                        |
// +-----------------------------------------------------------------+
//  Path: /modules/install/language/fr_fr/language.php
//

  define('YES', 'OUI');
  define('NO', 'NON');
  define('LANGUAGE','Français (FR)');
  define('LANGUAGE_TEXT','Langues disponibles: ');

  // Global entries for the <html> tag
  define('HTML_PARAMS','lang="fr-FR" xml:lang="fr-FR"');

  // charset for web pages and emails
  define('CHARSET', 'UTF-8');

  // META TAG TITLE
  define('META_TAG_TITLE', 'Installateur PhreeBooks&trade;');

  // Navigation
  define('INSTALL_NAV_WELCOME', 'Bienvenue');
  define('INSTALL_NAV_LICENSE', 'Licence');
  define('INSTALL_NAV_PREREQ', 'Préalables');
  define('INSTALL_NAV_SYSTEM', 'Paramètrage Système');
  define('INSTALL_NAV_DATABASE', 'Paramètrage Base de Données');
  define('INSTALL_NAV_ADMIN', 'Paramètrage Administrateur');
  define('INSTALL_NAV_COMPANY', 'Paramètrage Société');
  define('INSTALL_NAV_CHART', 'Plan Comptable');
  define('INSTALL_NAV_FY', 'Paramètrage Exercice Fiscal');
  define('INSTALL_NAV_DEFAULTS', 'Comptes par Défaut');
  define('INSTALL_NAV_FINISHED', 'Terminer');

  if (isset($_GET['main_page']) && ($_GET['main_page']== 'index' || $_GET['main_page']== 'license')) {
    define('TEXT_ERROR_WARNING', 'Bonjour: Juste un petit nombre de questions qui doivent être résolues avant de continuer.');
  } else {
    define('TEXT_ERROR_WARNING', '<span class="errors"><strong>ATTENTION: Problèmes rencontrés</strong></span>');
  }

  define('DB_ERROR_NOT_CONNECTED', 'Erreur d&#39;installation: Impossible de se connecter à la base de données');

  define('UPLOAD_SETTINGS','La taille maximum d&#39;upload supportée sera la MOINS ÉLEVÉE des valeurs suivantes:.<br />
<em>upload_max_filesize</em> dans php.ini %s <br />
<em>post_max_size</em> dans php.ini: %s <br />' . 
//'<em>PhreeBooks</em> Paramètres Upload: %s <br />' .
'Vous pourriez avoir certains paramètres d&#39;Apache qui vous empêcheront d&#39;uploader des fichiers ou qui limiteront ces fichiers à une taille maximale.
Voir la documentation d&#39;Apache pour plus d&#39;information.');

  define('TEXT_HELP_LINK', ' Plus d&#39;infos...');
  define('TEXT_CLOSE_WINDOW', 'Fermer la fenêtre');

  define('ERROR_TEXT_4_1_2', 'PHP est en version 4.1.2');
  define('ERROR_CODE_4_1_2', '1');

  define('ERROR_TEXT_STORE_CONFIGURE', 'Fichier /includes/configure.php inexistant');
  define('ERROR_CODE_STORE_CONFIGURE', '3');

  define('ERROR_TEXT_PHYSICAL_PATH_ISEMPTY', 'Le chemin d&#39;accès physique est vide');
  define('ERROR_CODE_PHYSICAL_PATH_ISEMPTY', '9');

  define('ERROR_TEXT_PHYSICAL_PATH_INCORRECT', 'Chemin d&#39;accès physique incorrect');
  define('ERROR_CODE_PHYSICAL_PATH_INCORRECT', '10');

  define('ERROR_TEXT_VIRTUAL_HTTP_ISEMPTY', 'Le chemin d&#39;accès virtuel HTTP est vide');
  define('ERROR_CODE_VIRTUAL_HTTP_ISEMPTY', '11');

  define('ERROR_TEXT_VIRTUAL_HTTPS_ISEMPTY', 'Le chemin d&#39;accès virtuel HTTPS est vide');
  define('ERROR_CODE_VIRTUAL_HTTPS_ISEMPTY', '12');

  define('ERROR_TEXT_VIRTUAL_HTTPS_SERVER_ISEMPTY', 'Le serveur virtuel HTTPS est vide');
  define('ERROR_CODE_VIRTUAL_HTTPS_SERVER_ISEMPTY', '13');

  define('ERROR_TEXT_DB_USERNAME_ISEMPTY', 'Le nom d&#39;utilisateur de la base de données est vide');
  define('ERROR_CODE_DB_USERNAME_ISEMPTY', '16'); // re-using another one, since message is essentially the same.

  define('ERROR_TEXT_DB_HOST_ISEMPTY', 'L&#39;hôte de la base de données est vide');
  define('ERROR_CODE_DB_HOST_ISEMPTY', '24');

  define('ERROR_TEXT_DB_NAME_ISEMPTY', 'Le nom de la base de données est vide'); 
  define('ERROR_CODE_DB_NAME_ISEMPTY', '25');

  define('ERROR_TEXT_DB_SQL_NOTEXIST', 'Fichier SQL d&#39;installation inexistant');
  define('ERROR_CODE_DB_SQL_NOTEXIST', '26');

  define('ERROR_TEXT_DB_NOTSUPPORTED', 'Base de données non supportée');
  define('ERROR_CODE_DB_NOTSUPPORTED', '27');

  define('ERROR_TEXT_DB_CONNECTION_FAILED', 'Échec de la connexion à la base de données');
  define('ERROR_CODE_DB_CONNECTION_FAILED', '28');

  define('ERROR_TEXT_DB_CREATE_FAILED', 'Création de la base de données impossible');
  define('ERROR_CODE_DB_CREATE_FAILED', '29');

  define('ERROR_TEXT_DB_NOTEXIST', 'Base de données inexistante');
  define('ERROR_CODE_DB_NOTEXIST', '30');

  define('ERROR_TEXT_STORE_ID_ISEMPTY', 'ID de la boutique requis');
  define('ERROR_CODE_STORE_ID_ISEMPTY', '109');

  define('ERROR_TEXT_STORE_NAME_ISEMPTY', 'Nom de la boutique requis');
  define('ERROR_CODE_STORE_NAME_ISEMPTY', '31');

  define('ERROR_TEXT_STORE_ADDRESS1_ISEMPTY', 'Adresse 1 de la boutique requise');
  define('ERROR_CODE_STORE_ADDRESS1_ISEMPTY', '32');

  define('ERROR_TEXT_STORE_OWNER_EMAIL_ISEMPTY', 'Adresse e-mail de la boutique requise');
  define('ERROR_CODE_STORE_OWNER_EMAIL_ISEMPTY', '33');

  define('ERROR_TEXT_STORE_OWNER_EMAIL_NOTEMAIL', 'Adresse e-mail de la boutique invalide');
  define('ERROR_CODE_STORE_OWNER_EMAIL_NOTEMAIL', '34');

  define('ERROR_TEXT_STORE_POSTAL_CODE_ISEMPTY', 'Code postal de la boutique requis');
  define('ERROR_CODE_STORE_POSTAL_CODE_ISEMPTY', '35');

  define('ERROR_TEXT_DEMO_SQL_NOTEXIST', 'Fichier SQL des produits de démo inexistant');
  define('ERROR_CODE_DEMO_SQL_NOTEXIST', '36');

  define('ERROR_TEXT_ADMIN_USERNAME_ISEMPTY', 'Le nom de l&#39;administrateur est vide');
  define('ERROR_CODE_ADMIN_USERNAME_ISEMPTY', '46');

  define('ERROR_TEXT_ADMIN_EMAIL_ISEMPTY', 'E-mail de l&#39;administrateur vide');
  define('ERROR_CODE_ADMIN_EMAIL_ISEMPTY', '47');

  define('ERROR_TEXT_ADMIN_EMAIL_NOTEMAIL', 'E-mail de l&#39;administrateur invalide');
  define('ERROR_CODE_ADMIN_EMAIL_NOTEMAIL', '48');

  define('ERROR_TEXT_LOGIN_PASS_ISEMPTY', 'Mot de passe administrateur vide');
  define('ERROR_CODE_ADMIN_PASS_ISEMPTY', '49');

  define('ERROR_TEXT_LOGIN_PASS_NOTEQUAL', 'Les mots de passe ne correspondent pas');
  define('ERROR_CODE_ADMIN_PASS_NOTEQUAL', '50');

  define('ERROR_TEXT_PHP_VERSION', 'Version de PHP non supportée');
  define('ERROR_CODE_PHP_VERSION', '55');

  define('ERROR_TEXT_ADMIN_CONFIGURE_WRITE', 'Impossible d&#39;écrire dans le fichier configure.php de l&#39;administration');
  define('ERROR_CODE_ADMIN_CONFIGURE_WRITE', '56');

  define('ERROR_TEXT_STORE_CONFIGURE_WRITE', 'Impossible d&#39;écrire dans /includes/configure.php');
  define('ERROR_CODE_STORE_CONFIGURE_WRITE', '57');

  define('ERROR_TEXT_CACHE_DIR_ISEMPTY', 'Le répertoire de cache Sessions/SQL est vide');
  define('ERROR_CODE_CACHE_DIR_ISEMPTY', '61');

  define('ERROR_TEXT_CACHE_DIR_ISDIR', 'Répertoire de cache Sessions/SQL inexistant');
  define('ERROR_CODE_CACHE_DIR_ISDIR', '62');

  define('ERROR_TEXT_CACHE_DIR_ISWRITEABLE', 'Impossible d&#39;écrire dans le répertoire de cache Session/SQL');
  define('ERROR_CODE_CACHE_DIR_ISWRITEABLE', '63');

  define('ERROR_TEXT_PHPBB_CONFIG_NOTEXIST', 'Fichiers de configuration de phpBB inexistants');
  define('ERROR_CODE_PHPBB_CONFIG_NOTEXIST', '68');

  define('ERROR_TEXT_REGISTER_GLOBALS_ON', 'register_globals est ON');
  define('ERROR_CODE_REGISTER_GLOBALS_ON', '69');

  define('ERROR_TEXT_SAFE_MODE_ON', 'safe_mode est ON');
  define('ERROR_CODE_SAFE_MODE_ON', '70');

  define('ERROR_TEXT_CACHE_CUSTOM_NEEDED','Un répertoire de cache est nécessaire pour utiliser la mise en cache des fichiers');
  define('ERROR_CODE_CACHE_CUSTOM_NEEDED', '71');

  define('ERROR_TEXT_TABLE_RENAME_CONFIGUREPHP_FAILED','Impossible de mettre à jour tous vos fichiers configure.php avec le nouveau préfixe');
  define('ERROR_CODE_TABLE_RENAME_CONFIGUREPHP_FAILED', '72');

  define('ERROR_TEXT_TABLE_RENAME_INCOMPLETE','Impossible de renommer toutes les tables');
  define('ERROR_CODE_TABLE_RENAME_INCOMPLETE', '73');

  define('ERROR_TEXT_SESSION_SAVE_PATH','PHP &#39;session.save_path&#39; n&#39;est pas inscriptible');
  define('ERROR_CODE_SESSION_SAVE_PATH','74');

  define('ERROR_TEXT_MAGIC_QUOTES_RUNTIME','PHP &#39;magic_quotes_runtime&#39; est activé');
  define('ERROR_CODE_MAGIC_QUOTES_RUNTIME','75');

  define('ERROR_TEXT_DB_VER_UNKNOWN','Version du moteur de base de données inconnue');
  define('ERROR_CODE_DB_VER_UNKNOWN','76');

  define('ERROR_TEXT_UPLOADS_DISABLED','Les uploads de fichier sont désactivés');
  define('ERROR_CODE_UPLOADS_DISABLED','77');

  define('ERROR_TEXT_ADMIN_PWD_REQUIRED','Le mot de passe Admin est nécessaire pour faire la mise à jour');
  define('ERROR_CODE_ADMIN_PWD_REQUIRED','78');

  define('ERROR_TEXT_PHP_SESSION_SUPPORT','Le support des sessions PHP est nécessaire');
  define('ERROR_CODE_PHP_SESSION_SUPPORT','80');

  define('ERROR_TEXT_PHP_AS_CGI','Il n&#39;est pas recommandé que PHP s&#39;exécute en cgi sauf pour les serveurs Windows');
  define('ERROR_CODE_PHP_AS_CGI','81');

  define('ERROR_TEXT_DISABLE_FUNCTIONS','Des fonctions PHP nécessaires sont désactivées sur votre serveur');
  define('ERROR_CODE_DISABLE_FUNCTIONS','82');

  define('ERROR_TEXT_OPENSSL_WARN','OpenSSL est &#39;une&#39; des manières de configurer un serveur pour offrir le support SSL (https://) sur votre site.<br /><br />S&#39;il est indiqué comme indisponible, les causes possibles peuvent être les suivantes:<br />(a) votre hébergeur ne supporte pas le SSL<br />(b) votre serveur web n&#39;a pas OpenSSL installé, mais PEUT avoir le service SSL disponible sous une autre forme<br />(c) votre hébergeur n&#39;est peut-être pas encore au courant des détails de votre certificat SSL pour qu&#39;il puisse l&#39;activer sur votre nom de domaine<br />(d) PHP n&#39;est pas encore configuré pour OpenSSL.<br /><br />Dans tous les cas, si vous avez besoin du cryptage sur vos pages web (SSL), vous devriez contacter votre hébergeur pour de l&#39;aide.');
  define('ERROR_CODE_OPENSSL_WARN','79');

  define('ERROR_TEXT_DB_PREFIX_NODOTS','Le préfixe de table de base de données ne doit contenir aucun des caractères suivants: / ou \\ ou . ');
  define('ERROR_CODE_DB_PREFIX_NODOTS','83');

  define('ERROR_TEXT_PHP_SESSION_AUTOSTART','PHP Session.autostart doit être désactivé.');
  define('ERROR_CODE_PHP_SESSION_AUTOSTART','84');
  define('ERROR_TEXT_PHP_SESSION_TRANS_SID','PHP Session.use_trans_sid doit être désactivé.');
  define('ERROR_CODE_PHP_SESSION_TRANS_SID','86');
  define('ERROR_TEXT_DB_PRIVS','Des permissions sont nécessaires pour l&#39;utilisateur de la base de données');
  define('ERROR_CODE_DB_PRIVS','87');
  define('ERROR_TEXT_COULD_NOT_WRITE_CONFIGURE_FILES','Erreur lors de l&#39;écriture dans le fichier /includes/configure.php');
  define('ERROR_CODE_COULD_NOT_WRITE_CONFIGURE_FILES','88');
  define('ERROR_TEXT_DB_EXISTS','La base de données existe déjà');
  define('ERROR_CODE_DB_EXISTS','108');

  define('ERROR_TEXT_NO_CHART_SELECTED','Veuillez choisir un plan comptable pour afficher les détails !');
  define('TEXT_CURRENT_SETTINGS','-- Paramètres Compte Courant --');
  define('TEXT_ID','ID Compte');
  define('TEXT_DESCRIPTION','Description');
  define('TEXT_ACCT_TYPE','Type Compte');

  define('ERROR_TEXT_CHART_NAME_ISEMPTY', 'Un modèle de plan comptable est requis.');
  define('ERROR_CODE_CHART_NAME_ISEMPTY', '94');

define('POPUP_ERROR_1_HEADING', 'PHP Version 4.1.2 détecté');
define('POPUP_ERROR_1_TEXT', 'Certaines releases de PHP Version 4.1.2 ont un bug qui affecte les tableaux super globaux. Cela peut rendre inaccessible la partie d&#39;administration de PhreeBooks&trade; . Nous vous conseillons de mettre à jour votre version de PHP si possible.<br /><br />PHP 4.3.2 ou plus serait un minimum pour que PhreeBooks&trade; tourne bien.<br />Nous vous recommandons FORTEMENT d&#39;utiliser PHP 4.3.11 ou supérieur (dans la série des v4.x).');
define('POPUP_ERROR_3_HEADING', 'Fichier /includes/configure.php inexistant');
define('POPUP_ERROR_3_TEXT', 'Le fichier /includes/configure.php est inexistant. Ce fichier sera créé pendant le processus d&#39;installation.');
define('POPUP_ERROR_4_HEADING', 'Chemin physique');
define('POPUP_ERROR_4_TEXT', 'Le chemin d&#39;accès physique est le chemin vers le répertoire où vos fichiers PhreeBooks&trade; sont installés. Par exemple, sur certains systèmes Linux, les fichiers HTML sont stockés dans /var/www/html. Si vous placez vos fichiers PhreeBooks&trade; dans un répertoire nommé &#39;store&#39;, le chemin d&#39;accès physique devrait être /var/www/html/store. Le programme d&#39;installation ne peut généralement pas deviner ce répertoire correctement.');
define('POPUP_ERROR_5_HEADING', 'Chemin virtuel HTTP');
define('POPUP_ERROR_5_TEXT', 'C&#39;est l&#39;adresse que vous auriez besoin de mettre dans un navigateur Web pour afficher votre site PhreeBooks&trade;. Si le site est dans le répertoire &#39;root&#39; de votre domaine, ce serait &#39;http://www.yourdomain.com&#39;. Si vous aviez mis les fichiers dans un répertoire nommé &#39;store&#39;, alors le chemin serait &#39;http://www.yourdomain.com/store&#39;.');
define('POPUP_ERROR_6_HEADING', 'Serveur virtuel HTTPS');
define('POPUP_ERROR_6_TEXT', 'C&#39;est l&#39;adresse de votre serveur sécurisé SSL. Cette adresse varie selon la façon dont le mode sécurisé SSL est implémenté sur votre serveur. Vous êtes invité à consulter l&#39;<a href="http://www.phreebooks.com/" target="_blank">entrÃ©e de la FAQ</a> sur SSL pour vous assurer d&#39;un paramètrage correct.');
define('POPUP_ERROR_7_HEADING', 'Chemin virtuel HTTPS');
define('POPUP_ERROR_7_TEXT', 'C&#39;est l&#39;adresse que vous auriez besoin de mettre dans un navigateur Web pour visualiser votre site PhreeBooks&trade; en mode sécurisé SSL. Vous êtes invité à consulter l&#39;<a href="http://www.phreebooks.com/" target="_blank">entrÃ©e de la FAQ</a> sur SSL pour vous assurer d&#39;un paramètrage correct.');
define('POPUP_ERROR_8_HEADING', 'Activer SSL');
define('POPUP_ERROR_8_TEXT', 'Ce paramètre détermine si le mode SSL Securisé (HTTPS:) est utilisé sur les pages vulnérables de votre site PhreeBooks&trade;.<br /><br />Toute page où des renseignements personnels ou financiers sont entrés (par exemple connexion, paiements, détails de compte) peut être protégée par le mode SSL sécurisé.<br /><br />Vous devez avoir accès à un serveur SSL (qui utilise HTTPS au lieu de HTTP).<br /><br />SI VOUS IGNOREZ si vous avez un serveur SSL, alors laissez ce paramètre réglé sur NON pour le moment, et vérifiez auprès de votre hébergeur. NOTE: Comme pour tous les paramètres, il peut être changé par la suite en éditant le fichier configure.php.');
define('POPUP_ERROR_9_HEADING', 'Le chemin physique est vide');
define('POPUP_ERROR_9_TEXT', 'Vous avez laissé l&#39;entrée pour le chemin d&#39;accès physique vide. Vous devez entrer quelque chose de valable ici.');
define('POPUP_ERROR_10_HEADING', 'Chemin physique incorrect');
define('POPUP_ERROR_10_TEXT', 'Votre saisie pour le chemin d&#39;accès physique ne semble pas être valide. Veuillez corriger et essayer à nouveau.');
define('POPUP_ERROR_11_HEADING', 'Le chemin virtuel HTTP est vide');
define('POPUP_ERROR_11_TEXT', 'Vous avez laissé l&#39;entrée pour le chemin d&#39;accès virtuel HTTP vide. Vous devez entrer quelque chose de valable ici.');
define('POPUP_ERROR_12_HEADING', 'Le chemin virtuel HTTPS est vide');
define('POPUP_ERROR_12_TEXT', 'Vous avez laissé l&#39;entrée pour le chemin d&#39;accès virtuel HTTPS vide avec le mode SSL activé. Vous devez mettre une entrée en vigueur ici ou désactiver le mode SSL.');
define('POPUP_ERROR_13_HEADING', 'Le serveur virtuel HTTPS est vide');
define('POPUP_ERROR_13_TEXT', 'Vous avez laissé l&#39;entrée pour le serveur HTTPS vide avec le mode SSL activé. Vous devez mettre une entrée en vigueur ici ou désactiver le mode SSL.');
define('POPUP_ERROR_14_HEADING', 'Type de base de données');
define('POPUP_ERROR_14_TEXT', 'PhreeBooks&trade; est conçu pour supporter de multiples types de bases de données. Malheureusement, pour le moment, ce support est incomplet. Pour le moment, vous devez toujours laisser cette entrée sur MySQL.');
define('POPUP_ERROR_15_HEADING', 'Hôte de la base de données');
define('POPUP_ERROR_15_TEXT', 'C&#39;est le nom du serveur Web sur lequel tourne le programme de base de données de votre hébergeur. Dans la plupart des cas, cela peut toujours être laissé positionné sur la valeur &#39;localhost&#39;. Dans certains cas exceptionnels, vous devrez demander à votre prestataire d&#39;hébergement le nom du serveur de leur moteur de base de données.');
define('POPUP_ERROR_16_HEADING', 'Nom d&#39;utilisateur de la base de données');
define('POPUP_ERROR_16_TEXT', 'Toutes les bases de données nécessitent un identifiant et un mot de passe pour y accéder. Le nom d&#39;utilisateur pour votre base de données peut aussi bien avoir été attribué par votre hébergeur et vous devriez les contacter pour plus de détails.');
define('POPUP_ERROR_17_HEADING', 'Mot de passe de la base de données');
define('POPUP_ERROR_17_TEXT', 'Toutes les bases de données nécessitent un identifiant et un mot de passe pour y accéder. Le mot de passe pour votre base de données peut aussi bien avoir été attribué par votre hébergeur et vous devriez les contacter pour plus de détails.');
define('POPUP_ERROR_18_HEADING', 'Nom de la base de données');
define('POPUP_ERROR_18_TEXT', 'C&#39;est le nom de la base de données qui sera utilisée par PhreeBooks&trade;. Si vous n&#39;êtes pas sûr(e) de ce que cela devrait être, alors vous devriez contacter votre hébergeur pour plus d&#39;informations.');
define('POPUP_ERROR_19_HEADING', 'Préfixe des tables de la base de données');
define('POPUP_ERROR_19_TEXT', 'PhreeBooks&trade; vous permet d&#39;ajouter un préfixe aux noms des tables qu&#39;il utilise pour stocker ses informations. Ceci est particulièrement utile si votre hébergeur vous autorise seulement une base de données, et que vous souhaitez installer d&#39;autres scripts sur votre système utilisant cette base de données. Normalement, vous devez simplement laisser le paramètre tel qu&#39;il est par défaut.');
define('POPUP_ERROR_20_HEADING', 'Création de la base de données');
define('POPUP_ERROR_20_TEXT', 'Ce paramètre détermine si le programme d&#39;installation doit essayer de créer la base de données principale pour PhreeBooks&trade;. NOTE: &#39;create&#39; dans ce contexte n&#39;a rien à voir avec l&#39;ajoût des tables dont PhreeBooks&trade; a besoin, qui sera fait quand même automatiquement. Beaucoup d&#39;hébergeurs ne donnent pas à leurs utilisateurs le droit &#39;create&#39;, mais fournissent une autre méthode pour créer des bases de données vierges, par exemple cPanel ou phpMyAdmin.');
define('POPUP_ERROR_21_HEADING', 'Connexion à la base de données');
define('POPUP_ERROR_21_TEXT', 'Les connexions persistantes sont un moyen de réduire la charge sur la base de données. Vous devriez consulter l&#39;hébergeur de votre serveur avant de définir cette option.  Activer les &#39;connexions persistantes&#39; pourrait causer à votre hébergeur des problèmes de base de données si rien n&#39;a été configuré pour les gérer.<br /><br />Encore une fois, assurez-vous de parler à votre hébergeur, avant d&#39;envisager l&#39;utilisation de cette option.');
define('POPUP_ERROR_22_HEADING', 'Sessions en base de données');
define('POPUP_ERROR_22_TEXT', 'Ceci détermine si les informations de session sont stockées dans un fichier ou dans la base de données. Bien que les sessions dans un fichier soient plus rapides, les sessions dans la base de données sont recommandées pour tous les magasins en ligne en utilisant les connexions SSL, pour des raisons de sécurité.');
define('POPUP_ERROR_23_HEADING', 'Activer SSL');
define('POPUP_ERROR_23_TEXT', '');
define('POPUP_ERROR_24_HEADING', 'L&#39;hôte de la base de données est vide');
define('POPUP_ERROR_24_TEXT', 'L&#39;entrée pour l&#39;hôte de la base de données est vide. Veuiller entrer un nom valide d&#39;hôte de base de données.<br />C&#39;est le nom du serveur Web sur lequel votre hébergeur fait tourner son moteur de base de données. Dans la plupart des cas, cela peut toujours être laissé positionné sur la valeur &#39;localhost&#39;. Dans certains cas exceptionnels, vous devrez demander à votre hébergeur le nom du serveur de leur moteur de base de données.');
define('POPUP_ERROR_25_HEADING', 'Le nom de la base de données est vide');
define('POPUP_ERROR_25_TEXT', 'L&#39;entrée pour le nom de la base de données est vide. Veuillez entrez le nom de la base que vous souhaitez utiliser pour PhreeBooks&trade;.<br />Il s&#39;agit du nom de la base de données qui sera utilisé par PhreeBooks&trade;. Si vous vous interrogez sur ce qu&#39;il devrait être, alors vous devriez contacter votre hébergeur pour plus d&#39;informations. ');
define('POPUP_ERROR_26_HEADING', 'Fichier SQL d&#39;installation inexistant');
define('POPUP_ERROR_26_TEXT', 'Le programme d&#39;installation n&#39;a pas pu trouver le fichier d&#39;installation SQL. Il devrait exister dans le répertoire &#39;modules/install/sql/current&#39; et s&#39;appeler quelque chose comme &#39;tables.sql&#39;.');
define('POPUP_ERROR_27_HEADING', 'Base de données non supportée');
define('POPUP_ERROR_27_TEXT', 'Le type de base de données que vous avez choisi ne semble pas être pris en charge par la version de PHP installée. Vous devez vérifier auprès de votre hébergeur que le type de base que vous avez sélectionné est pris en charge. Si c&#39;est votre propre serveur, alors veuillez vous assurer que la prise en charge de ce type de base de données a bien été compilée dans PHP, et que les fichiers nécessaires extensions/modules/dll sont chargés (vérifier essentiellement dans php.ini les extensions=mysql.so, etc...).');
define('POPUP_ERROR_28_HEADING', 'Échec de la connection à la base de données');
define('POPUP_ERROR_28_TEXT', 'Une connexion à la base de données n&#39;a pas pu être réalisée. Cela peut arriver pour un certain nombre de raisons.<br /><br />
Vous pouvez avoir donné un mauvais nom d&#39;hôte de base de données, ou bien le nom d&#39;utilisateur ou le <em>mot de passe</em> peuvent être incorrects. <br /><br />
Vous pouvez aussi avoir donné un mauvais nom de base de données (<strong>Existe-t&#39;il ?</strong> <strong>L&#39;avez-vous créée ?</strong> -- NOTE: PhreeBooks&trade; ne créé pas de base à votre place.).<br /><br />
Veuillez examiner toutes les entrées et vous assurer qu&#39;elles sont correctes.');
define('POPUP_ERROR_29_HEADING', 'Impossible de créer la base de données');
define('POPUP_ERROR_29_TEXT', 'Vous semblez ne pas avoir la permission pour créer une base de données vide. Vous avez besoin de contacter votre hébergeur pour qu&#39;il fasse cela pour vous. Ou bien, vous pourriez avoir besoin d&#39;utiliser cpanel ou phpMyAdmin pour créer une base de données vide. Après avoir créé la base de données manuellement, décochez l&#39;option &#39;Créer Base de Données&#39; dans le programme d&#39;installation PhreeBooks&trade; pour continuer.');
define('POPUP_ERROR_30_HEADING', 'Base de données inexistante');
define('POPUP_ERROR_30_TEXT', 'Le nom de base de données que vous avez indiqué ne semble pas exister.<br />(<strong>L&#39;avez-vous créée ?</strong> -- NOTE: PhreeBooks&trade; ne créé pas de base à votre place.).<br /><br />Veuillez vérifier les détails de votre base de données, puis vérifier cette entrée et faire les corrections nécessaires.');
define('POPUP_ERROR_31_HEADING', 'Le nom de société est vide');
define('POPUP_ERROR_31_TEXT', 'Veuillez préciser le nom par lequel vous ferez référence à votre société.');
define('POPUP_ERROR_32_HEADING', 'Le propriétaire de la société est vide');
define('POPUP_ERROR_32_TEXT', 'Veuillez fournir le nom du propriétaire de la société. Cette information apparaîtra dans la page &#39;Contactez Nous&#39; , les messages e-mail de &#39;Bienvenue&#39;, et à d&#39;autres endroits dans la société.');
define('POPUP_ERROR_33_HEADING', 'L&#39;adresse mail principale de la société est vide');
define('POPUP_ERROR_33_TEXT', 'Veuillez fournir l&#39;adresse mail principale de la société. C&#39;est l&#39;adresse qui sera indiquée pour les informations de contact dans les courriels qui sont envoyés depuis la société.');
define('POPUP_ERROR_34_HEADING', 'Adresse e-mail de la société invalide');
define('POPUP_ERROR_34_TEXT', 'Vous devez fournir une adresse e-mail valide.');
define('POPUP_ERROR_35_HEADING', 'L&#39;adresse de la société est vide');
define('POPUP_ERROR_35_TEXT', 'Veuillez fournir l&#39;adresse de votre société. Elle sera affichée sur la page &#39;Contactez Nous&#39; (désactivable si nécessaire), sur la facture et les matériaux d&#39;emballage. Elle sera également affichée si un client choisit de payer par chèque / virement à l&#39;encaissement.');
define('POPUP_ERROR_36_HEADING', 'Fichier SQL des produits de démo  inexistant');
define('POPUP_ERROR_36_TEXT', 'Nous n&#39;avons pas pu localiser le fichier SQL contenant les produits démo de PhreeBooks&trade; pour les charger dans votre société.  Veuillez vérifier que le fichier /zc_install/demo/xxxxxxx_demo.sql existe. (xxxxxxx = votre type de base de données).');
define('POPUP_ERROR_37_HEADING', 'Nom de la société');
define('POPUP_ERROR_37_TEXT', 'Le nom de votre société. Il sera utilisé dans les courriels envoyés par le système et, dans certains cas, dans le titre du navigateur.');
define('POPUP_ERROR_38_HEADING', 'Ville/Cité de la société');
define('POPUP_ERROR_38_TEXT', 'La ville/cité de la société peut être utilisée dans les courriels envoyés par le système. Elle apparaît également dans la mise en page des étiquettes d&#39;adresse pour la facturation, etc.');
define('POPUP_ERROR_39_HEADING', 'E-mail du propriétaire de la société');
define('POPUP_ERROR_39_TEXT', 'L&#39;adresse e-mail principale par laquelle votre société peut être contactée. La plupart des courriels envoyés par le système l&#39;utiliseront, ainsi que les pages &#39;Contactez Nous&#39;.');
define('POPUP_ERROR_40_HEADING', 'Pays de la société');
define('POPUP_ERROR_40_TEXT', 'Le pays dans lequel votre société est basée. Il est important que vous définissiez ce pays correctement pour être assuré(e) que les taxes et les options de livraison fonctionnent correctement. Il détermine également la mise en page des étiquettes d&#39;adresse pour la facturation, etc.');
define('POPUP_ERROR_41_HEADING', 'Région/Département de la société');
define('POPUP_ERROR_41_TEXT', 'Ceci représente une sous-division géographique du pays dans lequel votre société est basée. Exemple: un état des Etats-Unis');
define('POPUP_ERROR_42_HEADING', 'Adresse de la société');
define('POPUP_ERROR_42_TEXT', 'L&#39;adresse de votre entreprise, utilisée sur les factures et les confirmations de commandes. Deux lignes sont autorisées, la première ligne est requise.');
define('POPUP_ERROR_43_HEADING', 'Langue par défaut de la société');
define('POPUP_ERROR_43_TEXT', 'La langue par défaut que votre société va utiliser. PhreeBooks&trade; est par nature multi-langue, à con裩tion que le module linguistique approprié soit chargé. Malheureusement, pour le moment, PhreeBooks&trade; n&#39;a seulement qu&#39;un pack de langue anglaise par défaut.');
define('POPUP_ERROR_44_HEADING', 'Devise par défaut de la société');
define('POPUP_ERROR_44_TEXT', 'Sélectionnez une devise par défaut qui sera utilisée de suite par votre société. Si la devise souhaitée n&#39;est pas répertoriée ici, elle peut être modifiée dans la zone d&#39;administration une fois l&#39;installation terminée.<br><br>REMARQUE: Une fois qu&#39;une entrée du journal aura été faite, la devise par défaut ne pourra plus être changée !');
define('POPUP_ERROR_45_HEADING', 'Installer les produits démo');
define('POPUP_ERROR_45_TEXT', 'Veuillez choisir si vous souhaitez installer les produits de démonstration dans la base de données pour avoir un aperçu des méthodes par lesquelles les différentes fonctionnalités de PhreeBooks&trade; opèrent.');
define('POPUP_ERROR_46_HEADING', 'Le nom de l&#39;Administrateur est vide');
define('POPUP_ERROR_46_TEXT', 'Pour vous identifier sur l&#39;espace d&#39;administration quand l&#39;installation sera terminée, vous devez fournir un identifiant d&#39;Administrateur ici.');
define('POPUP_ERROR_47_HEADING', 'L&#39;adresse e-mail est vide');
define('POPUP_ERROR_47_TEXT', 'L&#39;adresse e-mail de l&#39;Administrateur est nécessaire pour pouvoir y envoyer un nouveau mot de passe en cas d&#39;oubli.');
define('POPUP_ERROR_48_HEADING', 'L&#39;e-mail de l&#39;Administrateur est invalide');
define('POPUP_ERROR_48_TEXT', 'Veuillez indiquer une adresse e-mail valide.');
define('POPUP_ERROR_49_HEADING', 'Le mot de passe de l&#39;Administrateur est vide');
define('POPUP_ERROR_49_TEXT', 'Pour votre sécurité, le mot de passe de l&#39;Administrateur ne peut être vide.');
define('POPUP_ERROR_50_HEADING', 'Les mots de passe ne correspondent pas');
define('POPUP_ERROR_50_TEXT', 'Veuillez entrer à nouveau le mot de passe de l&#39;Administrateur et sa confirmation.');
define('POPUP_ERROR_51_HEADING', 'Identifiant de l&#39;Administrateur');
define('POPUP_ERROR_51_TEXT', 'Pour pouvoir vous connecter sur l&#39;espace d&#39;administration quand l&#39;installation sera terminée, vous devez fournir un identifiant d&#39;Administrateur ici.');
define('POPUP_ERROR_52_HEADING', 'Adresse e-mail de l&#39;Administrateur');
define('POPUP_ERROR_52_TEXT', 'L&#39;adresse e-mail de l&#39;Administrateur est nécessaire pour pouvoir y envoyer un nouveau mot de passe en cas d&#39;oubli.');
define('POPUP_ERROR_53_HEADING', 'Mot de passe de l&#39;Administrateur');
define('POPUP_ERROR_53_TEXT', 'Le mot de passe de l&#39;Administrateur est le mot de passe qui permet l&#39;accès à votre espace d&#39;administration.');
define('POPUP_ERROR_54_HEADING', 'Confirmation du mot de passe de l&#39;Administrateur');
define('POPUP_ERROR_54_TEXT', 'Naturellement, vous devez fournir une confirmation à l&#39;identique du mot de passe avant qu&#39;il ne soit enregistré pour usage ultérieur.');
define('POPUP_ERROR_55_HEADING', 'Version de PHP non prise en charge');
define('POPUP_ERROR_55_TEXT', 'La version de PHP que vous utilisez sur votre serveur web n&#39;est pas prise en charge par PhreeBooks&trade; . <br /><br />PHP 4.3.2 est le minimum requis. <br />Toutefois, nous recommandons d&#39;utiliser au moins PHP 4.3.11 si possible.<br /><br />Si vous essayez d&#39;utiliser une version plus ancienne de PHP, notez que cela peut rendre votre espace d&#39;administration inaccessible, peut rendre votre site vulnérable à des attaques de hackers, et peut perturber une partie du code des sessions PHP qui garde les connexions d&#39;un client uniques et séparées des autres clients. Nous vous conseillons de mettre à jour votre version PHP.');
define('POPUP_ERROR_57_HEADING', 'Impossible d&#39;écrire dans le fichier configure.php de PhreeBooks&trade; .');
define('POPUP_ERROR_57_TEXT', 'Le fichier includes/configure.php n&#39;est pas accessible en écriture. Si vous utilisez un système Unix ou Linux, alors veuillez faire un CHMOD 777 ou 666 sur le fichier jusqu&#39;à ce que l&#39;installation de PhreeBooks&trade; soit terminée. Sur un système Windows, il suffit tout simplement de mettre le fichier est en lecture/écriture.');
define('POPUP_ERROR_58_HEADING', 'Préfixe des tables de la base de données');
define('POPUP_ERROR_58_TEXT', 'PhreeBooks&trade; vous permet d&#39;ajouter un préfixe aux noms des tables qu&#39;il utilise pour stocker ses informations. Ceci est particulièrement utile si votre hébergeur vous autorise qu&#39;une seule base de données, et que vous souhaitez installer d&#39;autres scripts sur votre système utilisant cette base de données. Normalement, vous devez simplement laisser le paramètre tel qu&#39;il est par défaut.');
define('POPUP_ERROR_59_HEADING', 'Répertoire de cache SQL');
define('POPUP_ERROR_59_TEXT', 'Les requêtes SQL peuvent être mises en cache soit dans la base de données, soit dans un fichier sur sur le disque dur de votre serveur, soit pas du tout. Si vous choisissez de mettre en cache les requêtes SQL dans un fichier sur votre serveur, alors vous devez fournir le répertoire o&amp;ugrave; ces informations seront enregistrées. <br /><br />L&#39;installation standard de PhreeBooks&trade; inclut un répertoire &#39;cache&#39;.  Vous devez mettre ce répertoire en lecture/écriture pour que votre serveur web (à savoir apache) puisse y accéder.<br /><br />Veuillez vous assurer que le répertoire que vous choisissez existe et que le serveur web puisse écrire dedans (CHMOD 777 ou au moins 666).');
define('POPUP_ERROR_60_HEADING', 'Méthode de cache SQL');
define('POPUP_ERROR_60_TEXT', 'Certaines requêtes SQL peuvent être mises en cache. Cela signifie que si elles sont mises en cache, elles peuvent s&#39;exécuter plus rapidement. Vous pouvez décider de la méthode de cache à utiliser pour les requêtes SQL.<br /><br /><strong>Aucune</strong>. Les requêtes SQL ne seront pas mises en cache. Si vous n&#39;avez que très peu de produits/catégories, cela peut donner la plus grande vitesse à votre site.<br /><br /><strong>Base de données</strong>. Les requêtes SQL sont mises en cache dans une table de la base de données. Étrangement, cela peut apporter un gain de vitesse pour les sites qui ont un nombre moyen de produits/catégories.<br /><br /><strong>Fichier</strong>. Les requêtes SQL sont mises en cache dans des fichiers sur le disque dur de votre serveur. Pour que cela fonctionne, vous devez vous assurer que le serveur web puisse écrire dans le répertoire dans lequel les requêtes doivent être mises en cache. Cette méthode semble être la meilleure pour les sites qui possèdent un grand nombre de produits/catégories.');
define('POPUP_ERROR_61_HEADING', 'Le répertoire de cache des sessions SQL est vide');
define('POPUP_ERROR_61_TEXT', 'Si vous voulez utiliser la mise en cache par fichiers des sessions/requêtes SQL, vous devez spécifier un répertoire valide sur votre serveur web, et vous assurer que le serveur web a les droits d&#39;écriture sur ce répertoire.');
define('POPUP_ERROR_62_HEADING', 'Répertoire de cache des sessions SQL inexistant');
define('POPUP_ERROR_62_TEXT', 'Si vous voulez utiliser le mise en cache par fichiers des requêtes Session/SQL, vous devez spécifier un répertoire valide sur votre serveur web, et vous assurer que le serveur web a les droits d&#39;écriture sur ce répertoire.');
define('POPUP_ERROR_63_HEADING', 'Impossible d&#39;écrire dans le répertoire de cache des sessions SQL');
define('POPUP_ERROR_63_TEXT', 'Si vous voulez utiliser la mise en cache par fichiers des sessions/requêtes SQL, vous devez spécifier un répertoire valide sur votre serveur web, et vous assurer que le serveur web a les droits d&#39;écriture sur ce répertoire.  CHMOD 666 ou 777 le plus souvent sur Linux/Unix.  Lecture/écriture pour les serveurs Windows (sur IIS, il faut le mettre pour le compte internet Invité).');
define('POPUP_ERROR_65_HEADING', 'Préfixe des tables phpBB');
define('POPUP_ERROR_65_TEXT', 'Veuillez indiquer le préfixe de vos tables phpBB dans leur base de données. Souvent, c&#39;est &#39;phpBB_&#39;.');
define('POPUP_ERROR_66_HEADING', 'Nom de la base de données phpBB');
define('POPUP_ERROR_66_TEXT', 'Veuillez indiquer le nom de la base de données dans laquelle vos tables phpBB sont installées.');
define('POPUP_ERROR_69_HEADING', 'register_globals est ON');
define('POPUP_ERROR_69_TEXT', 'PhreeBooks&trade; ne peut fonctionner qu&#39;avec le paramètre &#39;register_globals&#39; à OFF (plus sûr).<br /><br />Si vous voulez le désactiver et que votre hébergeur ne vous le permet pas, vous pouvez essayer d&#39;ajouter ceci dans un fichier .htaccess à la racine de votre boutique (vous pourrez avoir besoin de le créer s&#39;il n&#39;existe pas):<br /><br /><code>php_value session.use_trans_sid off<BR />php_value register_globals off<br />#php_value register_globals off<BR /><Files &#39;.ht*&#39;><BR />deny from all<BR /></Files></code><br /><br />ou bien demandez assistance à votre hébergeur.');
define('POPUP_ERROR_70_HEADING', 'safe_mode est ON');
define('POPUP_ERROR_70_TEXT', 'PhreeBooks&trade; ne fonctionne pas bien sur les serveurs qui ont le Safe Mode actif.<br /><br />Pour s&#39;exécuter, un système ERP  nécessite beaucoup de services qui sont souvent restreints chez les hébergeurs mutualisés à bas co&amp;ucirc;t. Pour faire tourner PhreeBooks&trade; de manière optimale, il est nécessaire de configurer le service d&#39;hébergement pour qu&#39;il n&#39;exécute pas votre espace web en &#39;Safe Mode&#39;.  Il faut pour cela que votre hébergeur écrive &#39;SAFE_MODE=OFF&#39; dans le fichier php.ini.');
define('POPUP_ERROR_71_HEADING', 'Répertoire de cache requis pour utiliser la mise en cache par fichiers');
define('POPUP_ERROR_71_TEXT', 'Si vous voulez utiliser le &#39;cache SQL par fichiers&#39; dans PhreeBooks&trade; , il vous faudra mettre les bonnes permissions sur le répertoire de cache de votre espace web.<br /><br />Autrement, vous pouvez choisir la &#39;mise en cache en base de données&#39; ou &#39;pas de mise en cache&#39; si vous préférez ne pas utiliser de répertoire de cache. Dans ce cas, vous DEVEZ désactiver aussi le &#39;stockage des sessions&#39;, parce que le suivi des sessions utilise aussi la mise en cache par fichiers.<br /><br />Pour configurer le répertoire de cache correctement, utilisez votre client FTP ou un accès SHELL à votre serveur web pour faire un CHMOD 666 ou 777 sur le répertoire afin de lui mettre les permissions en lecture et écriture.<br /><br />Plus particulièrement, l&#39;userID de votre serveur web (ex: &#39;apache&#39; ou &#39;www-user&#39; ou peut être &#39;IUSR_something&#39; sous Windows) doit avoir toutes les permissions &#39;lecture-écriture-suppression&#39; etc sur le répertoire de cache.');
define('POPUP_ERROR_72_HEADING', 'ERREUR: Impossible de mettre à jour vos fichiers configure.php avec le nouveau préfixe');
define('POPUP_ERROR_72_TEXT', 'Il y a eu une erreur en essayant de mettre à jour vos fichiers configure.php après avoir renommé vos tables.  Vous devrez éditer manuellement les fichiers /includes/configure.php et /admin/includes/configure.php et vous assurer qu&#39;ils contiennent le préfixe correct dans le &#39;define&#39; pour &#39;DB_PREFIX&#39;, pour pouvoir accéder à vos tables PhreeBooks&trade; .');
define('POPUP_ERROR_73_HEADING', 'ERREUR: Impossible d&#39;appliquer le nouveau préfixe à toutes les tables');
define('POPUP_ERROR_73_TEXT', 'Il y a eu une erreur en essayant de renommer vos tables de base de données avec le nouveau préfixe de table.  Vous devrez vérifier manuellement les noms de vos tables de base de données. Dans le pire des cas, vous devrez restaurer votre sauvegarde.');
define('POPUP_ERROR_74_HEADING', 'NOTE: Impossible d&#39;écrire dans PHP &#39;session.save_path&#39;');
define('POPUP_ERROR_74_TEXT', '<strong>Ceci est JUSTE une note</strong> pour vous informer que vous n&#39;avez pas la permission d&#39;écrire dans le répertoire spécifié par le paramètre PHP session.save_path.<br /><br />Cela signifie simplement que vous ne pouvez pas utiliser ce répertoire paramètré pour stocker temporairement des fichierse.  &amp;Agrave; la place, utilisez le &#39;rélitpertoire de cache suggéré&#39; dessous.<br /><br /><br />Ou bien, si le chemin est inconnu, alors il est possible que le paramètre ne soit pas configuré dans le fichier php.ini de votre serveur. Ce n&#39;est pas un problème. C&#39;est juste un avertissement. Parlez en à votre hébergeur pour plus de clarification si vous le souhaitez.');
define('POPUP_ERROR_75_HEADING', 'NOTE: PHP &#39;magic_quotes_runtime&#39; est actif');
define('POPUP_ERROR_75_TEXT', 'Il est préférable que &#39;magic_quotes_runtime&#39; soit désactivé. Lorsqu&#39;il est activé, ce paramètre peut être la cause d&#39;erreurs SQL inattendues de type 1064, et d&#39;autres problèmes d&#39;exécution de code.<br /><br />Si vous ne pouvez pas le désactiver pour le serveur entier, il est possible de le désactiver par un fichier .htaccess ou votre propre fichier php.ini dans votre espace web privé.  Parlez en à votre hébergeur pour plus d&#39;infos.');
define('POPUP_ERROR_76_HEADING', 'Version de votre moteur de base de données inconnue');
define('POPUP_ERROR_76_TEXT', 'La version du moteur de votre base de données n&#39;a pas pu être obtenue.<br /><br />Ce n&#39;est PAS NÉCESSAIREMENT un problème sérieux. En fait, cela peut même être courant sur un serveur en production, étant donné qu&#39;à cette étape de la vérification, nous ne connaissons pas forcément vos informations d&#39;identité pour se connecter sur le serveur, puisque celles ci ne sont demandés que plus tard dans le processus d&#39;installation.<br /><br />Vous pouvez en général continuer même si cette information est annoncée comme inconnue.');
define('POPUP_ERROR_77_HEADING', 'L&#39;upload de fichiers est DÉSACTIVÉ');
define('POPUP_ERROR_77_TEXT', 'L&#39;upload de fichiers est DÉSACTIVÉ. Pour l&#39;activer, vérifiez que <em><strong>file_uploads = on</strong></em> dans le fichier php.ini de votre serveur.');
define('POPUP_ERROR_78_HEADING', 'MOT DE PASSE ADMINISTRATEUR NÉCESSAIRE POUR MISE À JOUR');
define('POPUP_ERROR_78_TEXT', 'L&#39;identifiant Administrateur et son mot de passe sont requis pour faire des changements sur la base de données.<br /><br />Veuillez entrer un identifiant Administrateur et un mot de passe valides pour votre site PhreeBooks&trade; .');
define('POPUP_ERROR_79_HEADING','Informations OpenSSL');
define('POPUP_ERROR_79_TEXT','OpenSSL est &#39;une&#39; des manières de configurer un serveur pour offrir SSL (https://) sur votre site.<br /><br />S&#39;il est indiqué comme indisponible, les causes possibles peuvent être les suivantes:<br />(a) votre hébergeur ne supporte pas le SSL<br />(b) votre serveur web n&#39;a pas OpenSSL installé, mais PEUT avoir le service SSL disponible sous une autre forme<br />(c) votre hébergeur n&#39;est peut-être pas encore au courant des détails de votre certificat SSL pour qu&#39;il puisse l&#39;activer sur votre nom de domaine<br />(d) PHP n&#39;est pas encore configuré pour OpenSSL.<br /><br />Dans tous les cas, si vous avez besoin du cryptage sur vos pages web (SSL), vous devriez contacter votre hébergeur pour de l&#39;aide.');
define('POPUP_ERROR_80_HEADING', 'La prise en charge des Sessions PHP est requise');
define('POPUP_ERROR_80_TEXT', 'Vous devez activer la prise en charge des Sessions PHP sur votre serveur web.  Vous devriez essayer d&#39;installer ce module: php4-session<br /><br /><br />La prise en charge des Sessions PHP est nécessaire pour pouvoir gèrer les connexions utilisateurs et procédures de paiements/commandes. Veuillez en parler à votre hébergeur pour reconfigurer PHP afin de pouvoir utiliser les Sessions.');
define('POPUP_ERROR_81_HEADING', 'Il n&#39;est pas recommandé que PHP s&#39;exécute en CGI sauf sur Windows');
define('POPUP_ERROR_81_TEXT', 'Exécuter PHP en CGI peut être problématique sur certains serveurs Linux/Unix.<br /><br />Les serveurs Windows, toutefois, exécutent &#39;toujours&#39; PHP comme un module cgi, dans ce cas l&#39;avertissement peut être ignoré.');
define('POPUP_ERROR_82_HEADING', ERROR_TEXT_DISABLE_FUNCTIONS);
define('POPUP_ERROR_82_TEXT', 'Votre configuration PHP a une ou plusieurs des fonctions suivantes marquées comme &#39;désactivées&#39; dans le fichier PHP.INI de votre serveur:<br /><ul><li>set_time_limit</li><li>exec</li></ul>Votre serveur peut souffrir de diminution de performance due à l&#39;utilisation de ces mesures de sécurité qui sont habituellement implémentées sur des serveurs publics utilisés par beaucoup de monde... Elles ne sont pas toujours idéales pour faire tourner un système de e-Commerce.<br /><br />Il est recommandé de parler avec votre hébergeur pour déterminer s&#39;ils ont un autre serveur sur lequel votre site pourrait être placé sans ces restrictions.');
define('POPUP_ERROR_83_HEADING','Caractères invalides dans le préfixe des tables de la base de données');
define('POPUP_ERROR_93_TEXT','Le préfixe des tables doit contenir seulement des lettres, nombres, et tirets bas (_).<br /><br />Veuillez choisir un préfixe différent. <strong>Nous vous recommandons de le laisser vide</strong> ou d&#39;utiliser quelque chose de simple comme &#39;pb_&#39; .');
define('POPUP_ERROR_84_HEADING','PHP Session.autostart doit être désactivé.');
define('POPUP_ERROR_84_TEXT','Le paramètre session.auto_start du fichier PHP.INI de votre serveur est actif (&#39;ON&#39;).<br /><br />Cela pourrait vous causer des problèmes avec la gestion des sessions, car PhreeBooks&trade; est conçu pour démarrer les sessions quand il est temps de les activer. Avoir les sessions qui démarrent automatiquement peut être un problème avec quelques configurations serveur.<br /><br />Si vous voulez essayer de désactiver cela vous-même, vous pouvez essayer de mettre la ligne suivante dans un fichier .htaccess à la racine de votre site (même répertoire que index.php):<br /><br /><code>php_value session.auto_start 0</code><br /><br /> (Vous pouvez avoir besoin de créer ce fichier s&#39;il n&#39;existe pas.)');
define('POPUP_ERROR_85_HEADING','Quelques mise à jour SQL de la BDD ne sont pas installées.');
define('POPUP_ERROR_85_TEXT','Pendant le processus de mise à jour, quelques requêtes SQL n&#39;ont pas pu être exécutées car celles-ci auraient créé des entrées en double dans la base de données, ou les pré-requis (comme une colonne qui doit exister pour être changée ou supprimée) n&#39;étaient pas remplis.<br /><br />LA CAUSE LA PLUS COMMUNE de ces erreurs est que vous avez installé une contribution/add-on qui a altéré la structure de la BDD. La mise à jour essaye de ne pas vous créer de problèmes. <br /><br />VOTRE BOUTIQUE DEVRAIT BIEN MARCHER sans approfondir ces erreurs, toutefois, nous vous recommandons de les vérifier pour en être ssûr(e). <br /><br />Si vous voulez en savoir plus, regardez dans la table &#39;upgrade_exceptions&#39; de la base de données pour trouver le détail des requêtes qui ont échoué à l&#39;exécution et leur raison.');
define('POPUP_ERROR_86_HEADING','PHP Session.use_trans_sid doit être désactivé.');
define('POPUP_ERROR_86_TEXT','Le paramètre session.use_trans_sid du fichier PHP.INI de votre serveur est actif (&#39;ON&#39;).<br /><br />Cela pourrait vous causer des problèmes avec la gestion des sessions ainsi que des problèmes de sécurité.<br /><br />Vous pouvez contourner cela en utilisant un paramètre dans un .htaccess comme décrit ici : <a href="http://www.olate.com/articles/252">http://www.olate.com/articles/252</a>, ou vous pouvez le désactiver dans votre fichier PHP.INI si vous avez accès à celui-ci.<br /><br />Pour plus d&#39;informations sur les risques de sécurité qu&#39;il impose, regardez: <a href="http://shh.thathost.com/secadv/2003-05-11-php.txt">http://shh.thathost.com/secadv/2003-05-11-php.txt</a>.<br /><br />(Vous pouvez avoir besoin de créer le fichier .htaccess s&#39;il n&#39;existe pas.)');
define('POPUP_ERROR_87_HEADING','Permissions nécessaires pour l&#39;utilisateur de la base de données');
define('POPUP_ERROR_87_TEXT','Les opérations réalisées par PhreeBooks&trade; nécessitent les privilèges suivants sur la base de données:<ul><li>ALL PRIVILEGES<br /><em>ou</em></li><li>SELECT</li><li>INSERT</li><li>UPDATE</li><li>DELETE</li><li>CREATE</li><li>ALTER</li><li>INDEX</li><li>DROP</li></ul>Les activités journalières de votre boutique n&#39;ont pas besoin normalement des privilèges &#39;CREATE&#39; et &#39;DROP&#39;, mais ceux-ci sont nécessaires pour l&#39;installation, la mise à jour, et l&#39;exélitcution de patches SQL.');
define('POPUP_ERROR_88_HEADING','Erreur rencontrée en écrivant dans /includes/configure.php');
define('POPUP_ERROR_88_TEXT','En essayant d&#39;enregistrer vos paramètres, le programme d&#39;installation de PhreeBooks&trade; n&#39;a pas pu vérifier l&#39;écriture correcte dans le fichier de configuration configure.php. Veuillez vérifier que votre serveur web a bien les permissions d&#39;écriture sur le fichier configure.php décrit ci-dessous.<br /><br />- /includes/configure.php<br /><br />Vérifiez également qu&#39;il y a assez d&#39;espace disque (ou de quota disponible) pour pouvoir écrire les mises à jour dans ces fichiers. <br /><br />Si les fichiers font 0-octets en taille quand vous avez cette erreur, alors l&#39;espace disque disponible est certainement en cause.<br /><br /> Les permissions idéales sur les hébergements Unix/Linux sont CHMOD 777 jusqu&#39;à ce que l&#39;installation soit terminée. Ensuite, elles peuvent être remises sur 644 or 444 par sécurité après l&#39;installation.<br /><br />Si vous êtes sur un hébergement de type Windows, vous pouvez également trouvé nécessaire de faire un clic droit sur chacun de ces fichiers, choisir &#39;Propriétés&#39;, et l&#39;onglet &#39;Sécurité&#39;. Cliquez alors sur &#39;Ajouter&#39; et choisissez &#39;tout le monde&#39;, et donnez les accès en écriture/lecture pour &#39;Tout le monde&#39; jusqu&#39;à la fin de l&#39;installation. Après remettez en lecture seule.');
define('POPUP_ERROR_89_HEADING','Permission de mettre à jour');
define('POPUP_ERROR_89_TEXT','Phreebooks a détecté une installation précédente et vos paramètres de sécurité ne vous permettent pas la mise à jour. Ce n&#39;est pas un problème sauf si une mise à jour est exécutée.');
define('POPUP_ERROR_90_HEADING','ID Société');
define('POPUP_ERROR_90_TEXT','L&#39;ID de la société est utilisé pour les entrées de journal et dans les menus déroulants pour aider à identifier la succursale demandant l&#39;action. Pour les opérations multi-succursales, cette valeur sera combinée avec les IDs des autres succursales pour séparer les entrées.');
define('POPUP_ERROR_91_HEADING','Code postal de la société');
define('POPUP_ERROR_91_TEXT','Le code postal est utilisé pour les factures, etc. Il est aussi utilisé dans le module de livraison pour calculer les frais de port.');
define('POPUP_ERROR_92_HEADING','Numéros de téléphone/fax de la société');
define('POPUP_ERROR_92_TEXT','Deux numéros de téléphone et un de fax sont autorisés.');
define('POPUP_ERROR_93_HEADING','Site Web de la société');
define('POPUP_ERROR_93_TEXT','URL vers la page d&#39;accueil de la société. Peut être utilisé pour les factures, commandes fournisseurs, etc.');
define('POPUP_ERROR_94_HEADING','Modèle de plan comptable');
define('POPUP_ERROR_94_TEXT','Un modèle de plan comptable est requis. Si un plan comptable est déjà chargé dans le système, veuillez choisir ' . TEXT_CURRENT_SETTINGS . ' avant de continuer ou bien choisissez un modèle dans la liste. Pour visualiser un plan, sélectionnez un modèle et cliquez sur &#39;Voir les détails du plan&#39;.');
define('POPUP_ERROR_95_HEADING','Années d&#39;Exercice/Périodes Comptables');
define('POPUP_ERROR_95_TEXT','Les principes comptables utilisent les années d&#39;exercice fiscal et les périodes comptables pour suivre la performance fiscale. L&#39;année d&#39;exercice comprend 12 périodes comptables par exercice fiscal. Généralement, les périodes comptables s&#39;alignent sur les mois et les exercices fiscaux sur les années du calendrier. Phreebooks peut aussi autoriser des dates de début non-standards pour une période comptable et l&#39;exercice fiscal afin de permettre des dates de début à mi-mois/mi-année. Pour le moment, choisissez un mois et une année de début pour votre premier exercice fiscal. PhreeBooks&trade; positionnera le début de l&#39;exercice 1 au premier jour du mois choisi. <br /><br />Après l&#39;installation, les véritables jours de chaque période comptable pourront être modifiés pour correspondre au calendrier comptable de votre société. NOTE: Cette modification devra être faite avant toute écriture dans le journal.');
define('POPUP_ERROR_96_HEADING','Compte de stock des articles achetés par défaut');
define('POPUP_ERROR_96_TEXT','Compte à utiliser pour les articles reçus des fournisseurs. Notez que chaque SKU a son propre compte de stock mais celui-ci est utilisé pour le remplissage initial des formulaires de commande pour les articles non enregistrés en base de données avec un SKU.');
define('POPUP_ERROR_97_HEADING','Compte des achats par défaut');
define('POPUP_ERROR_97_TEXT','Compte du Grand Livre pour accumuler vos achats. Le compte des achats par défaut peut être chevauché sur une commande par niveau de commande pour plus de granularité des achats de votre société.');
define('POPUP_ERROR_98_HEADING','Compte des remises sur achats par défaut');
define('POPUP_ERROR_98_TEXT','Compte du Grand Livre pour accumuler les remises sur achats aux fournisseurs. Il peut contenir les bons de réduction/remises détachés avec vos articles du stock, remises pour pré-paiement sur les achats, etc.');
define('POPUP_ERROR_99_HEADING','Compte d&#39;achat des marchandises entrantes par défaut');
define('POPUP_ERROR_99_TEXT','Compte du Grand Livre où les charges de marchandises entrantes sont placées. Il est habituel d&#39;éclater les charges de marchandises entrantes dans un compte séparé pour ne pas affecter défavorablement le coût du stock reçu.');
define('POPUP_ERROR_100_HEADING','Compte Paiement Vendeur par défaut');
define('POPUP_ERROR_100_TEXT','Compte du Grand Livre où les paiements aux fournisseurs sont débités. C&#39;est typiquement un compte espéces, habituellement un compte de contrôle ou tirage d&#39;espèces.');
define('POPUP_ERROR_101_HEADING','Compte des ventes par défaut');
define('POPUP_ERROR_101_TEXT','Compte du Grand Livre pour accumuler vos ventes. Le compte des ventes par défaut peut être chevauché sur une commande par niveau de commande pour plus de granularité des ventes de votre société.');
define('POPUP_ERROR_102_HEADING','Compte des effets à recevoir par défaut');
define('POPUP_ERROR_102_TEXT','Compte du Grand Livre pour accumuler les espèces dues attribuées aux ventes avec paiement à terme, i.e. les ventes dont le paiement est attendu à une date ultérieure.');
define('POPUP_ERROR_103_HEADING','Compte des remises sur ventes par défaut');
define('POPUP_ERROR_103_TEXT','Compte du Grand Livre pour accumuler les remises sur les ventes aux clients. Il peut contenir les bons de réduction détachés avec vos articles du stock, remises pour pre-paiement sur les ventes, etc.');
define('POPUP_ERROR_104_HEADING','Compte des ventes des marchandises sortantes par défaut');
define('POPUP_ERROR_104_TEXT','Compte du Grand Livre ou les charges d&#39;expédition de marchandises sont placées. Il est habituel d&#39;éclater les charges de marchandises sortantes dans un compte séparé pour faire la différence entre les ventes de produits et les ventes de marchandises.');
define('POPUP_ERROR_105_HEADING','Compte Paiement Client par défaut');
define('POPUP_ERROR_105_TEXT','Compte du Grand Livre où les espèces sont trainées pour les paiements reçus de vos clients. C&#39;est typiquement un compte espéces, habituellement un compte de contrôle ou tirage d&#39;espèces.');
define('POPUP_ERROR_106_HEADING','Répertoire /includes');
define('POPUP_ERROR_106_TEXT','Impossible d&#39;écrire le fichier configure.php dans le répertoire /includes. Veuillez vérifier les permissions sur le répertoire /includes et les mettre sur 777.');
define('POPUP_ERROR_107_HEADING','Répertoire /my_files');
define('POPUP_ERROR_107_TEXT','Impossible de créer le répertoire /my_files. Veuillez vérifier les permissions sur le répertoire racine et les mettre sur 777.');
define('POPUP_ERROR_108_HEADING','La base de données existe');
define('POPUP_ERROR_108_TEXT','Impossible de créer les tables de base de données, elle existent déjà ! PhreeBooks&trade; ne peut faire une installation propre à partir de zéro car il a détecté une installation précédente. <br><br>L&#39;installation ne peut continuer tant que les tables de la base de données ne seront pas effacées.');
define('POPUP_ERROR_109_HEADING', 'L&#39;ID de société est vide');
define('POPUP_ERROR_109_TEXT', 'Veuillez indiquer l&#39;identifiant faisant référence à votre société. Moins de 15 caractères et sans espaces, ex: HQ, SWBranch, etc.');

?>