<?php
// +-----------------------------------------------------------------+
// |                   PhreeBooks Open Source ERP                    |
// +-----------------------------------------------------------------+
// | Copyright (c) 2008, 2009, 2010 PhreeSoft, LLC                   |
// | http://www.PhreeSoft.com                                        |
// +-----------------------------------------------------------------+
// | This program is free software: you can redistribute it and/or   |
// | modify it under the terms of the GNU General Public License as  |
// | published by the Free Software Foundation, either version 3 of  |
// | the License, or any later version.                              |
// |                                                                 |
// | This program is distributed in the hope that it will be useful, |
// | but WITHOUT ANY WARRANTY; without even the implied warranty of  |
// | MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the   |
// | GNU General Public License for more details.                    |
// |                                                                 |
// | The license that is bundled with this package is located in the |
// | file: /doc/manual/ch01-Introduction/license.html.               |
// | If not, see http://www.gnu.org/licenses/                        |
// +-----------------------------------------------------------------+
//  Path: /modules/install/language/fr_fr/finished.php
//

  define('TEXT_MAIN','<h2>Félicitations !</h2><h3>Vous avez installé PhreeBooks&trade; avec succès sur votre système !</h3>
<h2>ÉTAPES SUIVANTES</h2>Pour votre sécurité, vous devez changer les permissions en mode lecture seule sur votre fichier <strong>configure.php</strong> se trouvant dans le répertoire <strong>/includes/</strong> avant de permettre aux utilisateurs d&#39;accéder à votre société.<br /><br />
En plus, vous devez activer Javascript et autoriser les popups. PhreeBooks&trade; utilise ces fonctionnalités pour naviguer dans les comptes et les commandes ainsi que pour remplir les formulaires.<br /><br />
<h2>CONFIGURATION</h2>Nous vous encourageons à commencer par la lecture des <strong>FAQs</strong> de notre forum officiel de support et du <strong>manuel</strong> (lien &#39;Aide&#39;) afin d&#39;y trouver des informations utiles pour la configuration et la personnalisation selon vos propres critères de votre société.<br />
Si vous vous posez des questions, c&#39;est le premier endroit à consulter ! Si vous êtes bloqué, demandez de l&#39;aide sur le forum de support. Les personnes de notre communauté se feront un plaisir de vous aider en partageant leurs connaissances.<br /><br /> 
Il est aussi <strong>important</strong> que vous consultiez les <strong>fichiers d&#39;aide</strong> du répertoire <strong><a href="#" onclick=&#39;window.open("../../includes/addons/PhreeHelp/index.php","help","width=800,height=550,resizable=1,scrollbars=1,top=150,left=200");&#39;>/docs</a></strong> de votre site. <a href="#" class="headerLink" onclick=&#39;window.open("../../includes/addons/PhreeHelp/index.php","help","width=800,height=550,resizable=1,scrollbars=1,top=150,left=200");&#39;>Cliquez ici pour afficher la liste.</a>
<h2>NOTES IMPORTANTES</h2>L&#39;outil principal que vous aurez à utiliser pour personnaliser votre société est la <strong>Boîte à Outils Société</strong>, qui est dans le <strong>menu &#39;Société&#39;</strong>. Vous pouvez l&#39;utiliser pour rechercher presque n&#39;importe quoi que vous voudriez personnaliser ou changer, en particulier tout texte affiché sur votre site. <br /><br />
<h2>NOTES ADDITIONNELLES ET SUPPORT</h2>
<p>Dans notre <a target="_blank" href="http://www.phreebooks.com/pb_phpBB/index.php">forum en ligne</a>.</p>
<p>Nous sommes heureux que vous ayez choisi PhreeBooks&trade; pour votre solution ERP !<br /><br />' . '
<a href="http://www.phreebooks.com/index.php">Visitez le site officiel sur www.PhreeBooks.com</a><br />' . '
</p><p>&nbsp;</p>');

  define('TEXT_PAGE_HEADING', 'Installation de PhreeBooks&trade; - Terminée');
  define('ADMIN', 'Ouvrir votre société');
?>