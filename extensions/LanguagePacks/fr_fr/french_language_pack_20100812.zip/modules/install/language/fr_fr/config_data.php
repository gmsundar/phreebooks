<?php
// +-----------------------------------------------------------------+
// |                   PhreeBooks Open Source ERP                    |
// +-----------------------------------------------------------------+
// | Copyright (c) 2008, 2009, 2010 PhreeSoft, LLC                   |
// | http://www.PhreeSoft.com                                        |
// +-----------------------------------------------------------------+
// | This program is free software: you can redistribute it and/or   |
// | modify it under the terms of the GNU General Public License as  |
// | published by the Free Software Foundation, either version 3 of  |
// | the License, or any later version.                              |
// |                                                                 |
// | This program is distributed in the hope that it will be useful, |
// | but WITHOUT ANY WARRANTY; without even the implied warranty of  |
// | MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the   |
// | GNU General Public License for more details.                    |
// |                                                                 |
// | The license that is bundled with this package is located in the |
// | file: /doc/manual/ch01-Introduction/license.html.               |
// | If not, see http://www.gnu.org/licenses/                        |
// +-----------------------------------------------------------------+
//  Path: /modules/install/language/fr_fr/config_data.php
//

// Set some general translations (may be set in general/language already
define('TEXT_YES','Oui');
define('TEXT_NO','Non');
define('TEXT_SINGLE_MODE','Mode article sur 1 ligne');
define('TEXT_DOUBLE_MODE','Mode article sur 2 lignes');
define('TEXT_AFTER_DISCOUNT','Après Remise');
define('TEXT_BEFORE_DISCOUNT','Avant Remise');
define('TEXT_LOCAL','Local');
define('TEXT_DOWNLOAD','Download');
define('TEXT_CHECKED','Coché');
define('TEXT_UNCHECKED','Décoché');
define('TEXT_HIDE','Cacher');
define('TEXT_SHOW','Montrer');
define('TEXT_NUMBER','Nombre');
define('TEXT_DESCRIPTION','Description');
define('TEXT_BOTH','Les deux');
define('TEXT_PURCH_ORDER','Commandes Fournisseurs');
define('TEXT_PURCHASE','Achats');

/*********************************************************************************************************
									Configuration Data
/*********************************************************************************************************/
/************************** Group ID 0 (System set constants) ***********************************************/
// code CD_xx_yy_TITLE : CD - config data, xx - group ID, yy - sort order
define('CD_00_01_TITLE','Exercice Comptable Courant');
define('CD_00_01_DESC', 'Cette valeur définit l&#39;exercice comptable courant. FIXÉ PAR LE SYSTÈME.');
define('CD_00_02_TITLE','Exercice Comptable Courant - Date de Début');
define('CD_00_02_DESC', 'Cette valeur définit la date de début de l&#39;exercice comptable. FIXÉ PAR LE SYSTÈME.');
define('CD_00_03_TITLE','Exercice Comptable Courant - Date de Fin');
define('CD_00_03_DESC', 'Cette valeur définit la date de fin de l&#39;exercice comptable. FIXÉ PAR LE SYSTÈME.');
define('CD_00_04_TITLE','Modules Installés');
define('CD_00_04_DESC', 'Liste des noms de ficher des modules de livraisons séparés par un point-virgule. Mise à jour automatique. Inutile de l&#39;éditer. (Exemple: ups.php;flat.php;item.php)');
/************************** Group ID 1 (My Company) ***********************************************/
define('CD_01_01_TITLE','Nom de la société');
define('CD_01_01_DESC', 'Le nom de ma société');
define('CD_01_02_TITLE','Nom de contact effets à recevoir (créances)');
define('CD_01_02_DESC', 'Le nom par défaut ou l&#39;identifiant à utiliser pour toutes les opérations de créance.');
define('CD_01_03_TITLE','Nom de contact effets à payer (dettes)');
define('CD_01_03_DESC', 'Le nom par défaut ou l&#39;identifiant à utiliser pour toutes les opérations à payer.');
define('CD_01_04_TITLE','Adresse - ligne 1');
define('CD_01_04_DESC', 'Première ligne d&#39;adresse');
define('CD_01_05_TITLE','Adresse - ligne 2');
define('CD_01_05_DESC', 'Seconde ligne d&#39;adresse');
define('CD_01_06_TITLE','Ville/Cité');
define('CD_01_06_DESC', 'La ville/cité où se situe cette société');
define('CD_01_07_TITLE','Région/Département');
define('CD_01_07_DESC', 'La région ou le département où se situe cette société');
define('CD_01_08_TITLE','Code postal');
define('CD_01_08_DESC', 'Le code postal où se situe cette société');
define('CD_01_09_TITLE','Pays');
define('CD_01_09_DESC', 'Le pays où se situe cette société<br /><br /><strong>NOTE: Pensez à mettre à jour la région ou le département de la société.</strong>');
define('CD_01_10_TITLE','Numéro de téléphone principal');
define('CD_01_10_DESC', 'Entrez le numéro de téléphone principal de la société');
define('CD_01_11_TITLE','Numéro de téléphone secondaire');
define('CD_01_11_DESC', 'Entrez le numéro de téléphone secondaire (ou un numéro d&#39;appel gratuit)');
define('CD_01_12_TITLE','Numéro de fax');
define('CD_01_12_DESC', 'Entrez le numéro de fax de la société');
define('CD_01_13_TITLE','Adresse e-mail de la société');
define('CD_01_13_DESC', 'Entrez l&#39;adresse e-mail de la société');
define('CD_01_14_TITLE','Site web de la société');
define('CD_01_14_DESC', 'Entrez la page d&#39;accueil du site web de la société (sans le http://)');
define('CD_01_15_TITLE','ID fiscal de la société');
define('CD_01_15_DESC', 'Entrez le numéro d&#39;identification fiscal (fédéral) de la société');
define('CD_01_16_TITLE','ID de la société');
define('CD_01_16_DESC', 'Entrez le numéro d&#39;identification de la société. Ce numéro est utilisé pour identifier les transactions générées localement par rapport à des transactions importées / exportées.');
define('CD_01_18_TITLE','Activer le support multi-succursales');
define('CD_01_18_DESC', 'Activer la fonctionnalité succursales multiples.<br>Si NON est sélectionné, une seule localisation de la société sera prise en charge.');
define('CD_01_19_TITLE','Activer l&#39;affichage multi-devises');
define('CD_01_19_DESC', 'Activer les devises multiples dans les écrans de saisie utilisateur.<br>Si NON est sélectionné, seule la devise par défaut sera utilisée.');
define('CD_01_20_TITLE','Passer à la devise par défaut de la langue');
define('CD_01_20_DESC', 'Changer automatiquement de devise lorsque la langue est changée');
define('CD_01_25_TITLE','Activer les fonctions de livraison');
define('CD_01_25_DESC', 'Activer ou pas les fonctions et les champs de livraison.');
define('CD_01_30_TITLE','Activer le cryptage des informations');
define('CD_01_30_DESC', 'Activer ou pas le stockage crypté des champs.');
define('CD_01_50_TITLE','Activer les remises en valeur/pourcentage sur les totaux de commande');
define('CD_01_50_DESC', 'Cette fonctionnalité ajoute deux champs additionnels aux écrans de commande pour saisir une remise en valeur ou pourcentage sur la commande. Si elle est désactivée, les champs ne seront pas affichées sur les écrans de commande.');
define('CD_01_52_TITLE','Arrondir la taxe par autorité');
define('CD_01_52_DESC', 'L&#39;activation cette fonctionnalité fera arrondir par PhreeBooks&trade; les taxes calculées par autorité avant l&#39;additon de toutes les autorités applicables. Pour les taux de taxe à une seule autorité, cela empêchera les erreurs de calculs mathématiques de pénétrer dans le journal. Pour les taux de taxe multi-autorités, cela pourrait causer trop ou trop peu de taxe d&#39;être collectées. En cas de doute, conservez la valeur NON.');
define('CD_01_55_TITLE','Activer les lecteurs de code à barres');
define('CD_01_55_DESC', 'Si positionné sur VRAI, cette option permettra la saisie des données sur les formulaires de commande à l&#39;aide d&#39;un des lecteurs USB de code à barres supportés.');
define('CD_01_75_TITLE','Utiliser écran de commande à ligne unique');
define('CD_01_75_DESC', 'Si positionné sur VRAI, cette option utilise un écran de commande à ligne unique sans afficher les champs de prix plein et de remise. L&#39;écran à ligne unique utilise les numéros de compte du GL contre autoriser les numéros/descriptions pleines du GL dans le mode à deux lignes.');
/************************** Group ID 2 (Customer Defaults) ***********************************************/
define('CD_02_01_TITLE','Compte par défaut - Effets à recevoir');
define('CD_02_01_DESC', 'Compte par défaut des effets à recevoir');
define('CD_02_02_TITLE','Compte GL par défaut des ventes');
define('CD_02_02_DESC', 'Compte par défaut du Grand Livre pour les transactions de vente');
define('CD_02_03_TITLE','Compte GL par défaut des recettes en espèces');
define('CD_02_03_DESC', 'Compte par défaut du Grand Livre recevant les recettes lorsque les clients payent les factures.');
define('CD_02_04_TITLE','Compte GL par défaut des remises');
define('CD_02_04_DESC', 'Compte par défaut du Grand Livre recevant les remises lorsque les clients payent d&#39;avance avec une remise appliquée.');
define('CD_02_05_TITLE','Compte par défaut du transport (marchandises sortantes)');
define('CD_02_05_DESC', 'Compte par défaut pour enregistrer les frais de transport');
define('CD_02_06_TITLE','Compte par défaut des dépôts en banque clients');
define('CD_02_06_DESC', 'Compte espèces par défaut à utiliser pour les dépôts clients');
define('CD_02_07_TITLE','Compte de dettes par défaut des dépôts en banque clients');
define('CD_02_07_DESC', 'Compte par défaut des autres dettes courantes à utiliser pour les dépôts clients.');
define('CD_02_10_TITLE','Conditions de paiement');
define('CD_02_10_DESC', 'Sélection des conditions de paiement');
define('CD_02_11_TITLE','Utiliser la limite de crédit');
define('CD_02_11_DESC', 'Utiliser la limite de crédit par client lors du traitement des commandes');
define('CD_02_12_TITLE','Montant de la limite de crédit');
define('CD_02_12_DESC', 'Montant par défaut à utiliser pour la limite de crédit client');
define('CD_02_13_TITLE','Nombre de jours d&#39;échéance');
define('CD_02_13_DESC', 'Le nombre de jours d&#39;échéance du paiement pour usage lorsque les conditions sont acceptées (payable en # jours, exigible le)');
define('CD_02_14_TITLE','Nombre de jours de remise pour prépaiement');
define('CD_02_14_DESC', 'Le nombre de jours à utiliser pour une remise si paiement anticipé. Utiliser en conjonction avec remise pour paiement anticipé ci-dessous. Entrez 0 pour aucun rabais si prépaiement.');
define('CD_02_15_TITLE','Pourcentage de remise pour prépaiement');
define('CD_02_15_DESC', 'Pourcentage de remise pour paiement anticipé. Inutilisé sauf si le nombre de jours de remise pour prépaiement est égal à zéro.');
define('CD_02_16_TITLE','Date de départ du vieillissement de compte');
define('CD_02_16_DESC', 'Définit la date de début utilisée pour le calcul du vieillissement de compte. Les choix sont:<br>0 - Date de la facture ou 1 - Date d&#39;échéance');
define('CD_02_17_TITLE','Délai 1 de vieillissement de compte');
define('CD_02_17_DESC', 'Détermine le nombre de jours pour le premier avertissement de factures en souffrance. Le délai court à partir de la date de début de vieillissement de compte.');
define('CD_02_18_TITLE','Délai 2 de vieillissement de compte');
define('CD_02_18_DESC', 'Détermine le nombre de jours pour le premier avertissement de factures en souffrance. Le délai court à partir de la date de début de vieillissement de compte.');
define('CD_02_19_TITLE','Délai 3 de vieillissement de compte');
define('CD_02_19_DESC', 'Détermine le nombre de jours pour le premier avertissement de factures en souffrance. Le délai court à partir de la date de début de vieillissement de compte.');
define('CD_02_20_TITLE','Entête vieillissement de compte 1');
define('CD_02_20_DESC', 'C&#39;est l&#39;en-tête utilisée sur les rapports pour montrer le vieillissement de compte pour la date d&#39;échéance n°1.');
define('CD_02_21_TITLE','Entête vieillissement de compte 2');
define('CD_02_21_DESC', 'C&#39;est l&#39;en-tête utilisée sur les rapports pour montrer le vieillissement de compte pour la date d&#39;échéance n°2.');
define('CD_02_22_TITLE','En-tête vieillissement de compte 3');
define('CD_02_22_DESC', 'C&#39;est l&#39;en-tête utilisée sur les rapports pour montrer le vieillissement de compte pour la date d&#39;échéance n°3.');
define('CD_02_23_TITLE','En-tête vieillissement de compte 4');
define('CD_02_23_DESC', 'C&#39;est l&#39;en-tête utilisée sur les rapports pour montrer le vieillissement de compte pour la date d&#39;échéance n°4.');
define('CD_02_24_TITLE','Calcul des frais de financement');
define('CD_02_24_DESC', 'Détermine si oui ou non calculer les frais de financement sur les factures échues.');
define('CD_02_30_TITLE','Ajouter des taxes aux frais de livraison clients');
define('CD_02_30_DESC', 'Si activé, les frais d&#39;expédition seront ajoutés au calcul de la taxe des ventes. Si désactivé, l&#39;expédition ne sera pas taxée.');
define('CD_02_35_TITLE','Auto-incrémenter l&#39;ID client');
define('CD_02_35_DESC', 'Si défini à true, cette option assignera automatiquement un ID à un nouveau client/fournisseur lors de sa création.');
define('CD_02_40_TITLE','Montrer un popup avec l&#39;état du compte client sur les écrans de commande');
define('CD_02_40_DESC', 'Cette fonction affiche un popup état client sur les écrans de commande lorsqu&#39;un client est sélectionné dans la fenêtre contextuelle recherche de contact. Il affiche les soldes, le vieillissement ainsi que l&#39;état actif du compte.');
define('CD_02_50_TITLE','Calculer la taxe des ventes client avant application remise');
define('CD_02_50_DESC', 'Si les remises niveau commande sont activées, ce commutateur permet de déterminer si la taxe des ventes est calculée avant ou après l&#39;application de la remise aux commandes, ventes/factures, et devis clients.');
/************************** Group ID 3 (Vendor Defaults) ***********************************************/
define('CD_03_01_TITLE','Compte par défaut achats articles');
define('CD_03_01_DESC', 'Compte par défaut pour tous les articles sauf si spécifié dans l&#39;enregistrement individuel de l&#39;article.');
define('CD_03_02_TITLE','Compte GL par défaut des achats');
define('CD_03_02_DESC', 'Compte par défaut du Grand Livre pour tous les achats sauf si spécifié dans l&#39;enregistrement individuel du fournisseur.');
define('CD_03_03_TITLE','Compte GL par défaut des paiements en espèces');
define('CD_03_03_DESC', 'Compte par défaut du Grand Livre recevant les paiements lorsque les factures fournisseurs sont payées.');
define('CD_03_04_TITLE','Compte par défaut du transport fournisseurs (marchandises entrantes)');
define('CD_03_04_DESC', 'Compte par défaut pour enregistrer les frais de transport des envois fournisseurs');
define('CD_03_05_TITLE','Compte d&#39;escompte sur achat');
define('CD_03_05_DESC', 'Compte d&#39;escompte pour un achat payé avec des conditions d&#39;escompte de paiement anticipé.');
define('CD_03_06_TITLE','Compte par défaut des dépôts en banque fournisseurs');
define('CD_03_06_DESC', 'Compte espèces par défaut à utiliser pour les dépôts fournisseurs.');
define('CD_03_07_TITLE','Compte de dettes par défaut des dépôts en banque fournisseurs');
define('CD_03_07_DESC', 'Compte par défaut des autres dettes courantes à utiliser pour les dépôts fournisseurs.');
define('CD_03_10_TITLE','Limite de crédit fournisseur par défaut');
define('CD_03_10_DESC', 'La limite de crédit par défaut pour le fournisseur sauf si elle est indiquée dans le compte spécifique au fournisseur');
define('CD_03_11_TITLE','Conditions générales du fournisseur');
define('CD_03_11_DESC', 'Modalités de paiement par défaut');
define('CD_03_12_TITLE','Nombre de jours des conditions de paiement');
define('CD_03_12_DESC', 'Le nombre de jours avant que le paiement soit exigible (utilisé seulement pour les paramètres payable en # jours et exigible le)');
define('CD_03_13_TITLE','Pourcentage escompte pour prépaiement');
define('CD_03_13_DESC', 'Pourcentage d&#39;escompte pour paiement anticipé. Utilisé avec &#39;Nombre de jours des conditions de paiement&#39;');
define('CD_03_14_TITLE','Nombre de jours d&#39;escompte pour paiement');
define('CD_03_14_DESC', 'Le nombre de jours ou un escompte pour paiement anticipé s&#39;applique');
define('CD_03_15_TITLE','Date de départ du vieillissement des effets à payer');
define('CD_03_15_DESC', 'Définit la date de début utilisée pour le calcul du vieillissement des effets à payer<br />0 - Date de la facture ou 1 - Date d&#39;échéance');
define('CD_03_16_TITLE','Délai 1 de vieillissement des effets à payer');
define('CD_03_16_DESC', 'Le nombre de jours depuis la date de départ du vieillissement des effets à payer pour l&#39;avertissement n°1');
define('CD_03_17_TITLE','Délai 2 de vieillissement des effets à payer');
define('CD_03_17_DESC', 'Le nombre de jours depuis la date de départ du vieillissement des effets à payer pour l&#39;avertissement n°2');
define('CD_03_18_TITLE','Délai 3 de vieillissement des effets à payer');
define('CD_03_18_DESC', 'Le nombre de jours depuis la date de départ du vieillissement des effets à payer pour l&#39;avertissement n°3');
define('CD_03_19_TITLE','En-tête vieillissement des effets à payer 1');
define('CD_03_19_DESC', 'C&#39;est l&#39;en-tête utilisée sur les rapports pour montrer le vieillissement des effets à payer pour la date d&#39;échéance n°1.');
define('CD_03_20_TITLE','En-tête vieillissement des effets à payer 2');
define('CD_03_20_DESC', 'C&#39;est l&#39;en-tête utilisée sur les rapports pour montrer le vieillissement des effets à payer pour la date d&#39;échéance n°2.');
define('CD_03_21_TITLE','En-tête vieillissement des effets à payer 3');
define('CD_03_21_DESC', 'C&#39;est l&#39;en-tête utilisée sur les rapports pour montrer le vieillissement des effets à payer pour la date d&#39;échéance n°3.');
define('CD_03_22_TITLE','En-tête vieillissement des effets à payer 4');
define('CD_03_22_DESC', 'C&#39;est l&#39;en-tête utilisée sur les rapports pour montrer le vieillissement des effets à payer pour la date d&#39;échéance n°4.');
define('CD_03_30_TITLE','Ajouter des taxes aux frais de livraison fournisseurs');
define('CD_03_30_DESC', 'Si activé, les frais d&#39;expédition seront ajoutés au calcul de la taxe des ventes. Si désactivé, l&#39;expédition ne sera pas taxée.');
define('CD_03_35_TITLE','Auto-incrémenter l&#39;ID fournisseur');
define('CD_03_35_DESC', 'Si défini à true, cette option assignera automatiquement un ID à un nouveau fournisseur lors de sa création.');
define('CD_03_40_TITLE','Montrer un popup avec l&#39;état du compte fournisseur sur les écrans de commande');
define('CD_03_40_DESC', 'Cette fonction affiche un popup état fournisseur sur les écrans de commande lorsqu&#39;un fournisseur est sélectionné dans la fenêtre contextuelle recherche de contact. Il affiche les soldes, le vieillissement ainsi que l&#39;état actif du compte.');
define('CD_03_50_TITLE','Calculer la taxe des ventes fournisseur avant application escompte');
define('CD_03_50_DESC', 'Si les remises niveau commande sont activées, ce commutateur permet de déterminer si la taxe des ventes est calculée avant ou après l&#39;application de l&#39;escompte aux commandes d&#39;achats, achats, et devis fournisseurs.');
/************************** Group ID 4 (Employee Defaults) ***********************************************/

/************************** Group ID 5 (Inventory Defaults) ***********************************************/
define('CD_05_01_TITLE','Compte GL par défaut des ventes/entrées des articles en stock');
define('CD_05_01_DESC', 'Compte Grand Livre par défaut des ventes/entrées des stocks de type: Articles en stock');
define('CD_05_02_TITLE','Compte GL par défaut d&#39;inventaire des articles en stock');
define('CD_05_02_DESC', 'Compte Grand Livre par défaut d&#39;inventaire des stocks de type: Articles en stock');
define('CD_05_03_TITLE','Compte GL par défaut du coût des ventes des articles en stock');
define('CD_05_03_DESC', 'Compte Grand Livre par défaut du coût des ventes des stocks de type: Articles en stock');
define('CD_05_04_TITLE','Méthode GL par défaut de coût des articles en stock');
define('CD_05_04_DESC', 'Méthode par défaut de coût des stocks de type: Articles en stock<br />f - FIFO, l - LIFO, a - Moyenne');
define('CD_05_05_TITLE','Compte GL par défaut des ventes/entrées des articles en Master-Stock');
define('CD_05_05_DESC', 'Compte Grand Livre par défaut des ventes/entrées des stocks de type: Articles en Master-Stock');
define('CD_05_06_TITLE','Compte GL par défaut d&#39;inventaire des articles en Master-Stock');
define('CD_05_06_DESC', 'Compte Grand Livre par défaut d&#39;inventaire des stocks de type: Articles en Master-Stock');
define('CD_05_07_TITLE','Compte GL par défaut du coût des ventes des articles en Master-Stock');
define('CD_05_07_DESC', 'Compte Grand Livre par défaut du coût des ventes des stocks de type: Articles en Master-Stock');
define('CD_05_08_TITLE','Méthode GL par défaut de coût des articles en Master-Stock');
define('CD_05_08_DESC', 'Méthode par défaut de coût des stocks de type: Articles en Master-Stock<br />f - FIFO, l - LIFO, a - Moyenne');
define('CD_05_11_TITLE','Compte GL par défaut des ventes/entrées des articles d&#39;assemblage');
define('CD_05_11_DESC', 'Compte Grand Livre par défaut des ventes/entrées des stocks de type: Articles d&#39;assemblage');
define('CD_05_12_TITLE','Compte GL par défaut d&#39;inventaire des articles d&#39;assemblage');
define('CD_05_12_DESC', 'Compte Grand Livre par défaut d&#39;inventaire des stocks de type: Articles d&#39;assemblage');
define('CD_05_13_TITLE','Compte GL par défaut du coût des ventes des articles d&#39;assemblage');
define('CD_05_13_DESC', 'Compte Grand Livre par défaut du coût des ventes des stocks de type: Articles d&#39;assemblage');
define('CD_05_14_TITLE','Méthode GL par défaut de coût des articles d&#39;assemblage');
define('CD_05_14_DESC', 'Méthode par défaut de coût des stocks de type: Articles d&#39;assemblage<br />f - FIFO, l - LIFO, a - Moyenne');
define('CD_05_16_TITLE','Compte GL par défaut des ventes/entrées des articles diffusés');
define('CD_05_16_DESC', 'Compte Grand Livre par défaut des ventes/entrées des stocks de type: Articles diffusés');
define('CD_05_17_TITLE','Compte GL par défaut d&#39;inventaire des articles diffusés');
define('CD_05_17_DESC', 'Compte Grand Livre par défaut d&#39;inventaire des stocks de type: Articles diffusés');
define('CD_05_18_TITLE','Compte GL par défaut du coût des ventes des articles diffusés');
define('CD_05_18_DESC', 'Compte Grand Livre par défaut du coût des ventes des stocks de type: Articles diffusés');
define('CD_05_19_TITLE','Méthode GL par défaut de coût des articles diffusés');
define('CD_05_19_DESC', 'Méthode par défaut de coût des stocks de type: Articles diffusés<br />f - FIFO, l - LIFO, a - Moyenne');
define('CD_05_21_TITLE','Compte GL par défaut des ventes/entrées des articles hors-stock');
define('CD_05_21_DESC', 'Compte Grand Livre par défaut des ventes/entrées des stocks de type: Articles hors-stock');
define('CD_05_22_TITLE','Compte GL par défaut d&#39;inventaire des articles hors-stock');
define('CD_05_22_DESC', 'Compte Grand Livre par défaut d&#39;inventaire des stocks de type: Articles hors-stock');
define('CD_05_23_TITLE','Compte GL par défaut du coût des ventes des articles hors-stock');
define('CD_05_23_DESC', 'Compte Grand Livre par défaut du coût des ventes des stocks de type: Articles hors-stock');
define('CD_05_31_TITLE','Compte GL par défaut des ventes/entrées des articles de service');
define('CD_05_31_DESC', 'Compte Grand Livre par défaut des ventes/entrées des stocks de type: Articles de service');
define('CD_05_32_TITLE','Compte GL par défaut d&#39;inventaire des articles de service');
define('CD_05_32_DESC', 'Compte Grand Livre par défaut d&#39;inventaire des stocks de type: Articles de service');
define('CD_05_33_TITLE','Compte GL par défaut du coût des ventes des articles de service');
define('CD_05_33_DESC', 'Compte Grand Livre par défaut du coût des ventes des stocks de type: Articles de service');
define('CD_05_36_TITLE','Compte GL par défaut des ventes/entrées des articles de labeur');
define('CD_05_36_DESC', 'Compte Grand Livre par défaut des ventes/entrées des stocks de type: articles de labeur');
define('CD_05_37_TITLE','Compte GL par défaut d&#39;inventaire des articles de labeur');
define('CD_05_37_DESC', 'Compte Grand Livre par défaut d&#39;inventaire des stocks de type: articles de labeur');
define('CD_05_38_TITLE','Compte GL par défaut du coût des ventes des articles de labeur');
define('CD_05_38_DESC', 'Compte Grand Livre par défaut du coût des ventes des stocks de type: articles de labeur');
define('CD_05_41_TITLE','Compte GL par défaut des ventes/entrées des articles d&#39;activité');
define('CD_05_41_DESC', 'Compte Grand Livre par défaut des ventes/entrées des stocks de type: Articles d&#39;activité');
define('CD_05_42_TITLE','Compte GL par défaut des ventes/entrées des articles de charge');
define('CD_05_42_DESC', 'Compte Grand Livre par défaut des ventes/entrées des stocks de type: Articles de charge');
define('CD_05_50_TITLE','Taux de taxe par défaut des ventes pour les nouveaux articles en stock');
define('CD_05_50_DESC', 'Détermine le taux de taxe par défaut des ventes à utiliser lors de l&#39;ajout de nouveaux articles en stock.<br><br>NOTE: Cette valeur est appliquée à stocks Auto-Add mais peut être modifiée dans Inventaire => Écran maintenance. Les taux de taxe sont choisis dans la table tax_rates et doivent être configurés à travers Paramètrage => Taux de taxe des ventes.');
define('CD_05_52_TITLE','Taux de taxe par défaut des achats pour les nouveaux articles en stock');
define('CD_05_52_DESC', 'Détermine le taux de taxe par défaut des achats à utiliser lors de l&#39;ajout de nouveaux articles en stock.<br><br>NOTE: Cette valeur est appliquée à stocks Auto-Add mais peut être modifiée dans Inventaire => Écran maintenance. Les taux de taxe sont choisis dans la table tax_rates et doivent être configurés à travers Paramètrage => Taux de taxe des achats.');
define('CD_05_55_TITLE','Activer la création automatique des articles en stock');
define('CD_05_55_DESC', 'Permet la création automatique des articles en stock dans les écrans de commande.<br /><br />UGS sont pas requises dans PhreeBooks&trade; pour les stocks de type non-traçable. Cette fonction permet la création automatique des numéros de référence dans la table inventaire de la base de données. Le type de stockage utilisé sera des articles en stock. Les comptes GL utilisés seront les comptes par défaut et la méthode de coût pour des articles en stock.');
define('CD_05_60_TITLE','Remplissage automatique du menu déroulant de stock lors de la saisie des SKU sur les écrans de commande');
define('CD_05_60_DESC', 'Permet à un appel AJAX de remplir les choix possibles lorsque les données sont saisies dans le champ SKU. Cette fonction est utile lorsque les SKU sont connus et accélère le remplissage des formulaires de commande. Peut ralentir les saisies SKU lorsque des scanners à codes barres sont utilisés.');
define('CD_05_65_TITLE','Activer la recherche automatique des SKU correspondants sur l&#39;écran de commande');
define('CD_05_65_DESC', 'Si activé, PhreeBooks recherche une longueur de SKU dans le formulaire de commande de valeur égale à la longueur du code barre et lorsque la longueur est trouvée, essaie de faire correspondre avec un article du stock. Cela permet une saisie rapide des articles en utilisant des lecteurs de codes barres.');
define('CD_05_70_TITLE','Longueur du SKU pour les lecteurs de codes barres dans les écrans de commande');
define('CD_05_70_DESC', 'Définit le nombre de caractères attendus lors de la lecture de valeurs de codes barres du stock. PhreeBooks effectue une recherche uniquement lorsque le nombre de caractères a été atteint. Des valeurs typiques sont 12 et 13 caractères.');
define('CD_05_75_TITLE','Activer la mise à jour automatique du coût des articles en stock pour les commandes fournisseurs / Achats');
define('CD_05_75_DESC', 'Si activé, PhreeBooks mettra à jour le coût des articles dans la table inventory avec soit le prix commande fournisseur, soit le prix Achat/Recevoir. Utile pour des commandes fournisseurs/Achats immédiates et la mise à jour des prix depuis l&#39;écran de commande sans devoir modifier la table inventory d&#39;abord.');
/************************** Group ID 6 (Special Cases (Payment, Shippping, Price Sheets) **************/
// 
// This group is from add-on modules which will not have a language translation here.
// They should be included with the module.
// 
/************************** Group ID 7 (User Account Defaults) ***********************************************/
define('CD_07_17_TITLE','Mot de passe');
define('CD_07_17_DESC', 'Longueur minimale du mot de passe');
/************************** Group ID 8 (General Settings) ***********************************************/
define('CD_08_01_TITLE','Nombre maximum de résultats de recherche par page');
define('CD_08_01_DESC', 'Nombre maximum de résultats de recherche renvoyés par page');
define('CD_08_03_TITLE','Vérifier automatiquement les mises à jour du logiciel');
define('CD_08_03_DESC', 'Vérifier automatiquement les mises à jour du logiciel lors de la connexion à PhreeBooks&trade;.');
define('CD_08_05_TITLE','Cacher les messages de succès');
define('CD_08_05_DESC', 'Cacher les messages sur les opérations réussies.<br>Seuls les messages d&#39;attention et d&#39;erreur seront affichés.');
define('CD_08_07_TITLE','Mise à jour automatique des devises');
define('CD_08_07_DESC', 'Mise à jour du taux de change des devises chargées à chaque connexion.<br>Si désactivé, les devises peuvent être mises à jour manuellement dans le menu <em>Paramètrage => Devises</em>.');
define('CD_08_10_TITLE','Limiter les résultats de l&#39;historique Client/Fournisseur');
define('CD_08_10_DESC', 'Limite la longueur des valeurs de l&#39;historique montrées dans les comptes client/fournisseur pour les ventes/achats.');
define('CD_08_15_TITLE','Programme par défaut pour générer les rapports et formulaires PDF');
define('CD_08_15_DESC', 'Définit l&#39;application tierce par défaut à utiliser pour générer les rapports et formulaires. FPDF est plus stable et produit des résultats plus fiables, mais ne peut pas gérer les polices UTF-8 ou les codes à barres. TCPDF est plus robuste mais subit encore un développement dans la douleur et peut nécessiter des mises à jour supplémentaires pour rester en phase avec sa version en cours.');
/************************** Group ID 9 (Import/Export Settings) ***********************************************/
define('CD_09_01_TITLE','Préférence d&#39;exportation des éditions/formulaires');
define('CD_09_01_DESC', 'Spécifie la préférence d&#39;exportation lors de l&#39;exportation des rapports et des formulaires. &#39;Local&#39; va les sauvegarder dans le répertoire /my_files/reports du serveur web pour être utilisés avec toutes les sociétés. &#39;Download&#39; va télécharger le fichier par votre navigateur pour le sauvegarder/l&#39;imprimer sur votre machine locale.');
/************************** Group ID 10 (Shipping Defaults) ***********************************************/
define('CD_10_01_TITLE','Unité de mesure du poids par défaut');
define('CD_10_01_DESC', 'Définit l&#39;unité de mesure par défaut pour tous les colis. Les valeurs valides sont:<br>LBS - Livres<br>KGS - Kilogrammes');
define('CD_10_02_TITLE','Devise à utiliser pour les options de livraison par défaut');
define('CD_10_02_DESC', 'Les valeurs valides sont<br>USD - Dollars US<br>EUR - Euros');
define('CD_10_03_TITLE','Unité de mesure des dimensions des colis par défaut');
define('CD_10_03_DESC', 'Unité de mesure des colis. Les valeurs valides sont:<br>IN - Pouces<br>CM - Centimètres');
define('CD_10_04_TITLE','Pré-sélectionne la case à cocher Adresse de résidence');
define('CD_10_04_DESC', '0 - Définit la case de livraison à résidence par défaut comme décochée (adresse commerciale)<br>1 - Définit la case de livraison à résidence par défaut comme cochée (adresse de résidence)');
define('CD_10_05_TITLE','Spécifie le type de colis par défaut');
define('CD_10_05_DESC', 'Spécifie le type de colis par défaut à utiliser pour l&#39;expédition.');
define('CD_10_06_TITLE','Service de ramassage de colis par défaut');
define('CD_10_06_DESC', 'Spécifie le type par défaut de service de ramassage de colis.');
define('CD_10_07_TITLE','Pré-définit la longueur de colis par défaut');
define('CD_10_07_DESC', 'Entrez la longueur de colis par défaut à utiliser pour un envoi standard.');
define('CD_10_08_TITLE','Pré-définit la largeur de colis par défaut');
define('CD_10_08_DESC', 'Entrez la largeur de colis par défaut à utiliser pour un envoi standard.');
define('CD_10_09_TITLE','Pré-définit la hauteur de colis par défaut');
define('CD_10_09_DESC', 'Entrez la hauteur de colis par défaut à utiliser pour un envoi standard.');
define('CD_10_10_TITLE','Afficher la case à cocher des frais supplémentaires de manutention');
define('CD_10_10_DESC', 'Affiche la case à cocher des frais supplémentaires de manutention');
define('CD_10_12_TITLE','Pré-sélectionner la case à cocher de manutention supplémentaire');
define('CD_10_12_DESC', 'Pré-sélectionne la case à cocher de manutention supplémentaire');
define('CD_10_14_TITLE','Afficher l&#39;option de sélection d&#39;assurance');
define('CD_10_14_DESC', 'Affiche l&#39;option de sélection d&#39;assurance.');
define('CD_10_16_TITLE','Pré-sélectionner l&#39;option d&#39;assurance');
define('CD_10_16_DESC', 'Pré-sélectionne la case à cocher d&#39;option d&#39;assurance comme paramètre par défaut.');
define('CD_10_18_TITLE','Valeur d&#39;assurance du colis par défaut');
define('CD_10_18_DESC', 'Spécifie la valeur monétaire par défaut (basée sur la devise utilisée) à ajouter pour l&#39;assurance. Cette valeur sera généralement supplantée par l&#39;application appelante avec la valeur de vente/d&#39;achat lorsque l&#39;estimateur de livraison est invoqué.');
define('CD_10_20_TITLE','Afficher la case à cocher de fractionnement des gros envois');
define('CD_10_20_DESC', 'Affiche la case à cocher pour permettre de fractionner les envois lourds pour les service de petits colis.');
define('CD_10_22_TITLE','Pré-sélectionner la case à cocher de fractionnement des gros envois');
define('CD_10_22_DESC', 'Pré-sélectionne la case à cocher de fractionnement d&#39;envoi. Cette fonctionnalité fractionnera les envois gros et grands en morceaux plus petits (de poids sélectionnable par l&#39;utilisateur) pour expédier par un transporteur de petits colis, i.e. UPS, FedEx, DHL, etc.');
define('CD_10_24_TITLE','Poids de fractionnement des gros envois');
define('CD_10_24_DESC', 'Poids par défaut à utiliser lors du fractionnement des gros envois pour les transporteurs de petits colis.');
define('CD_10_26_TITLE','Afficher la case à cocher de confirmation de livraison');
define('CD_10_26_DESC', 'Affiche la case à cocher de confirmation de livraison');
define('CD_10_28_TITLE','Pré-sélectionner la case à cocher de confirmation de livraison.');
define('CD_10_28_DESC', 'Pré-sélectionne la case à cocher de confirmation de livraison. Les valeurs valides sont:<br>0 - Décochée<br>1 - Cochée');
define('CD_10_30_TITLE','Type de confirmation de livraison demandée.');
define('CD_10_30_DESC', 'Spécifie la valeur par défaut pour le type de confirmation de livraison demandée');
define('CD_10_32_TITLE','Afficher la case à cocher de frais de manutention ');
define('CD_10_32_DESC', 'Affiche la case à cocher de frais de manutention .');
define('CD_10_34_TITLE','Pré-sélectionner la case à cocher de frais de manutention sur livraison');
define('CD_10_34_DESC', 'Pré-sélectionne la case à cocher de l&#39;option de frais de manutention sur la livraison.');
define('CD_10_36_TITLE','Frais de manutention sur livraison par défaut');
define('CD_10_36_DESC', 'Spécifie les frais de manutention par défaut pour une livraison basés sur l&#39;unité de mesure monétaire');
define('CD_10_38_TITLE','Afficher les options de livraison contre-remboursement');
define('CD_10_38_DESC', 'Activer la case à cocher contre-remboursement et les options');
define('CD_10_40_TITLE','Pré-sélectionner la case à cocher de contre-remboursement');
define('CD_10_40_DESC', 'Pré-sélectionne la case à cocher de contre-remboursement');
define('CD_10_42_TITLE','Type de paiement par défaut');
define('CD_10_42_DESC', 'Sélectionne le type de paiement à accepter par défaut');
define('CD_10_44_TITLE','Afficher la case à cocher de ramassage le Samedi');
define('CD_10_44_DESC', 'Affiche la case à cocher de ramassage le Samedi');
define('CD_10_46_TITLE','Pré-sélectionner la case à cocher de ramassage le Samedi');
define('CD_10_46_DESC', 'Pré-sélectionne la case à cocher de ramassage le Samedi');
define('CD_10_48_TITLE','Afficher la case à cocher de livraison le Samedi');
define('CD_10_48_DESC', 'Affiche la case à cocher de livraison le Samedi');
define('CD_10_50_TITLE','Pré-sélectionner la case à cocher de livraison le Samedi');
define('CD_10_50_DESC', 'Pré-sélectionne la case à cocher de livraison le Samedi');
define('CD_10_52_TITLE','Afficher la case à cocher de matières dangereuses');
define('CD_10_52_DESC', 'Affiche la case à cocher de matières dangereuses');
define('CD_10_54_TITLE','Pré-sélectionner la case à cocher de matières dangereuses');
define('CD_10_54_DESC', 'Pré-sélectionne la case à cocher de matières dangereuses');
define('CD_10_56_TITLE','Afficher la case à cocher réfrigéré');
define('CD_10_56_DESC', 'Affiche la case à cocher réfrigéré');
define('CD_10_58_TITLE','Pré-sélectionner la case à cocher réfrigéré');
define('CD_10_58_DESC', 'Pré-sélectionne la case à cocher réfrigéré');
define('CD_10_60_TITLE','Afficher la case à cocher de services de retour');
define('CD_10_60_DESC', 'Affiche la case à cocher de services de retour');
define('CD_10_62_TITLE','Pré-sélectionner la case à cocher de services de retour');
define('CD_10_62_DESC', 'Pré-sélectionne la case à cocher de services de retour');
define('CD_10_64_TITLE','Sélection par défaut pour les services de retour (call tags)');
define('CD_10_64_DESC', 'Sélectionnez la valeur par défaut à utiliser si la case à cocher de services de retour est sélectionnée.');
/************************** Group ID 11 (Address Book Defaults) ***********************************************/
define('CD_11_02_TITLE','Champ contact du compte requis');
define('CD_11_02_DESC', 'Exiger ou non de remplir le champ contact dans le paramètrage des comptes (fournisseurs, clients, employés)');
define('CD_11_03_TITLE','Champ adresse 1 du compte requis');
define('CD_11_03_DESC', 'Exiger ou non de remplir le champ adresse 1 dans le paramètrage des comptes (fournisseurs, clients, employés)');
define('CD_11_04_TITLE','Champ adresse 2 du compte requis');
define('CD_11_04_DESC', 'Exiger ou non de remplir le champ adresse 2 dans le paramètrage des comptes (fournisseurs, clients, employés)');
define('CD_11_05_TITLE','Champ ville/cité du compte requis');
define('CD_11_05_DESC', 'Exiger ou non de remplir le champ ville/cité dans le paramètrage des comptes (fournisseurs, clients, employés)');
define('CD_11_06_TITLE','Champ région/département du compte requis');
define('CD_11_06_DESC', 'Exiger ou non de remplir le champ région/département dans le paramètrage des comptes (fournisseurs, clients, employés)');
define('CD_11_07_TITLE','Champ code postal du compte requis');
define('CD_11_07_DESC', 'Exiger ou non de remplir le champ code postal dans le paramètrage des comptes (fournisseurs, clients, employés)');
define('CD_11_08_TITLE','Champ téléphone 1 du compte requis');
define('CD_11_08_DESC', 'Exiger ou non de remplir le champ téléphone 1 dans le paramètrage des comptes (fournisseurs, clients, employés)');
define('CD_11_09_TITLE','Champ adresse e-mail du compte requis');
define('CD_11_09_DESC', 'Exiger ou non de remplir le champ adresse e-mail dans le paramètrage des comptes (fournisseurs, clients, employés)');
define('CD_11_10_TITLE','Champ adresse 1 de livraison requis');
define('CD_11_10_DESC', 'Exiger ou non de remplir le champ adresse 1 dans les champs de livraison.');
define('CD_11_11_TITLE','Champ adresse 2 de livraison requis');
define('CD_11_11_DESC', 'Exiger ou non de remplir le champ adresse 2 dans les champs de livraison.');
define('CD_11_12_TITLE','Champ contact de livraison equis');
define('CD_11_12_DESC', 'Exiger ou non de remplir le champ contact de livraison dans les champs de livraison.');
define('CD_11_13_TITLE','Champ ville/cité de livraison requis');
define('CD_11_13_DESC', 'Exiger ou non de remplir le champ ville/cité dans les champs de livraison.');
define('CD_11_14_TITLE','Champ région/département de livraison du compte requis');
define('CD_11_14_DESC', 'Exiger ou non de remplir le champ région/département dans les champs de livraison.');
define('CD_11_15_TITLE','Champ code postal de livraison requis');
define('CD_11_15_DESC', 'Exiger ou non de remplir le champ code postal dans les champs de livraison.');
/************************** Group ID 12 (e-mail Settings) ***********************************************/
define('CD_12_01_TITLE','Méthode de transport e-mail');
define('CD_12_01_DESC', 'Définit la méthode d&#39;envoi des courriels.<br /><br /><strong>PHP</strong> est la valeur par défaut, et utilise des wrappers PHP intégrés pour le traitement.<br /><br />Les serveurs fonctionnant sous Windows et MacOS devraient positionner ce paramètre sur <strong>SMTP</strong>.<br /><br /><strong>SMTPAUTH</strong> doit être utilisé uniquement si votre serveur requiert l&#39;autorisation SMTP pour envoyer des messages. Vous devez également configurer vos paramètres SMTPAUTH dans les champs appropriés dans cette section admin.<br /><br /><strong>sendmail</strong> est utilisé par les hôtes Linux/Unix utilisant le programme sendmail sur le serveur.<br /><strong>"sendmail-f "</strong> est uniquement pour les serveurs qui nécessitent l&#39;utilisation du paramètre -f pour envoyer le courrier. Il s&#39;agit d&#39;un paramètre de sécurité souvent utilisé pour prévenir l&#39;usurpation d&#39;identité. Peut provoquer des erreurs si votre serveur de messagerie hôte n&#39;est pas configuré pour l&#39;utiliser.<br /><br /><strong>Qmail</strong> est utilisé par les hôtes Linux/Unix exécutant Qmail comme enveloppe sendmail dans /var/qmail/bin/sendmail.');
define('CD_12_02_TITLE','Retours à la ligne des e-mails');
define('CD_12_02_DESC', 'Définit la séquence de caractères utilisée pour séparer les en-têtes du courriel.');
define('CD_12_03_TITLE','Envoyer les e-mails');
define('CD_12_03_DESC', 'Envoyer les e-mails');
define('CD_12_04_TITLE','Utiliser HTML MIME lors de l&#39;envoi des e-mails');
define('CD_12_04_DESC', 'Envoyer les courriels au format HTML avec l&#39;encodage MIME');
define('CD_12_05_TITLE','Vérifier les adresses e-mail par DNS');
define('CD_12_05_DESC', 'Vérifier les adresses e-mail via un serveur DNS');
define('CD_12_06_TITLE','Activer l&#39;archivage des e-mails ?');
define('CD_12_06_DESC', 'Si vous souhaitez avoir les messages e-mails archivés/entreposées lors de leur envoi, réglez ce paramètre sur "true".');
define('CD_12_07_TITLE','E-mail erreurs friendly');
define('CD_12_07_DESC', 'Voulez-vous afficher les erreurs friendly si les courriels échouent ? Mettre ce paramètre sur faux affichera les erreurs PHP et conduira probablement le script à l&#39;échec. Positionner sur faux uniquement pour le dépannage, et sur vrai pour une boutique en production.');
define('CD_12_10_TITLE','Adresse e-mail (affichée pour vous contacter)');
define('CD_12_10_DESC', 'Adresse e-mail du propriétaire du magasin. Utilisée en "affichage uniquement" pour informer les clients sur la façon de vous contacter.');
define('CD_12_11_TITLE','Adresse e-mail (envoyé FROM)');
define('CD_12_11_DESC', 'Adresse depuis laquelle les messages e-mails seront "envoyés" par défaut. Peut être supplantée lors de la composition dans les modules admin.');
define('CD_12_12_TITLE','Envoi des e-mails obligatoirement depuis un domaine connu ?');
define('CD_12_12_DESC', 'Est-ce que votre serveur de messagerie exige que tous les courriels sortants aient leur adresse "FROM" qui corresponde à un domaine connu existant sur votre serveur web ?<br /><br />Cela est souvent établi afin d&#39;éviter le trucage et le spam. Si la valeur est OUI, l&#39;adresse e-mail (envoyé FROM) sera utilisée comme adresse "FROM" pour tous les messages sortants.');
define('CD_12_15_TITLE','Format des e-mails Admin ?');
define('CD_12_15_DESC', 'Veuillez sélectionner le format des e-mails supplémentaires Admin');
define('CD_12_40_TITLE','Définir la liste déroulante des adresses e-mail "Contactez Nous"');
define('CD_12_40_DESC', 'Sur la page "Contactez Nous", définissez la liste des adresses e-mail, dans ce format: Nom 1 &lt;email@adresse1&gt;, Nom 2 &lt;email@adresse2&gt;');
define('CD_12_50_TITLE','Contactez Nous - Afficher nom et adresse de la boutique');
define('CD_12_50_DESC', 'Inclure le nom de la boutique et son adresse<br />0= off 1= on');
define('CD_12_70_TITLE','Compte de boîte aux lettres pour le courrier par SMTP');
define('CD_12_70_DESC', 'Entrez le nom du compte de boîte aux lettres (me@mydomain.com) fourni par votre hébergeur. C&#39;est le nom du compte dont votre hôte a besoin pour l&#39;authentification SMTP.<br />Uniquement nécessaire si vous utilisez l&#39;authentification SMTP pour le courrier électronique.');
define('CD_12_71_TITLE','Mot de passe du compte pour le courrier par SMTP');
define('CD_12_71_DESC', 'Entrez le mot de passe pour votre boîte aux lettres SMTP.<br />Uniquement nécessaire si vous utilisez l&#39;authentification SMTP pour le courrier électronique.');
define('CD_12_72_TITLE','Hôte du serveur de courrier SMTP');
define('CD_12_72_DESC', 'Entrez le nom DNS de votre serveur de messagerie SMTP.<br />Exemple: mail.mydomain.com<br />ou 55.66.77.88<br />Uniquement nécessaire si vous utilisez l&#39;authentification SMTP pour le courrier électronique.');
define('CD_12_73_TITLE','Port du serveur de courrier SMTP');
define('CD_12_73_DESC', 'Entrez le numéro de port IP sur lequel fonctionne votre serveur de messagerie SMTP.<br />Uniquement nécessaire si vous utilisez l&#39;authentification SMTP pour le courrier électronique.');
define('CD_12_74_TITLE','Convertir les devises pour les e-mails TEXTE');
define('CD_12_74_DESC', 'Quelles conversions de devises avez vous besoin pour les courriels TEXTE ?<br />Défaut = &amp;pound;,£:&amp;euro;,€');
/************************** Group ID 13 (General Ledger Settings) ***********************************************/
define('CD_13_01_TITLE','Changement automatique d&#39;exercice comptable');
define('CD_13_01_DESC', 'Modifie automatiquement l&#39;exercice comptable courant en se basant sur la date du serveur et le calendrier fiscal courant. Si non autorisé, la période comptable en cours doit être modifiée manuellement dans le menu <em>Grand Livre => Utilitaires</em>.');
define('CD_13_05_TITLE','Afficher le nom complet des comptes GL');
define('CD_13_05_DESC', 'Détermine la manière d&#39;afficher les comptes du Grand Livre dans les menus déroulants.<br>Nombre - Numéro de compte GL seulement.<br>Description - Description de compte GL uniquement.<br>Les 2 - Le numéro et le nom de compte GL seront affichés.');
/************************** Group ID 15 (Sessions Settings) ***********************************************/
define('CD_15_01_TITLE','Expiration (timeout) de session en secondes');
define('CD_15_01_DESC', 'Entrez le temps en secondes. Par défaut=3600<br />Exemple: 3600= 1 heure<br /><br />Note: trop peu de secondes peut entraîner des problèmes de session expirée lors de l&#39;ajout/modification de produits.');
define('CD_15_05_TITLE','Renouvellement automatique de la session pour éviter les timeouts entre rechargements de page');
define('CD_15_05_DESC', 'Si activée, cette option utilisera AJAX pour rafraîchir le chronomètreur de session toutes les 5 minutes pour empêcher l&#39;expiration de la session et la déconnection de l&#39;utilisateur. Cette fonctionnalité aide à empêcher les posts perdus lorsque PhreeBooks est resté inactif et qu&#39;un post renvoie sur un écran de connexion.');
/************************** Group ID 17 (Credit Card Settings) ***********************************************/
define('CD_17_01_TITLE','Longueur minimale du nom du possesseur de carte de crédit');
define('CD_17_01_DESC', 'Entrez la longueur minimale du nom du possesseur de carte de crédit.');
define('CD_17_02_TITLE','Longueur minimale du numéro de carte de crédit');
define('CD_17_02_DESC', 'Entrez la longueur minimale du numéro de carte de crédit.');
define('CD_17_03_TITLE','Autoriser les cartes Visa');
define('CD_17_03_DESC', 'Autoriser les cartes de crédit Visa.');
define('CD_17_04_TITLE','Autoriser les cartes Master Card');
define('CD_17_04_DESC', 'Autoriser les cartes de crédit Master Card.');
define('CD_17_05_TITLE','Autoriser les cartes American Express');
define('CD_17_05_DESC', 'Autoriser les cartes de crédit American Express.');
define('CD_17_06_TITLE','Autoriser les cartes Discover');
define('CD_17_06_DESC', 'Autoriser les cartes de crédit Discover.');
define('CD_17_07_TITLE','Autoriser les cartes Diners Club');
define('CD_17_07_DESC', 'Autoriser les cartes de crédit Diners Club.');
define('CD_17_08_TITLE','Autoriser les cartes JCB');
define('CD_17_08_DESC', 'Autoriser les cartes de crédit JCB.');
define('CD_17_09_TITLE','Autoriser les cartes Australian Bankcard');
define('CD_17_09_DESC', 'Autoriser les cartes de crédit Australian Bankcard.');
/************************** Group ID 19 (Layout Settings) ***********************************************/

/************************** Group ID 20 (Website Maintenence) ***********************************************/
define('CD_20_99_TITLE','Activer la génération d&#39;un fichier trace pour débogage');
define('CD_20_99_DESC', 'Activer la génération d&#39;une trace pour le débogage.<br>Si OUI est sélectionné, un menu supplémentaire sera ajouté au menu Outils pour downloader les informations de traçage afin de déboguer les problèmes rencontrés.');
/************************** Group ID 99 (Alternate (non-displayed Settings) *********************************/
// 
// This group is from add-on modules which will not have a language translation here.
// They should be included with the module.
// 

?>