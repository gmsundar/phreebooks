<?php
// +-----------------------------------------------------------------+
// |                   PhreeBooks Open Source ERP                    |
// +-----------------------------------------------------------------+
// | Copyright (c) 2008, 2009, 2010 PhreeSoft, LLC                   |
// | http://www.PhreeSoft.com                                        |
// +-----------------------------------------------------------------+
// | This program is free software: you can redistribute it and/or   |
// | modify it under the terms of the GNU General Public License as  |
// | published by the Free Software Foundation, either version 3 of  |
// | the License, or any later version.                              |
// |                                                                 |
// | This program is distributed in the hope that it will be useful, |
// | but WITHOUT ANY WARRANTY; without even the implied warranty of  |
// | MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the   |
// | GNU General Public License for more details.                    |
// |                                                                 |
// | The license that is bundled with this package is located in the |
// | file: /doc/manual/ch01-Introduction/license.html.               |
// | If not, see http://www.gnu.org/licenses/                        |
// +-----------------------------------------------------------------+
//  Path: /modules/setup/language/fr_fr/modules/assets_tabs.php
//

define('ASSETS_CAT_HEADING_TITLE', 'Onglets d&#39;Actifs');
define('ASSETS_HEADING_CATEGORY_NAME', 'Nom Onglet');
define('ASSETS_INFO_CATEGORY_DESCRIPTION', 'Description de l&#39;onglet');
define('ASSETS_INFO_CATEGORY_NAME', 'Nom de l&#39;onglet d&#39;Actif<br />Le nom doit être court (10), sans caractères spéciaux ou espaces.');
define('ASSETS_INFO_INSERT_INTRO', 'Veuillez entrer le nouvel onglet avec ses propriétés');
define('ASSETS_EDIT_INTRO', 'Veuillez faire les changements nécessaires');
define('ASSETS_INFO_HEADING_NEW_CATEGORY', 'Nouvel onglet');
define('ASSETS_INFO_HEADING_EDIT_CATEGORY', 'Modifier onglet');
define('ASSETS_INFO_DELETE_INTRO', 'Êtes-vous sûr(e) de vouloir supprimer cet onglet ?\nLes onglets ne peuvent pas être supprimés s&#39;il y a un actif dans l&#39;onglet.');
define('ASSETS_INFO_DELETE_ERROR','Ce nom d&#39;onglet existe déjà, veuillez utiliser un autre nom.');
define('TEXT_DISPLAY_NUMBER_OF_CATEGORIES', TEXT_DISPLAY_NUMBER . 'onglets');
define('ASSETS_TABS_LOG','Onglets d&#39;Actif - ');

?>