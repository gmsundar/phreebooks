<?php
// +-----------------------------------------------------------------+
// |                   PhreeBooks Open Source ERP                    |
// +-----------------------------------------------------------------+
// | Copyright (c) 2008, 2009, 2010 PhreeSoft, LLC                   |
// | http://www.PhreeSoft.com                                        |
// +-----------------------------------------------------------------+
// | This program is free software: you can redistribute it and/or   |
// | modify it under the terms of the GNU General Public License as  |
// | published by the Free Software Foundation, either version 3 of  |
// | the License, or any later version.                              |
// |                                                                 |
// | This program is distributed in the hope that it will be useful, |
// | but WITHOUT ANY WARRANTY; without even the implied warranty of  |
// | MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the   |
// | GNU General Public License for more details.                    |
// |                                                                 |
// | The license that is bundled with this package is located in the |
// | file: /doc/manual/ch01-Introduction/license.html.               |
// | If not, see http://www.gnu.org/licenses/                        |
// +-----------------------------------------------------------------+
//  Path: /modules/setup/language/fr_fr/modules/chart_of_accounts.php
//

/************* Release 2.0 additions ***********************/
define('GL_INFO_HEADING_ONLY', 'Ce compte est une en-tête et ne peut pas accepter de valeurs postées');
define('GL_INFO_PRIMARY_ACCT_ID', 'Si ce compte est un sous-compte, sélectionnez le compte principal:');
define('ERROR_ACCT_TYPE_REQ','Le type de compte GL est nécessaire !');
define('GL_ERROR_CANT_MAKE_HEADING','Ce compte présente un solde. Il ne peut être converti en compte-tête.');
/***********************************************************/

define('GL_POPUP_WINDOW_TITLE','Plan Comptable');
define('GL_HEADING_ACCOUNT_NAME', 'ID Compte');
define('GL_HEADING_SUBACCOUNT', 'Sous-Compte');
define('GL_EDIT_INTRO', 'Veuillez faire les changements nécessaires');
define('GL_INFO_ACCOUNT_TYPE', 'Type de compte (obligatoire)');
define('GL_INFO_ACCOUNT_INACTIVE', 'Compte inactif');
define('GL_INFO_INSERT_INTRO', 'Veuillez saisir le nouveau compte du GL et ses propriétés');
define('GL_INFO_NEW_ACCOUNT', 'Nouveau compte');
define('GL_INFO_EDIT_ACCOUNT', 'Modifier le compte');
define('GL_INFO_DELETE_ACCOUNT', 'Supprimer le compte');
define('GL_INFO_DELETE_INTRO', 'Êtes-vous sûr(e) de vouloir supprimer ce compte ?\nUn compte ne peut être supprimé s&#39;il y a une écriture de journal s&#39;y rapportant.');
define('GL_DISPLAY_NUMBER_OF_COA', TEXT_DISPLAY_NUMBER . 'comptes');
define('GL_ERROR_CANT_DELETE','Ce compte ne peut pas être supprimé car il y a des écritures de journal s&#39;y rapportant.');
define('GL_LOG_CHART_OF_ACCOUNTS','Plan comptable - ');
?>