<?php
// +-----------------------------------------------------------------+
// |                   PhreeBooks Open Source ERP                    |
// +-----------------------------------------------------------------+
// | Copyright (c) 2008, 2009, 2010 PhreeSoft, LLC                   |
// | http://www.PhreeSoft.com                                        |
// +-----------------------------------------------------------------+
// | This program is free software: you can redistribute it and/or   |
// | modify it under the terms of the GNU General Public License as  |
// | published by the Free Software Foundation, either version 3 of  |
// | the License, or any later version.                              |
// |                                                                 |
// | This program is distributed in the hope that it will be useful, |
// | but WITHOUT ANY WARRANTY; without even the implied warranty of  |
// | MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the   |
// | GNU General Public License for more details.                    |
// |                                                                 |
// | The license that is bundled with this package is located in the |
// | file: /doc/manual/ch01-Introduction/license.html.               |
// | If not, see http://www.gnu.org/licenses/                        |
// +-----------------------------------------------------------------+
//  Path: /modules/setup/language/fr_fr/modules/countries.php
//

define('SETUP_TITLE_COUNTRIES', 'Pays');
define('SETUP_COUNTRY_CODE_CODES', 'Codes ISO');
define('SETUP_COUNTRY_EDIT_INTRO', 'Veuillez faire les changements nécessaires');
define('SETUP_INFO_COUNTRY_NAME', 'Nom Pays');
define('SETUP_INFO_COUNTRY_CODE_2', 'Code ISO (2)');
define('SETUP_INFO_COUNTRY_CODE_3', 'Code ISO (3)');
define('SETUP_INFO_ADDRESS_FORMAT', 'Format d&#39;adresse:');
define('SETUP_COUNTRY_INSERT_INTRO', 'Veuillez entrer le nouveau pays avec ses données associées');
define('SETUP_COUNTRY_DELETE_INTRO', 'Êtes-vous sûr(e) de vouloir supprimer ce pays ?');
define('SETUP_INFO_HEADING_NEW_COUNTRY', 'Nouveau pays');
define('SETUP_INFO_HEADING_EDIT_COUNTRY', 'Modifier pays');
define('SETUP_INFO_HEADING_DELETE_COUNTRY', 'Supprimer pays');
define('TEXT_DISPLAY_NUMBER_OF_COUNTRIES', TEXT_DISPLAY_NUMBER . 'pays');
define('SETUP_LOG_COUNTRIES','Pays - ');
?>