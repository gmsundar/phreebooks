<?php
// +-----------------------------------------------------------------+
// |                   PhreeBooks Open Source ERP                    |
// +-----------------------------------------------------------------+
// | Copyright (c) 2008, 2009, 2010 PhreeSoft, LLC                   |
// | http://www.PhreeSoft.com                                        |
// +-----------------------------------------------------------------+
// | This program is free software: you can redistribute it and/or   |
// | modify it under the terms of the GNU General Public License as  |
// | published by the Free Software Foundation, either version 3 of  |
// | the License, or any later version.                              |
// |                                                                 |
// | This program is distributed in the hope that it will be useful, |
// | but WITHOUT ANY WARRANTY; without even the implied warranty of  |
// | MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the   |
// | GNU General Public License for more details.                    |
// |                                                                 |
// | The license that is bundled with this package is located in the |
// | file: /doc/manual/ch01-Introduction/license.html.               |
// | If not, see http://www.gnu.org/licenses/                        |
// +-----------------------------------------------------------------+
//  Path: /modules/setup/language/fr_fr/language.php
//

// configuration
define('SETUP_CONFIG_EDIT_INTRO', 'Veuillez faire les changements nécessaires');
define('SETUP_INFO_DATE_ADDED', 'Date de création:');
define('SETUP_INFO_LAST_MODIFIED', 'Dernière mise à jour:');
define('SETUP_NO_MODULE_NAME','Le script d&#39;installation nécessite un nom de module !');

// company manager
define('SETUP_CO_MGR_COPY_CO','Copier une société');
define('SETUP_CO_MGR_COPY_HDR','Entrez le nom de la base de données de la nouvelle société (doit être conforme aux conventions de nommage de MySQL et de votre système de fichiers, typiquement 8-12 caractères alphanumériques). Ce nom est utilisé comme nom de base de données et sera ajouté dans le répertoire &#39;my_files&#39; pour conserver les données spécifiques de l&#39;entreprise . Si vos privilèges ne permettent pas la création de la base de données, demandez à votre administrateur de créer la base de données avant de créer la société.');
define('SETUP_CO_MGR_SRVR_NAME','Serveur de la BDD ');
define('SETUP_CO_MGR_DB_NAME','Nom de la BDD ');
define('SETUP_CO_MGR_DB_USER','Nom d&#39;utilisateur de la BDD ');
define('SETUP_CO_MGR_DB_PW','Mot de passe de la BDD ');
define('SETUP_CO_MGR_CO_NAME','Nom complet de la société ');
define('SETUP_CO_MGR_SELECT_OPTIONS','Sélectionnez les enregistrements de base de données à copier dans la nouvelle société.');
define('SETUP_CO_MGR_OPTION_1','Copier tout le contenu de la BDD dans la nouvelle société.');
define('SETUP_CO_MGR_OPTION_2','Copier le plan comptable dans la nouvelle société.');
define('SETUP_CO_MGR_OPTION_3','Copier les éditions/formulaires dans la nouvelle société.');
define('SETUP_CO_MGR_OPTION_4','Copier le stock dans la nouvelle société.');
define('SETUP_CO_MGR_OPTION_5','Copier les clients dans la nouvelle société.');
define('SETUP_CO_MGR_OPTION_6','Copier les fournisseurs dans la nouvelle société.');
define('SETUP_CO_MGR_OPTION_7','Copier les employés dans la nouvelle société.');
define('SETUP_CO_MGR_OPTION_8','Copier les utilisateurs dans la nouvelle société.');
define('SETUP_CO_MGR_ERROR_EMPTY_FIELD','Les noms de la base de données et de la société ne peuvent être vides !');
define('SETUP_CO_MGR_NO_DB','Erreur de création de la BDD, vérifiez les privilèges et le nom de la BDD. Votre administrateur pourrait avoir à créer les tables de base de données avant que vous créiez la société.');
define('SETUP_CO_MGR_DUP_DB_NAME','Erreur - Le nom de la BDD ne peut pas être le même que le nom de la base actuelle !');
define('SETUP_CO_MGR_CANNOT_CONNECT','Erreur de connexion à la nouvelle base de données. Vérifiez le nom d&#39;utilisateur et son mot de passe.');
define('SETUP_CO_MGR_ERROR_1','Erreur de création des tables de la BDD.');
define('SETUP_CO_MGR_ERROR_2','Erreur lors du chargement des données dans les tables de la BDD.');
define('SETUP_CO_MGR_ERROR_3','Erreur de création des répertoires de la société.');
define('SETUP_CO_MGR_ERROR_4','Erreur lors de la création du fichier de configuration de la société.');
define('SETUP_CO_MGR_ERROR_5A','Erreur en effaçant la table ');
define('SETUP_CO_MGR_ERROR_5B','. DB Error # ');
define('SETUP_CO_MGR_ERROR_6','Erreur en copiant la table ');
define('SETUP_CO_MGR_ERROR_7','Erreur lors du chargement des données de démonstration.');
define('SETUP_CO_MGR_CREATE_SUCCESS','Nouvelle société créée avec succès');
define('SETUP_CO_MGR_DELETE_SUCCESS','La société a été supprimée avec succès !');
define('SETUP_CO_MGR_LOG','Gestion de la société - ');

define('SETUP_CO_MGR_ADD_NEW_CO','Créer une nouvelle société');
define('SETUP_CO_MGR_ADD_NEW_DEMO','Ajouter les données de démonstration aux tables de la BDD.');

define('SETUP_CO_MGR_DEL_CO','Supprimer une société');
define('SETUP_CO_MGR_SELECT_DELETE','Choisissez la société à supprimer:');
define('SETUP_CO_MGR_DELETE_CONFIRM','ATTENTION: CETTE OPÉRATION EFFACE DÉFINITIVEMENT LA SOCIÉTÉ DE LA BASE DE DONNÉES AINSI QUE TOUS SES FICHIERS SPÉCIFIQUES ! TOUTES LES DONNÉES SERONT PERDUES !');
define('SETUP_CO_MGR_JS_DELETE_CONFIRM','Êtes-vous sûr(e) de vouloir supprimer cette société ?');

?>