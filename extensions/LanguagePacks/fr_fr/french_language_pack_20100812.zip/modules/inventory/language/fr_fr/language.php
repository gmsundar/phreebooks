<?php
// +-----------------------------------------------------------------+
// |                   PhreeBooks Open Source ERP                    |
// +-----------------------------------------------------------------+
// | Copyright (c) 2008, 2009, 2010 PhreeSoft, LLC                   |
// | http://www.PhreeSoft.com                                        |
// +-----------------------------------------------------------------+
// | This program is free software: you can redistribute it and/or   |
// | modify it under the terms of the GNU General Public License as  |
// | published by the Free Software Foundation, either version 3 of  |
// | the License, or any later version.                              |
// |                                                                 |
// | This program is distributed in the hope that it will be useful, |
// | but WITHOUT ANY WARRANTY; without even the implied warranty of  |
// | MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the   |
// | GNU General Public License for more details.                    |
// |                                                                 |
// | The license that is bundled with this package is located in the |
// | file: /doc/manual/ch01-Introduction/license.html.               |
// | If not, see http://www.gnu.org/licenses/                        |
// +-----------------------------------------------------------------+
//  Path: /modules/inventory/language/fr_fr/language.php
//

/********************* Release R2.1 additions *************************/
define('INV_TOOLS_STOCK_ROUNDING_ERROR','SKU: %s -> Le stock indique %s disponible(s) mais inférieur à votre précision. Veuillez réparer vos soldes de stock, le stock disponible sera arrondi à %s.');
define('INV_TOOLS_BALANCE_CORRECTED','SKU: %s -> Le stock inventorié disponible a été changé en %s.');

/********************* Release R2.0 additions *************************/
define('INV_TYPES_SA','Assemblage sérialisé');

/********************* Release R1.9 additions *************************/
define('INV_TYPES_SI','Article du stock');
define('INV_TYPES_SR','Article sérialisé');
define('INV_TYPES_MS','Article du Master-Stock');
define('INV_TYPES_AS','Article assemblé');
define('INV_TYPES_NS','Article hors-stock');
define('INV_TYPES_LB','Labeur');
define('INV_TYPES_SV','Service');
define('INV_TYPES_SF','Frais fixe - Service');
define('INV_TYPES_CI','Article de charge');
define('INV_TYPES_AI','Article d&#39;activité');
define('INV_TYPES_DS','Description');
define('INV_TYPES_IA','Article partie d&#39;assemblage');
define('INV_TYPES_MI','Sous-article du Master-Stock');
define('INV_TEXT_FIFO','FIFO');
define('INV_TEXT_LIFO','LIFO');
define('INV_TEXT_AVERAGE','Moyenne');
define('INV_TEXT_GREATER_THAN','Plus grand que');
define('TEXT_CHECKED','Coché');
define('TEXT_UNCHECKED','Non coché');
define('TEXT_SGL_PREC','Simple précision');
define('TEXT_DBL_PREC','Double précision');
define('TEXT_NOT_USED','Inutilisé');
define('TEXT_DIR_ENTRY','Entrée directe');
define('TEXT_ITEM_COST','Coût article');
define('TEXT_RETAIL_PRICE','Prix de détail');
define('TEXT_PRICE_LVL_1','Prix de niveau 1');	
define('TEXT_DEC_AMT','Diminution selon le montant');
define('TEXT_DEC_PCNT','Diminution en pourcentage');
define('TEXT_INC_AMT','Augmentation selon le montant');
define('TEXT_INC_PCNT','Augmentation en pourcentage');
define('TEXT_NEXT_WHOLE','Euro suivant');
define('TEXT_NEXT_FRACTION','Centimes constants');
define('TEXT_NEXT_INCREMENT','Incrément suivant');
define('INV_XFER_SUCCESS','%s pièces du SKU %s transférées avec succès');
define('TEXT_INV_MANAGED','Stock contrôlé');
define('TEXT_FILTERS','Filtres:');
define('TEXT_SHOW_INACTIVE','Afficher inactif');
define('TEXT_APPLY','Appliquer');
define('AJAX_INV_NO_INFO','Pas assez d&#39;informations fournies pour retrouver les détails de l&#39;article');

/********************* Release R1.8 additions *************************/
define('INV_TOOLS_VALIDATE_SO_PO','Valider dans le stock les valeurs des quantités commandées');
define('INV_TOOLS_VALIDATE_SO_PO_DESC','Cette opération execute un test pour s&#39;assurer que, dans le stock, votre quantité en commandes fournisseurs et votre quantité en commandes clients correspondent avec les écritures de journal. La valeur calculée à partir des écritures de journal remplace la valeur dans la table inventory.');
define('INV_TOOLS_REPAIR_SO_PO','Test et réparation dans le stock des valeurs des quantités commandées');
define('INV_TOOLS_BTN_SO_PO_FIX','Commencer le test et réparer');
define('INV_TOOLS_PO_ERROR','SKU: %s avait une quantité de %s sur la commande fournisseur et devait être de %s. Le solde de la table Inventaire a été fixé.');
define('INV_TOOLS_SO_ERROR','SKU: %s avait une quantité de %s sur la commande client et devait être de %s. Le solde de la table Inventaire a été fixé.');
define('INV_TOOLS_SO_PO_RESULT','Fin du traitement dans le stock des quantités commandées. Le nombre total d&#39;articles traités était de %s. Le nombre d&#39;enregistrements avec des erreurs a été de %s.');
define('INV_TOOLS_AUTDIT_LOG_SO_PO','Outils du stock - Réparation des commandes clients/fournisseurs Qté (%s)');
define('INV_ENTRY_PURCH_TAX','Taxe par défaut sur les achats');
define('INV_ENTRY_ITEM_TAXABLE', 'Taxe par défaut sur les ventes');
define('TEXT_LAST_MONTH','Le mois dernier');
define('TEXT_LAST_3_MONTH','3 mois');
define('TEXT_LAST_6_MONTH','6 mois');
define('TEXT_LAST_12_MONTH','12 mois');

/********************* Release R1.7 additions *************************/
define('TEXT_WHERE_USED','Utilisé dans');
define('TEXT_CURRENT_COST','Coût actuel de l&#39;assemblage');
define('JS_INV_TEXT_ASSY_COST','Le prix actuel pour assembler ce SKU est de: ');
define('JS_INV_TEXT_USAGE','Ce SKU est utilisé dans les assemblages suivants: ');
define('JS_INV_TEXT_USAGE_NONE','Ce SKU est utilisé dans aucun assemblage.');
define('INV_HEADING_UPC_CODE','Code UPC');
define('INV_SKU_ACTIVITY','Activité du SKU');
define('INV_ENTRY_INVENTORY_DESC_SALES','Description à la vente');
define('INV_ERROR_DELETE_HISTORY_EXISTS','Impossible de supprimer cet article du stock car il existe un enregistrement dans la table inventory_history.');
define('INV_ERROR_DELETE_ASSEMBLY_PART','Impossible de supprimer cet article du stock car il fait partie d&#39;un assemblage.');

define('INV_TOOLS_VALIDATE_INVENTORY','Valider dans le stock les quantités disponibles affichées');
define('INV_TOOLS_VALIDATE_INV_DESC','Cette opération execute un test pour s&#39;assurer que vos quantités disponibles listées dans la table inventory et affichées sur les écrans de stock sont les mêmes que les quantités dans la table inventory_history telles que calculées par PhreeBooks lorsque les mouvements de stock surviennent. Les seuls articles testés sont ceux qui sont suivis dans le calcul du coût des marchandises vendues. La réparation des soldes du stock va corriger uniquement la quantité dans le stock et ne touchera pas les données de l&#39;historique du stock.');
define('INV_TOOLS_REPAIR_TEST','Tester les soldes du stock avec l&#39;historique du coût des biens vendus');
define('INV_TOOLS_REPAIR_FIX','Réparer les soldes du stock avec l&#39;historique du coût des biens vendus');
define('INV_TOOLS_REPAIR_CONFIRM','Êtes-vous sûr(e) de vouloir réparer, dans le stock, les quantités disponibles pour les faire correspondre aux valeurs calculées par PhreeBooks de l&#39;historique du coût des biens vendus ?');
define('INV_TOOLS_BTN_TEST','Vérifier les soldes du stock');
define('INV_TOOLS_BTN_REPAIR','Synchroniser les qtés en stock');
define('INV_TOOLS_OUT_OF_BALANCE','SKU: %s -> le stock indique %s disponible(s) mais l&#39;historique du coût des biens vendus montre %s disponible(s)');
define('INV_TOOLS_IN_BALANCE','Vos soldes du stock sont OK.');

/********************* Release R1.6 and earlier additions *************************/
define('INV_ASSY_HEADING_TITLE', 'Assemblage/Désassemblage du stock');
define('TEXT_INVENTORY_REVALUATION', 'Ré-évaluation du stock');
define('INV_FIELD_HEADING_TITLE', 'Gestion champs du stock');
define('INV_POPUP_WINDOW_TITLE', 'Articles du stock');
define('INV_POPUP_PRICE_MGR_WINDOW_TITLE','Gestion prix du stock');
define('INV_POPUP_ADJ_WINDOW_TITLE','Ajustements du stock');
define('INV_ADJUSTMENT_ACCOUNT','Compte d&#39;ajustement');
define('INV_POPUP_PRICES_WINDOW_TITLE','Liste des prix SKU');
define('INV_BULK_SKU_ENTRY_TITLE','Saisie des prix SKU en vrac');
define('INV_POPUP_XFER_WINDOW_TITLE','Transfert du stock entre magasins');

define('INV_HEADING_QTY_ON_HAND', 'Qté disponible');
define('INV_QTY_ON_HAND', 'Qté disponible');
define('INV_HEADING_SERIAL_NUMBER', 'N° de série');
define('INV_HEADING_QTY_TO_ASSY', 'Qté pour assembler');
define('INV_HEADING_QTY_ON_ORDER', 'Qté en commande');
define('INV_HEADING_QTY_IN_STOCK', 'Qté en stock');
define('TEXT_QTY_THIS_STORE','Qté pour cette succursale');
define('INV_HEADING_QTY_ON_SO', 'Qté sur commandes clients');
define('INV_QTY_ON_SALES_ORDER', 'Qté sur commandes clients');
define('INV_HEADING_PREFERRED_VENDOR', 'Fournisseur préféré');
define('INV_HEADING_LEAD_TIME', 'Délai de livraison (en jours)');
define('INV_QTY_ON_ORDER', 'Qté sur commandes fournisseurs');
define('INV_ASSY_PARTS_REQUIRED','Composants requis pour cet assemblage');
define('INV_TEXT_REMAINING','Qté restante');
define('INV_TEXT_UNIT_COST','Coût unitaire');
define('INV_TEXT_CURRENT_VALUE','Valeur actuelle');
define('INV_TEXT_NEW_VALUE','Nouvelle valeur');

define('INV_ADJ_QUANTITY','Qté d&#39;ajustement');
define('INV_REASON_FOR_ADJUSTMENT','Raison de l&#39;ajustement');
define('INV_ADJ_VALUE', 'Valeur Ajust.');
define('INV_ROUNDING', 'Arrondi');
define('INV_RND_VALUE', 'Valeur Arrondi');
define('INV_BOM','Note de fournitures');
define('INV_ADJ_DELETE_ALERT', 'Êtes-vous sûr(e) de vouloir supprimer cet ajustement du stock ?');
define('INV_MSG_DELETE_INV_ITEM', 'Êtes-vous sûr(e) de vouloir supprimer cet article du stock ?');

define('INV_XFER_FROM_STORE','Transfert depuis magasin ID');
define('INV_XFER_TO_STORE','vers magasin ID');
define('INV_XFER_QTY','Quantité transférée');
define('INV_XFER_ERROR_NO_COGS_REQD','Cet article du stock n&#39;est pas suivi dans le coût des marchandises vendues. Par conséquent, le transfert de cet article entre les magasins ne l&#39;oblige pas à être posté !');
define('INV_XFER_ERROR_QTY_ZERO','Cette quantité d&#39;article du stock ne peut pas être inférieure à zéro ! Re-saisissez le transfert dans la direction opposée avec une quantité positive.');
define('INV_XFER_ERROR_SAME_STORE_ID','Les IDs des magasins source et destination sont les mêmes, le transfert n&#39;a pas été effectué !');
define('INV_XFER_ERROR_NOT_ENOUGH_SKU','Impossible de transférer le stock, pas assez de disponible en stock pour transférer !');

define('INV_HEADING_NEW_ITEM', 'Nouvel article de stock'); 
define('INV_HEADING_FIELD_INFO', 'Informations du champ de stock');
define('INV_HEADING_FIELD_PROPERTIES', 'Type et propriétés du champ (un seul choix possible)');
define('INV_ENTER_SKU','Entrez le SKU, le type d&#39;article et la méthode de coût puis appuyez sur Continuer<br />La longueur maximum pour le SKU est de ' . MAX_INVENTORY_SKU_LENGTH . ' caractères (' . (MAX_INVENTORY_SKU_LENGTH - 5) . ' pour le Master-Stock)');
define('INV_MS_ATTRIBUTES','Attributs du Master-Stock');
define('INV_TEXT_ATTRIBUTE_1','Attribut 1');
define('INV_TEXT_ATTRIBUTE_2','Attribut 2');
define('INV_TEXT_ATTRIBUTES','Attributs');
define('INV_MS_CREATED_SKUS','Les SKUs suivants seront créés');

define('INV_ENTRY_INVENTORY_TYPE', 'Type de stock');
define('INV_ENTRY_INVENTORY_DESC_SHORT', 'Description courte');
define('INV_ENTRY_INVENTORY_DESC_PURCHASE', 'Description à l&#39;achat');
define('INV_ENTRY_IMAGE_PATH','Chemin relatif de l&#39;image');
define('INV_ENTRY_SELECT_IMAGE','Sélectionner l&#39;image');
define('INV_ENTRY_ACCT_SALES', 'Compte Ventes/Recettes');
define('INV_ENTRY_ACCT_INV', 'Compte Stock/Salaires');
define('INV_ENTRY_ACCT_COS', 'Compte Coût des ventes');
define('INV_ENTRY_INV_ITEM_COST','Coût de l&#39;article');
define('INV_ENTRY_FULL_PRICE', 'Prix fort');
define('INV_ENTRY_ITEM_WEIGHT', 'Poids de l&#39;article');
define('INV_ENTRY_ITEM_MINIMUM_STOCK', 'Niveau minimum du stock');
define('INV_ENTRY_ITEM_REORDER_QUANTITY', 'Qté de réapprovisionnement');
define('INV_ENTRY_INVENTORY_COST_METHOD', 'Méthode de coût');
define('INV_ENTRY_INVENTORY_SERIALIZE', 'Article sérialisé');
define('INV_MASTER_STOCK_ATTRIB_ID','ID (max 2 caractères)');

define('INV_DATE_ACCOUNT_CREATION', 'Date de création');
define('INV_DATE_LAST_UPDATE', 'Dernière mise à jour');
define('INV_DATE_LAST_JOURNAL_DATE', 'Date de dernière écriture');

// Inventory History
define('INV_SKU_HISTORY','Historique du SKU');
define('INV_OPEN_PO','Commandes fournisseurs ouvertes');
define('INV_OPEN_SO','Commandes clients ouvertes');
define('INV_PURCH_BY_MONTH','Achats par mois');
define('INV_SALES_BY_MONTH','Ventes par mois');

define('INV_NO_RESULTS','Aucun résultat trouvé !');
define('INV_PO_NUMBER','N° Commande Fournisseur');
define('INV_SO_NUMBER','N° Commande Client');
define('INV_PO_DATE','Date Commande Fournisseur');
define('INV_SO_DATE','Date Commande Client');
define('INV_PO_RCV_DATE','Date de réception');
define('INV_SO_SHIP_DATE','Date d&#39;expédition');
define('INV_PURCH_COST','Coût à l&#39;achat');
define('INV_SALES_INCOME','Revenu des ventes');
define('TEXT_MONTH','Ce mois');

define('INV_MSG_COPY_INTRO', 'Veuillez entrer un nouvel ID de SKU à copier vers:');
define('INV_MSG_RENAME_INTRO', 'Veuillez entrer un nouvel ID de SKU pour renommer ce SKU en:');
define('INV_ERROR_DUPLICATE_SKU','Le nouvel article du stock ne peut pas être créé car le SKU est déjà utilisé.');
define('INV_ERROR_CANNOT_DELETE','L&#39;article du stock ne peut pas être supprimé car, dans le système, il y a des écritures de journal correspondant au SKU');
define('INV_ERROR_BAD_SKU','Il y avait une erreur avec la liste des articles assemblés, veuillez valider les valeurs SKU et vérifier les quantités. Le SKU défaillant était: ');
define('INV_ERROR_SKU_INVALID','Le SKU n&#39;est pas valide. Veuillez vérifier la valeur SKU et le compte stock.');
define('INV_ERROR_SKU_BLANK','Le SKU a été laissé en blanc. Veuillez entrer une valeur SKU et réessayer.');
define('INV_ERROR_FIELD_BLANK','Le nom du champ a été laissé en blanc. Veuillez entrer un nom de champ et réessayer.');
define('INV_ERROR_FIELD_DUPLICATE','Le champ que vous avez entré est en double, Veuillez changer le nom du champ et soumettre à nouveau.');
define('INV_ERROR_NEGATIVE_BALANCE','Erreur déconstruction du stock, pas assez du stock disponible pour déconstruire la quantité demandée !');
define('TEXT_DISPLAY_NUMBER_OF_ITEMS', 'Affiche <b>%d</b> à <b>%d</b> (sur <b>%d</b> articles)');
define('TEXT_DISPLAY_NUMBER_OF_FIELDS', 'Affiche <b>%d</b> à <b>%d</b> (sur <b>%d</b> champs)');
define('INV_CATEGORY_MEMBER', 'Membre de catégorie:');
define('INV_FIELD_NAME', 'Nom du champ: ');
define('INV_DESCRIPTION', 'Description: ');
define('TEXT_USE_DEFAULT_PRICE_SHEET','Utiliser les paramètres tarifaires par défaut');
define('INV_ERROR_ASSY_CANNOT_DELETE','Impossible de supprimer l&#39;assemblage. Il a été utilisé par une autre écriture de journal !');
define('INV_POST_SUCCESS','Ajustement du stock posté avec succès Réf # ');
define('INV_POST_ASSEMBLY_SUCCESS','Assemblage réussi SKU: ');
define('INV_NO_PRICE_SHEETS','Aucune feuille tarifaire n&#39;a été définie !');
define('INV_DEFINED_PRICES','Prix définis pour SKU: ');

define('INV_LABEL_DEFAULT_TEXT_VALUE', 'Valeur par défaut: ');
define('INV_LABEL_MAX_NUM_CHARS', 'Nombre maximum de caractères (longueur)');
define('INV_LABEL_FIXED_255_CHARS', 'Limité à 255 caractères maximum');
define('INV_LABEL_MAX_255', '(pour des longueurs de moins de 256 caractères)');
define('INV_LABEL_CHOICES', 'Entrez la chaîne de sélection');
define('INV_LABEL_TEXT_FIELD', 'Champ texte');
define('INV_LABEL_HTML_TEXT_FIELD', 'Code HTML');
define('INV_LABEL_HYPERLINK', 'Hyper-lien');
define('INV_LABEL_IMAGE_LINK', 'Nom de fichier image');
define('INV_LABEL_INVENTORY_LINK', 'Lien dans le stock (lien pointant vers un autre article du stock [URL])');
define('INV_LABEL_INTEGER_FIELD', 'Nombre entier');
define('INV_LABEL_INTEGER_RANGE', 'Plage des entiers');
define('INV_LABEL_DECIMAL_FIELD', 'Nombre décimal');
define('INV_LABEL_DECIMAL_RANGE', 'Plage des décimaux');
define('INV_LABEL_DEFAULT_DISPLAY_VALUE', 'Format d&#39;affichage (max, décimales)');
define('INV_LABEL_DROP_DOWN_FIELD', 'Liste déroulante');
define('INV_LABEL_RADIO_FIELD', 'Bouton radio de sélection<br />Entrez tous les choix séparés par des virgules.<br />Ex: valeur1:desc1:def1,valeur2:desc2:def2<br /><u>Clé:</u><br />valeur = La valeur à placer dans la base de données<br />desc = Description textuelle du choix<br />def = par défaut 0 ou 1, 1 étant le choix par défaut<br />Note: Seulement 1 choix par défaut est autorisé par liste');
define('INV_LABEL_DATE_TIME_FIELD', 'Date et heure');
define('INV_LABEL_CHECK_BOX_FIELD', 'Case à cocher (choix OUI ou NON)');
define('INV_LABEL_TIME_STAMP_FIELD', 'Horodatage');
define('INV_LABEL_TIME_STAMP_VALUE', 'Champ système permettant de connaître les dernières date et heure où un article particulier du stock a été modifié.');

define('INV_FIELD_NAME_RULES','Les nom de champs ne peuvent pas contenir des espaces ou <br />des caractères spéciaux et ne peuvent pas dépasser 64 caractères.');
define('INV_DELETE_INTRO_INV_FIELDS', 'Êtes-vous sûr(e) de vouloir supprimer ce champ de stock ?\nTOUTES LES DONNÉES SERONT PERDUES !');
define('INV_INFO_HEADING_DELETE_INVENTORY', 'Supprimer le champ de stock');
define('INV_CATEGORY_CANNOT_DELETE','Impossible de supprimer la catégorie. Elle est utilisée par le champ: ');
define('INV_CANNOT_DELETE_SYSTEM','Les champs dans la catégorie système ne peuvent pas être supprimés !');
define('INV_IMAGE_PATH_ERROR','Erreur dans le chemin d&#39;accès spécifié pour l&#39;image à uploader !');
define('INV_IMAGE_FILE_TYPE_ERROR','Erreur dans le fichier image uploadé. Type de fichier inacceptable.');
define('INV_IMAGE_FILE_WRITE_ERROR','Il y a eu un problème d&#39;écriture du fichier image dans le répertoire spécifié.');
define('INV_FIELD_RESERVED_WORD','Le nom de champ saisi est un mot réservé. Veuillez choisir un nouveau nom de champ.');

// java script errors and messages
define('JS_SKU_BLANK', '* Le nouvel article a besoin d&#39;un code SKU ou UPC\n');
define('JS_COGS_AUTO_CALC','Le prix unitaire sera calculé par le système.');
define('JS_NO_SKU_ENTERED','Une valeur SKU est nécessaire.\n');
define('JS_ADJ_VALUE_ZERO','Une quantité non nulle d&#39;ajustement est nécessaire.\n');
define('JS_XFER_VALUE_ZERO','Une quantité positive de transfert est nécessaire.\n');
define('JS_ASSY_VALUE_ZERO','Une quantité non nulle d&#39;assemblage est nécessaire.\n');
define('JS_NOT_ENOUGH_PARTS','Pas assez en stock pour assembler les quantités souhaitées');
define('JS_MS_INVALID_ENTRY','L&#39;ID et la description sont des champs obligatoires. Veuillez entrer ces deux valeurs et appuyer sur OK.');
define('JS_INV_TEXT_ASSY_COST','Le prix actuel pour assembler ce SKU est de: ');
define('JS_INV_TEXT_USAGE','Ce SKU est utilisé dans les assemblages suivants: ');
define('JS_INV_TEXT_USAGE_NONE','Ce SKU est utilisé dans aucun assemblage.');

// audit log messages
define('INV_LOG_ADJ','Ajustement du stock - ');
define('INV_LOG_ASSY','Assemblage du stock - ');
define('INV_LOG_FIELDS','Champs de stock - ');
define('INV_LOG_INVENTORY','Article du stock - ');
define('INV_LOG_PRICE_MGR','Gestion des prix du stock - ');
define('INV_LOG_TRANSFER','Transfert de stock depuis %s vers %s');

// the inventory type indexes should not be changed or the inventory module won't work.
// system generated types (not to be displayed are: ai - assembly item, mi - master stock with attributes)
$inventory_types = array(
  'si' => INV_TYPES_SI,
  'sr' => INV_TYPES_SR,
  'ms' => INV_TYPES_MS,
  'as' => INV_TYPES_AS,
  'sa' => INV_TYPES_SA,
  'ns' => INV_TYPES_NS,
  'lb' => INV_TYPES_LB,
  'sv' => INV_TYPES_SV,
  'sf' => INV_TYPES_SF,
  'ci' => INV_TYPES_CI,
  'ai' => INV_TYPES_AI,
  'ds' => INV_TYPES_DS,
);

// used for identifying inventory types in reports and forms that are not selectable by the user
$inventory_types_plus       = $inventory_types;
$inventory_types_plus['ia'] = INV_TYPES_IA;
$inventory_types_plus['mi'] = INV_TYPES_MI;

$cost_methods = array(
  'f' => INV_TEXT_FIFO,	   // First-in, First-out
  'l' => INV_TEXT_LIFO,	   // Last-in, First-out
  'a' => INV_TEXT_AVERAGE, // Average Costing
); 

$integer_lengths = array(
  '0' => '-127 ' . TEXT_TO . ' 127',
  '1' => '-32,768 ' . TEXT_TO . ' 32,768',
  '2' => '-8,388,608 ' . TEXT_TO . ' 8,388,607',
  '3' => '-2,147,483,648 ' . TEXT_TO . ' 2,147,483,647',
  '4' => INV_TEXT_GREATER_THAN . ' 2,147,483,648',
);

$decimal_lengths = array(
  '0' => TEXT_SGL_PREC,
  '1' => TEXT_DBL_PREC,
);

$check_box_choices = array(
  '0' => TEXT_UNCHECKED, 
  '1' => TEXT_CHECKED,
);

$price_mgr_sources = array(
  '0' => TEXT_NOT_USED,	// Do not remove this selection, leave as first entry
  '1' => TEXT_DIR_ENTRY,
  '2' => TEXT_ITEM_COST,
  '3' => TEXT_RETAIL_PRICE,
// Price Level 1 needs to always be at the end (it is pulled from the first row to avoid a circular reference)
// The index can change but must be matched with the javascript to update the price source values.
  '4' => TEXT_PRICE_LVL_1,
);	

$price_mgr_adjustments = array(
  '0' => TEXT_NONE,
  '1' => TEXT_DEC_AMT,
  '2' => TEXT_DEC_PCNT,
  '3' => TEXT_INC_AMT,
  '4' => TEXT_INC_PCNT,
);

$price_mgr_rounding = array(
  '0' => TEXT_NONE,
  '1' => TEXT_NEXT_WHOLE,
  '2' => TEXT_NEXT_FRACTION,
  '3' => TEXT_NEXT_INCREMENT,
);
?>