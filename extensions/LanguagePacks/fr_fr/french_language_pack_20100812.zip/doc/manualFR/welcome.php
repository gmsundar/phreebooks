<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<!-- document position within table of contents; levels separated by dots(.) ie 3.2.4 (one required)-->
<meta name="doc_pos" content="00">
<!-- index positions - used to build index list; up to two levels separated by a dot(.) (zero or more) -->
<meta name="doc_index_1" content="Help.Home">
<!-- glossay items - used to build glossary (zero or more)-->
<!-- glossary terms are imploded with a colon separator -->
<!-- <meta name="doc_glossary_1" content="term:definition of glossary entry"> -->
<!-- Title - Used as the table of contents and index reference title (one required)-->
<meta name="doc_title" content="Bienvenue à PhreeBooks"> 
<!-- End of meta tags -->

<link rel="stylesheet" type="text/css" href="stylesheet.css">
<title>Welcome to PhreeBooks</title>
</head>

<body>

<h1 align="center">Bienvenue à PhreeBooks</h1>
<p>PhreeBooks est une application open source de comptabilité conçue pour la facilité d'utilisation et des fonctionnalités robustes. Rédigé en PHP et MySQL disponibles librement, PhreeBooks a été testé sur de multiples plateformes et navigateurs pour assurer la compatibilité la plus large possible.</p>
<p>Certaines de ses fonctionnalités saillantes sont les suivantes:</p>
<ul>
  <li>Interface basée sur le Web</li>
  <li>Moteur comptable toutes fonctions</li>
  <li>Contrôle complet du stock y compris les assemblages</li>
  <li>Multi-sociétés</li>
  <li>Multi-langues</li>
  <li>Robuste capacité d'éditions</li>
  <li>Capacités d'importation/exportation complètes</li>
  <li>Script d'installation et de configuration convivial</li>
  <li>Sécurité extensive au niveau utilisateur</li>
</ul>
<p>PhreeBooks est diffusé sous la <a href="ch01-Introduction/license.html">licence GNU</a>.</p>
<p>&nbsp;</p>
</body>
</html>
