<?php
// +-----------------------------------------------------------------+
// |                   PhreeBooks Open Source ERP                    |
// +-----------------------------------------------------------------+
// | Copyright (c) 2008, 2009, 2010 PhreeSoft, LLC                   |
// | http://www.PhreeSoft.com                                        |
// +-----------------------------------------------------------------+
// | This program is free software: you can redistribute it and/or   |
// | modify it under the terms of the GNU General Public License as  |
// | published by the Free Software Foundation, either version 3 of  |
// | the License, or any later version.                              |
// |                                                                 |
// | This program is distributed in the hope that it will be useful, |
// | but WITHOUT ANY WARRANTY; without even the implied warranty of  |
// | MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the   |
// | GNU General Public License for more details.                    |
// |                                                                 |
// | The license that is bundled with this package is located in the |
// | file: /doc/manual/ch01-Introduction/license.html.               |
// | If not, see http://www.gnu.org/licenses/                        |
// +-----------------------------------------------------------------+
//  Path: /modules/general/language/fr_fr/language.php
//

// NOTE: NEW RELEASE ADDITIONS/UPDATES/CHANGES ARE AT THE BOTTOM OF THIS FILE 

define('LANGUAGE','Français (FR)');

// look in your $PATH_LOCALE/locale directory for available locales.
// on RedHat6.0 I used 'en_US'
// on FreeBSD 4.0 I use 'en_US.ISO_8859-1'
// this may not work under win32 environments..
setlocale(LC_ALL, 'fr_FR.UTF-8');
setlocale(LC_CTYPE, 'C');

define('DATE_FORMAT', 'd/m/Y'); // this is used for date(), use only values: Y, m and d (case sensitive)
define('DATE_DELIMITER', '/'); // must match delimiter used in DATE_FORMAT
define('DATE_TIME_FORMAT', DATE_FORMAT . ' %H:%M:%S');
define('DATE_FORMAT_SPIFFYCAL', 'dd/MM/yyyy');  //Use only 'dd', 'MM' and 'yyyy' here in any order
define('MAX_NUM_PRICE_LEVELS', 5);
define('MAX_NUM_ADDRESSES', 5); // *****  For Import/Export Module, set the maximum number of addresses *****
define('MAX_INVENTORY_SKU_LENGTH', 15); // database is currently set for a maximum of 24 characters

// Global entries for the <html> tag
define('HTML_PARAMS','lang="fr-FR" xml:lang="fr-FR"');

// charset for web pages and emails
define('CHARSET', 'UTF-8');
define('LANG_I18N','fr');

// Meta-tags: page title
define('TITLE', 'PhreeBooks&trade;');

// **************  Release 2.1 changes  ********************
define('BOX_PHREEFORM_MODULE','PhreeForm');
define('BOX_PHREEFORM_MODULE_ADM','Administration PhreeForm');
define('TEXT_HERE', 'ici');
define('TEXT_COPYRIGHT','Copyright');
define('TEXT_COPYRIGHT_NOTICE','Ce programme est libre, vous pouvez le redistribuer et/ou
le modifier selon les termes de la Licence Publique Générale GNU
publiée par la Free Software Foundation (version 3 ou bien
toute autre version ultérieure). Ce programme est distribué
dans l&#39;espoir qu&#39;il sera utile, mais SANS AUCUNE GARANTIE,
ni explicite ni implicite, y compris les garanties de commercialisation ou
d&#39;adaptation dans un but spécifique. Reportez-vous à la Licence Publique Générale
GNU pour plus de détails. La Licence qui est liée à ce package
est située %s.');
define('TEXT_EXCHANGE_RATE','Taux de change');
define('TEXT_BRANCH','Succursale');

// **************  Release 2.0 changes  ********************
define('TEXT_HEADING','En-tête');
define('TEXT_MOVE_LEFT','Déplacer vers la gauche');
define('TEXT_MOVE_RIGHT','Déplacer vers la droite');
define('TEXT_MOVE_UP','Déplacer vers le haut');
define('TEXT_MOVE_DOWN','Déplacer vers le bas');
define('TEXT_PROFILE','Profil');
define('TEXT_FIND','Rechercher ...');
define('TEXT_DETAILS','Détails');
define('TEXT_HIDE','Cacher');
define('BOX_PHREECRM_MODULE','PhreeCRM');
define('BOX_ACCOUNTS_NEW_CONTACT','Nouveau Contact');
define('TEXT_ENCRYPTION_ENABLED','La clé de cryptage est définie');
define('BOX_GL_BUDGET','Budgets');
define('TEXT_DEFAULT_PRICE_SHEET','Feuille tarifaire par défaut');
define('TEXT_PURCH_ORDER','Commandes fournisseurs');
define('TEXT_PURCHASE','Achats');

// **************  Release 1.9 changes  ********************
define('TEXT_START_DATE','Date de début');
define('TEXT_END_DATE','Date de fin');
define('TEXT_PROJECT','Projet');
define('DB_ERROR_NOT_CONNECTED', 'Erreur BDD: Impossible de se connecter à la base de données !');
define('BOX_BANKING_VENDOR_DEPOSITS', 'Dépôts en banque Fournisseurs');
define('BOX_AR_QUOTE_STATUS', 'Gestion Devis Ventes');
define('BOX_AP_RFQ_STATUS', 'Gestion Devis Achat');
define('BOX_PROJECTS_PHASES','Phases de Projet');
define('BOX_PROJECTS_COSTS','Coûts de Projet');
define('BOX_ACCOUNTS_MAINTAIN_PROJECTS','Maintenir les Projets');
define('BOX_ACCOUNTS_NEW_PROJECT', 'Nouveau Projet');
define('TEXT_JAN', 'Jan');
define('TEXT_FEB', 'Fév');
define('TEXT_MAR', 'Mar');
define('TEXT_APR', 'Avr');
define('TEXT_MAY', 'Mai');
define('TEXT_JUN', 'Jun');
define('TEXT_JUL', 'Jul');
define('TEXT_AUG', 'Aou');
define('TEXT_SEP', 'Sep');
define('TEXT_OCT', 'Oct');
define('TEXT_NOV', 'Nov');
define('TEXT_DEC', 'Déc');
define('TEXT_SUN', 'D');
define('TEXT_MON', 'L');
define('TEXT_TUE', 'M');
define('TEXT_WED', 'M');
define('TEXT_THU', 'J');
define('TEXT_FRI', 'V');
define('TEXT_SAT', 'S');

// **************  Release 1.8 changes  ********************
define('BOX_BANKING_CUSTOMER_DEPOSITS', 'Dépôts en banque Clients');
define('GEN_CALENDAR_FORMAT_ERROR', "Un format de date erroné a été soumis, veuillez vérifier toutes vos dates ! Reçu: %s. (Format de date: " . DATE_FORMAT . ") Veuillez vérifier si votre SEPARATOR dans /modules/general/language/langname/language.php est conforme aussi pour SpiffyCal: " . DATE_FORMAT_SPIFFYCAL);

// **************  Release 1.7 and earlier  ********************
// header text in includes/header.php
define('HEADER_TITLE_TOP', 'Accueil');
define('HEADER_TITLE_LOGOFF', 'Déconnexion');

// Menu heading translations
define('MENU_HEADING_CUSTOMERS', 'Clients');
define('MENU_HEADING_VENDORS', 'Fournisseurs');
define('MENU_HEADING_INVENTORY', 'Stock');
define('MENU_HEADING_BANKING', 'Banque');
define('MENU_HEADING_GL', 'Grand Livre');
define('MENU_HEADING_EMPLOYEES', 'Employés');
define('MENU_HEADING_SETUP', 'Paramètrage');
define('MENU_HEADING_TOOLS', 'Outils');
define('MENU_HEADING_QUALITY','Qualité');
define('MENU_HEADING_REPORTS', 'Éditions');
define('MENU_HEADING_COMPANY','Société');

// Report Group Defiditions (import/export tabs, reports/forms)
define('TEXT_RECEIVABLES','Effets à Recevoir');
define('TEXT_PAYABLES','Effets à Payer');
define('TEXT_INVENTORY','Stock');
define('TEXT_HR','Ressources Humaines');
define('TEXT_MANUFAC','Fabrication');
define('TEXT_BANKING','Banque');
define('TEXT_GL','Grand Livre');
define('TEXT_MISC','Divers');

// General Ledger Menu Labels
define('BOX_GL_JOURNAL_ENTRY', 'Écriture de Journal');
define('BOX_GL_ACCOUNTS', 'Plan Comptable');
define('BOX_GL_UTILITIES', 'Utilitaires du Journal Général');

// Accounts Menu Labels
define('BOX_ACCOUNTS_NEW_CUSTOMER', 'Nouveau Client');
define('BOX_ACCOUNTS_MAINTAIN_CUSTOMERS', 'Maintenir les Clients');
define('BOX_ACCOUNTS_NEW_EMPLOYEE', 'Nouvel Employé');
define('BOX_ACCOUNTS_MAINTAIN_EMPLOYEES', 'Maintenir les Employés');
define('BOX_ACCOUNTS_NEW_VENDOR', 'Nouveau Fournisseur');
define('BOX_ACCOUNTS_MAINTAIN_VENDORS', 'Maintenir les Fournisseurs');
define('BOX_ACCOUNTS_NEW_BRANCH', 'Nouvelle Succursale');
define('BOX_ACCOUNTS_MAINTAIN_BRANCHES', 'Maintenir les Succursales');

// Banking Menu Labels
define('BOX_BANKING_CUSTOMER_RECEIPTS', 'Recettes Clients');
define('BOX_BANKING_CUSTOMER_PAYMENTS', 'Remboursements aux Clients');
define('BOX_BANKING_PAY_BILLS', 'Factures payées');
define('BOX_BANKING_VENDOR_RECEIPTS', 'Remboursements des Fournisseurs');
define('BOX_BANKING_SELECT_FOR_PAYMENT', 'Choix pour Paiement');
define('BOX_BANKING_BANK_ACCOUNT_REGISTER', 'Registre Compte Bancaire');
define('BOX_BANKING_ACCOUNT_RECONCILIATION', 'Rapprochement de Compte');
define('BOX_BANKING_VOID_CHECKS', 'Annuler Chèques');

// HR Menu Labels
define('BOX_HR_MAINTAIN_REPS', 'Maintenir les Représentants');
define('BOX_HR_PAYROLL_ENTRY', 'Entrée Livre de Paie');
define('BOX_HR_DEPARTMENTS', 'Départements');
define('BOX_HR_DEPT_TYPES', 'Types de Départements');

// Inventory Menu labels
define('BOX_INV_MAINTAIN', 'Éditer/Maintenir');
define('BOX_INV_PURCHASE_RECEIVE', 'Acheter/Recevoir');
define('BOX_INV_ADJUSTMENTS', 'Ajustements');
define('BOX_INV_ASSEMBLIES', 'Assemblages');
define('BOX_INV_DEFAULTS', 'Paramètres par défaut du stock');
define('BOX_INV_REPORTS', 'Éditions');
define('BOX_INV_TABS', 'Paramètrer les onglets du stock');
define('BOX_INV_FIELDS', 'Paramètrer les champs du stock');
define('BOX_INV_TRANSFER','Transfert du Stock');

// Payables Menu Labels
define('BOX_AP_PURCHASE_ORDER', 'Commandes Fournisseurs');
define('BOX_AP_CREDIT_MEMO', 'Avoirs Fournisseurs');
define('BOX_AP_DEFAULTS', 'Paramètres par défaut des Fournisseurs');
define('BOX_AP_REPORTS', 'Éditions');
define('BOX_AP_REQUEST_QUOTE', 'Demande de Devis');
define('BOX_AP_RECEIVE_INVENTORY', 'Acheter/Recevoir');
define('BOX_AP_ORDER_STATUS', 'Gestion des Commandes Fournisseurs');
//define('BOX_AP_WRITE_CHECK', 'Rédiger Chèques');

// Receivables Menu Labels
define('BOX_AR_SALES_ORDER', 'Commandes Clients');
define('BOX_AR_QUOTE', 'Devis');
define('BOX_AR_INVOICE', 'Ventes/Factures');
define('BOX_AR_CREDIT_MEMO', 'Avoirs Clients');
define('BOX_AR_SHIPMENTS', 'Livraisons');
define('BOX_AR_ORDER_STATUS', 'Gestion des Commandes Clients');
define('BOX_AR_DEFAULTS', 'Paramètres par défaut des Clients');
//define('BOX_AR_POINT_OF_SALE','Point de Vente');
define('BOX_AR_INVOICE_MGR', 'Gestion des Factures');

// Setup/Misc Menu Labels
define('BOX_TAX_AUTH', 'Autorités fiscales sur les ventes');
define('BOX_TAX_AUTH_VEND', 'Autorités fiscales sur les achats');
define('BOX_TAX_RATES', 'Taux de Taxe Ventes');
define('BOX_TAX_RATES_VEND', 'Taux de Taxe Achats');
define('BOX_TAXES_COUNTRIES', 'Pays');
define('BOX_TAXES_ZONES', 'Régions/Départements');
define('BOX_CURRENCIES', 'Devises');
define('BOX_LANGUAGES', 'Langues');

// Configuration and defaults menu
define('BOX_HEADING_SEARCH','Recherche');
define('BOX_HEADING_USERS','Utilisateurs');
define('BOX_HEADING_BACKUP','Sauvegarde Société');
define('BOX_COMPANY_CONFIG','Paramètres de Configuration');

// Tools Menu Labels
define('BOX_HEADING_ENCRYPTION', 'Cryptage des Données');
define('BOX_IMPORT_EXPORT', 'Import/Export');
define('BOX_SHIPPING_MANAGER', 'Gestion des Livraisons');
define('BOX_COMPANY_MANAGER', 'Gestion des Sociétés');
define('BOX_HEADING_ADMIN_TOOLS', 'Outils d&#39;administration');

// Services Menu Labels
define('BOX_SHIPPING', 'Services de livraison');
define('BOX_PAYMENTS', 'Services de paiement');
define('BOX_PRICE_SHEETS', 'Services tarifaires');
define('BOX_PRICE_SHEET_MANAGER', 'Gestion des Tarifs');

// Quality Menu Labels
define('BOX_QUALITY_HOME','Accueil Qualité');

// General Headings
define('GEN_HEADING_PLEASE_SELECT','Veuillez choisir...');

// User Manager
define('HEADING_TITLE_USERS','Utilisateurs');
define('HEADING_TITLE_USER_INFORMATION','Informations Utilisateur');
define('HEADING_TITLE_SEARCH_INFORMATION','Chercher dans les écritures de journal');

// Address/contact identifiers
define('GEN_PRIMARY_NAME', 'Nom/Société');
define('GEN_EMPLOYEE_NAME', 'Nom employé');
define('GEN_CONTACT', 'Contact');
define('GEN_ADDRESS1', 'Adresse1');
define('GEN_ADDRESS2', 'Adresse2');
define('GEN_CITY_TOWN', 'Ville/Cité');
define('GEN_STATE_PROVINCE', 'Région/Département');
define('GEN_POSTAL_CODE', 'Code postal');
define('GEN_COUNTRY', 'Pays');
define('GEN_COUNTRY_CODE', 'Code ISO');

define('GEN_FIRST_NAME','Prénom');
define('GEN_MIDDLE_NAME','Surnom');
define('GEN_LAST_NAME','Nom');
define('GEN_TELEPHONE1', 'Téléphone');
define('GEN_TELEPHONE2', 'Téléphone secondaire');
define('GEN_FAX','Fax');
define('GEN_TELEPHONE4', 'Téléphone portable');

define('GEN_USERNAME','Identifiant utilisateur');
define('GEN_DISPLAY_NAME','Nom d&#39;affichage');
define('GEN_ACCOUNT_ID', 'ID Compte');
define('GEN_CUSTOMER_ID', 'ID Client:');
define('GEN_STORE_ID', 'ID Boutique');
define('GEN_VENDOR_ID', 'ID Fournisseur:');
define('GEN_EMAIL','E-mail');
define('GEN_WEBSITE','Site Web');
define('GEN_ACCOUNT_LINK','Lien vers compte Employé');

// General defiditions
define('TEXT_ABSCISSA','Abscisse');
define('TEXT_ACCOUNT_TYPE', 'Type de compte');
define('TEXT_ACCOUNTING_PERIOD', 'Période Comptable');
define('TEXT_ACCOUNTS', 'Comptes');
define('TEXT_ACCT_DESCRIPTION', 'Description du compte');
define('TEXT_ACTIVE','Active');
define('TEXT_ACTION','Action');
define('TEXT_ADD','Ajout');
define('TEXT_ADJUSTMENT','Ajustement');
define('TEXT_ALL','Tout');
define('TEXT_ALIGN','Aligner');
define('TEXT_AMOUNT','Montant');
define('TEXT_AND','et');
define('TEXT_BACK','Retour');
define('TEXT_BALANCE','Solde');
define('TEXT_BOTTOM','Bas');
define('TEXT_BREAK','Break');
define('TEXT_CANCEL','Annuler');
define('TEXT_CARRIER','Transporteur');
define('TEXT_CATEGORY_NAME', 'Nom de la catégorie');
define('TEXT_CAUTION','Avertissement');
define('TEXT_CENTER','Centrer');
define('TEXT_CHANGE','Changer');
define('TEXT_CLEAR','Purger');
define('TEXT_CLOSE','Fermer');
define('TEXT_COLLAPSE','Replier');
define('TEXT_COLLAPSE_ALL','Tout replier');
define('TEXT_COLOR','Couleur');
define('TEXT_COLUMN','Colonne');
define('TEXT_CONTAINS','Contient');
define('TEXT_COPY','Copier');
define('TEXT_COPY_TO','Copier vers');
define('TEXT_CONFIRM_PASSWORD','Confirmer le mot de passe');
define('TEXT_CONTINUE','Continuer');
define('TEXT_CREDIT_AMOUNT','Montant du crédit');
define('TEXT_CRITERIA','Critères');
define('TEXT_CUSTCOLOR','Couleur habituelle (intervalle 0-255)');
define('TEXT_CURRENCY','Devise');
define('TEXT_CURRENT','Actuel');
define('TEXT_CUSTOM','Sur mesure');
define('TEXT_DATE','Date');
define('TEXT_DEBIT_AMOUNT','Montant Débit');
define('TEXT_DELETE','Supprimer');
define('TEXT_DEFAULT','Par défaut');
define('TEXT_DEPARTMENT','Service');
define('TEXT_DESCRIPTION','Description');
define('TEXT_DISCOUNT','Remise');
define('TEXT_DOWN','Bas');
define('TEXT_EDIT','Modification');
define('TEXT_ENTER_NEW', 'Saisir Nouveau ...');
define('TEXT_ERROR','Erreur');
define('TEXT_EQUAL','Égal à');
define('TEXT_ESTIMATE','Estimateur');
define('TEXT_EXPAND','Développer');
define('TEXT_EXPAND_ALL','Développer tout');
define('TEXT_EXPORT','Exporter');
define('TEXT_EXPORT_CSV','Exporter en CSV');
define('TEXT_EXPORT_PDF','Exporter en PDF');
define('TEXT_FALSE','Faux');
define('TEXT_FIELD', 'Champ');
define('TEXT_FIELDS','Champs');
define('TEXT_FILE_UPLOAD','Uploader un fichier');
define('TEXT_FILL','Remplir');
define('TEXT_FILTER','Filtrer');
define('TEXT_FINISH','Terminer');
define('TEXT_FORM','Formulaire');
define('TEXT_FORMS','Formulaires');
define('TEXT_FLDNAME','Nom du Champ');
define('TEXT_FONT','Police');
define('TEXT_FROM','De');
define('TEXT_FULL','Tous');
define('TEXT_GENERAL','Général'); // typical, standard
define('TEXT_GET_RATES','Obtenir les taux');
define('TEXT_GL_ACCOUNT','Compte GL');
define('TEXT_GREATER_THAN','Supérieur à');
define('TEXT_GROUP','Grouper');
define('TEXT_HEIGHT','hauteur');
define('TEXT_HELP', 'Aide');
define('TEXT_HISTORY','Historique');
define('TEXT_HORIZONTAL','Horizontal');
define('TEXT_IMPORT','Importer');
define('TEXT_INACTIVE','Inactif');
define('TEXT_INFO', 'Info'); // Information
define('TEXT_INSERT', 'Insérer');
define('TEXT_INSTALL', 'Installer');
define('TEXT_INVOICE', 'Facture');
define('TEXT_INVOICES', 'Factures');
define('TEXT_IN_LIST', 'Dans la liste (csv)');
define('TEXT_ITEMS', 'éléments');
define('TEXT_JOURNAL_TYPE', 'Type de Journal');
define('TEXT_LEFT','Gauche');
define('TEXT_LENGTH','longueur');
define('TEXT_LESS_THAN','Inférieur à');
define('TEXT_LEVEL','Niveau');
define('TEXT_MOVE','Déplacer');
define('TEXT_NA','N/A'); // not applicable
define('TEXT_NO','Non');
define('TEXT_NONE', '- Aucun -');
define('TEXT_NOTE', 'Note:');
define('TEXT_NOTES', 'Notes');
define('TEXT_NEW', 'Nouveau');
define('TEXT_NOT_EQUAL','Différent de');
define('TEXT_NUM_AVAILABLE', '# disponible');
define('TEXT_NUM_REQUIRED', '# requis');
define('TEXT_OF','de');
define('TEXT_OPEN','Ouvert');
define('TEXT_OPTIONS','Options');
define('TEXT_ORDER','Classement');
define('TEXT_ORDINATE','Calculer');
define('TEXT_PAGE','Page');
define('TEXT_PAID','Payé');
define('TEXT_PASSWORD','Mot de passe');
define('TEXT_PAY','Rémunération');
define('TEXT_PAYMENT','Paiement');
define('TEXT_PAYMENT_METHOD','Méthode de Paiement');
define('TEXT_PAYMENTS','Paiements');
define('TEXT_PERIOD','Période');
define('TEXT_PGCOYNM','Nom société');
define('TEXT_POST_DATE', 'Date d&#39;affichage');
define('TEXT_PRICE', 'Prix');
define('TEXT_PRICE_MANAGER', 'Feuilles tarifaires');
define('TEXT_PRINT','Imprimer');
define('TEXT_PRINTED','Imprimé');
define('TEXT_PROCESSING', 'En traitement');
define('TEXT_PROPERTIES','Propriétés');
define('TEXT_PO_NUMBER', 'Commande Fournisseur #');
define('TEXT_QUANTITY','Quantité');
define('TEXT_RANGE','Intervalle');
define('TEXT_READ_ONLY','Lecture seulement');
define('TEXT_RECEIVE','Recevoir');
define('TEXT_RECEIVE_ALL','Recevoir Commande Fournisseur');
define('TEXT_RECEIPTS','Recettes');
define('TEXT_RECUR','Rappel mémoire');
define('TEXT_REFERENCE','Référence');
define('TEXT_REMOVE','Enlever');
define('TEXT_RENAME','Renommer');
define('TEXT_REPLACE','Remplacer');
define('TEXT_REPORT','Édition');
define('TEXT_REPORTS','Éditions');
define('TEXT_RESET','Initialiser');
define('TEXT_RESULTS','Résultats');
define('TEXT_REVISE','Revoir');
define('TEXT_RIGHT','Droite');
define('TEXT_SAVE', 'Enregistrer');
define('TEXT_SAVE_AS', 'Enregistrer sous');
define('TEXT_SEARCH', 'Rechercher');
define('TEXT_SECURITY','Sécurité');
define('TEXT_SECURITY_SETTINGS','Paramètres de Sécurité');
define('TEXT_SELECT','Choisir');
define('TEXT_SEND','Envoyer');
define('TEXT_SEPARATOR','Séparateur');
define('TEXT_SERIAL_NUMBER','N° de série');
define('TEXT_SERVICE_NAME','Nom du service');
define('TEXT_SEQUENCE', 'Séquence');
define('TEXT_SHIP','Livrer');
define('TEXT_SHIP_ALL','Remplir Commande Client');
define('TEXT_SHOW','Afficher');
define('TEXT_SLCTFIELD','Choisissez un champ...');
define('TEXT_SEQ','Séquence');
define('TEXT_SIZE','Taille');
define('TEXT_SKU','SKU');
define('TEXT_SORT','Trier');
define('TEXT_SORT_ORDER','Classement');
define('TEXT_SOURCE', 'Source');
define('TEXT_STATUS','Statut');
define('TEXT_STATISTICS','Statistiques');
define('TEXT_STDCOLOR','Couleur Standard');
define('TEXT_SUCCESS','Succès');
define('TEXT_SYSTEM','Système');
define('TEXT_TIME','Time');
define('TEXT_TITLE','Intitulé');
define('TEXT_TO','À');
define('TEXT_TOP','Haut');
define('TEXT_TOTAL','Total');
define('TEXT_TRANSACTION_DATE','Date de Transaction');
define('TEXT_TRANSACTION_TYPE','Type de Transaction');
define('TEXT_TRIM','Rogner');
define('TEXT_TRUE','Vrai');
define('TEXT_TRUNCATE','Tronquer');
define('TEXT_TRUNC','Tronquer les longues descriptions');
define('TEXT_TYPE','Type');
define('TEXT_UNIT_PRICE','Prix Unitaire');
define('TEXT_UNPRINTED','Non imprimé');
define('TEXT_UP','Vers le haut');
define('TEXT_UPDATE','Mettre à jour');
define('TEXT_URL','URL');
define('TEXT_USERS','Utilisateurs');
define('TEXT_UTILITIES','Utilitaires');
define('TEXT_VALUE', 'Valeur');
define('TEXT_VERTICAL','Vertical');
define('TEXT_VIEW','Voir');
define('TEXT_VIEW_SHIP_LOG','Voir le journal des livraisons');
define('TEXT_WEIGHT','Poids');
define('TEXT_WIDTH','largeur');
define('TEXT_YES','Oui');

// javascript messages
define('JS_ERROR', 'Des erreurs se sont produites lors du traitement de votre formulaire !\nVeuillez apporter les corrections suivantes:\n\n');
define('JS_CTL_PANEL_DELETE_BOX','Voulez-vous vraiment supprimer cette boîte ?');
define('JS_CTL_PANEL_DELETE_IDX','Voulez-vous vraiment supprimer cet index ?');

// Audit log messages
define('GEN_LOG_LOGIN','Ouverture de session utilisateur -> ');
define('GEN_LOG_LOGIN_FAILED','Échec connexion utilisateur - id -> ');
define('GEN_LOG_LOGOFF','Fermeture de session utilisateur -> ');
define('GEN_LOG_RESEND_PW','Ré-envoyer le mot de passe par e-mail -> ');
define('GEN_LOG_USER_ADD','Maintenance Utilisateur - Nom d&#39;utilisateur créé -> ');
define('GEN_LOG_USER_COPY','Maintenance Utilisateur - Copier');
define('GEN_MSG_COPY_INTRO','Veuillez saisir le nouveau nom d&#39;utilisateur.');
define('GEN_ERROR_DUPLICATE_ID','Ce nom d&#39;utilisateur est déjà utilisé. Veuillez choisir un nom diférent.');
define('GEN_MSG_COPY_SUCCESS','L&#39;utilisateur a été copié. Veuillez définir le mot de passe et toutes les autres propriétés de ce nouvel utilisateur.');
define('GEN_LOG_USER_UPDATE','Maintenance Utilisateur - Nom d&#39;utilisateur mis à jour -> ');
define('GEN_LOG_USER_DELETE','Maintenance Utilisateur - Nom d&#39;utilisateur supprimé -> ');
define('GEN_DB_DATA_BACKUP','Sauvegarde de la base de données de la société');
define('GEN_LOG_PERIOD_CHANGE','Période Comptable - Changer');

// constants for use in prev_next_display function
define('TEXT_SHOW_NO_LIMIT', ' (0 pour illimité) ');
define('TEXT_RESULT_PAGE', 'Page %s sur %d');
define('TEXT_GO_FIRST','Aller à la première page');
define('TEXT_GO_PREVIOUS','Page précédente');
define('TEXT_GO_NEXT','Page suivante');
define('TEXT_GO_LAST','Aller à la dernière page');
define('TEXT_DISPLAY_NUMBER', 'Affiche <b>%d</b> à <b>%d</b> (sur <b>%d</b>) ');
define('PREVNEXT_BUTTON_PREV', '&lt;&lt;');
define('PREVNEXT_BUTTON_NEXT', '&gt;&gt;');
define('TEXT_FIELD_REQUIRED', '&nbsp;<span class="fieldRequired">*</span>');

// misc error messages
define('GEN_ERRMSG_NO_DATA','Un champ obligatoire a été laissé en blanc. Champ: ');
define('ERROR_MSG_ACCT_PERIOD_CHANGE','La période comptable a été automatiquement changée à: %s');
define('ERROR_MSG_BAD_POST_DATE','AVERTISSEMENT: La date d&#39;affichage tombe en dehors de la période comptable en cours !');
define('ERROR_MSG_POST_DATE_NOT_IN_FISCAL_YEAR','La date d&#39;affichage spécifiée n&#39;est pas dans l&#39;un des exercices fiscaux actuellement définis. Changez soit la date d&#39;affichage ou ajoutez l&#39;exercice fiscal nécessaire.');
define('ERROR_NO_PERMISSION','Vous n&#39;avez pas la permission d&#39;effectuer l&#39;opération demandée. Veuillez contacter l&#39;administrateur pour demander des autorisations d&#39;accès.');
define('ERROR_NO_SEARCH_PERMISSION','Vous n&#39;avez pas la permission de consulter ce résultat de recherche.');
define('ERROR_NO_DEFAULT_CURRENCY_DEFINED', 'ERREUR: Il n&#39;existe pas actuellement de devise par défaut. Veuillez en définir une à: Paramètrage -&gt; Devises');
define('ERROR_CANNOT_CREATE_DIR','Le répertoire de sauvegarde ne peut être créé dans /my_files. Veuillez vérifier les permissions.');
define('ERROR_COMPRESSION_FAILED','La compression de la sauvegarde a échoué: ');
define('TEXT_EMAIL','E-mail: ');
define('TEXT_SENDER_NAME','Nom de l&#39;expéditeur: ');
define('TEXT_RECEPIENT_NAME','Nom du destinataire: ');
define('TEXT_MESSAGE_SUBJECT','Objet du message: ');
define('TEXT_MESSAGE_BODY','Corps du message: ');
define('EMAIL_SEND_FAILED','Le courriel n&#39;a pas été envoyé.');
define('EMAIL_SEND_SUCCESS','Le courriel a été envoyé avec succès.');
define('GEN_PRICE_SHEET_CURRENCY_NOTE','NOTE: Toutes les valeurs sont dans: %s');
define('DEBUG_TRACE_MISSING','Impossible de trouver le fichier trace. Assurez-vous d&#39;avoir capturé une trace avant d&#39;essayer de downloader le fichier !');

// search filters
define('TEXT_ASC','ASC');
define('TEXT_DESC','DESC');
define('TEXT_INFO_SEARCH_DETAIL_FILTER','Filtre de recherche: ');
define('TEXT_INFO_SEARCH_PERIOD_FILTER','Période Comptable: ');
define('HEADING_TITLE_SEARCH_DETAIL','Rechercher: ');
define('TEXT_TRANSACTION_AMOUNT','Montant de la transaction');
define('TEXT_REFERENCE_NUMBER','N° de Facture/Commande');
define('TEXT_CUST_VEND_ACCT','Compte Client/Fournisseur');
define('TEXT_INVENTORY_ITEM','Article du Stock');
define('TEXT_GENERAL_LEDGER_ACCOUNT','Compte du Grand Livre');
define('TEXT_JOURNAL_RECORD_ID','ID de l&#39;enregistrement du journal');

// Version Check notices
define('TEXT_VERSION_CHECK_NEW_VER','Une nouvelle version de PhreeBooks&trade; est disponible. Version installée: <b>%s</b> - Version disponible: <b>%s</b>');

// control panel defines
define('CP_ADD_REMOVE_BOXES','Ajout/Suppression de boîtes de profil');
define('CP_CHANGE_PROFILE','Changer de profil...');

// Defines for login screen
define('HEADING_TITLE', 'Connexion à PhreeBooks&trade;');
define('TEXT_LOGIN_NAME', 'Identifiant: ');
define('TEXT_LOGIN_PASS', 'Mot de passe: ');
define('TEXT_LOGIN_ENCRYPT', 'Clé de cryptage (laisser vide si inutilisée): ');
define('TEXT_LOGIN_COMPANY','Choisir une société: ');
define('TEXT_LOGIN_LANGUAGE','Choisir la langue: ');
define('TEXT_LOGIN_THEME','Choisir un thème: ');
define('TEXT_LOGIN_BUTTON','Connexion');
define('ERROR_WRONG_LOGIN', 'Vous avez saisi un mauvais identifiant et/ou mot de passe.');
define('TEXT_PASSWORD_FORGOTTEN', 'Ré-envoyer le mot de passe');

// Defines for users.php
define('ENTRY_PASSWORD_NEW_ERROR_NOT_MATCHING', 'Le mot de passe et sa confirmation ne correspondent pas.');
define('ENTRY_PASSWORD_NEW_ERROR', 'Votre nouveau mot de passe doit contenir un minimum de ' . ENTRY_PASSWORD_MIN_LENGTH . ' caractères.');
define('TEXT_DELETE_INTRO_USERS', 'Êtes-vous sûr(e) de vouloir supprimer ce compte utilisateur ?');
define('TEXT_DELETE_ENTRY', 'Êtes-vous sûr(e) de vouloir supprimer cette entrée ?');
define('TEXT_FILL_ALL_LEVELS','Positionner tout au niveau');

// defines for password forgotten
define('LOST_HEADING_TITLE', 'Ré-envoyer mot de passe');
define('TEXT_ADMIN_EMAIL', 'Adresse e-mail: ');
define('ERROR_WRONG_EMAIL', '<p>Vous avez entré une adresse e-mail erronée.</p>');
define('ERROR_WRONG_EMAIL_NULL', '<p>Bien essayé, mec :-P</p>');
define('SUCCESS_PASSWORD_SENT', '<p>Succès: Un nouveau mot de passe a été envoyé à votre adresse e-mail.</p>');
define('TEXT_EMAIL_SUBJECT', 'Votre demande de réinitialisation de mot de passe');
define('TEXT_EMAIL_FROM', EMAIL_FROM);
define('TEXT_EMAIL_MESSAGE', 'Un nouveau mot de passe a été demandé par votre adresse e-mail.' . "\n\n" . 'Votre nouveau mot de passe pour &#39;' . COMPANY_NAME . '&#39; est:' . "\n\n" . '   %s' . "\n\n");

// Error messages for importing reports, forms and import/export functions
define('TEXT_IMP_ERMSG1','La taille du fichier dépasse la directive upload_max_filesize dans les paramètres de votre fichier php.ini.');
define('TEXT_IMP_ERMSG2','La taille du fichier dépasse la directive MAX_FLE_SIZE dans le formulaire PhreeBooks&trade;.');
define('TEXT_IMP_ERMSG3','Le fichier n&#39;a pas été complètement uploadé. Veuillez réessayer.');
define('TEXT_IMP_ERMSG4','Aucun fichier n&#39;a été sélectionné pour uploader.');
define('TEXT_IMP_ERMSG5','Erreur php inconnue d&#39;upload, php a renvoyé l&#39;erreur # ');
define('TEXT_IMP_ERMSG6','Ce fichier n&#39;est pas signalé par le serveur comme un fichier texte.');
define('TEXT_IMP_ERMSG7','Le fichier uploadé ne contient aucune donnée !');
define('TEXT_IMP_ERMSG8','PhreeBooks n&#39;a pas pu trouver un rapport valable à importer dans le fichier uploadé!');
define('TEXT_IMP_ERMSG9',' a été importé avec succès !');
define('TEXT_IMP_ERMSG10','Il y a eu une erreur inattendue en uploadant le fichier !');
define('TEXT_IMP_ERMSG11','Le fichier a été importé avec succès !');
define('TEXT_IMP_ERMSG12','Le fichier exporté ne contenait aucune donnée !');
define('TEXT_IMP_ERMSG13','Il y a eu une erreur inattendue en uploadant le fichier ! Aucun fichier n&#39;a été uploadé.');
define('TEXT_IMP_ERMSG14','Erreur dans le fichier d&#39;entrée. Plus de 2 qualificatifs texte ont été trouvés ! La chaîne de texte fautive était: ');
define('TEXT_IMP_ERMSG15','Le fichier d&#39;importation a besoin d&#39;une valeur de référence d&#39;index pour traiter les données ! Incluez des données et vérifiez la boîte &#39;Voir&#39; pour le nom du champ: ');

/********************* Release R1.7 additions *************************/
define('BOX_INV_TOOLS','Outils du Stock');

/********************* Release R1.8 additions *************************/
// Configuration Groups - Moved menu from DB to here since it's loaded every time, allows translation
// code CD_xx_TITLE : CG - config group, xx - index, must match with menu_navigation.php
define('CG_01_TITLE','Ma Société');
define('CG_01_DESC', 'Informations générales sur la société');
define('CG_02_TITLE','Paramètres par défaut des Clients');
define('CG_02_DESC', 'Paramètres par défaut pour les comptes clients');
define('CG_03_TITLE','Paramètres par défaut des Fournisseurs');
define('CG_03_DESC', 'Paramètres par défaut pour les comptes fournisseurs');
define('CG_04_TITLE','Paramètres par défaut des Employés');
define('CG_04_DESC', 'Paramètres par défaut pour les employés');
define('CG_05_TITLE','Paramètres par défaut du Stock');
define('CG_05_DESC', 'Paramètres par défaut pour les comptes du stock');
define('CG_07_TITLE','Paramètres par défaut des Utilisateurs');
define('CG_07_DESC', 'Paramètres par défaut pour les comptes utilisateurs');
define('CG_08_TITLE','Paramètres généraux');
define('CG_08_DESC', 'Paramètres généraux de l&#39;application');
define('CG_09_TITLE','Paramètres d&#39;Import/Export');
define('CG_09_DESC', 'Paramètres par défaut pour l&#39;Import/Export');
define('CG_10_TITLE','Paramètres de Livraison');
define('CG_10_DESC', 'Paramètres par défaut pour la livraison/le transport');
define('CG_11_TITLE','Paramètres par défaut du carnet d&#39;adresses');
define('CG_11_DESC', 'Paramètres par défaut pour le carnet d&#39;adresses');
define('CG_12_TITLE','Options e-mail');
define('CG_12_DESC', 'Paramètres généraux pour le transport e-mail et les courriels HTML');
define('CG_13_TITLE','Paramètres par défaut du Grand Livre');
define('CG_13_DESC', 'Paramètres par défaut pour les comptes du Grand Livre');
define('CG_15_TITLE','Sessions');
define('CG_15_DESC', 'Options de session');
define('CG_17_TITLE','Cartes de crédit');
define('CG_17_DESC', 'Cartes de crédit acceptées');
define('CG_19_TITLE','Paramètres de mise en page');
define('CG_19_DESC', 'Options de mise en page');
define('CG_20_TITLE','Maintenance du site Web');
define('CG_20_DESC', 'Options de maintenance du site web');

/********************* Release R1.9 additions *************************/
define('TEXT_EMPLOYEE','Employé');
define('TEXT_SALES_REP','Représentant');
define('TEXT_BUYER','Acheteur');

?>