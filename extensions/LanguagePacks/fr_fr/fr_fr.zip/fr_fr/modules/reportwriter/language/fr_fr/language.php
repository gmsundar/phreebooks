<?php 
// +-----------------------------------------------------------------+
// |                   PhreeBooks Open Source ERP                    |
// +-----------------------------------------------------------------+
// | Copyright (c) 2008, 2009, 2010 PhreeSoft, LLC                   |
// | http://www.PhreeSoft.com                                        |
// +-----------------------------------------------------------------+
// | This program is free software: you can redistribute it and/or   |
// | modify it under the terms of the GNU General Public License as  |
// | published by the Free Software Foundation, either version 3 of  |
// | the License, or any later version.                              |
// |                                                                 |
// | This program is distributed in the hope that it will be useful, |
// | but WITHOUT ANY WARRANTY; without even the implied warranty of  |
// | MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the   |
// | GNU General Public License for more details.                    |
// |                                                                 |
// | The license that is bundled with this package is located in the |
// | file: /doc/manual/ch01-Introduction/license.html.               |
// | If not, see http://www.gnu.org/licenses/                        |
// +-----------------------------------------------------------------+
//  Path: /modules/reportwriter/language/fr_fr/language.php
// 

define('RW_FONT_HELVETICA','helvetica');
define('RW_FONT_COURIER','Courier');
define('RW_FONT_TIMES','Times Roman');
define('RW_FONT_SERIF','Serif');

if (!defined('PDF_APP')) define('PDF_APP','TCPDF'); // possible choices are FPDF and TCPDF 
$Fonts = array (
  'helvetica' => RW_FONT_HELVETICA,
  'courier'   => RW_FONT_COURIER,
  'times'     => RW_FONT_TIMES,
);
if (PDF_APP == 'TCPDF') {
  $Fonts['freeserif'] = RW_FONT_SERIF;
  define('PDF_DEFAULT_FONT','freeserif');
} else {
  define('PDF_DEFAULT_FONT','helvetica');
}

// Reportwriter Defaults
define('RW_DEFAULT_COLUMN_WIDTH','25'); // in millimeters
define('RW_DEFAULT_MARGIN','8'); // in millimeters
define('RW_DEFAULT_TITLE1', '%reportname%');
define('RW_DEFAULT_TITLE2', 'Édition générée le %date%');
define('RW_DEFAULT_PAPERSIZE', 'Letter:216:282'); // must match id from array $PaperSizes defined below
define('RW_DEFAULT_ORIENTATION', 'P');

// **************  Release 2.0 changes  ********************
define('RW_FRM_RNDDECIMAL','Arrondir les décimales');
define('RW_FRM_RNDPRECISE','Arrondir la précision');
define('RW_SERIAL_FORM','Faire de ceci un formulaire séquentiel (principalement utilisé pour les imprimantes de reçus et les imprimantes en ligne). Les propriétés de la page seront limitées car la sortie est basée sur la séquence de la liste des champs. En cas de doute, laissez cette case non-cochée.');

// **************  Release 1.9 changes  ********************
define('RW_FRM_SET_PRINTED','Positionner l&#39;indicateur &#39;imprimé&#39;');
define('RW_FRM_SET_PRINTED_NOTE','Positionner à 1 le champ sélectionné après que chaque formulaire ait été généré. Le champ doit être dans la même table que le champ saut de page du formulaire.');
define('TEXT_CC_NAME','CC:');
define('RW_TEXT_DISPLAY_ON','Afficher sur:');
define('RW_TEXT_ALL_PAGES','Toutes les pages');
define('RW_TEXT_FIRST_PAGE','Première page');
define('RW_TEXT_LAST_PAGE','Dernière page');
define('RW_TEXT_TOTAL_ONLY','Afficher uniquement les totaux');
define('TEXT_DUPLICATE','Dupliquer');
define('RW_FRM_PRINTED','Indicateur d&#39;impression');

// **************  Release 1.8 changes  ********************
define('RW_FRM_PAGE_BREAK','Champ saut de page du formulaire (table.fieldname)');
define('RW_RPT_PAGE_BREAK','Saut de page par groupe');
define('RW_NULL_PCUR','Null 0 - Devise postée');
define('RW_DEF_CUR','Devise par défaut');
define('RW_NULL_DCUR','Null 0 - Devise par défaut');
define('RW_EMAIL_MSG_DETAIL','Texte du corps du message e-mail');

// **************  Release 1.7 changes  ********************
define('RW_BAR_CODE','Image de code barre');
define('RW_TEXT_GROUP_TOTAL_FOR','Total groupé pour: ');
define('RW_TEXT_REPORT_TOTAL_FOR','Total reporté pour: ');
define('RW_FRM_YES_SKIP_NO','Oui, mettre à blanc No');
define('RW_TEXT_PURCHASES','Achats');

// Headings
define('RW_HEADING_TITLE','Éditions et Formulaires');

// Report and Form page title definitions
define('RW_TITLE_RPTFRM','Édition/Formulaire: ');
define('RW_TITLE_RPRBLDR','Constructeur d&#39;Éditions et de Formulaires - ');
define('RW_TITLE_REPORT_GEN','Générateur d&#39;Éditions');
define('RW_TITLE_STEP1','Menu');
define('RW_TITLE_STEP2','Étape 2');
define('RW_TITLE_STEP3','Étape 3');
define('RW_TITLE_STEP4','Étape 4');
define('RW_TITLE_STEP5','Étape 5');
define('RW_TITLE_STEP6','Étape 6');
define('RW_TITLE_MENU','Menu des éditions');
define('RW_TITLE_CRITERIA','Paramètrage des critères');
define('RW_TITLE_PAGESAVE','Enregistrer l&#39;édition');
define('RW_TITLE_PAGESETUP','Paramètres de mise en page');
define('RW_TITLE_SECURITY','Paramètres de sécurité');

// Javascript messages
define('RW_JS_SELECT_REPORT','Veuillez sélectionner une édition ou un formulaire !');
define('RW_JS_ENTER_EXPORT_NAME','Entrez un nom pour cette définition:');
define('RW_JS_ENTER_DESCRIPTION','Entrez une description pour cette définition:');

// General 
define('TEXT_AUTO_ALIGN','Alignement automatique');
define('TEXT_CONTINUED','À suivre');
define('TEXT_PAGE_SETUP','Mise en page');
define('TEXT_DB_LINKS','Relations en base de données');
define('TEXT_FIELD_SETUP','Paramètrage des champs');
define('TEXT_CRITERIA','Critères de filtre');
define('GL_CURRENT_PERIOD','Période actuelle');
define('TEXT_USE_ACCOUNTING_PERIODS','Utiliser les périodes comptables (champ: period)');
define('TEXT_ALL_USERS','Autoriser tous les utilisateurs');
define('TEXT_ALL_EMPLOYEES','Autoriser tous les employés');
define('TEXT_ALL_DEPTS','Autoriser tous les services');
define('TEXT_FORM_FIELD','Champ de formulaire: ');
define('RW_NARRATIVE_DETAIL','Description détaillée (255 caractères maximum)');
define('RW_FORM_DELIVERY_METHOD','Méthode de livraison du formulaire');
define('RW_RPT_DELIVERY_METHOD','Méthode d&#39;envoi de l&#39;édition');
define('RW_BROWSER','Navigateur: ');
define('RW_DOWNLOAD','Download: ');
define('RW_DL_FILENAME_SOURCE','Nom du fichier source');
define('RW_TEXT_PREFIX','Préfixe: ');
define('RW_TEXT_SOURCE_FIELD',' Champ source: ');
define('RW_TEXT_MIN_VALUE','Valeur min');
define('RW_TEXT_MAX_VALUE','Valeur max');
define('RW_JOURNAL_DESCRIPTION','Description de journal');

// Paper Size Definitions
define('TEXT_PAPER','Taille du papier');
define('TEXT_PAPER_WIDTH','Largeur du papier');
define('TEXT_ORIEN','Orientation');
define('TEXT_MM','mm');
define('TEXT_PORTRAIT','portrait');
define('TEXT_LANDSCAPE','paysage');
define('TEXT_USEFUL_INFO','Informations utiles');
define('TEXT_LEGAL','Legal');
define('TEXT_LETTER','Letter');

// Definitions for date selection dropdown list
define('TEXT_TODAY','Aujourd&#39;hui');
define('TEXT_WEEK','Cette semaine');
define('TEXT_WTD','Semaine à ce jour');
define('TEXT_MONTH','Ce mois');
define('TEXT_MTD','Mois à ce jour');
define('TEXT_QUARTER','Ce trimestre');
define('TEXT_QTD','Trimestre à ce jour');
define('TEXT_YEAR','Cette année');
define('TEXT_YTD','Année à ce jour');

// definitions for db tables
define('TEXT_TABLE1','Table 1');
define('TEXT_TABLE2','Table 2');
define('TEXT_TABLE3','Table 3');
define('TEXT_TABLE4','Table 4');
define('TEXT_TABLE5','Table 5');
define('TEXT_TABLE6','Table 6');

// Message definitions
define('RW_RPT_SAVEDEF','Le nom que vous avez entré est l&#39;édition par défaut. Veuillez entrer un nouveau nom d&#39;édition.');
define('RW_RPT_SAVEDUP','Ce nom d&#39;édition existe déjà ! Appuyez sur Remplacer pour écraser ou entrez un nouveau nom et appuyez sur continuer.');
define('RW_RPT_DUPDB','Il y a une erreur dans votre sélection de base de données. Vérifiez vos noms de base de données et les équations de liens.');
define('RW_RPT_BADFLD','Il y a une erreur dans votre champ ou description de base de données. Veuillez vérifier et réessayer.');
define('RW_RPT_BADDATA','Il y a une erreur dans un de vos champs de données. Veuillez vérifier et réessayer.');
define('RW_RPT_FUNC_NOT_FOUND','Une fonction spéciale a été demandée mais n&#39;a pu être trouvée. La fonction spéciale demandée était: ');
define('RW_RPT_EMPTYFIELD','Un champ de données a été laissé vide. Il est situé au numéro de séquence: ');
define('RW_RPT_EMPTYTABLE','Une entrée de données originale de table n&#39;a pas été trouvée pour créer un double au numéro de séquence: ');
define('RW_RPT_NO_SPECIAL_REPORT','Aucun nom de fonction spéciale d&#39;édition n&#39;a été entré.  Soit décochez la case à cocher, soit entrez un nom de fonction !');
define('RW_RPT_NO_TABLE_DATA','Vos états de table ont retourné aucune ligne. Soit les tables sont vides, soit il y a une erreur dans les états de lien !');
define('RW_RPT_DEFDEL','Si vous remplacez cette édition/ce formulaire, l&#39;édition/le formulaire original sera supprimé !');
define('RW_RPT_NODATA','Il y avait aucune donnée dans cette édition sur la base des critères fournis !');
define('RW_RPT_NOROWS','Cette édition/ce formulaire avec les critères de filtrage sélectionnés ne contient aucune donnée !');
define('RW_RPT_WASSAVED',' a été enregistré et copié dans l&#39;édition: ');
define('RW_RPT_UPDATED','Le nom de l&#39;édition a été mis à jour !');
define('RW_FRM_NORPT','Aucun nom de formulaire n&#39;a été choisi pour effectuer cette opération.');
define('RW_RPT_NORPT','Aucune édition ou formulaire n&#39;a été choisi pour effectuer cette opération.');
define('RW_RPT_NORPTTYPE','Un type d&#39;édition ou de formulaire doit être choisi !');
define('RW_RPT_REPDUP','Le nom que vous avez entré est déjà en cours d&#39;utilisation. Veuillez entrer un nouveau nom d&#39;édition !');
define('RW_RPT_REPDEL','Appuyez sur OK pour supprimer cette édition.');
define('RW_RPT_REPOVER','Appuyez sur OK pour remplacer cette édition.');
define('RW_RPT_NOSHOW','Il n&#39;y a aucune édition à montrer !');
define('RW_RPT_NOFIELD','Il n&#39;y a aucun champ à montrer!');
define('RW_FRM_RPTENTER','Entrez un nom pour ce formulaire:');
define('RW_RPT_RPTENTER','Entrez un nom pour cette édition:');
define('RW_RPT_RPTNOENTER','(Laissez vide pour utiliser le nom d&#39;édition par défaut à partir du fichier d&#39;importation)');
define('RW_RPT_MAX30','(maximum 30 caractères)');
define('RW_FRM_RPTGRP','Entrez le groupe dont ce formulaire fait partie:');
define('RW_RPT_RPTGRP','Entrez le groupe dont cette édition fait partie:');
define('RW_RPT_DEFIMP','Choisissez une édition par défaut à importer.');
define('RW_RPT_RPTBROWSE','ou recherchez une édition à uploader.');
define('RW_RPT_SPECIAL_REPORT','Édition spéciale (programmeurs uniquement)');
define('RW_RPT_CANNOT_EDIT','Il s&#39;agit d&#39;une édition standart, les changements ne peuvent pas être enregistrés dans le visualiseur d&#39;édition ! L&#39;édition doit d&#39;abord être copié sur un My Report avant que les changements puissent être sauvegardés de façon permanente ou puissent être édités dans Report Builder.');
define('RW_FRM_NO_SELECTION','Veuillez choisir une édition ou un formulaire !');
define('RW_RPT_EXPORT_SUCCESS','L&#39;édition/le formulaire a été exporté avec succès.');
define('RW_RPT_EXPORT_FAILED','L&#39;édition/le formulaire n&#39;a pas été exporté !');
define('RW_EMAIL_BODY',"Ci-joint votre %s de %s \n\nPour visualiser la pièce jointe, vous devez avoir un logiciel de lecture des pdf installé sur votre ordinateur.");

// Report  Specific
define('RW_RPT_RPTFILTER','Filtres d&#39;édition: ');
define('RW_RPT_GROUPBY','Groupés par:');
define('RW_RPT_SORTBY','Classés par:');
define('RW_RPT_DATERANGE','Intervalle de date:');
define('RW_RPT_CRITBY','Filtres:');
define('RW_RPT_ADMIN','Page Administrateur');
define('RW_RPT_BRDRLINE','Ligne de bordure');
define('RW_RPT_BOXDIM','Ligne unique Dimensions extérieures (mm)');
define('RW_RPT_CRITTYPE','Type de critères');
define('RW_RPT_TYPECREATE','Choisissez le type d&#39;édition ou de formulaire à créer:');
define('RW_RPT_CUSTRPT','Éditions personnalisés');
define('RW_RPT_DATEDEF','Date par défaut choisie');
define('RW_RPT_DATEFNAME','Date du nom de champ (table.fieldname)');
define('RW_RPT_DATEINFO','Informations de date de l&#39;édition');
define('RW_RPT_DATEINST','Décochez toutes les boîtes pour une édition indépendante de la date; laissez la date du nom de champ à vide');
define('RW_RPT_DATELIST','Liste des champs Date<br />(cochez tout ce qui s&#39;applique)');
define('RW_RPT_DEFRPT','Éditions standarts');
define('RW_RPT_ENDPOS','Position de la fin (mm)');
define('RW_RPT_ENTRFLD','Entrez un nouveau champ');
define('RW_RPT_FLDLIST','Liste des champs');
define('RW_RPT_FORMOUTPUT','Choisissez un formulaire à afficher');
define('RW_RPT_FORMSELECT','Sélection formulaire');
define('RW_RPT_GRPLIST','Liste de groupement');
define('RW_RPT_IMAGECUR','Image actuelle');
define('RW_RPT_IMAGEUPLOAD','Uploader une nouvelle image');
define('RW_RPT_IMAGESEL','Sélection image');
define('RW_RPT_IMAGESTORED','Sélectionnez image stockée');
define('RW_RPT_IMAGEDIM','Dimensions image (mm)');
define('RW_RPT_LINEATTRIB','Attributs de la ligne');
define('RW_RPT_LINEWIDTH','Largeur de la ligne (pts) ');
define('RW_RPT_LINKEQ','Équation de liens (voir note ci-dessous)');
define('RW_RPT_DB_LINK_HELP','Les équations de liens doivent être en syntaxe SQL. Les tables peuvent être identifiées soit par leur nom de table dans la BDD (telles qu&#39;elles apparaissent dans la liste déroulante), soit ,d&#39;une meilleure façon, par un alias [tablex] (x = 1 à 6) entre crochets []. tablex est une référence à la table sélectionnée par la liste déroulante &#39;Table x&#39;. Par exemple, [table1].id = [table2].ref_id relierait le champ id de la table sélectionnée par la liste déroulante &#39;Table 1&#39; au champ ref_id de la table sélectionnée par la liste déroulante &#39;Table 2&#39;. L&#39;utilisation des alias permettra la portabilité des éditions/formulaires à supporter les préfixes de table de base de données, au cas où ils seraient utilisés. Après la saisie de chaque ligne, ReportWriter vérifiera que l&#39;équation constitue une instruction SQL valide.');
define('RW_RPT_FIELD_HELP','Note: Si plusieurs champs sont affichés dans la même colonne, le champ avec la plus grande largeur déterminera la largeur de la colonne.');
define('RW_RPT_MYRPT','Mes éditions');
define('RW_RPT_NOBRDR','Pas de bordure');
define('RW_RPT_NOFILL','Pas de remplissage');
define('RW_RPT_DISPNAME','Nom à afficher');
define('RW_RPT_PGFILDESC','Description du filtre de l&#39;édition');
define('RW_RPT_PGHEADER','En-tête - Informations / Mise en forme');
define('RW_RPT_PGLAYOUT','Mise en page');
define('RW_RPT_PGMARGIN_L','Marge de gauche');
define('RW_RPT_PGMARGIN_R','Marge de droite');
define('RW_RPT_PGMARGIN','Marges de page');
define('RW_RPT_RNRPT','Renommer édition');
define('RW_RPT_PGTITL1','Intitulé 1 de l&#39;édition');
define('RW_RPT_PGTITL2','Intitulé 2 de l&#39;édition');
define('RW_RPT_RPTDATA','Données de l&#39;en-tête d&#39;édition');
define('RW_RPT_RPTID','Identification Édition/Formulaire');
define('RW_RPT_RPTIMPORT','Importer édition');
define('RW_RPT_SORTLIST','Informations de classement');
define('RW_RPT_STARTPOS','Position de départ (coin supérieur gauche en mm)');
define('RW_RPT_TBLNAME','Nom de table');
define('RW_RPT_TEXTATTRIB','Attributs de texte');
define('RW_RPT_TEXTDISP','Texte à afficher');
define('RW_RPT_TEXTPROC','Traitement du texte');
define('RW_RPT_TBLFNAME','Nom du champ');
define('RW_RPT_TOTALS','Totaux de l&#39;édition');
define('RW_RPT_FLDTOTAL','Saisir les champs à totaliser (Table.Fieldname)');
define('RW_RPT_TABLE_HEADING_PROP','Propriétés en-tête de table');
define('RW_RPT_TABLE_BODY_PROP','Propriétés corps de table');

// Form Group Definitions
define('RW_FRM_BANKCHK','Chèques bancaires');
define('RW_FRM_BANKDEPSLIP','Bordereau de dépôt en banque');
define('RW_FRM_COLLECTLTR','Collection Letters');
define('RW_FRM_CUSTLBL','Labels - Client');
define('RW_FRM_CUSTQUOTE','Devis Client');
define('RW_FRM_VENDQUOTE','Devis Fournisseur');
define('RW_FRM_CUSTSTATE','Relevés des consommateurs');
define('RW_FRM_INVPKGSLIP','Factures et bordereaux d&#39;emballage');
define('RW_FRM_CRDMEMO','Avoirs - Client');
define('RW_FRM_PURCHORD','Commandes fournisseurs');
define('RW_FRM_SALESORD','Commandes clients');
define('RW_FRM_SALESREC','Recettes des ventes');
define('RW_FRM_VENDLBL','Labels - Fournisseur');
define('RW_FRM_VENDOR_CRDMEMO','Avoirs - Fournisseur');

// Form Processing Definitions
define('RW_FRM_CNVTDLR','Convertir des Dollars');
define('RW_FRM_CNVTEURO','Convertir des Euros');
define('RW_FRM_COMMA','Virgule - ,');
define('RW_FRM_COMMASP','Virgule-Espace');
define('RW_FRM_COYBLOCK','Bloc de données société');
define('RW_FRM_COYDATA','Ligne de données société');
define('RW_FRM_DATABLOCK','Bloc de données');
define('RW_FRM_DATALINE','Ligne de données');
define('RW_FRM_DATATABLE','Table de données');
define('RW_FRM_DATATABLEDUP','Copie de table de données');
define('RW_FRM_DATATOTAL','Données du total');
define('RW_FRM_DATE','Date formatée');
define('RW_FRM_DATE_TIME', 'Date/Heure');
define('RW_FRM_FIXEDTXT','Champ de texte fixe');
define('RW_FRM_IMAGE','Image - JPG ou PNG');
define('RW_FRM_LINE','Ligne');
define('RW_FRM_LOWERCASE','En minuscules');
define('RW_FRM_NEGATE','Inverser');
define('RW_FRM_NEWLINE','Saut de ligne');
define('RW_FRM_NOIMAGE','Pas d&#39;image');
define('RW_FRM_NULLDLR','Nul si 0 - Dollars');
define('RW_FRM_NUM_2_WORDS','Nombre de mots');
define('RW_FRM_PAGENUM','Numéro de page');
define('RW_POSTED_CURR','Devise postée');
define('RW_FRM_QUOTE_SINGLE', 'Simple apostrophe - &#39;');
define('RW_FRM_QUOTE_DOUBLE', 'Double apostrophe - "');
define('RW_FRM_RECTANGLE','Rectangle');
define('RW_FRM_RNDR2','Arrondir (2 décimales)');
define('RW_FRM_SEMISP','Point-virgule-espace');
define('RW_FRM_DELNL','Passer saut de ligne blanche');
define('RW_FRM_SHIP_METHOD','Méthode d&#39;envoi');
define('RW_FRM_SPACE1','Simple espace');
define('RW_FRM_SPACE2','Double espace');
define('RW_FRM_TAB', 'Tabulation - \t');
define('RW_FRM_TERMS_TO_LANG','Conditions de langue');
define('RW_FRM_UPPERCASE','En majuscules');
define('RW_FRM_ORDR_QTY','Quantité commandée');
define('RW_BRANCH_ID','ID Contact');
define('RW_REP_ID','Nom d&#39;utilisateur');

// Color definitions
define('TEXT_RED','Rouge');
define('TEXT_GREEN','Vert');
define('TEXT_BLUE','Bleu');
define('TEXT_BLACK','Noir');
define('TEXT_ORANGE','Orange');
define('TEXT_YELLOW','Jaune');
define('TEXT_WHITE','Blanc');

// numbers
define('TEXT_ZERO','zéro');
define('TEXT_ONE','un');
define('TEXT_TWO','deux');
define('TEXT_THREE','trois');
define('TEXT_FOUR','quatre');
define('TEXT_FIVE','cinq');
define('TEXT_SIX','six');
define('TEXT_SEVEN','sept');
define('TEXT_EIGHT','huit');
define('TEXT_NINE','neuf');
define('TEXT_TEN','dix');
define('TEXT_ELEVEN','onze');
define('TEXT_TWELVE','douze');
define('TEXT_THIRTEEN','treize');
define('TEXT_FOURTEEN','quatorze');
define('TEXT_FIFTEEN','quinze');
define('TEXT_SIXTEEN','seize');
define('TEXT_SEVENTEEN','dix-sept');
define('TEXT_EIGHTEEN','dix-huit');
define('TEXT_NINETEEN','dix-neuf');
define('TEXT_TWENTY','vingt');
define('TEXT_THIRTY','trente');
define('TEXT_FORTY','quarante');
define('TEXT_FIFTY','cinquante');
define('TEXT_SIXTY','soixante');
define('TEXT_SEVENTY','soixante-dix');
define('TEXT_EIGHTY','quatre-vingt');
define('TEXT_NINETY','quatre-vingt-dix');
define('TEXT_HUNDERD','cent');
define('TEXT_THOUSAND','mille');
define('TEXT_MILLION','million');
define('TEXT_BILLION','milliard');
define('TEXT_TRILLION','trillion');
define('TEXT_DOLLARS','Euros');

// journal names
define('TEXT_JOURNAL_ID_02','Journal Général');
define('TEXT_JOURNAL_ID_03','Devis Fournisseur');
define('TEXT_JOURNAL_ID_04','Commande Fournisseur');
define('TEXT_JOURNAL_ID_06','Achats');
define('TEXT_JOURNAL_ID_07','Fournisseur CM');
define('TEXT_JOURNAL_ID_08','Paye');
define('TEXT_JOURNAL_ID_09','Devis Client');
define('TEXT_JOURNAL_ID_10','Commande Client');
define('TEXT_JOURNAL_ID_12','Ventes/Facture');
define('TEXT_JOURNAL_ID_13','Client CM');
define('TEXT_JOURNAL_ID_14','Assemblage de Stock');
define('TEXT_JOURNAL_ID_16','Ajustement de Stock');
define('TEXT_JOURNAL_ID_18','Recettes espèces');
define('TEXT_JOURNAL_ID_19','Journal point de vente');
define('TEXT_JOURNAL_ID_20','Distribution espèces');
define('TEXT_JOURNAL_ID_21','Journal point d&#39;achat');

// Paper sizes supported in fpdf class, includes dimensions width, length in mm for page setup
$PaperSizes = array (
	'A3:297:420'     => 'A3',
	'A4:210:297'     => 'A4',
	'A5:148:210'     => 'A5',
	'Legal:216:357'  => TEXT_LEGAL,
	'Letter:216:282' => TEXT_LETTER,
);

// Available font sizes in units: points
$FontSizes = array (
	'8'  => '8', 
	'9'  => '9', 
	'10' => '10', 
	'11' => '11', 
	'12' => '12', 
	'14' => '14', 
	'16' => '16', 
	'18' => '18', 
	'20' => '20', 
	'24' => '24', 
	'28' => '28', 
	'32' => '32', 
	'36' => '36', 
	'40' => '40', 
	'50' => '50',
);

// Available font sizes in units: points
$LineSizes = array (
	'1' => '1', 
	'2' => '2', 
	'3' => '3', 
	'4' => '4', 
	'5' => '5', 
	'6' => '6', 
	'7' => '7', 
	'8' => '8', 
	'9' => '9', 
	'10'=>'10',
);

// Font colors keyed by color Red:Green:Blue
$FontColors = array (
	'0:0:0'       => TEXT_BLACK, // Leave black first as it is typically the default value
	'255:0:0'     => TEXT_RED,
	'255:128:0'   => TEXT_ORANGE,
	'255:255:0'   => TEXT_YELLOW,
	'0:255:0'     => TEXT_GREEN,
	'0:0:255'     => TEXT_BLUE,
	'255:255:255' => TEXT_WHITE,
);

// journal definitions
$rw_xtra_jrnl_defs = array(
  '2'  => TEXT_JOURNAL_ID_02,
  '3'  => TEXT_JOURNAL_ID_03,
  '4'  => TEXT_JOURNAL_ID_04,
  '6'  => TEXT_JOURNAL_ID_06,
  '7'  => TEXT_JOURNAL_ID_07,
  '8'  => TEXT_JOURNAL_ID_08,
  '9'  => TEXT_JOURNAL_ID_09,
  '10' => TEXT_JOURNAL_ID_10,
  '12' => TEXT_JOURNAL_ID_12,
  '13' => TEXT_JOURNAL_ID_13,
  '14' => TEXT_JOURNAL_ID_14,
  '16' => TEXT_JOURNAL_ID_16,
  '18' => TEXT_JOURNAL_ID_18,
  '19' => TEXT_JOURNAL_ID_19,
  '20' => TEXT_JOURNAL_ID_20,
  '21' => TEXT_JOURNAL_ID_21,
);

// The below functions are used to convert a number to language for USD (primarily for checks)
function value_to_words_en_us($number) {
	$number   = round($number, 2);
	$po裩tion = array('', ' '.TEXT_THOUSAND, ' '.TEXT_MILLION, ' '.TEXT_BILLION, ' '.TEXT_TRILLION);
	$dollars  = intval($number);
	$cents    = round(($number - $dollars) * 100);
	if (strlen($cents) == 1) $cents = '0' . $cents;
	if ($dollars < 1) {
		$output = TEXT_ZERO;
	} else {
		$output = build_1000_words($dollars, $po裩tion);
	}
	return strtoupper($output . ' ' . TEXT_DOLLARS . ' ' . TEXT_AND . ' ' . $cents . '/100');
}

function build_1000_words($number, $po裩tion) {
	$output = '';
	$suffix = array_shift($po裩tion);
	$tens = $number % 100;
	$number = intval($number / 100);
	$hundreds = $number % 10;
	$number = intval($number / 10);
	if ($number >= 1) $output = build_1000_words($number, $po裩tion);
	switch ($hundreds) {
		case 1: $output .= ' ' . TEXT_ONE   . ' ' . TEXT_HUNDERD; break;
		case 2: $output .= ' ' . TEXT_TWO   . ' ' . TEXT_HUNDERD; break;
		case 3: $output .= ' ' . TEXT_THREE . ' ' . TEXT_HUNDERD; break;
		case 4: $output .= ' ' . TEXT_FOUR  . ' ' . TEXT_HUNDERD; break;
		case 5: $output .= ' ' . TEXT_FIVE  . ' ' . TEXT_HUNDERD; break;
		case 6: $output .= ' ' . TEXT_SIX   . ' ' . TEXT_HUNDERD; break;
		case 7: $output .= ' ' . TEXT_SEVEN . ' ' . TEXT_HUNDERD; break;
		case 8: $output .= ' ' . TEXT_EIGHT . ' ' . TEXT_HUNDERD; break;
		case 9: $output .= ' ' . TEXT_NINE  . ' ' . TEXT_HUNDERD; break;
	}
	$output .= build_100_words($tens);
	return $output . $suffix;
}

function build_100_words($number) {
	if ($number > 9 && $number < 20) {
		switch ($number) {
			case 10: return ' ' . TEXT_TEN;
			case 11: return ' ' . TEXT_ELEVEN;
			case 12: return ' ' . TEXT_TWELVE;
			case 13: return ' ' . TEXT_THIRTEEN;
			case 14: return ' ' . TEXT_FOURTEEN;
			case 15: return ' ' . TEXT_FIFTEEN;
			case 16: return ' ' . TEXT_SIXTEEN;
			case 17: return ' ' . TEXT_SEVENTEEN;
			case 18: return ' ' . TEXT_EIGHTEEN;
			case 19: return ' ' . TEXT_NINETEEN;
		}
	}
	$output = '';
	$tens = intval($number / 10);
	switch ($tens) {
		case 2: $output .= ' ' . TEXT_TWENTY;  break;
		case 3: $output .= ' ' . TEXT_THIRTY;  break;
		case 4: $output .= ' ' . TEXT_FORTY;   break;
		case 5: $output .= ' ' . TEXT_FIFTY;   break;
		case 6: $output .= ' ' . TEXT_SIXTY;   break;
		case 7: $output .= ' ' . TEXT_SEVENTY; break;
		case 8: $output .= ' ' . TEXT_EIGHTY;  break;
		case 9: $output .= ' ' . TEXT_NINETY;  break;
	}
	$ones = $number % 10;
	switch ($ones) {
		case 1: $output .= (($output) ? '-' : ' ') . TEXT_ONE;   break;
		case 2: $output .= (($output) ? '-' : ' ') . TEXT_TWO;   break;
		case 3: $output .= (($output) ? '-' : ' ') . TEXT_THREE; break;
		case 4: $output .= (($output) ? '-' : ' ') . TEXT_FOUR;  break;
		case 5: $output .= (($output) ? '-' : ' ') . TEXT_FIVE;  break;
		case 6: $output .= (($output) ? '-' : ' ') . TEXT_SIX;   break;
		case 7: $output .= (($output) ? '-' : ' ') . TEXT_SEVEN; break;
		case 8: $output .= (($output) ? '-' : ' ') . TEXT_EIGHT; break;
		case 9: $output .= (($output) ? '-' : ' ') . TEXT_NINE;  break;
	}
	return $output;
}

/********************** DO NOT EDIT BELOW THIS LINE **********************************/

// Sets the default groups for forms, index max 4 chars
$ReportGroups = array (
	'ar'   => TEXT_RECEIVABLES,
	'ap'   => TEXT_PAYABLES,
	'inv'  => TEXT_INVENTORY,
	'hr'   => TEXT_HR,
	'man'  => TEXT_MANUFAC,
	'bnk'  => TEXT_BANKING,
	'gl'   => TEXT_GL,
	'misc' => TEXT_MISC);  // do not delete misc category

// This array is imploded with the first entry = number of text boxes to build (0, 1 or 2), 
// the remaining is the dropdown menu listings
$CritChoices = array(
	 0 => '2:ALL:RANGE:EQUAL',
	 1 => '0:YES:NO',
	 2 => '0:ALL:YES:NO',
	 3 => '0:ALL:ACTIVE:INACTIVE',
	 4 => '0:ALL:PRINTED:UNPRINTED',
//	 5 => NOT_USED_AVAILABLE,
	 6 => '1:EQUAL',
	 7 => '2:RANGE',
	 8 => '1:NOT_EQUAL',
	 9 => '1:IN_LIST',
	10 => '1:LESS_THAN',
	11 => '1:GREATER_THAN',
);

// Paper orientation
$PaperOrientation = array (
	'P' => TEXT_PORTRAIT,
	'L' => TEXT_LANDSCAPE,
);
	
$FontAlign = array (
	'L' => TEXT_LEFT,
	'R' => TEXT_RIGHT,
	'C' => TEXT_CENTER,
);

$TotalLevels = array(
	'0' => TEXT_NO,
	'1' => TEXT_YES,
);

$DateChoices = array(
	'a' => TEXT_ALL,
	'b' => TEXT_RANGE,
	'c' => TEXT_TODAY,
	'd' => TEXT_WEEK,
	'e' => TEXT_WTD,
	'l' => GL_CURRENT_PERIOD,
	'f' => TEXT_MONTH,
	'g' => TEXT_MTD,
	'h' => TEXT_QUARTER,
	'i' => TEXT_QTD,
	'j' => TEXT_YEAR,
	'k' => TEXT_YTD,
);

/*********************************************************************************************
Form unique defaults
**********************************************************************************************/ 
// Sets the groupings for forms indexed to a specific report (top level) grouping, 
// index is of the form ReportGroup[index]:FormGroup[index], each have a max of 4 chars
// This array is linked to the ReportGroups array by using the index values of ReportGroup
// the first value must match an index value of ReportGroup.
$FormGroups = array (
	'bnk:deps'  => RW_FRM_BANKDEPSLIP,
	'ap:quot'   => RW_FRM_VENDQUOTE,
	'ap:po'     => RW_FRM_PURCHORD,
	'ap:chk'    => RW_FRM_BANKCHK,	// Bank checks grouped with the ap (accounts payable report group
	'ap:cm'     => RW_FRM_VENDOR_CRDMEMO,
	'ap:lblv'   => RW_FRM_VENDLBL,
	'ap:pur'    => RW_TEXT_PURCHASES,
	'ar:quot'   => RW_FRM_CUSTQUOTE,
	'ar:so'     => RW_FRM_SALESORD,
	'ar:inv'    => RW_FRM_INVPKGSLIP,
	'ar:cm'     => RW_FRM_CRDMEMO,
	'ar:lblc'   => RW_FRM_CUSTLBL,
	'ar:rcpt'   => RW_FRM_SALESREC,
	'ar:cust'   => RW_FRM_CUSTSTATE,
	'ar:col'    => RW_FRM_COLLECTLTR,
	'misc:misc' => TEXT_MISC);  // do not delete misc category

// DataTypes
// A corresponding class function needs to be generated for each new function added.
// The index code is also used to identify the form to include to set the properties.
$FormEntries = array(
	'Data'    => RW_FRM_DATALINE,
	'TBlk'    => RW_FRM_DATABLOCK,
	'Tbl'     => RW_FRM_DATATABLE,
	'TDup'    => RW_FRM_DATATABLEDUP,
	'Ttl'     => RW_FRM_DATATOTAL,
	'Text'    => RW_FRM_FIXEDTXT,
	'Img'     => RW_FRM_IMAGE,
	'Rect'    => RW_FRM_RECTANGLE,
	'Line'    => RW_FRM_LINE,
	'CDta'    => RW_FRM_COYDATA,
	'CBlk'    => RW_FRM_COYBLOCK,
	'PgNum'   => RW_FRM_PAGENUM,
);
if (PDF_APP == 'TCPDF') $FormEntries['BarCode'] = RW_BAR_CODE;

// The function to process these values is: ProcessData
// A case statement needs to be generated to process each new value
$FormProcessing = array(
	''           => TEXT_NONE,
	'uc'         => RW_FRM_UPPERCASE,
	'lc'         => RW_FRM_LOWERCASE,
	'neg'        => RW_FRM_NEGATE,
	'rnd2d'      => RW_FRM_RNDR2,
	'rnd_dec'    => RW_FRM_RNDDECIMAL,
	'rnd_pre'    => RW_FRM_RNDPRECISE,
	'def_cur'    => RW_DEF_CUR,
	'null_dcur'  => RW_NULL_DCUR,
	'posted_cur' => RW_POSTED_CURR,
	'null_pcur'  => RW_NULL_PCUR,
	'dlr'        => RW_FRM_CNVTDLR,
	'null-dlr'   => RW_FRM_NULLDLR,
	'euro'       => RW_FRM_CNVTEURO,
	'date'       => RW_FRM_DATE,
	'n2wrd'      => RW_FRM_NUM_2_WORDS,
	'terms'      => RW_FRM_TERMS_TO_LANG,
	'ordr_qty'   => RW_FRM_ORDR_QTY,
	'branch'     => RW_BRANCH_ID,
	'rep_id'     => RW_REP_ID,
	'ship_name'  => RW_FRM_SHIP_METHOD,
	'j_desc'     => RW_JOURNAL_DESCRIPTION,
	'yesBno'     => RW_FRM_YES_SKIP_NO,
	'printed'    => RW_FRM_PRINTED,
);

// The function to process these values is: AddSep
// A case statement needs to be generated to process each new value
$TextProcessing = array(
	''        => TEXT_NONE,
	'sp'      => RW_FRM_SPACE1,
	'2sp'     => RW_FRM_SPACE2,
	'comma'   => RW_FRM_COMMA,
	'com-sp'  => RW_FRM_COMMASP,
	'nl'      => RW_FRM_NEWLINE,
	'semi-sp' => RW_FRM_SEMISP,
	'del-nl'  => RW_FRM_DELNL,
);

// Bar code Types (for use with TCPDF)
$BarCodeTypes = array(
	'C39'     => 'CODE 39',
	'C39+'    => 'CODE 39 w/checksum',
	'C39E'    => 'CODE 39 EXTENDED',
	'C39E+'   => 'CODE 39 EXT w/checksum',
	'I25'     => 'Interleaved 2 of 5',
	'C128A'   => 'CODE 128 A',
	'C128B'   => 'CODE 128 B',
	'C128C'   => 'CODE 128 C',
	'EAN13'   => 'EAN 13',
	'UPCA'    => 'UPC-A',
	'POSTNET' => 'POSTNET',
	'CODABAR' => 'CODABAR',
);
?>