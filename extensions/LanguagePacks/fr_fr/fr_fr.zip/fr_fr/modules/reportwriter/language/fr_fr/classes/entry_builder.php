<?php
// +-----------------------------------------------------------------+
// |                   PhreeBooks Open Source ERP                    |
// +-----------------------------------------------------------------+
// | Copyright (c) 2008, 2009, 2010 PhreeSoft, LLC                   |
// | http://www.PhreeSoft.com                                        |
// +-----------------------------------------------------------------+
// | This program is free software: you can redistribute it and/or   |
// | modify it under the terms of the GNU General Public License as  |
// | published by the Free Software Foundation, either version 3 of  |
// | the License, or any later version.                              |
// |                                                                 |
// | This program is distributed in the hope that it will be useful, |
// | but WITHOUT ANY WARRANTY; without even the implied warranty of  |
// | MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the   |
// | GNU General Public License for more details.                    |
// |                                                                 |
// | The license that is bundled with this package is located in the |
// | file: /doc/manual/ch01-Introduction/license.html.               |
// | If not, see http://www.gnu.org/licenses/                        |
// +-----------------------------------------------------------------+
//  Path: /modules/reportwriter/language/fr_fr/classes/entry_builder.php
//

// Release 1.8 language changes
define('TEXT_SO_POST_DATE','Date de post commande client');
define('RW_EB_PAYMENT_DETAIL','Détails de paiement');

//
define('RW_EB_RECORD_ID','ID Enregistrement');
define('RW_EB_JOURNAL_ID','ID Journal');
define('RW_EB_STORE_ID','ID Boutique');
define('RW_EB_JOURNAL_DESC','Description de journal');
define('RW_EB_CLOSED','Fermé');
define('RW_EB_FRT_TOTAL','Montant transport');
define('RW_EB_FRT_CARRIER','Transporteur');
define('RW_EB_FRT_SERVICE','Service de transport');
define('RW_EB_TERMS','Conditions');
define('RW_EB_INV_DISCOUNT','Remise facture');
define('RW_EB_SALES_TAX','Taxe sur les ventes');
define('RW_EB_TAX_AUTH','Autorités fiscales');
define('RW_EB_TAX_DETAILS','Détails de taxe');
define('RW_EB_INV_SUBTOTAL','Sous-total facturé');
define('RW_EB_INV_TOTAL','Montant facturé');
define('RW_EB_CUR_CODE','Code devise');
define('RW_EB_CUR_EXC_RATE','Taux de change devise');
define('RW_EB_SO_NUM','N° Commande Client');
define('RW_EB_INV_NUM','N° Facture');
define('RW_EB_PO_NUM','N° Commande Fournisseur');
define('RW_EB_SALES_REP','Représentant des ventes');
define('RW_EB_AR_ACCT','Compte A/R');
define('RW_EB_BILL_ACCT_ID','Facturation - ID Compte');
define('RW_EB_BILL_ADD_ID','Facturation - ID Adresse');
define('RW_EB_BILL_PRIMARY_NAME','Facturation - Nom principal');
define('RW_EB_BILL_CONTACT','Facturation - Contact');
define('RW_EB_BILL_ADDRESS1','Facturation - Adresse 1');
define('RW_EB_BILL_ADDRESS2','Facturation - Adresse 2');
define('RW_EB_BILL_CITY','Facturation - Ville/Cité');
define('RW_EB_BILL_STATE','Facturation - Région/Département');
define('RW_EB_BILL_ZIP','Facturation - Code Postal');
define('RW_EB_BILL_COUNTRY','Facturation - Pays');
define('RW_EB_BILL_TELE1','Facturation - Téléphone 1');
define('RW_EB_BILL_TELE2','Facturation - Téléphone 2');
define('RW_EB_BILL_FAX','Facturation - Fax');
define('RW_EB_BILL_TELE4','Facturation - Tél Portable');
define('RW_EB_BILL_EMAIL','Facturation - E-mail');
define('RW_EB_BILL_WEBSITE','Facturation - Site Web');
define('RW_EB_SHIP_ACCT_ID','Livraison - ID Compte');
define('RW_EB_SHIP_ADD_ID','Livraison - ID Adresse');
define('RW_EB_SHIP_PRIMARY_NAME','Livraison - Nom principal');
define('RW_EB_SHIP_CONTACT','Livraison - Contact');
define('RW_EB_SHIP_ADDRESS1','Livraison - Adresse 1');
define('RW_EB_SHIP_ADDRESS2','Livraison - Adresse 2');
define('RW_EB_SHIP_CITY','Livraison - Ville/Cité');
define('RW_EB_SHIP_STATE','Livraison - Région/Département');
define('RW_EB_SHIP_ZIP','Livraison - Code Postal');
define('RW_EB_SHIP_COUNTRY','Livraison - Pays');
define('RW_EB_SHIP_TELE1','Livraison - Téléphone 1');
define('RW_EB_SHIP_TELE2','Livraison - Téléphone 2');
define('RW_EB_SHIP_FAX','Livraison - Fax');
define('RW_EB_SHIP_TELE4','Livraison - Tél Portable');
define('RW_EB_SHIP_EMAIL','Livraison - E-mail');
define('RW_EB_SHIP_WEBSITE','Livraison - Site Web');
define('RW_EB_CUSTOMER_ID','ID Client');
define('RW_EB_ACCOUNT_NUMBER','Numéro de compte');
define('RW_EB_GOV_ID_NUMBER','Numéro ID Gouvernement');
define('RW_EB_SHIP_DATE','Date d&#39;expédition');
define('RW_EB_TOTAL_PAID','Montant payé');
define('RW_EB_PAYMENT_DATE','Date de paiement');
define('RW_EB_PAYMENT_DUE_DATE','Date d&#39;échéance du paiement');
define('RW_EB_PAYMENT_METHOD','Méthode de paiement');
define('RW_EB_PAYMENT_REF','Référence de paiement');
define('RW_EB_PAYMENT_DEP_ID','ID Dépôt de paiement');
define('RW_EB_BALANCE_DUE','Solde dû');

// Data table defines
define('RW_EB_SO_DESC','order_description');
define('RW_EB_SO_QTY','order_qty');
define('RW_EB_SO_TOTAL_PRICE','order_price');
define('RW_EB_SO_UNIT_PRICE','order_unit_price');
define('RW_EB_SO_SKU','order_sku');
define('RW_EB_SO_SERIAL_NUM','order_serial_num');
define('RW_EB_SHIPPED_PRIOR','qty_shipped_prior');
define('RW_EB_BACKORDER_QTY','qty_on_backorder');
define('RW_EB_INV_DESC','invoice_description');
define('RW_EB_INV_QTY','invoice_qty');
define('RW_EB_INV_TOTAL_PRICE','invoice_full_price');
define('RW_EB_INV_UNIT_PRICE','invoice_unit_price');
define('RW_EB_INV_DISCOUNT','invoice_discount');
define('RW_EB_INV_PRICE','invoice_price');
define('RW_EB_INV_SKU','invoice_sku');
define('RW_EB_INV_SERIAL_NUM','invoice_serial_num');

?>