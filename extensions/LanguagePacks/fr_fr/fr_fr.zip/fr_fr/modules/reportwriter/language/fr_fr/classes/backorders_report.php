<?php
// +-----------------------------------------------------------------+
// |                   PhreeBooks Open Source ERP                    |
// +-----------------------------------------------------------------+
// | Copyright (c) 2008, 2009, 2010 PhreeSoft, LLC                   |
// | http://www.PhreeSoft.com                                        |
// +-----------------------------------------------------------------+
// | This program is free software: you can redistribute it and/or   |
// | modify it under the terms of the GNU General Public License as  |
// | published by the Free Software Foundation, either version 3 of  |
// | the License, or any later version.                              |
// |                                                                 |
// | This program is distributed in the hope that it will be useful, |
// | but WITHOUT ANY WARRANTY; without even the implied warranty of  |
// | MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the   |
// | GNU General Public License for more details.                    |
// |                                                                 |
// | The license that is bundled with this package is located in the |
// | file: /doc/manual/ch01-Introduction/license.html.               |
// | If not, see http://www.gnu.org/licenses/                        |
// +-----------------------------------------------------------------+
//  Path: /modules/reportwriter/language/fr_fr/classes/backorders_report.php
//

define('RW_BO_RECORD_ID','ID Enregistrement');
define('RW_BO_STORE_ID','ID Boutique');
define('RW_BO_FRT_TOTAL','Montant transport');
define('RW_BO_FRT_CARRIER','Transporteur');
define('RW_BO_FRT_SERVICE','Service de transport');
define('RW_BO_SALES_TAX','Taxe sur les ventes');
//define('RW_BO_TAX_AUTH','Autorités fiscales');
define('RW_BO_INV_TOTAL','Montant facturé');
define('RW_BO_BALANCE_DUE','Solde dû');
define('RW_BO_CUR_CODE','Code devise');
define('RW_BO_CUR_EXC_RATE','Taux de change devise');
define('RW_BO_INV_NUM','N° Commande Client');
define('RW_BO_PO_NUM','N° Commande Fournisseur');
define('RW_BO_SALES_REP','Représentant des ventes');
define('RW_BO_AR_ACCT','Compte A/R');
define('RW_BO_BILL_ACCT_ID','Facturation - ID Compte');
define('RW_BO_BILL_ADD_ID','Facturation - ID Adresse');
define('RW_BO_BILL_PRIMARY_NAME','Facturation - Nom principal');
define('RW_BO_BILL_CONTACT','Facturation - Contact');
define('RW_BO_BILL_ADDRESS1','Facturation - Adresse 1');
define('RW_BO_BILL_ADDRESS2','Facturation - Adresse 2');
define('RW_BO_BILL_CITY','Facturation - Ville/Cité');
define('RW_BO_BILL_STATE','Facturation - Région/Département');
define('RW_BO_BILL_ZIP','Facturation - Code Postal');
define('RW_BO_BILL_COUNTRY','Facturation - Pays');
define('RW_BO_BILL_TELE1','Facturation - Téléphone 1');

define('RW_BO_QTY_ORDERED','Commandé');
define('RW_QTY_IN_STOCK','En Stock');
define('RW_BO_QTY_BACKORDER','Réapprovisionnement');

?>