<?php
// +-----------------------------------------------------------------+
// |                   PhreeBooks Open Source ERP                    |
// +-----------------------------------------------------------------+
// | Copyright (c) 2008, 2009, 2010 PhreeSoft, LLC                   |
// | http://www.PhreeSoft.com                                        |
// +-----------------------------------------------------------------+
// | This program is free software: you can redistribute it and/or   |
// | modify it under the terms of the GNU General Public License as  |
// | published by the Free Software Foundation, either version 3 of  |
// | the License, or any later version.                              |
// |                                                                 |
// | This program is distributed in the hope that it will be useful, |
// | but WITHOUT ANY WARRANTY; without even the implied warranty of  |
// | MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the   |
// | GNU General Public License for more details.                    |
// |                                                                 |
// | The license that is bundled with this package is located in the |
// | file: /doc/manual/ch01-Introduction/license.html.               |
// | If not, see http://www.gnu.org/licenses/                        |
// +-----------------------------------------------------------------+
//  Path: /modules/reportwriter/language/fr_fr/classes/is_budget.php
//

define('RW_FIN_REVENUES','Revenus');
define('RW_FIN_COST_OF_SALES','Coût des ventes');
define('RW_FIN_GROSS_PROFIT','Bénéfice brut');
define('RW_FIN_EXPENSES','Charges');
define('RW_FIN_NET_INCOME','Revenu net');

// drop down headings
define('IS_BUDGET_ACCOUNT','Compte');
define('IS_BUDGET_CUR_MONTH','Mois en cours');
define('IS_BUDGET_YTD','Année à ce jour');
define('IS_BUDGET_LY_CUR','Dernière année en cours');
define('IS_BUDGET_LAST_YTD','Dernière année à ce jour');
define('IS_BUDGET_CUR_BUDGET','Budget en cours');
define('IS_BUDGET_YTD_BUDGET','Budget année à ce jour');
?>