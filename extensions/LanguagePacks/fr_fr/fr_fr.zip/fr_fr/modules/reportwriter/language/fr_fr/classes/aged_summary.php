<?php
// +-----------------------------------------------------------------+
// |                   PhreeBooks Open Source ERP                    |
// +-----------------------------------------------------------------+
// | Copyright (c) 2008, 2009, 2010 PhreeSoft, LLC                   |
// | http://www.PhreeSoft.com                                        |
// +-----------------------------------------------------------------+
// | This program is free software: you can redistribute it and/or   |
// | modify it under the terms of the GNU General Public License as  |
// | published by the Free Software Foundation, either version 3 of  |
// | the License, or any later version.                              |
// |                                                                 |
// | This program is distributed in the hope that it will be useful, |
// | but WITHOUT ANY WARRANTY; without even the implied warranty of  |
// | MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the   |
// | GNU General Public License for more details.                    |
// |                                                                 |
// | The license that is bundled with this package is located in the |
// | file: /doc/manual/ch01-Introduction/license.html.               |
// | If not, see http://www.gnu.org/licenses/                        |
// +-----------------------------------------------------------------+
//  Path: /modules/reportwriter/language/fr_fr/classes/aged_summary.php
//

define('RW_AR_RECORD_ID','ID Enregistrement');
define('RW_AR_JOURNAL_ID','ID Journal');
define('RW_AR_STORE_ID','ID Boutique');
define('RW_AR_JOURNAL_DESC','Description de journal');
define('RW_AR_CLOSED','Fermé');
define('RW_AR_FRT_TOTAL','Montant transport');
define('RW_AR_FRT_CARRIER','Transporteur');
define('RW_AR_FRT_SERVICE','Service de transport');
define('RW_AR_TERMS','Conditions');
define('RW_AR_SALES_TAX','Taxe sur les ventes');
define('RW_AR_TAX_AUTH','Autorités fiscales');
define('RW_AR_INV_TOTAL','Montant facturé');
define('RW_AR_BALANCE_DUE','Solde dû');
define('RW_AR_CUR_CODE','Code Devise');
define('RW_AR_CUR_EXC_RATE','Taux de change devise');
define('RW_AR_SO_NUM','N° Commande Client');
define('RW_AR_INV_NUM','N° Facture');
define('RW_AR_PO_NUM','N° Commande Fournisseur');
define('RW_AR_SALES_REP','Représentant des ventes');
define('RW_AR_AR_ACCT','Compte A/R');
define('RW_AR_BILL_ACCT_ID','Facturation - ID Compte');
define('RW_AR_BILL_ADD_ID','Facturation - ID Adresse');
define('RW_AR_BILL_PRIMARY_NAME','Facturation - Nom principal');
define('RW_AR_BILL_CONTACT','Facturation - Contact');
define('RW_AR_BILL_ADDRESS1','Facturation - Adresse 1');
define('RW_AR_BILL_ADDRESS2','Facturation - Adresse 2');
define('RW_AR_BILL_CITY','Facturation - Ville/Cité');
define('RW_AR_BILL_STATE','Facturation - Région/Département');
define('RW_AR_BILL_ZIP','Facturation - Code postal');
define('RW_AR_BILL_COUNTRY','Facturation - Pays');
define('RW_AR_BILL_TELE1','Facturation - Téléphone 1');
define('RW_AR_BILL_TELE2','Facturation - Téléphone 2');
define('RW_AR_BILL_FAX','Facturation - Fax');
define('RW_AR_BILL_EMAIL','Facturation - E-mail');
define('RW_AR_BILL_WEBSITE','Facturation - Site Web');
define('RW_AR_SHIP_ACCT_ID','Livraison - ID Compte');
define('RW_AR_SHIP_ADD_ID','Livraison - ID Adresse');
define('RW_AR_SHIP_PRIMARY_NAME','Livraison - Nom principal');
define('RW_AR_SHIP_CONTACT','Livraison - Contact');
define('RW_AR_SHIP_ADDRESS1','Livraison - Adresse 1');
define('RW_AR_SHIP_ADDRESS2','Livraison - Adresse 2');
define('RW_AR_SHIP_CITY','Livraison - Ville/Cité');
define('RW_AR_SHIP_STATE','Livraison - Région/Département');
define('RW_AR_SHIP_ZIP','Livraison - Code postal');
define('RW_AR_SHIP_COUNTRY','Livraison - Pays');
define('RW_AR_SHIP_TELE1','Livraison - Téléphone 1');
define('RW_AR_SHIP_TELE2','Livraison - Téléphone 2');
define('RW_AR_SHIP_FAX','Livraison - Fax');
define('RW_AR_SHIP_EMAIL','Livraison - E-mail');
define('RW_AR_SHIP_WEBSITE','Livraison - Site Web');
define('RW_AR_CUSTOMER_ID','ID Client');
define('RW_AR_ACCOUNT_NUMBER','Numéro de compte');
define('RW_AR_SHIP_DATE','Date d&#39;expédition');
define('RW_AR_AGE1','Age ' . AR_AGING_HEADING_1);
define('RW_AR_AGE2','Age ' . AR_AGING_HEADING_2);
define('RW_AR_AGE3','Age ' . AR_AGING_HEADING_3);
define('RW_AR_AGE4','Age ' . AR_AGING_HEADING_4);

?>