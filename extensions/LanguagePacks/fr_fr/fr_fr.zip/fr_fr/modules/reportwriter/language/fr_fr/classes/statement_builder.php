<?php
// +-----------------------------------------------------------------+
// |                   PhreeBooks Open Source ERP                    |
// +-----------------------------------------------------------------+
// | Copyright (c) 2008, 2009, 2010 PhreeSoft, LLC                   |
// | http://www.PhreeSoft.com                                        |
// +-----------------------------------------------------------------+
// | This program is free software: you can redistribute it and/or   |
// | modify it under the terms of the GNU General Public License as  |
// | published by the Free Software Foundation, either version 3 of  |
// | the License, or any later version.                              |
// |                                                                 |
// | This program is distributed in the hope that it will be useful, |
// | but WITHOUT ANY WARRANTY; without even the implied warranty of  |
// | MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the   |
// | GNU General Public License for more details.                    |
// |                                                                 |
// | The license that is bundled with this package is located in the |
// | file: /doc/manual/ch01-Introduction/license.html.               |
// | If not, see http://www.gnu.org/licenses/                        |
// +-----------------------------------------------------------------+
//  Path: /modules/reportwriter/language/fr_fr/classes/statement_builder.php
//

define('RW_SB_RECORD_ID','ID Enregistrement');
define('RW_SB_CUSTOMER_ID','ID Client');
define('RW_SB_ACCOUNT_NUMBER','Numéro de compte');
define('RW_SB_SALES_REP','Représentant des ventes');
define('RW_SB_TERMS','Conditions');
define('RW_SB_BILL_PRIMARY_NAME','Facturation - Nom principal');
define('RW_SB_BILL_CONTACT','Facturation - Contact');
define('RW_SB_BILL_ADDRESS1','Facturation - Adresse 1');
define('RW_SB_BILL_ADDRESS2','Facturation - Adresse 2');
define('RW_SB_BILL_CITY','Facturation - Ville/Cité');
define('RW_SB_BILL_STATE','Facturation - Région/Département');
define('RW_SB_BILL_ZIP','Facturation - Code Postal');
define('RW_SB_BILL_COUNTRY','Facturation - Pays');
define('RW_SB_BILL_TELE1','Facturation - Téléphone 1');
define('RW_SB_BILL_TELE2','Facturation - Téléphone 2');
define('RW_SB_BILL_FAX','Facturation - Fax');
define('RW_SB_BILL_EMAIL','Facturation - e-mail');
define('RW_SB_BILL_WEBSITE','Facturation - Site Web');
define('RW_SB_PRIOR_BALANCE','Solde précédent');
define('RW_SB_BALANCE_DUE','Solde dû');

// Table fields
define('RW_SB_JOURNAL_DESC','Description de Journal');
define('RW_SB_INV_NUM','N° Facture');
define('RW_SB_PO_NUM','N° Commande Fournisseur');
define('RW_SB_DUE_DATE','Date d&#39;échéance');
define('RW_SB_PMT_RCVD','Pmt reçu');
define('RW_SB_INV_TOTAL','Montant facture');

?>