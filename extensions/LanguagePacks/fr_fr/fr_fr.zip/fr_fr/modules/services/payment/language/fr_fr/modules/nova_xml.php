<?php
// +-----------------------------------------------------------------+
// |                   PhreeBooks Open Source ERP                    |
// +-----------------------------------------------------------------+
// | Copyright (c) 2008, 2009, 2010 PhreeSoft, LLC                   |
// | http://www.PhreeSoft.com                                        |
// +-----------------------------------------------------------------+
// | This program is free software: you can redistribute it and/or   |
// | modify it under the terms of the GNU General Public License as  |
// | published by the Free Software Foundation, either version 3 of  |
// | the License, or any later version.                              |
// |                                                                 |
// | This program is distributed in the hope that it will be useful, |
// | but WITHOUT ANY WARRANTY; without even the implied warranty of  |
// | MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the   |
// | GNU General Public License for more details.                    |
// |                                                                 |
// | The license that is bundled with this package is located in the |
// | file: /doc/manual/ch01-Introduction/license.html.               |
// | If not, see http://www.gnu.org/licenses/                        |
// +-----------------------------------------------------------------+
//  Path: /modules/services/payment/language/fr_fr/modules/nova_xml.php
//

// Admin Configuration Items
  define('MODULE_PAYMENT_NOVA_XML_TEXT_TITLE', 'Nova (marchant virtuel)'); // Payment option title as displayed in the admin
  define('MODULE_PAYMENT_NOVA_XML_TEXT_DESCRIPTION', 'En mode test, les cartes renvoyent un code de succès, mais elles ne sont pas traitées.<br /><br />');

// Catalog Items
  define('MODULE_PAYMENT_NOVA_XML_TEXT_CATALOG_TITLE', 'Carte de Crédit');  // Payment option title as displayed to the customer
  define('MODULE_PAYMENT_NOVA_XML_TEXT_CREDIT_CARD_TYPE', 'Type de carte de crédit:');
  define('MODULE_PAYMENT_NOVA_XML_TEXT_CREDIT_CARD_OWNER', 'Possesseur carte de crédit:');
  define('MODULE_PAYMENT_NOVA_XML_TEXT_CREDIT_CARD_NUMBER', 'Numéro de carte de crédit:');
  define('MODULE_PAYMENT_NOVA_XML_TEXT_CREDIT_CARD_EXPIRES', 'Date d&#39;expiration carte de crédit:');
  define('MODULE_PAYMENT_NOVA_XML_TEXT_CVV', 'Numéro CVV (<a href="javascript:popupWindowCvv()">' . 'Plus d&#39;informations' . '</a>)');
  define('MODULE_PAYMENT_NOVA_XML_TEXT_JS_CC_OWNER', '* Le nom du propriétaire de la carte de crédit doit avoir au moins ' . CC_OWNER_MIN_LENGTH . ' caractères.\n');
  define('MODULE_PAYMENT_NOVA_XML_TEXT_JS_CC_NUMBER', '* Le numéro de carte de crédit doit avoir au moins ' . CC_NUMBER_MIN_LENGTH . ' caractères.\n');
  define('MODULE_PAYMENT_NOVA_XML_TEXT_JS_CC_CVV', '* Les 3 ou 4 chiffres CVV à l&#39;arrière de la carte de crédit doivent être saisis.\n');
  define('MODULE_PAYMENT_NOVA_XML_TEXT_DECLINED_MESSAGE', 'La transaction par carte de crédit n&#39;a pas été traitée correctement. Si aucune raison n&#39;est donnée, la carte a été refusée par la banque.');
  define('MODULE_PAYMENT_NOVA_XML_NO_DUPS','La carte de crédit n&#39;a pas été traitée parce qu&#39;elle l&#39;a déjà été. Pour re-débiter une carte de crédit, la carte de crédit doit être valide et ne contenir aucun caractère *.');
  define('MODULE_PAYMENT_NOVA_XML_TEXT_ERROR', 'Erreur de carte de crédit !');
?>