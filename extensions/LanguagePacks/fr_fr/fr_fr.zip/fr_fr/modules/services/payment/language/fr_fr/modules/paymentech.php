<?php
/**
 * Paymentech Payment Module V.1.0 created by s_mack - 09/18/2007 Released under GPL
 *
 * @package languageDefines
 * @copyright Portions Copyright 2007 s_mack
 * @copyright Portions Copyright 2003-2005 Zen Cart Development Team
 * @copyright Portions Copyright 2003 osCommerce
 * @license http://www.zen-cart.com/license/2_0.txt GNU Public License V2.0
 */


// Admin Configuration Items
  define('MODULE_PAYMENT_PAYMENTECH_TEXT_TITLE', 'Paymentech'); // Payment option title as displayed in the admin
  define('MODULE_PAYMENT_PAYMENTECH_TEXT_DESCRIPTION', 'Traitement carte de crédit via le portail Chase Orbital/Paymentech');

// Catalog Items
  define('MODULE_PAYMENT_PAYMENTECH_TEXT_CATALOG_TITLE', 'Carte de Crédit');  // Payment option title as displayed to the customer
  define('MODULE_PAYMENT_PAYMENTECH_TEXT_CREDIT_CARD_TYPE', 'Type de carte de crédit:');
  define('MODULE_PAYMENT_PAYMENTECH_TEXT_CREDIT_CARD_OWNER', 'Possesseur carte de crédit:');
  define('MODULE_PAYMENT_PAYMENTECH_TEXT_CREDIT_CARD_NUMBER', 'Numéro de carte de crédit:');
  define('MODULE_PAYMENT_PAYMENTECH_TEXT_CREDIT_CARD_EXPIRES', 'Date d&#39;expiration carte de crédit:');
  define('MODULE_PAYMENT_PAYMENTECH_TEXT_CVV', 'Numéro CVV (<a href="javascript:popupWindowCvv()">' . 'Plus d&#39;informations' . '</a>)');
  define('MODULE_PAYMENT_PAYMENTECH_TEXT_POPUP_CVV_LINK', 'Qu&#39;est-ce que c&#39;est ?');
  define('MODULE_PAYMENT_PAYMENTECH_TEXT_JS_CC_OWNER', '* Le nom du propriétaire de la carte de crédit doit avoir au moins ' . CC_OWNER_MIN_LENGTH . ' caractères.\n');
  define('MODULE_PAYMENT_PAYMENTECH_TEXT_JS_CC_NUMBER', '* Le numéro de carte de crédit doit avoir au moins ' . CC_NUMBER_MIN_LENGTH . ' caractères.\n');
  define('MODULE_PAYMENT_PAYMENTECH_TEXT_JS_CC_CVV', '* Les 3 ou 4 chiffres CVV à l&#39;arrière de la carte de crédit doivent être saisis.\n');
  define('MODULE_PAYMENT_PAYMENTECH_TEXT_GATEWAY_ERROR', 'Une erreur inattendue du portail pour cartes de crédit s&#39;est produite. Votre commande n&#39;a pas été traitée.');
  define('MODULE_PAYMENT_PAYMENTECH_TEXT_DECLINED_MESSAGE', 'Votre carte de crédit n\a pas pu être autorisée pour cette raison: <i>Refusée (%s)</i>.');
  define('MODULE_PAYMENT_PAYMENTECH_NO_DUPS','La carte de crédit n&#39;a pas été traitée parce qu&#39;elle l&#39;a déjà été. Pour re-débiter une carte de crédit, la carte de crédit doit être valide et ne contenir aucun caractère *.');
  define('MODULE_PAYMENT_PAYMENTECH_TEXT_ERROR', 'Erreur de carte de crédit !');
  define('MODULE_PAYMENT_PAYMENTECH_TEST_URL_PRIMARY', 'https://orbitalvar1.paymentech.net');
  define('MODULE_PAYMENT_PAYMENTECH_PRODUCTION_URL_PRIMARY', 'https://orbital1.paymentech.net/authorize');
  define('MODULE_PAYMENT_PAYMENTECH_EMAIL_GATEWAY_ERROR_SUBJECT', 'Problème du portail Paymentech');
  define('MODULE_PAYMENT_PAYMENTECH_EMAIL_SYSTEM_ERROR_SUBJECT', 'Problème du système Paymentech');
  define('MODULE_PAYMENT_PAYMENTECH_EMAIL_DECLINED_SUBJECT', 'Transaction Paymentech refusée');
?>