<?php
// +-----------------------------------------------------------------+
// |                   PhreeBooks Open Source ERP                    |
// +-----------------------------------------------------------------+
// | Copyright (c) 2008, 2009, 2010 PhreeSoft, LLC                   |
// | http://www.PhreeSoft.com                                        |
// +-----------------------------------------------------------------+
// | This program is free software: you can redistribute it and/or   |
// | modify it under the terms of the GNU General Public License as  |
// | published by the Free Software Foundation, either version 3 of  |
// | the License, or any later version.                              |
// |                                                                 |
// | This program is distributed in the hope that it will be useful, |
// | but WITHOUT ANY WARRANTY; without even the implied warranty of  |
// | MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the   |
// | GNU General Public License for more details.                    |
// |                                                                 |
// | The license that is bundled with this package is located in the |
// | file: /doc/manual/ch01-Introduction/license.html.               |
// | If not, see http://www.gnu.org/licenses/                        |
// +-----------------------------------------------------------------+
//  Path: /modules/gen_ledger/language/fr_fr/language.php
//

// ******************* Release 2.0 Additions ******************/
define('GENERAL_JOURNAL_18_C_DESC','Écriture Recettes Client');
define('GENERAL_JOURNAL_18_V_DESC','Écriture Recettes Fournisseur');
define('GENERAL_JOURNAL_20_V_DESC','Écriture Paiement Fournisseur');
define('GENERAL_JOURNAL_20_C_DESC','Écriture Paiement Client');
define('GL_BUDGET_HEADING_TITLE','Gestion Budgétaire');
define('GL_BUDGET_INTRO_TEXT','Cet outil établit les budgets pour les comptes du Grand Livre.<br />NOTE: L&#39;icône &#39;Enregistrer&#39; doit être enfoncée après la saisie des données avant que le compte ou l&#39;exercice fiscal ne soit changé !');
define('GL_COPY_ACTUAL_CONFIRM','Êtes-vous sûr(e) de vouloir remplacer les montants budgétaires dans tous les comptes du Grand Livre pour l&#39;exercice fiscal choisi avec les montants réalisés de l&#39;exercice précédent ? Cette opération ne peut pas être annulée !');
define('GL_BUDGET_COPY_HINT','Copier les montants réalisés de l&#39;exercice fiscal précédent');
define('GL_CLEAR_ACTUAL_CONFIRM','Êtes-vous sûr(e) de vouloir effacer les montants budgétaires dans tous les comptes du Grand Livre pour l&#39;exercice fiscal sélectionné ? Cette opération ne peut pas être annulée !');
define('TEXT_BUDGET_CLEAR_HINT','Effacer tous les budgets pour le présent exercice fiscal');
define('TEXT_LOAD_ACCT_PRIOR','Charger les montants réalisés dans l&#39;exercice fiscal précédent');
define('ERROR_NO_GL_ACCT_INFO','Il n\'y a aucune donnée pour l\'exercice fiscal précédent sélectionné !');
define('TEXT_PERIOD_DATES','Période / Dates');
define('TEXT_PRIOR_FY','Exercice fiscal précédent');
define('TEXT_BUDGET','Budget');
define('TEXT_NEXT_FY','Exercice fiscal suivant');
define('GL_TEXT_COPY_PRIOR','Copier le budget précédent vers le budget courant');
define('GL_TEXT_ALLOCATE','Allouer le total jusqu&#39;à l&#39;exercice fiscal');
define('GL_TEXT_COPY_NEXT','Copier le budget suivant vers le budget courant');
define('GL_JS_CANNOT_COPY','Cet enregistrement ne peut être copié car il n&#39;a pas encore été sauvegardé !');
define('GL_JS_COPY_CONFIRM','Vous avez choisi de copier cet enregistrement de journal. Cela va créer une copie de l&#39;enregistrement en cours avec les champs modifiés. NOTE: La référence doit être différente ou cette opération va échouer lors de l&#39;envoi. Appuyez sur OK pour continuer ou sur Annuler pour revenir au formulaire.');

// ************************************************************/
// General
define('TEXT_SELECT_FILE','Fichier à importer: ');

// Titles and headings
define('GL_ENTRY_TITLE','Écriture Journal Général');
define('GL_HEADING_BEGINNING_BALANCES','Plan comptable - Soldes d&#39;ouverture');
define('GL_HEADING_IMPORT_BEG_BALANCES','Importer soldes d&#39;ouverture');

// Audit Log Messages
define('GL_LOG_ADD_JOURNAL','Écriture Journal Général - ');
define('GL_LOG_FY_UPDATE','Exercice fiscal Journal Général - ');
define('GL_LOG_PURGE_DB','Journal Général - Purge de la Base de données');

// Special buttons
define('GL_BTN_PURGE_DB','Purger les écritures de journal');
define('GL_BTN_BEG_BAL','Saisir les soldes d&#39;ouverture');
define('GL_BTN_IMP_BEG_BALANCES','Importer le stock, les effets à payer, les effets à recevoir, les soldes d&#39;ouverture');
define('GL_BTN_CHG_ACCT_PERIOD', 'Modifier la période comptable courante');
define('GL_BTN_NEW_FY', 'Générer le prochain exercice fiscal');
define('GL_BTN_UPDATE_FY', 'Mettre à jour les modifications d&#39;exercice fiscal');
define('GL_BB_IMPORT_INVENTORY','Importer le stock');
define('GL_BB_IMPORT_PAYABLES','Importer les effets à payer');
define('GL_BB_IMPORT_RECEIVABLES','Importer les effets à recevoir');
define('GL_BB_IMPORT_SALES_ORDERS','Importer les commandes clients ');
define('GL_BB_IMPORT_PURCH_ORDERS','Importer les commandes fournisseurs');
define('GL_BB_IMPORT_HELP_MSG','Se référer au fichier d&#39;aide pour les besoins de format.');

// GL Utilities
define('GL_UTIL_HEADING_TITLE', 'Maintenance du Journal Général, Configuration et Utilitaires');
define('GL_UTIL_PERIOD_LEGEND','Périodes comptables et exercices fiscaux');
define('GL_UTIL_BEG_BAL_LEGEND','Journal Général Soldes d&#39;ouverture');
define('GL_UTIL_PURGE_ALL','Purger toutes les transactions du Journal (redémarrage)');
define('GL_FISCAL_YEAR','Exercice fiscal');
define('GL_UTIL_FISCAL_YEAR_TEXT','Les dates calendaires d&#39;exercice fiscal peuvent être modifiées ici. Veuillez noter que les dates d&#39;exercice fiscal ne peuvent pas être changées pour une période allant jusqu&#39;à et y compris la dernière écriture du journal général dans le système.');
define('GL_UTIL_BEG_BAL_TEXT','Pour les initialisations et les transferts depuis un autre système de comptabilité.');
define('GL_UTIL_PURGE_DB','Supprimer toutes les écritures de journal (tapez &#39;purge&#39; dans la boîte texte et appuyez sur le bouton de purge)<br />');
define('GL_UTIL_PURGE_DB_CONFIRM','Êtes-vous sûr(e) de vouloir effacer toutes les écritures de journal ?');
define('GL_UTIL_PURGE_CONFIRM','Tous les enregistrements de journal ont été supprimés et les bases de données nettoyées.');
define('GL_UTIL_PURGE_FAIL','Aucune écriture de journal n&#39;a été touchée !');
define('GL_CURRENT_PERIOD','Le période comptable courante est: ');
define('GL_WARN_ADD_FISCAL_YEAR','Êtes-vous sûr(e) de vouloir ajouter l&#39;exercice fiscal: ');
define('GL_ERROR_FISCAL_YEAR_SEQ','La dernière période de l&#39;exercice fiscal modifié ne s&#39;aligne pas avec la date de début du prochain exercice fiscal. La date de début du prochain exercice fiscal a été modifiée et devrait être revue.');
define('GL_WARN_CHANGE_ACCT_PERIOD','Entrez la période comptable à considérer comme courante:');
define('GL_ERROR_BAD_ACCT_PERIOD','La période comptable choisie n&#39;a pas été définie. Soit ré-entrez la période, soit ajoutez un exercice fiscal pour continuer.');
define('GL_ERROR_NO_BALANCE','Impossible de mettre à jour les soldes d&#39;ouverture parce que les débits et les crédits ne correspondent pas !');
define('GL_ERROR_UPDATE_COA_HISTORY','Erreur de mise à jour de l&#39;historique du plan comptable après avoir réglé les soldes d&#39;ouverture !');
define('GL_BEG_BAL_ERROR_0',' trouvé sur la ligne ');
define('GL_BEG_BAL_ERROR_1','ID invalide de plan comptable trouvé sur la ligne ');
define('GL_BEG_BAL_ERROR_2A','Aucun numéro de facture trouvé sur la ligne ');
define('GL_BEG_BAL_ERROR_2B','. Indiqué comme en attente de paiement !');
define('GL_BEG_BAL_ERROR_3','Fin de l&#39;importation. Aucun numéro de facture trouvé sur la ligne ');
define('GL_BEG_BAL_ERROR_4A','Fin du script. Mauvais format de date trouvé sur la ligne ');
define('GL_BEG_BAL_ERROR_4B','. Format attendu ');
define('GL_BEG_BAL_ERROR_5','Ligne sautée. Montant total nul trouvé sur la ligne ');
define('GL_BEG_BAL_ERROR_6','ID invalide de plan comptable trouvé sur la ligne ');
define('GL_BEG_BAL_ERROR_7','Article de stock sauté. Quantité nulle trouvée sur la ligne ');
define('GL_BEG_BAL_ERROR_8A','Échec de mise à jour du SKU # ');
define('GL_BEG_BAL_ERROR_8B',', le processus a pris fin.');
define('GL_BEG_BAL_ERROR_9A','Échec de mise à jour du compte # ');

// GL popup
define('TEXT_DISPLAY_NUMBER_OF_ACCTS', 'Affiche <b>%d</b> à <b>%d</b> (sur <b>%d</b> comptes GL)');

// General Ledger Translations
define('GL_ERROR_JOURNAL_BAD_ACCT','Impossible de trouver le numéro de compte du Grand Livre !');
define('GL_ERROR_OUT_OF_BALANCE','L&#39;écriture ne peut pas être postée parce que les débits et les crédits ne balancent pas !');
define('GL_ERROR_BAD_ACCOUNT','Un ou plusieurs des numéros de compte GL ne sont pas valides. Veuillez corriger et soumettre à nouveau.');
define('GL_ERROR_NO_REFERENCE','Pour les opérations récurrentes, un numéro de référence de départ doit être entré. PhreeBooks l&#39;incrémentera à chaque écriture récurrente.');
define('GL_ERROR_RECUR_ROLL_REQD','Il s&#39;agit d&#39;une écriture récurrente. Voulez-vous aussi mettre à jour les futures écritures ? (Appuyez sur Annuler pour mettre à jour uniquement cette écriture)');
define('GL_ERROR_RECUR_DEL_ROLL_REQD','Il s&#39;agit d&#39;une écriture récurrente. Voulez-vous aussi mettre à jour les futures écritures ? (Appuyez sur Annuler pour mettre à jour uniquement cette écriture)');
define('GL_ERROR_NO_ITEMS','Aucun élément n&#39;a été posté. Pour qu&#39;un élément soit enregistré, la quantité ne doit pas être vide.');
define('GL_ERROR_NO_POST','Il y a eu des erreurs pendant le traitement, l&#39;enregistrement n&#39;a pas été posté.');
define('GL_ERROR_NO_DELETE','Il y a eu des erreurs pendant le traitement, l&#39;enregistrement n&#39;a pas été supprimé.');
define('GL_ERROR_CANNOT_FIND_NEXT_ID','Impossible de lire le numéro de commande/facture suivant dans la table: ' . TABLE_CURRENT_STATUS);
define('GL_ERROR_CANNOT_DELETE_MAIN','Échec de suppression de l&#39;enregistrement principal de journal # ');
define('GL_ERROR_CANNOT_DELETE_ITEM','Échec de suppression de l&#39;enregistrement détaillé de journal # %d. Aucune ligne n&#39;a été trouvée !');
define('GL_ERROR_NEVER_POSTED','Impossible de supprimer cette écriture car elle n&#39;a jamais été postée.');
define('GL_DELETE_GL_ROW','Êtes-vous sûr(e) de vouloir supprimer cette ligne de journal ?');
define('GL_DELETE_ALERT','Êtes-vous sûr(e) de vouloir supprimer cette écriture de journal ?');
define('GL_ERROR_DIED_CREATING_RECORD','Mort en essayant de construire une écriture de journal avec id = ');
define('GL_ERROR_POSTING_CHART_BALANCES','Erreur en postant les soldes du plan comptable vers le compte id: ');
define('GL_ERROR_OUT_OF_BALANCE_A','La balance avant inventaire n&#39;est pas équilibrée. Débits: ');
define('GL_ERROR_OUT_OF_BALANCE_B',' et crédits: ');
define('GL_ERROR_OUT_OF_BALANCE_C',' dans la période ');
define('GL_ERROR_NO_GL_ACCT_NUMBER','Pas de numéro de compte fourni dans /gen_ledger.php pour la fonction: ');
define('GL_ERROR_UPDATING_ACCOUNT_HISTORY','Erreur de mise à jour de l&#39;historique de compte client/fournisseur.');
define('GL_ERROR_DELETING_ACCOUNT_HISTORY','Erreur de suppression d&#39;enregistrement dans l&#39;historique de compte client/fournisseur');
define('GL_ERROR_UPDATING_INVENTORY_STATUS','La mise à jour de l&#39;état du stock exige que le SKU soit dans la base de données. Le SKU défaillant était: ');
define('GL_ERROR_CALCULATING_COGS','Le calcul du coût des biens vendus exige que le SKU soit dans la base de données, l&#39;opération a échoué.');
define('GL_ERROR_POSTING_INV_HISTORY','Erreur en postant l&#39;historique du stock.');
define('GL_ERROR_UNPOSTING_COGS','Erreur en ramenant le coût des biens vendus à l&#39;état initial. SKU: ');
define('GL_ERROR_BAD_SKU_ENTERED','Impossible de trouver le SKU saisi. Aucune action n&#39;a été prise.');
define('GL_ERROR_SKU_NOT_ASSY','Impossible d&#39;assembler un article du stock qui n&#39;a pas de composants. SKU: ');
define('GL_ERROR_NOT_ENOUGH_PARTS','Pas assez de pièces pour construire le nombre requis d&#39;assemblages. SKU: ');
define('GL_ERROR_POSTING_NEG_INVENTORY','Erreur en postant le coût des biens vendus pour un avoir fournisseur, le stock deviendra négatif et les coûts des biens vendus ne peuvent être calculés. Le SKU touché est: ');
define('GL_ERROR_SERIALIZE_QUANTITY','Erreur en calculant les coûts des biens vendus pour un article sérialisé, la quantité n&#39;était pas égale à 1 par ligne article soumise.');
define('GL_ERROR_SERIALIZE_EMPTY','Erreur en calculant les coûts des biens vendus pour un article sérialisé, le numéro de série saisi était vide.');
define('GL_ERROR_SERIALIZE_COGS','Erreur sur les coûts des biens vendus. Soit le numéro de série n&#39;a pas été trouvé, soit plus d&#39;un article avec un numéro de série correspondant ont été trouvés.');
define('GL_ERROR_NO_RETAINED_EARNINGS_ACCOUNT','Zéro ou plus d&#39;un compte de bénéfices non distribués trouvés. Il doit y avoir un seul et unique compte des bénéfices non distribués dans PhreeBooks pour fonctionner correctement !');

define('GL_DISPLAY_NUMBER_OF_ENTRIES', TEXT_DISPLAY_NUMBER . ' écritures GL');
define('GL_TOTALS','Totaux:');
define('GL_OUT_OF_BALANCE','Balance déséquilibrée:');
define('GL_ACCOUNT_INCREASED','Compte sera augmenté');
define('GL_ACCOUNT_DECREASED','Compte sera réduit');

define('GL_JOURNAL_ENTRY_COGS','Coût des biens vendus');

// Journal Entries
define('GENERAL_JOURNAL_0_DESC','Importer les écritures de soldes d&#39;ouverture du stock');
define('GL_MSG_IMPORT_0_SUCCESS','Soldes d&#39;ouverture du stock importés avec succès. Le nombre d&#39;enregistrements importés était de: ');
define('GL_MSG_IMPORT_0','Soldes d&#39;ouverture du stock importés');

define('GENERAL_JOURNAL_2_DESC','Écriture Journal Général');
define('GENERAL_JOURNAL_2_ERROR_2','GL - Le numéro de référence de Journal Général que vous avez saisi est en double, veuillez entrer un nouveau numéro de référence !');

define('GENERAL_JOURNAL_3_DESC','Écriture Devis Achat');
define('GENERAL_JOURNAL_3_ERROR_2','PQ - Le numéro de devis achat que vous avez saisi est en double, veuillez entrer un nouveau numéro de devis achat !');
define('GENERAL_JOURNAL_3_ERROR_5','PQ - Échec d&#39;incrémentation du numéro de devis achat !');
define('GENERAL_JOURNAL_3_LEDGER_DISCOUNT','Montant remise sur devis achat');
define('GENERAL_JOURNAL_3_LEDGER_FREIGHT','Montant transport sur devis achat');
define('GENERAL_JOURNAL_3_LEDGER_HEADING','Total devis achat');

define('GENERAL_JOURNAL_4_DESC','Écriture Commande Fournisseur');
define('GENERAL_JOURNAL_4_ERROR_2','PO - Le numéro de commande fournisseur que vous avez saisi est en double, veuillez entrer un nouveau numéro de commande fournisseur !');
define('GENERAL_JOURNAL_4_ERROR_5','PO - Échec d&#39;incrémentation du numéro de commande fournisseur !');
define('GENERAL_JOURNAL_4_ERROR_6','PO - Une commande fournisseur ne peut pas être supprimée s&#39;il y a des éléments qui ont été reçus !');
define('GENERAL_JOURNAL_4_LEDGER_DISCOUNT','Montant remise sur commande fournisseur');
define('GENERAL_JOURNAL_4_LEDGER_FREIGHT','Montant transport sur commande fournisseur');
define('GENERAL_JOURNAL_4_LEDGER_HEADING','Total commande fournisseur');
define('GL_MSG_IMPORT_4_SUCCESS','Commandes fournisseurs importées avec succès. Le nombre d&#39;enregistrements importés était de: ');
define('GL_MSG_IMPORT_4','Commandes fournisseurs importées');

define('GENERAL_JOURNAL_6_DESC','Écriture Achat/Recevoir');
define('GENERAL_JOURNAL_6_ERROR_2','P/R - Le numéro de facture que vous avez saisi est en double, veuillez entrer un nouveau numéro de facture !');
define('GENERAL_JOURNAL_6_ERROR_6','P/R - Un achat ne peut pas être supprimé s&#39;il y a eu un avoir ou un paiement appliqué !');
define('GENERAL_JOURNAL_6_LEDGER_DISCOUNT','Montant remise sur Achat/Recevoir');
define('GENERAL_JOURNAL_6_LEDGER_FREIGHT','Montant transport sur Achat/Recevoir');
define('GENERAL_JOURNAL_6_LEDGER_HEADING','Total stock sur Achat/Recevoir');
define('GL_MSG_IMPORT_6_SUCCESS','Écritures d&#39;effets à payer importées avec succès. Le nombre d&#39;enregistrements importés était de: ');
define('GL_MSG_IMPORT_6','Effets à payer importés');

define('GENERAL_JOURNAL_7_DESC','Écriture Avoir Fournisseur');
define('GENERAL_JOURNAL_7_ERROR_2','VCM - Le numéro d&#39;avoir que vous avez saisi est en double, veuillez entrer un nouveau numéro d&#39;avoir !');
define('GENERAL_JOURNAL_7_ERROR_5','VCM - Échec d&#39;incrémentation du numéro d&#39;avoir !');
define('GENERAL_JOURNAL_7_ERROR_6','VCM - Un avoir ne peut pas être supprimé s&#39;il y a eu un paiement appliqué !');
define('GENERAL_JOURNAL_7_LEDGER_DISCOUNT','Montant remise sur avoir fournisseur');
define('GENERAL_JOURNAL_7_LEDGER_FREIGHT','Montant transport sur avoir fournisseur');
define('GENERAL_JOURNAL_7_LEDGER_HEADING','Total avoir fournisseur');

define('GENERAL_JOURNAL_9_DESC','Écriture Devis Ventes');
define('GENERAL_JOURNAL_9_ERROR_2','SQ - Le numéro de devis ventes que vous avez saisi est en double, veuillez entrer un nouveau numéro de devis ventes !');
define('GENERAL_JOURNAL_9_ERROR_5','SQ - Échec d&#39;incrémentation du numéro de devis ventes !');
define('GENERAL_JOURNAL_9_LEDGER_DISCOUNT','Montant remise sur devis vente');
define('GENERAL_JOURNAL_9_LEDGER_FREIGHT','Montant transport sur devis vente');
define('GENERAL_JOURNAL_9_LEDGER_HEADING','Total devis vente');

define('GENERAL_JOURNAL_10_DESC','Écriture Ordre Ventes');
define('GENERAL_JOURNAL_10_ERROR_2','SO - Le numéro de commande client que vous avez saisi est en double, veuillez entrer un nouveau numéro de commande client !');
define('GENERAL_JOURNAL_10_ERROR_5','SO - Échec d&#39;incrémentation du numéro de commande client !');
define('GENERAL_JOURNAL_10_ERROR_6','SO - Une commande client ne peut pas être supprimée s&#39;il y a des éléments qui ont été expédiés !');
define('GENERAL_JOURNAL_10_LEDGER_DISCOUNT','Montant remise sur commande client');
define('GENERAL_JOURNAL_10_LEDGER_FREIGHT','Montant transport sur commande client');
define('GENERAL_JOURNAL_10_LEDGER_HEADING','Total commande client');
define('GL_MSG_IMPORT_10_SUCCESS','Commandes clients importées avec succès. Le nombre d&#39;enregistrements importés était de: ');
define('GL_MSG_IMPORT_10','Commandes clients importés');

define('GENERAL_JOURNAL_12_DESC','Écriture Ventes/Facture');
define('GENERAL_JOURNAL_12_ERROR_2','S/I - Le numéro de facture que vous avez saisi est en double, veuillez entrer un nouveau numéro de facture !');
define('GENERAL_JOURNAL_12_ERROR_5','S/I - Échec d&#39;incrémentation du numéro de facture !');
define('GENERAL_JOURNAL_12_ERROR_6','S/I - Une facture ne peut pas être supprimée s&#39;il y a eu un avoir ou un paiement appliqué !');
define('GENERAL_JOURNAL_12_LEDGER_DISCOUNT','Montant remise sur ventes/facture');
define('GENERAL_JOURNAL_12_LEDGER_FREIGHT','Montant transport sur ventes/facture');
define('GENERAL_JOURNAL_12_LEDGER_HEADING','Total ventes/facture');
define('GL_MSG_IMPORT_12','Écritures d&#39;effets à recevoir importées');
define('GL_MSG_IMPORT_12_SUCCESS','Effets à recevoir importés avec succès. Le nombre d&#39;enregistrements importés était de: ');
define('GL_MSG_IMPORT_12','Factures importées');

define('GENERAL_JOURNAL_13_DESC','Écriture Avoir Client');
define('GENERAL_JOURNAL_13_ERROR_2','CCM - Le numéro d&#39;avoir que vous avez saisi est en double, veuillez entrer un nouveau numéro d&#39;avoir !');
define('GENERAL_JOURNAL_13_ERROR_5','CCM - Échec d&#39;incrémentation du numéro d&#39;avoir !');
define('GENERAL_JOURNAL_13_ERROR_6','CCM - Un avoir ne peut pas être supprimé s&#39;il y a eu un paiement appliqué !');
define('GENERAL_JOURNAL_13_LEDGER_DISCOUNT','Montant remise sur avoir client');
define('GENERAL_JOURNAL_13_LEDGER_FREIGHT','Montant transport sur avoir client');
define('GENERAL_JOURNAL_13_LEDGER_HEADING','Total avoir client');

define('GENERAL_JOURNAL_14_DESC','Écriture Assemblage du Stock');

define('GENERAL_JOURNAL_16_DESC','Écriture Ajustement du Stock');

define('GENERAL_JOURNAL_18_DESC','Écriture Recettes Client');
define('GENERAL_JOURNAL_18_ERROR_2','C/R - Le numéro de recette que vous avez saisi est en double, veuillez entrer un nouveau numéro de recette !');
define('GENERAL_JOURNAL_18_ERROR_5','C/R - Échec d&#39;incrémentation du numéro de recette !');
define('GENERAL_JOURNAL_18_ERROR_6','C/R - Une recette ne peut pas être supprimée si l&#39;écriture a été rapprochée avec la banque !');
define('GENERAL_JOURNAL_18_DISCOUNT_HEADING','Remise sur recette client');
define('GENERAL_JOURNAL_18_LEDGER_HEADING','Total recette client');
/*
define('GENERAL_JOURNAL_19_DESC','Écriture Point de Vente');
define('GENERAL_JOURNAL_19_ERROR_2','S/I - Le numéro de recette que vous avez saisi est en double, veuillez entrer un nouveau numéro de recette !');
define('GENERAL_JOURNAL_19_ERROR_5','S/I - Échec d&#39;incrémentation du numéro de recette !');
define('GENERAL_JOURNAL_19_ERROR_6','S/I - Une recette ne peut pas être supprimée s&#39;il y a eu un paiement appliqué !');
define('GENERAL_JOURNAL_19_LEDGER_DISCOUNT','Montant Remise sur point de vente');
define('GENERAL_JOURNAL_19_LEDGER_FREIGHT','Montant transport sur point de vente');
define('GENERAL_JOURNAL_19_DISCOUNT_HEADING','Remise sur recette client');
define('GENERAL_JOURNAL_19_LEDGER_HEADING','Total point de vente');
*/
define('GENERAL_JOURNAL_20_DESC','Écriture Paiement Fournisseur');
define('GENERAL_JOURNAL_20_ERROR_2','V/P - Le numéro de vérification que vous avez saisi est en double, veuillez entrer un nouveau numéro de vérification !');
define('GENERAL_JOURNAL_20_ERROR_5','V/P - Échec d&#39;incrémentation du numéro de paiement !');
define('GENERAL_JOURNAL_20_ERROR_6','V/P - Un paiement ne peut pas être supprimé si l&#39;écriture a été rapprochée avec la banque !');
define('GENERAL_JOURNAL_20_DISCOUNT_HEADING','Remise sur paiement fournisseur');
define('GENERAL_JOURNAL_20_LEDGER_HEADING','Total paiement fournisseur');
/*
define('GENERAL_JOURNAL_21_DESC','Écriture Achat');
define('GENERAL_JOURNAL_21_ERROR_2','P/R - Le numéro de vérification que vous avez saisi est en double, veuillez entrer un nouveau numéro de vérification !');
define('GENERAL_JOURNAL_21_ERROR_6','P/R - Un achat ne peut pas être supprimé s&#39;il y a eu un paiement appliqué !');
define('GENERAL_JOURNAL_21_LEDGER_DISCOUNT','Montant remise sur achat');
define('GENERAL_JOURNAL_21_LEDGER_FREIGHT','Montant transport sur achat');
define('GENERAL_JOURNAL_21_DISCOUNT_HEADING','Remise sur achat');
define('GENERAL_JOURNAL_21_LEDGER_HEADING','Total achat');
*/
?>