<?php
// +-----------------------------------------------------------------+
// |                   PhreeBooks Open Source ERP                    |
// +-----------------------------------------------------------------+
// | Copyright (c) 2008, 2009, 2010 PhreeSoft, LLC                   |
// | http://www.PhreeSoft.com                                        |
// +-----------------------------------------------------------------+
// | This program is free software: you can redistribute it and/or   |
// | modify it under the terms of the GNU General Public License as  |
// | published by the Free Software Foundation, either version 3 of  |
// | the License, or any later version.                              |
// |                                                                 |
// | This program is distributed in the hope that it will be useful, |
// | but WITHOUT ANY WARRANTY; without even the implied warranty of  |
// | MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the   |
// | GNU General Public License for more details.                    |
// |                                                                 |
// | The license that is bundled with this package is located in the |
// | file: /doc/manual/ch01-Introduction/license.html.               |
// | If not, see http://www.gnu.org/licenses/                        |
// +-----------------------------------------------------------------+
//  Path: /modules/install/language/fr_fr/inspect.php
//

  define('TEXT_PAGE_HEADING', 'Installation de PhreeBooks&trade; - Inspection du Système');
  define('INSTALL_BUTTON', ' Installer'); // this comes before TEXT_MAIN
  define('UPGRADE_BUTTON', 'Mettre à jour'); // this comes before TEXT_MAIN
  define('DB_UPGRADE_BUTTON', 'Mettre à jour la base de données'); // this comes before TEXT_MAIN
  define('REFRESH_BUTTON', 'Re-vérifier');
//Button meanings: (to be made into help-text for future version):
// "Install" = make new configure.php files, regardless of existing contents.  Load new database by dropping old tables.
// "Upgrade" = read old configure.php files, and write new ones using new structure. Upgrade database, instead of wiping and new install
// "Database Upgrade" = don't write the configure.php files -- simply jump to the database-upgrade page. Only displayed if detected database version is new enough to not require configure.php file updates.

  define('TEXT_MAIN', 'Prenez un moment pour vérifier si votre serveur web possède toutes les fonctionnalités requises pour faire fonctionner PhreeBooks&trade;. Veuillez résoudre tous les problèmes détectés avant de poursuivre. Puis cliquez sur <em>'.INSTALL_BUTTON.'</em> pour continuer.');
  define('SYSTEM_INSPECTION_RESULTS', 'Résultats de l&#39;inspection du système');
  define('OTHER_INFORMATION', 'Autres informations système (uniquement à titre de référence)');
  define('OTHER_INFORMATION_DESCRIPTION', 'Les informations suivantes n&#39;indiquent pas forcément un problème de configuration. Elle servent simplement à vous récapituler certains paramètres.');

  define('NOT_EXIST','NON TROUVÉ');
  define('WRITABLE','inscriptible');
  define('UNWRITABLE',"<span class='errors'>écriture impossible</span>");
  define('UNKNOWN','inconnnu');

  define('UPGRADE_DETECTION','Mode mise à jour disponible');
  define('LABEL_PREVIOUS_INSTALL_FOUND','Installation antérieure de PhreeBooks&trade; trouvée');
  define('LABEL_PREVIOUS_VERSION_NUMBER','La base de données de PhreeBooks&trade; semble être en version %s');
  define('LABEL_PREVIOUS_VERSION_NUMBER_UNKNOWN','<em>Toutefois, la version de votre base de données n&#39;a pas pu être déterminée, chose qui résulte habituellement de préfixes de tables incorrects, ou d&#39;autres paramètre de base de données erronés. <br /><br />ATTENTION: Utilisez seulement l&#39;option de mise à jour si vous êtes sûr(e) que vos paramètres dans configure.php sont corrects.</em>');

  define('DISPLAY_PHP_INFO','Lien PHP Info: ');
  define('VIEW_PHP_INFO_LINK_TEXT','Voir le PHPINFO de votre serveur');
  define('LABEL_WEBSERVER','Serveur web');
  define('LABEL_MYSQL_AVAILABLE','Support de MySQL');
  define('LABEL_MYSQL_VER','Version de MySQL');
  define('LABEL_DB_PRIVS','Privilèges base de données');
  define('LABEL_POSTGRES_AVAILABLE','Support de PostgreSQL');
  define('LABEL_PHP_VER','Version de PHP');
  define('LABEL_REGISTER_GLOBALS','register_globals');
  define('LABEL_SET_TIME_LIMIT','Temps d&#39;exécution PHP maximal par page');
  define('LABEL_DISABLED_FUNCTIONS','Fonctions PHP désactivées');
  define('LABEL_SAFE_MODE','PHP safe_mode');
  define('LABEL_CURRENT_CACHE_PATH','Répertoire courant du cache SQL');
  define('LABEL_SUGGESTED_CACHE_PATH','Répertoire suggéré du cache SQL');
  define('LABEL_HTTP_HOST','Hôte HTTP');
  define('LABEL_PATH_TRANLSATED','PATH_TRANSLATED');
  define('LABEL_PHP_API_MODE','PHP API Mode');
  define('LABEL_PHP_MODULES','Modules PHP actifs');
  define('LABEL_PHP_EXT_SESSIONS','Support des sessions');
  define('LABEL_PHP_SESSION_AUTOSTART','PHP session.autostart');
  define('LABEL_PHP_EXT_SAVE_PATH','PHP session.save_path');
  define('LABEL_PHP_EXT_FTP','Support de FTP');
  define('LABEL_PHP_EXT_CURL','Support de cURL');
  define('LABEL_PHP_MAG_QT_RUN','PHP magic_quotes_runtime');
  define('LABEL_PHP_EXT_GD','Support de GD');
  define('LABEL_PHP_EXT_OPENSSL','Support d&#39;OpenSSL');
  define('LABEL_PHP_UPLOAD_STATUS','PHP file_uploads');
  define('LABEL_PHP_EXT_PFPRO','Support de Payflow Pro');
  define('LABEL_PHP_EXT_ZLIB','Support de la compression ZLIB');
  define('LABEL_PHP_SESSION_TRANS_SID','PHP session.use_trans_sid');
  define('LABEL_DISK_FREE_SPACE','Espace disque libre sur le serveur');
  define('LABEL_XML_SUPPORT','Support de XML');
  define('LABEL_OPEN_BASEDIR','PHP open_basedir (restrictions)');
  define('LABEL_UPLOAD_TMP_DIR','PHP upload_tmp_dir');
  define('LABEL_SENDMAIL_FROM','PHP sendmail_from');
  define('LABEL_SENDMAIL_PATH','PHP sendmail_path');
  define('LABEL_SMTP_MAIL','PHP destination SMTP');
  define('LABEL_CONFIG_WRITEABLE','Répertoire /includes inscriptible');
  define('LABEL_MY_FILES_CREATE','Répertoire /my_files inscriptible');
  define('LABEL_CRITICAL','Eléments critiques');
  define('LABEL_RECOMMENDED','Eléments recommandés');
  define('LABEL_OPTIONAL','Eléments optionnels');
  define('LABEL_UPGRADE_PERMISSION','Permission de mise à jour');

  define('LABEL_EXPLAIN','&nbsp;Cliquez ici pour plus d&#39;infos');
  define('LABEL_FOLDER_PERMISSIONS','Permissions sur les fichiers et répertoires');
  define('LABEL_WRITABLE_FOLDER_INFO','Pour que la plupart des fonctions usuelles et d&#39;administration de PhreeBooks&trade; fonctionnent correctement,
vous devrez mettre la permission en écriture sur plusieurs fichiers/répertoires.  Voici la liste des répertoires qui doivent avoir les permissions en lecture et écriture, 
avec les paramètres recommandés pour CHMOD. Veuillez corriger ces permissions avant de continuer l&#39;installation. 
Actualisez cette page dans votre navigateur pour vérifier à nouveau les permissions.<br /><br />Certains hébergeurs ne vous permettent pas de mettre des CHMOD 777, mais seulement 666. Commencez d&#39;abord avec les permissions les plus grandes, puis baissez si besoin.');


?>