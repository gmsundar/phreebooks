<?php
// +-----------------------------------------------------------------+
// |                   PhreeBooks Open Source ERP                    |
// +-----------------------------------------------------------------+
// | Copyright (c) 2008, 2009, 2010 PhreeSoft, LLC                   |
// | http://www.PhreeSoft.com                                        |
// +-----------------------------------------------------------------+
// | This program is free software: you can redistribute it and/or   |
// | modify it under the terms of the GNU General Public License as  |
// | published by the Free Software Foundation, either version 3 of  |
// | the License, or any later version.                              |
// |                                                                 |
// | This program is distributed in the hope that it will be useful, |
// | but WITHOUT ANY WARRANTY; without even the implied warranty of  |
// | MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the   |
// | GNU General Public License for more details.                    |
// |                                                                 |
// | The license that is bundled with this package is located in the |
// | file: /doc/manual/ch01-Introduction/license.html.               |
// | If not, see http://www.gnu.org/licenses/                        |
// +-----------------------------------------------------------------+
//  Path: /modules/install/language/fr_fr/system_setup.php
//

  define('SAVE_SYSTEM_SETTINGS', 'Enregistrer les paramètres système'); //this comes before TEXT_MAIN
  define('TEXT_MAIN', 'Nous allons maintenant configurer l&#39;environnement système de PhreeBooks&trade;.  Veuillez vérifier soigneusement chaque paramètre, et changer si nécessaire selon votre arborescence. Cliquez ensuite sur <em>'.SAVE_SYSTEM_SETTINGS.'</em> pour continuer.');
  define('TEXT_PAGE_HEADING', 'Installation de PhreeBooks&trade; - Paramètrage Système');
  define('SERVER_SETTINGS', 'Paramètres du serveur');
  define('PHYSICAL_PATH', 'Chemin physique vers PhreeBooks&trade;');
  define('PHYSICAL_PATH_INSTRUCTION', 'Chemin d&#39;accès physique vers votre<br />répertoire PhreeBooks&trade;.<br />Sans slash à la fin.');
  define('VIRTUAL_HTTP_PATH', 'Chemin virtuel HTTP');
  define('VIRTUAL_HTTP_PATH_INSTRUCTION', 'Chemin d&#39;accès virtuel vers votre<br />répertoire PhreeBooks&trade;.<br />Sans slash à la fin.');
  define('VIRTUAL_HTTPS_PATH', 'Chemin virtuel sécurisé HTTPS');
  define('VIRTUAL_HTTPS_PATH_INSTRUCTION', 'Chemin d&#39;accès virtuel vers votre<br />répertoire sécurisé PhreeBooks&trade;.<br />Sans slash à la fin.');
  define('VIRTUAL_HTTPS_SERVER', 'Serveur virtuel sécurisé HTTPS');
  define('VIRTUAL_HTTPS_SERVER_INSTRUCTION', 'Serveur virtuel pour votre<br />répertoire sécurisé PhreeBooks&trade;.<br />Sans slash à la fin.');
  define('ENABLE_SSL', 'Activer SSL');
  define('ENABLE_SSL_INSTRUCTION', 'Voulez-vous activer Secure Sockets Layer (SSL) ?<br />Laissez sur NON sauf si vous êtes absolument sûr(e) d&#39;avoir SSL en fonctionnement.');
?>