<?php
// +-----------------------------------------------------------------+
// |                   PhreeBooks Open Source ERP                    |
// +-----------------------------------------------------------------+
// | Copyright (c) 2008, 2009, 2010 PhreeSoft, LLC                   |
// | http://www.PhreeSoft.com                                        |
// +-----------------------------------------------------------------+
// | This program is free software: you can redistribute it and/or   |
// | modify it under the terms of the GNU General Public License as  |
// | published by the Free Software Foundation, either version 3 of  |
// | the License, or any later version.                              |
// |                                                                 |
// | This program is distributed in the hope that it will be useful, |
// | but WITHOUT ANY WARRANTY; without even the implied warranty of  |
// | MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the   |
// | GNU General Public License for more details.                    |
// |                                                                 |
// | The license that is bundled with this package is located in the |
// | file: /doc/manual/ch01-Introduction/license.html.               |
// | If not, see http://www.gnu.org/licenses/                        |
// +-----------------------------------------------------------------+
//  Path: /modules/install/language/fr_fr/fiscal_setup.php
//

  define('SAVE_STORE_SETTINGS', 'Enregistrer les paramètres de l&#39;exercice fiscal'); //this comes before TEXT_MAIN
  define('SKIP_STORE_SETTINGS', 'Exercice fiscal existant - Sauter cette étape'); //this comes before TEXT_MAIN
  define('TEXT_MAIN', 'Cette section de l&#39;outil d&#39;installation PhreeBooks&trade; vous aidera à mettre en place l&#39;année d&#39;exercice de votre société. Vous serez en mesure de modifier ces paramètres plus tard en utilisant le menu <em>Grand Livre</em>.  Veuillez faire votre choix et appuyez sur <em>'.SAVE_STORE_SETTINGS.'</em> pour continuer. Si une année d&#39;exercice existe déjà dans la base de données, le bouton <em>'.SKIP_STORE_SETTINGS.'</em> apparaîtra à la place. Appuyez sur ce bouton pour sauter cette étape.');
  define('TEXT_FISCAL_YEAR_EXISTS','Les exercices fiscaux de <b>%d</b> à <b>%d</b> sont déjà dans la base de données, veuillez appuyer sur <em>' . SKIP_STORE_SETTINGS . '</em> pour continuer.');
  define('TEXT_PAGE_HEADING', 'Installation PhreeBooks&trade; - Paramètrage Exercice Fiscal');
  define('STORE_INFORMATION', 'Informations sur l&#39;exercice fiscal');

  define('STORE_DEFAULT_PERIOD', 'Première période comptable');
  define('STORE_DEFAULT_PERIOD_INSTRUCTION', 'Choisissez le mois de départ de votre première période comptable. PhreeBooks&trade; initialisera le début au premier jour du mois sélectionné comme période 1.');

  define('STORE_DEFAULT_FY', 'Année d&#39;exercice');
  define('STORE_DEFAULT_FY_INSTRUCTION', 'Choisissez l&#39;année de départ de votre premier exercice fiscal. Le mois sélectionné ci-dessus et cette année choisie constitueront la première date à laquelle des entrées de journal pourront être faites.');

  define('TEXT_JAN', 'Janvier');
  define('TEXT_FEB', 'Février');
  define('TEXT_MAR', 'Mars');
  define('TEXT_APR', 'Avril');
  define('TEXT_MAY', 'Mai');
  define('TEXT_JUN', 'Juin');
  define('TEXT_JUL', 'Juillet');
  define('TEXT_AUG', 'Août');
  define('TEXT_SEP', 'Septembre');
  define('TEXT_OCT', 'Octobre');
  define('TEXT_NOV', 'Novembre');
  define('TEXT_DEC', 'Décembre');

  $period_values = array();
  $period_values[] = array('id' => '01', 'text' => TEXT_JAN);
  $period_values[] = array('id' => '02', 'text' => TEXT_FEB);
  $period_values[] = array('id' => '03', 'text' => TEXT_MAR);
  $period_values[] = array('id' => '04', 'text' => TEXT_APR);
  $period_values[] = array('id' => '05', 'text' => TEXT_MAY);
  $period_values[] = array('id' => '06', 'text' => TEXT_JUN);
  $period_values[] = array('id' => '07', 'text' => TEXT_JUL);
  $period_values[] = array('id' => '08', 'text' => TEXT_AUG);
  $period_values[] = array('id' => '09', 'text' => TEXT_SEP);
  $period_values[] = array('id' => '10', 'text' => TEXT_OCT);
  $period_values[] = array('id' => '11', 'text' => TEXT_NOV);
  $period_values[] = array('id' => '12', 'text' => TEXT_DEC);

  $fiscal_years = array();
  $fiscal_years[] = array('id' => '2005', 'text' => '2005');
  $fiscal_years[] = array('id' => '2006', 'text' => '2006');
  $fiscal_years[] = array('id' => '2007', 'text' => '2007');
  $fiscal_years[] = array('id' => '2008', 'text' => '2008');
  $fiscal_years[] = array('id' => '2009', 'text' => '2009');
  $fiscal_years[] = array('id' => '2010', 'text' => '2010');
  $fiscal_years[] = array('id' => '2011', 'text' => '2011');
  $fiscal_years[] = array('id' => '2012', 'text' => '2012');
  $fiscal_years[] = array('id' => '2013', 'text' => '2013');
  $fiscal_years[] = array('id' => '2014', 'text' => '2014');
  $fiscal_years[] = array('id' => '2015', 'text' => '2015');
  $fiscal_years[] = array('id' => '2016', 'text' => '2016');
  $fiscal_years[] = array('id' => '2017', 'text' => '2017');
  $fiscal_years[] = array('id' => '2018', 'text' => '2018');
?>