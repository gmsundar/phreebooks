<?php
// +-----------------------------------------------------------------+
// |                   PhreeBooks Open Source ERP                    |
// +-----------------------------------------------------------------+
// | Copyright (c) 2008, 2009, 2010 PhreeSoft, LLC                   |
// | http://www.PhreeSoft.com                                        |
// +-----------------------------------------------------------------+
// | This program is free software: you can redistribute it and/or   |
// | modify it under the terms of the GNU General Public License as  |
// | published by the Free Software Foundation, either version 3 of  |
// | the License, or any later version.                              |
// |                                                                 |
// | This program is distributed in the hope that it will be useful, |
// | but WITHOUT ANY WARRANTY; without even the implied warranty of  |
// | MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the   |
// | GNU General Public License for more details.                    |
// |                                                                 |
// | The license that is bundled with this package is located in the |
// | file: /doc/manual/ch01-Introduction/license.html.               |
// | If not, see http://www.gnu.org/licenses/                        |
// +-----------------------------------------------------------------+
//  Path: /modules/install/language/fr_fr/chart_setup.php
//

  define('SAVE_STORE_SETTINGS', 'Enregistrer les paramètres du plan comptable'); //this comes before TEXT_MAIN
  define('TEXT_MAIN', 'Cette section de l&#39;outil d&#39;installation PhreeBooks&trade; vous aidera à configurer le plan comptable de votre société.  PhreeBooks&trade; inclut plusieurs exemples simples de plans comptables à sélectionner. Vous serez en mesure de modifier n&#39;importe lequel de ces paramètres plus tard à l&#39;aide du menu du Gand Livre.  Veuillez choisir un plan comptable et cliquez sur <em>'.SAVE_STORE_SETTINGS.'</em> pour continuer.<br><br>NOTE: Si vous prévoyez d&#39;installer les données de démonstration, utilisez le plan intitulé &#39;US - Retail store simple Chart of Accounts&#39; pour être assuré(e) que les comptes de coût s&#39;alignent correctement. Ne pas faire cela entrainera un échec et nécessitera que les comptes client/fournisseur et les comptes de frais de stock soient corrigés avec les comptes GL corrects.');
  define('TEXT_PAGE_HEADING', 'Installation de PhreeBooks&trade; - Paramètrage du Plan Comptable');
  define('STORE_INFORMATION', 'Informations sur le plan comptable');
  define('STORE_VIEW_COA_DETAILS','Voir les détails du plan');

  define('STORE_DEFAULT_COA', 'Plans comptables disponibles');
  define('STORE_DEFAULT_COA_INSTRUCTION', 'Choisissez le modèle que vous souhaitez pour votre plan comptable par défaut. Des comptes pourront être ajoutés ou enlevés ultérieurement par le menu <em>Journal Général</em>.');
?>