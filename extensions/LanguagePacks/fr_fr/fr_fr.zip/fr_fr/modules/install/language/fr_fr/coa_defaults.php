<?php
// +-----------------------------------------------------------------+
// |                   PhreeBooks Open Source ERP                    |
// +-----------------------------------------------------------------+
// | Copyright (c) 2008, 2009, 2010 PhreeSoft, LLC                   |
// | http://www.PhreeSoft.com                                        |
// +-----------------------------------------------------------------+
// | This program is free software: you can redistribute it and/or   |
// | modify it under the terms of the GNU General Public License as  |
// | published by the Free Software Foundation, either version 3 of  |
// | the License, or any later version.                              |
// |                                                                 |
// | This program is distributed in the hope that it will be useful, |
// | but WITHOUT ANY WARRANTY; without even the implied warranty of  |
// | MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the   |
// | GNU General Public License for more details.                    |
// |                                                                 |
// | The license that is bundled with this package is located in the |
// | file: /doc/manual/ch01-Introduction/license.html.               |
// | If not, see http://www.gnu.org/licenses/                        |
// +-----------------------------------------------------------------+
//  Path: /modules/install/language/fr_fr/coa_defaults.php
//

  define('SAVE_STORE_SETTINGS', 'Enregistrer les paramètres par défaut'); //this comes before TEXT_MAIN
  define('TEXT_MAIN', 'Cette section de l&#39;outil d&#39;installation PhreeBooks&trade; vous aidera à configurer les comptes par défaut de votre société. Vous serez en mesure de modifier n&#39;importe lequel de ces paramètres plus tard à l&#39;aide du menu <em>Société</em>.  Veuillez faire vos sélections et cliquez sur <em>'.SAVE_STORE_SETTINGS.'</em> pour continuer. <br /><br />NOTE: PhreeBooks&trade; prendra une supposition éclairée pour l&#39;inventaire des comptes par défaut à cette étape. Il est recommandé de revoir ces paramètres via le menu <em>Société</em> avant de configurer des articles du stock.');
  define('TEXT_PAGE_HEADING', 'Installation de PhreeBooks&trade; - Comptes par Défaut');
  define('STORE_INFORMATION', 'Informations sur les comptes par défaut');
  define('COA_REFERENCE','Votre plan comptable de référence:');

// for best guess of accounts to pre-set the account pull downs
  define('TEXT_INVENTORY','stock');
  define('TEXT_PAYABLE','effets à payer');
  define('TEXT_PURCHASE_DISCOUNT','escompte sur les achats');
  define('ORD_FREIGHT','transport');
  define('TEXT_CHECKING','chèques');
  define('TEXT_SALES','ventes');
  define('TEXT_RECEIVABLES','effets à recevoir');
  define('TEXT_SALES_DISCOUNT','remise sur les ventes');
  define('TEXT_COGS','coût des ventes');

  define('STORE_DEFAULT_INV_ACCT','Compte achat articles en stock par défaut');
  define('STORE_DEFAULT_INV_ACT_INSTRUCTION','Sélectionnez un compte à utiliser pour les articles gérés en stock achetés auprès des fournisseurs. Ce compte doit être un compte de type &#39;Stock&#39;');
  define('STORE_DEFAULT_AP_PURCH','Compte achats par défaut');
  define('STORE_DEFAULT_AP_PURCH_INSTRUCTION','Sélectionnez un compte à utiliser pour les articles gérés en stock achetés auprès des fournisseurs. Ce compte doit être un compte de type &#39;Effets à payer&#39;');
  define('STORE_DEFAULT_AP_DISC','Compte escompte sur achats par défaut');
  define('STORE_DEFAULT_AP_DISC_INSTRUCTION','Sélectionnez un compte à utiliser pour les remises sur les paiements faits aux fournisseurs. Ce compte doit être un compte de type &#39;Revenu&#39;');
  define('STORE_DEFAULT_AP_FRT','Compte frais de livraison achats par défaut');
  define('STORE_DEFAULT_AP_FRT_INSTRUCTION','Sélectionnez un compte à utiliser pour les frais de transport liés aux achats de marchandises. Ce compte doit être un compte de type &#39;Dépense&#39;');
  define('STORE_DEFAULT_AP_PMT','Compte paiements fournisseurs par défaut');
  define('STORE_DEFAULT_AP_PMT_INSTRUCTION','Sélectionnez un compte à utiliser pour les paiements faits aux fournisseurs pour les factures, les paiements d&#39;inventaire, etc. Ce compte doit être un compte de type &#39;Espèces&#39;');
  define('STORE_DEFAULT_AR_SALES','Compte ventes par défaut');
  define('STORE_DEFAULT_AR_SALES_INSTRUCTION','Sélectionnez un compte à utiliser pour les ventes aux clients. Ce compte doit être un compte de type &#39;Revenu&#39;');
  define('STORE_DEFAULT_AR_RCV','Compte effets à recevoir par défaut');
  define('STORE_DEFAULT_AR_RCV_INSTRUCTION','Sélectionnez un compte à utiliser pour les ventes facturées aux clients. Ce compte doit être un compte de type &#39;Effets à recevoir&#39;');
  define('STORE_DEFAULT_AR_DISC','Compte remises sur ventes par défaut');
  define('STORE_DEFAULT_AR_DISC_INSTRUCTION','Sélectionnez un compte à utiliser pour les remises aux clients par les promotions, les paiements anticipés, etc. Ce compte doit être un compte de type &#39;Revenu&#39;');
  define('STORE_DEFAULT_AR_FRT','Compte frais de livraison des ventes par défaut');
  define('STORE_DEFAULT_AR_FRT_INSTRUCTION','Sélectionnez un compte à utiliser pour les frais de transport liés aux envois aux clients. Ce compte doit être un compte de type &#39;Revenu&#39;');
  define('STORE_DEFAULT_AR_RCPT','Compte paiements clients par défaut');
  define('STORE_DEFAULT_AR_RCPT_INSTRUCTION','Sélectionnez un compte à utiliser pour les paiements reçus des clients. Ce compte doit être un compte de type &#39;Espèces&#39;');

?>