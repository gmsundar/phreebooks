<?php
// +-----------------------------------------------------------------+
// |                   PhreeBooks Open Source ERP                    |
// +-----------------------------------------------------------------+
// | Copyright (c) 2008, 2009, 2010 PhreeSoft, LLC                   |
// | http://www.PhreeSoft.com                                        |
// +-----------------------------------------------------------------+
// | This program is free software: you can redistribute it and/or   |
// | modify it under the terms of the GNU General Public License as  |
// | published by the Free Software Foundation, either version 3 of  |
// | the License, or any later version.                              |
// |                                                                 |
// | This program is distributed in the hope that it will be useful, |
// | but WITHOUT ANY WARRANTY; without even the implied warranty of  |
// | MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the   |
// | GNU General Public License for more details.                    |
// |                                                                 |
// | The license that is bundled with this package is located in the |
// | file: /doc/manual/ch01-Introduction/license.html.               |
// | If not, see http://www.gnu.org/licenses/                        |
// +-----------------------------------------------------------------+
//  Path: /modules/install/language/fr_fr/store_setup.php
//

  define('SAVE_STORE_SETTINGS', 'Enregistrer les paramètres de la société'); //this comes before TEXT_MAIN
  define('TEXT_MAIN', 'Cette section de l&#39;outil d&#39;installation de PhreeBooks&trade; vous aidera à commencer la configuration de base de votre société. Vous pourrez changer tous ces paramètres plus tard à l&#39;aide du menu d&#39;administration. Entrez soigneusement chaque valeur et cliquez sur <em>'.SAVE_STORE_SETTINGS.'</em> pour continuer.');
  define('TEXT_PAGE_HEADING', 'Installation de PhreeBooks&trade; - Configuration de la Société');
  define('STORE_INFORMATION', 'Informations sur la société');
  define('STORE_ID', 'ID Société');
  define('STORE_ID_INSTRUCTION', 'Entrez une courte abbréviation du nom de votre société (ou succursale) à utiliser dans les menus déroulants.');
  define('STORE_NAME', 'Nom de la société');
  define('STORE_NAME_INSTRUCTION', 'Quel est le nom de votre société ?');
  define('STORE_CITY_TOWN', 'Ville/Cité de la société');
  define('STORE_CITY_TOWN_INSTRUCTION', 'Dans quelle ville/cité se situe votre société ?');
  define('STORE_POSTAL_CODE', 'Code postal de la société');
  define('STORE_POSTAL_CODE_INSTRUCTION', 'Quel est votre code postal ?');
  define('STORE_OWNER_EMAIL', 'E-mail de la société');
  define('STORE_OWNER_EMAIL_INSTRUCTION', 'Quelle est l&#39;adresse e-mail principale de la société ?');
  define('STORE_WEBSITE', 'Site Web de la société');
  define('STORE_WEBSITE_INSTRUCTION', 'Quelle est l&#39;adresse du site web de la société ? (sans http://)');
  define('STORE_TELEPHONE1', 'N° de téléphone principal de la société');
  define('STORE_TELEPHONE1_INSTRUCTION', 'Quel est le numéro de téléphone principal ?');
  define('STORE_TELEPHONE2', 'N° de téléphone secondaire de la société');
  define('STORE_TELEPHONE2_INSTRUCTION', 'Quel est le numéro de téléphone secondaire ?');
  define('STORE_FAX', 'N° de fax de la société');
  define('STORE_FAX_INSTRUCTION', 'Quel est le numéro de fax de la société ?');
  define('STORE_COUNTRY', 'Pays de la société');
  define('STORE_COUNTRY_INSTRUCTION', 'Dans quel pays se situe votre société ?');
  define('STORE_ZONE', 'Région/Département de la société');
  define('STORE_ZONE_INSTRUCTION', 'Dans quel région/département se situe votre société ?');
  define('STORE_ADDRESS1', 'Ligne d&#39;adresse 1 de la société');
  define('STORE_ADDRESS1_INSTRUCTION', 'Quelle est la ligne 1 de l&#39;adresse principale de votre société ?');
  define('STORE_ADDRESS2', 'Ligne d&#39;adresse 2 de la société');
  define('STORE_ADDRESS2_INSTRUCTION', 'Quelle est la ligne 2 de l&#39;adresse principale de votre société ?');
  define('STORE_DEFAULT_CURRENCY', 'Devise par défaut');
  define('STORE_DEFAULT_CURRENCY_INSTRUCTION', 'Veuillez sélectionner votre devise par défaut ?');
  define('DEMO_INFORMATION', 'Informations sur la démo');
  define('DEMO_INSTALL', 'Société de démonstration');
  define('DEMO_INSTALL_INSTRUCTION', 'Voulez-vous installer aussi les produits, les comptes fournisseurs et clients de démonstration dans PhreeBooks&trade; ?');
?>