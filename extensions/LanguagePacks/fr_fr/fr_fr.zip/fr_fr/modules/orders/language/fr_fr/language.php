<?php
// +-----------------------------------------------------------------+
// |                   PhreeBooks Open Source ERP                    |
// +-----------------------------------------------------------------+
// | Copyright (c) 2008, 2009, 2010 PhreeSoft, LLC                   |
// | http://www.PhreeSoft.com                                        |
// +-----------------------------------------------------------------+
// | This program is free software: you can redistribute it and/or   |
// | modify it under the terms of the GNU General Public License as  |
// | published by the Free Software Foundation, either version 3 of  |
// | the License, or any later version.                              |
// |                                                                 |
// | This program is distributed in the hope that it will be useful, |
// | but WITHOUT ANY WARRANTY; without even the implied warranty of  |
// | MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the   |
// | GNU General Public License for more details.                    |
// |                                                                 |
// | The license that is bundled with this package is located in the |
// | file: /doc/manual/ch01-Introduction/license.html.               |
// | If not, see http://www.gnu.org/licenses/                        |
// +-----------------------------------------------------------------+
//  Path: /modules/orders/language/fr_fr/language.php
//

/********************* Release R2.1 additions ***********************/
define('TEXT_SAVE_OPEN_PREVIOUS','Enregistrer - Ouvrir facture précédente');
define('TEXT_SAVE_OPEN_NEXT','Enregistrer - Ouvrir facture suivante');
define('ORD_WARN_FORM_MODIFIED','Il semble y avoir déjà des données dans ce formulaire. Voulez-vous rechercher un contact existant ?');

/********************* Release R2.0 additions ***********************/
define('ORD_ERROR_NOT_CUR_PERIOD','Vos permissions vous empêchent de poster dans une période autre que la période actuelle !');
define('ORD_ERROR_DEL_NOT_CUR_PERIOD','Vos permissions vous empêchent de supprimer une commande d&#39;une période autre que la période actuelle !');

/********************* Release R1.9 additions ***********************/
define('ORD_DISCOUNT_GL_ACCT','Compte GL remise');
define('ORD_FREIGHT_GL_ACCT','Compte GL transport');
define('ORD_INV_STOCK_LOW','Pas assez de cet article en stock.');
define('ORD_INV_STOCK_BAL','Le nombre d&#39;articles en stock est: ');
define('ORD_INV_OPEN_POS','Les commandes fournisseurs ouvertes suivantes sont dans le système:');
define('ORD_INV_STOCK_STATUS','Com.Four.: %s Qté: %s Exigible: %s');
define('ORD_JS_SKU_NOT_UNIQUE','Impossible de trouver une correspondance unique pour ce SKU. Soit le champ de recherche SKU a donné lieu à plusieurs correspondances, soit rien n&#39;a été trouvé.');
define('ORD_JS_NO_CID','Les informations de contact doivent être chargées dans ce formulaire avant que les propriétés puissent être récupérées.');

/********************* Release R1.7 additions ***********************/
define('POPUP_BAR_CODE_TITLE','Saisie de Code Barre');
define('ORD_BAR_CODE_INTRO','Entrez la quantité et scannez l&#39;article.');
define('TEXT_UPC_CODE','Code Barre');

/********************************************************************/
// General
define('ORD_ADD_UPDATE', 'Ajouter/Mettre à jour');
define('ORD_AP_ACCOUNT', 'Compte A/P');
define('ORD_AR_ACCOUNT', 'Compte A/R');
define('ORD_CASH_ACCOUNT', 'Compte espéces');
define('ORD_CLOSED','Fermé ?');
define('ORD_COPY_BILL','Copier -->');
define('ORD_CUSTOMER_NAME','Nom Client');
define('ORD_DELETE_ALERT','Êtes-vous sûr(e) de vouloir supprimer cette commande ?');
define('ORD_DELIVERY_DATES', 'Dates de livraison');
define('ORD_DISCOUNT_PERCENT','Pourcentage de remise (%)');
define('ORD_DROP_SHIP', 'Livraison directe');
define('ORD_EXPECTED_DATES','Dates de livraison prévues - ');
define('ORD_FREIGHT', 'Port');
define('ORD_FREIGHT_ESTIMATE', 'Estimation du port');
define('ORD_FREIGHT_SERVICE', 'Service');
define('ORD_INVOICE_TOTAL', 'Total facturé');
define('ORD_MANUAL_ENTRY', 'Saisie manuelle');
define('ORD_NA','N/A');
define('ORD_NEW_DELIVERY_DATES', 'Nouvelles dates de livraison');
define('ORD_PAID', 'Payé');
define('ORD_PURCHASE_TAX', 'Taxe sur les achats');
define('ORD_ROW_DELETE_ALERT','Êtes-vous sûr(e) de vouloir supprimer cette ligne ?');
define('ORD_SALES_TAX', 'Taxe sur les ventes');
define('ORD_SHIP_CARRIER', 'Transporteur');
define('ORD_SHIP_TO', 'Livrer à:');
define('ORD_SHIPPED', 'Livré');
define('ORD_SUBTOTAL', 'Sous-total');
define('ORD_TAX_RATE', 'Taux de Taxe');
define('ORD_TAXABLE', 'Taxable');
define('ORD_VENDOR_NAME','Nom fournisseur');
define('ORD_VOID_SHIP','Annuler l&#39;envoi');
define('ORD_WAITING_FOR_INVOICE','En attente de facturation');
define('ORD_WAITING','Attente ?');
define('ORD_SO_INV_MESSAGE','Laissez les commandes clients ou le numéro de facture à vide pour que le système y attribue un numéro.');
define('ORD_CONVERT_TO_SO_INV','Convertir en commande client/facture');
define('ORD_CONVERT_TO_SO','Convertir en commande fournisseur ');
define('ORD_CONVERT_TO_INV','Convertir en facture ');
define('ORD_PO_MESSAGE','Laissez le numéro de commande fournisseur à vide pour que le système y attribue un numéro.');
define('ORD_CONVERT_TO_SO_INV','Convertir en commande client/facture');
define('ORD_CONVERT_TO_PO','Générer automatiquement les commandes fournisseurs ');

// Javascript Messages
define('ORD_JS_RECUR_NO_INVOICE','Pour une transaction récurrente, un numéro de facture de départ doit être entré. PhreeBooks incrémentera ce numéro à chaque écriture récurrente.');
define('ORD_JS_RECUR_ROLL_REQD','Il s&#39;agit d&#39;une écriture récurrente. Voulez-vous aussi mettre à jour les écritures futures ? (Appuyez sur Annuler pour mettre à jour cette écriture seulement)');
define('ORD_JS_RECUR_DEL_ROLL_REQD','Il s&#39;agit d&#39;une écriture récurrente. Voulez-vous aussi supprimer les écritures futures ? (Appuyez sur Annuler pour supprimer cette écriture seulement)');
define('ORD_JS_WAITING_FOR_PAYMENT','Soit attendre que la facture soit vérifiée, soit qu&#39;un numéro de facture soit entré.');
define('ORD_JS_SERIAL_NUM_PROMPT','Entrez le numéro de série pour cette ligne article. NOTE: La quantité doit être 1 pour les articles sérialisés.');
define('ORD_JS_NO_STOCK_A','AVERTISSEMENT! Il n&#39;y a pas assez d&#39;articles SKU ');
define('ORD_JS_NO_STOCK_B',' en stock pour remplir la commande.\nLe nombre d&#39;articles en stock est de: ');
define('ORD_JS_NO_STOCK_C','\n\nCliquez sur OK pour continuer ou sur Annuler pour revenir au formulaire de commande.');
define('ORD_JS_INACTIVE_A','AVERTISSEMENT! Le SKU: ');
define('ORD_JS_INACTIVE_B',' est un article inactif.\n\nCliquez sur OK pour continuer ou sur Annuler pour revenir au formulaire de commande');
define('ORD_JS_CANNOT_CONVERT_QUOTE','Un devis de vente non-posté ne peut être converti en une commande client ou une vente/facture !');
define('ORD_JS_CANNOT_CONVERT_SO','Une commande client non-postée ne peut être convertie en une commande fournisseur !');

// Audit log messages
define('ORD_DELIVERY_DATES','Dates de livraison des commandes clients/fournisseurs - ');

// Recur Transactions
define('ORD_RECUR_INTRO','Cette transaction peut être répétée à l&#39;avenir en sélectionnant le nombre d&#39;écritures à créer et la fréquence à laquelle elles sont postées. L&#39;écriture actuelle est considérée comme la première répétition.');
define('ORD_RECUR_ENTRIES','Entrez le nombre d&#39;écritures à créer');
define('ORD_RECUR_FREQUENCY','Combien de fois poster les écritures');
define('ORD_TEXT_WEEKLY','Hebdomadaire');
define('ORD_TEXT_BIWEEKLY','Bi-hebdomadaire');
define('ORD_TEXT_MONTHLY','Mensuel');
define('ORD_TEXT_QUARTERLY','Trimestriel');
define('ORD_TEXT_YEARLY','Annuel');
define('ORD_PAST_LAST_PERIOD','La transaction postée ne peut se répéter au delà de la dernière période dans le système !');

// Tooltips
define('ORD_TT_PURCH_INV_NUM','Si vous laissez ce champ vide, Phreebooks va automatiquement y attribuer un numéro.');

// Purchase Quote Specific
define('ORD_TEXT_3_BILL_TO', 'Remettre à:');
define('ORD_TEXT_3_REF_NUM', 'Référence #');
define('ORD_TEXT_3_WINDOW_TITLE','Demande de devis');
define('ORD_TEXT_3_EXPIRES', 'Date d&#39;expiration');
define('ORD_TEXT_3_NUMBER', 'N° de Devis');
define('ORD_TEXT_3_TEXT_REP', 'Acheteur');
define('ORD_TEXT_3_ITEM_COLUMN_1','Qté');
define('ORD_TEXT_3_ITEM_COLUMN_2','Reçu');
define('ORD_TEXT_3_ERROR_NO_VENDOR','Aucun fournisseur sélectionné ! Soit choisissez un fournisseur dans le menu contextuel, soit entrez les informations et sélectionnez: ' . ORD_ADD_UPDATE);
define('ORD_TEXT_3_NUMBER_OF_ORDERS', TEXT_DISPLAY_NUMBER . 'devis fourniseur');
define('ORD_TEXT_3_CLOSED_TEXT',TEXT_CLOSE);

// Purchase Order Specific
define('ORD_TEXT_4_BILL_TO', 'Remettre à:');
define('ORD_TEXT_4_REF_NUM', 'Référence #');
define('ORD_TEXT_4_WINDOW_TITLE','Commande Fournisseur');
define('ORD_TEXT_4_EXPIRES', 'Date d&#39;expiration');
define('ORD_TEXT_4_NUMBER', 'N° de Commande Fournisseur');
define('ORD_TEXT_4_TEXT_REP', 'Acheteur');
define('ORD_TEXT_4_ITEM_COLUMN_1','Qté');
define('ORD_TEXT_4_ITEM_COLUMN_2','Reçu');
define('ORD_TEXT_4_ERROR_NO_VENDOR','Aucun fournisseur sélectionné ! Soit choisissez un fournisseur dans le menu contextuel, soit entrez les informations et sélectionnez: ' . ORD_ADD_UPDATE);
define('ORD_TEXT_4_NUMBER_OF_ORDERS', TEXT_DISPLAY_NUMBER . 'commandes fournisseurs');
define('ORD_TEXT_4_CLOSED_TEXT',TEXT_CLOSE);

// Purchase/Receive Specific
define('ORD_TEXT_6_BILL_TO', 'Remettre à:');
define('ORD_TEXT_6_REF_NUM', 'Référence #');
define('ORD_TEXT_6_WINDOW_TITLE','Inventaire Achat/Recevoir');
define('ORD_TEXT_6_ERROR_NO_VENDOR','Aucun fournisseur sélectionné ! Soit choisissez un fournisseur dans le menu contextuel, soit entrez les informations et sélectionnez: ' . ORD_ADD_UPDATE);
define('ORD_TEXT_6_NUMBER', 'N° de Facture');
define('ORD_TEXT_6_TEXT_REP', 'Acheteur');
define('ORD_TEXT_6_ITEM_COLUMN_1','Solde Com.Fournisseur');
define('ORD_TEXT_6_ITEM_COLUMN_2','Reçu');
define('ORD_TEXT_6_NUMBER_OF_ORDERS', TEXT_DISPLAY_NUMBER . 'articles reçus');
define('ORD_TEXT_6_CLOSED_TEXT','Facture acquittée');

// Vendor Credit Memo Specific
define('ORD_TEXT_7_BILL_TO', 'Remettre à:');
define('ORD_TEXT_7_REF_NUM', 'Référence #');
define('ORD_TEXT_7_WINDOW_TITLE','Avoir Fournisseur');
define('ORD_TEXT_7_ERROR_NO_VENDOR','Aucun fournisseur sélectionné ! Soit choisissez un fournisseur dans le menu contextuel, soit entrez les informations et sélectionnez: ' . ORD_ADD_UPDATE);
define('ORD_TEXT_7_NUMBER', 'N° d&#39;Avoir');
define('ORD_TEXT_7_TEXT_REP', 'Acheteur');
define('ORD_TEXT_7_ITEM_COLUMN_1','Reçu');
define('ORD_TEXT_7_ITEM_COLUMN_2','Retourné');
define('ORD_TEXT_7_NUMBER_OF_ORDERS', TEXT_DISPLAY_NUMBER . 'factures fournisseurs');
define('ORD_TEXT_7_CLOSED_TEXT','Avoir pris');

// Customer Quote Specific
define('ORD_TEXT_9_BILL_TO', 'Facturer à:');
define('ORD_TEXT_9_REF_NUM', 'Commande #');
define('ORD_TEXT_9_WINDOW_TITLE','Devis Client');
define('ORD_TEXT_9_EXPIRES', 'Date d&#39;expiration');
define('ORD_TEXT_9_NUMBER', 'N° de Devis');
define('ORD_TEXT_9_TEXT_REP', 'Représentant Ventes');
define('ORD_TEXT_9_ITEM_COLUMN_1','Qté');
define('ORD_TEXT_9_ITEM_COLUMN_2','Facturé');
define('ORD_TEXT_9_ERROR_NO_VENDOR','Aucun client sélectionné ! Soit choisissez un client dans le menu contextuel, soit entrez les informations et sélectionnez: ' . ORD_ADD_UPDATE);
define('ORD_TEXT_9_NUMBER_OF_ORDERS', TEXT_DISPLAY_NUMBER . 'devis client');
define('ORD_TEXT_9_CLOSED_TEXT',TEXT_CLOSE);

// Sales Order Specific
define('ORD_TEXT_10_BILL_TO', 'Facturer à:');
define('ORD_TEXT_10_REF_NUM', 'Commande #');
define('ORD_TEXT_10_WINDOW_TITLE','Commande Client');
define('ORD_TEXT_10_EXPIRES', 'Livrer à date');
define('ORD_TEXT_10_NUMBER', 'N° de Commande Client');
define('ORD_TEXT_10_TEXT_REP', 'Représentant Ventes');
define('ORD_TEXT_10_ITEM_COLUMN_1','Qté');
define('ORD_TEXT_10_ITEM_COLUMN_2','Facturé');
define('ORD_TEXT_10_ERROR_NO_VENDOR','Aucun client sélectionné ! Soit choisissez un client dans le menu contextuel, soit entrez les informations et sélectionnez: ' . ORD_ADD_UPDATE);
define('ORD_TEXT_10_NUMBER_OF_ORDERS', TEXT_DISPLAY_NUMBER . 'commandes clients');
define('ORD_TEXT_10_CLOSED_TEXT',TEXT_CLOSE);

// Ventes/Facture Specific
define('ORD_TEXT_12_BILL_TO', 'Facturer à:');
define('ORD_TEXT_12_REF_NUM', 'Commande #');
define('ORD_TEXT_12_WINDOW_TITLE','Ventes/Facture');
define('ORD_TEXT_12_EXPIRES', 'Livrer à date');
define('ORD_TEXT_12_ERROR_NO_VENDOR','Aucun client sélectionné !');
define('ORD_TEXT_12_NUMBER', 'N° de Facture');
define('ORD_TEXT_12_TEXT_REP', 'Représentant Ventes');
define('ORD_TEXT_12_ITEM_COLUMN_1','Solde Com.Fournisseur');
define('ORD_TEXT_12_ITEM_COLUMN_2','Qté');
define('ORD_TEXT_12_NUMBER_OF_ORDERS', TEXT_DISPLAY_NUMBER . 'factures');
define('ORD_TEXT_12_CLOSED_TEXT','Payé en totalité');

// Customer Credit Memo Specific
define('ORD_TEXT_13_BILL_TO', 'Facturer à:');
define('ORD_TEXT_13_REF_NUM', 'Référence');
define('ORD_TEXT_13_WINDOW_TITLE','Avoir Client');
define('ORD_TEXT_13_EXPIRES', 'Livrer à date');
define('ORD_TEXT_13_ERROR_NO_VENDOR','Aucun client sélectionné !');
define('ORD_TEXT_13_NUMBER', 'N° d&#39;Avoir');
define('ORD_TEXT_13_TEXT_REP', 'Représentant Ventes');
define('ORD_TEXT_13_ITEM_COLUMN_1','Livré');
define('ORD_TEXT_13_ITEM_COLUMN_2','Retourné');
define('ORD_TEXT_13_NUMBER_OF_ORDERS', TEXT_DISPLAY_NUMBER . 'factures');
define('ORD_TEXT_13_CLOSED_TEXT','Crédit payé');

/*
// Cash Receipts Specific
define('ORD_TEXT_18_BILL_TO', 'Vente à:');
define('ORD_TEXT_18_REF_NUM', 'Commande #');
define('ORD_TEXT_18_WINDOW_TITLE','Recettes espèces');
define('ORD_TEXT_18_EXPIRES', 'Livrer à date');
define('ORD_TEXT_18_ERROR_NO_VENDOR','Aucun client sélectionné !');
define('ORD_TEXT_18_NUMBER', 'N° de Reçu');
define('ORD_TEXT_18_TEXT_REP', 'Rep Ventes');
define('ORD_TEXT_18_ITEM_COLUMN_1','Solde Com.Fournisseur');
define('ORD_TEXT_18_ITEM_COLUMN_2','Qté');
define('ORD_TEXT_18_NUMBER_OF_ORDERS', TEXT_DISPLAY_NUMBER . 'reçus');

// Point of Sale Specific
define('ORD_TEXT_19_BILL_TO', 'Vente à:');
define('ORD_TEXT_19_REF_NUM', 'Commande #');
define('ORD_TEXT_19_WINDOW_TITLE','Point de vente');
define('ORD_TEXT_19_EXPIRES', 'Livrer à date');
define('ORD_TEXT_19_ERROR_NO_VENDOR','Aucun client sélectionné !');
define('ORD_TEXT_19_NUMBER', 'N° de Reçu');
define('ORD_TEXT_19_TEXT_REP', 'Rep Ventes');
define('ORD_TEXT_19_ITEM_COLUMN_1','Solde Com.Fournisseur');
define('ORD_TEXT_19_ITEM_COLUMN_2','Qté');
define('ORD_TEXT_19_NUMBER_OF_ORDERS', TEXT_DISPLAY_NUMBER . 'ventes');

// Cash Distribution Journal
define('ORD_TEXT_20_BILL_TO', 'Remettre à:');
define('ORD_TEXT_20_REF_NUM', 'Référence #');
define('ORD_TEXT_20_WINDOW_TITLE','Distribution en espèces');
define('ORD_TEXT_20_ERROR_NO_VENDOR','Aucun fournisseur sélectionné ! Soit choisissez un fournisseur dans le menu contextuel, soit entrez les informations et sélectionnez: ' . ORD_ADD_UPDATE);
define('ORD_TEXT_20_NUMBER', 'N° de Paiement');
define('ORD_TEXT_20_TEXT_REP', 'Acheteur');
define('ORD_TEXT_20_ITEM_COLUMN_1','Solde Com.Fournisseur');
define('ORD_TEXT_20_ITEM_COLUMN_2','Reçu');
define('ORD_TEXT_20_NUMBER_OF_ORDERS', TEXT_DISPLAY_NUMBER . 'paiements');

// Direct Inventory Purchase/Receive (Checks)
define('ORD_TEXT_21_BILL_TO', 'Remettre à:');
define('ORD_TEXT_21_REF_NUM', 'Référence #');
define('ORD_TEXT_21_WINDOW_TITLE','Achat direct');
define('ORD_TEXT_21_ERROR_NO_VENDOR','Aucun fournisseur sélectionné ! Soit choisissez un fournisseur dans le menu contextuel, soit entrez les informations et sélectionnez: ' . ORD_ADD_UPDATE);
define('ORD_TEXT_21_NUMBER', 'N° de Paiement');
define('ORD_TEXT_21_TEXT_REP', 'Acheteur');
define('ORD_TEXT_21_ITEM_COLUMN_1','Solde Com.Fournisseur');
define('ORD_TEXT_21_ITEM_COLUMN_2','Reçu');
define('ORD_TEXT_21_NUMBER_OF_ORDERS', TEXT_DISPLAY_NUMBER . 'paiements');
*/

// popup specific
define('ORD_POPUP_WINDOW_TITLE_3', 'Devis fournisseur');
define('ORD_POPUP_WINDOW_TITLE_4', 'Commande Fournisseurs');
define('ORD_POPUP_WINDOW_TITLE_6', 'Achat/Reçus de Stock');
define('ORD_POPUP_WINDOW_TITLE_7', 'Avoir fournisseur');
define('ORD_POPUP_WINDOW_TITLE_9', 'Demande de devis');
define('ORD_POPUP_WINDOW_TITLE_10', 'Commandes Clients');
define('ORD_POPUP_WINDOW_TITLE_12', 'Ventes/Factures');
define('ORD_POPUP_WINDOW_TITLE_13', 'Avoir');
//define('ORD_POPUP_WINDOW_TITLE_19', 'Point de vente');
//define('ORD_POPUP_WINDOW_TITLE_21', 'Achat direct de stock');

// recur specific
define('ORD_RECUR_WINDOW_TITLE_2', 'Entrées Journal Général récurrentes');
define('ORD_RECUR_WINDOW_TITLE_3', 'Devis fournisseurs récurrents');
define('ORD_RECUR_WINDOW_TITLE_4', 'Commandes Fournisseurs récurrentes');
define('ORD_RECUR_WINDOW_TITLE_6', 'Achat/Reçus de Stock récurrents');
define('ORD_RECUR_WINDOW_TITLE_7', 'Avoirs fournisseurs récurrents');
define('ORD_RECUR_WINDOW_TITLE_9', 'Demande de devis récurrentes');
define('ORD_RECUR_WINDOW_TITLE_10', 'Commandes Clients récurrentes');
define('ORD_RECUR_WINDOW_TITLE_12', 'Ventes/Factures récurrentes');
define('ORD_RECUR_WINDOW_TITLE_13', 'Avoirs récurrents');
//define('ORD_RECUR_WINDOW_TITLE_19', 'Point de vente récurrents');
//define('ORD_RECUR_WINDOW_TITLE_21', 'Achat direct de stock récurrents');

define('ORD_HEADING_NUMBER_3', 'N° de Devis');
define('ORD_HEADING_NUMBER_4', 'N° de Commande Fournisseur');
define('ORD_HEADING_NUMBER_6', 'Facture #');
define('ORD_HEADING_NUMBER_7', 'N° d&#39;Avoir');
define('ORD_HEADING_NUMBER_9', 'N° de Devis');
define('ORD_HEADING_NUMBER_10', 'N° de Commande Client');
define('ORD_HEADING_NUMBER_12', 'Facture #');
define('ORD_HEADING_NUMBER_13', 'N° d&#39;Avoir');
//define('ORD_HEADING_NUMBER_19', 'N° de Reçu');
//define('ORD_HEADING_NUMBER_21', 'N° de Paiement');

define('ORD_HEADING_STATUS_3', ORD_CLOSED);
define('ORD_HEADING_STATUS_4', ORD_CLOSED);
define('ORD_HEADING_STATUS_6', ORD_WAITING);
define('ORD_HEADING_STATUS_7', ORD_WAITING);
define('ORD_HEADING_STATUS_9', ORD_CLOSED);
define('ORD_HEADING_STATUS_10', ORD_CLOSED);
define('ORD_HEADING_STATUS_12', TEXT_PAID);
define('ORD_HEADING_STATUS_13', TEXT_PAID);
//define('ORD_HEADING_STATUS_19', ORD_CLOSED);
//define('ORD_HEADING_STATUS_21', ORD_CLOSED);

define('ORD_HEADING_NAME_3',ORD_VENDOR_NAME);
define('ORD_HEADING_NAME_4',ORD_VENDOR_NAME);
define('ORD_HEADING_NAME_6',ORD_VENDOR_NAME);
define('ORD_HEADING_NAME_7',ORD_VENDOR_NAME);
define('ORD_HEADING_NAME_9',ORD_CUSTOMER_NAME);
define('ORD_HEADING_NAME_10',ORD_CUSTOMER_NAME);
define('ORD_HEADING_NAME_12',ORD_CUSTOMER_NAME);
define('ORD_HEADING_NAME_13',ORD_CUSTOMER_NAME);
//define('ORD_HEADING_NAME_19',ORD_CUSTOMER_NAME);
//define('ORD_HEADING_NAME_21',ORD_VENDOR_NAME);

?>