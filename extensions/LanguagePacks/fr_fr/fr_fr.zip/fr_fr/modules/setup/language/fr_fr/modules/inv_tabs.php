<?php
// +-----------------------------------------------------------------+
// |                   PhreeBooks Open Source ERP                    |
// +-----------------------------------------------------------------+
// | Copyright (c) 2008, 2009, 2010 PhreeSoft, LLC                   |
// | http://www.PhreeSoft.com                                        |
// +-----------------------------------------------------------------+
// | This program is free software: you can redistribute it and/or   |
// | modify it under the terms of the GNU General Public License as  |
// | published by the Free Software Foundation, either version 3 of  |
// | the License, or any later version.                              |
// |                                                                 |
// | This program is distributed in the hope that it will be useful, |
// | but WITHOUT ANY WARRANTY; without even the implied warranty of  |
// | MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the   |
// | GNU General Public License for more details.                    |
// |                                                                 |
// | The license that is bundled with this package is located in the |
// | file: /doc/manual/ch01-Introduction/license.html.               |
// | If not, see http://www.gnu.org/licenses/                        |
// +-----------------------------------------------------------------+
//  Path: /modules/setup/language/fr_fr/modules/inv_tabs.php
//

define('INV_CAT_HEADING_TITLE', 'Onglets de Stock');
define('INV_HEADING_CATEGORY_NAME', 'Nom Catégorie');
define('INV_INFO_CATEGORY_DESCRIPTION', 'Description de la catégorie');
define('INV_INFO_CATEGORY_NAME', 'Nom de la catégorie de stock<br />Le nom doit être court (10), sans caractères spéciaux ou espaces.');
define('INV_INFO_INSERT_INTRO', 'Veuillez entrer la nouvelle catégorie avec ses propriétés');
define('INV_EDIT_INTRO', 'Veuillez faire les changements nécessaires');
define('INV_INFO_HEADING_NEW_CATEGORY', 'Nouvelle catégorie');
define('INV_INFO_HEADING_EDIT_CATEGORY', 'Modifier la catégorie');
define('INV_INFO_DELETE_INTRO', 'Êtes-vous sûr(e) de vouloir supprimer cette catégorie ?\nLes catégories ne peuvent pas être supprimées s&#39;il y a un champ du stock dans la catégorie.');
define('INV_INFO_DELETE_ERROR','Ce nom de catégorie existe déjà, veuillez utiliser un autre nom.');
define('TEXT_DISPLAY_NUMBER_OF_CATEGORIES', TEXT_DISPLAY_NUMBER . 'catégories');
define('INV_TABS_LOG','Onglets de stock - ');

?>