<?php
// +-----------------------------------------------------------------+
// |                   PhreeBooks Open Source ERP                    |
// +-----------------------------------------------------------------+
// | Copyright (c) 2008, 2009, 2010 PhreeSoft, LLC                   |
// | http://www.PhreeSoft.com                                        |
// +-----------------------------------------------------------------+
// | This program is free software: you can redistribute it and/or   |
// | modify it under the terms of the GNU General Public License as  |
// | published by the Free Software Foundation, either version 3 of  |
// | the License, or any later version.                              |
// |                                                                 |
// | This program is distributed in the hope that it will be useful, |
// | but WITHOUT ANY WARRANTY; without even the implied warranty of  |
// | MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the   |
// | GNU General Public License for more details.                    |
// |                                                                 |
// | The license that is bundled with this package is located in the |
// | file: /doc/manual/ch01-Introduction/license.html.               |
// | If not, see http://www.gnu.org/licenses/                        |
// +-----------------------------------------------------------------+
//  Path: /modules/setup/language/fr_fr/modules/zones.php
//

define('SETUP_TITLE_ZONES', 'Régions/Départements');
define('SETUP_HEADING_NEW_ZONE', 'Nouvelle région/nouveau département');
define('SETUP_HEADING_EDIT_ZONE', 'Modifier la région/le département');
define('SETUP_INFO_HEADING_DELETE_ZONE', 'Supprimer la région/le département');
define('SETUP_HEADING_ZONE_CODE', 'Code');
define('SETUP_ZONES_EDIT_INTRO', 'Veuillez faire les changements nécessaires');
define('SETUP_INFO_ZONES_NAME', 'Nom de région/département:');
define('SETUP_INFO_ZONES_CODE', 'Code de région/département:');
define('SETUP_ZONES_INSERT_INTRO', 'Veuillez entrer la nouvelle région/le nouveau département avec ses données associées');
define('SETUP_ZONES_DELETE_INTRO', 'Êtes-vous sûr(e) de vouloir supprimer cette région/ce département ?');
define('TEXT_DISPLAY_NUMBER_OF_ZONES', TEXT_DISPLAY_NUMBER . 'régions/départements');
define('SETUP_ZONES_LOG','Régions/Départements - ');

?>