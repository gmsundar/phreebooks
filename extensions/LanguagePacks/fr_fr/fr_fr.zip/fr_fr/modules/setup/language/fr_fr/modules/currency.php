<?php
// +-----------------------------------------------------------------+
// |                   PhreeBooks Open Source ERP                    |
// +-----------------------------------------------------------------+
// | Copyright (c) 2008, 2009, 2010 PhreeSoft, LLC                   |
// | http://www.PhreeSoft.com                                        |
// +-----------------------------------------------------------------+
// | This program is free software: you can redistribute it and/or   |
// | modify it under the terms of the GNU General Public License as  |
// | published by the Free Software Foundation, either version 3 of  |
// | the License, or any later version.                              |
// |                                                                 |
// | This program is distributed in the hope that it will be useful, |
// | but WITHOUT ANY WARRANTY; without even the implied warranty of  |
// | MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the   |
// | GNU General Public License for more details.                    |
// |                                                                 |
// | The license that is bundled with this package is located in the |
// | file: /doc/manual/ch01-Introduction/license.html.               |
// | If not, see http://www.gnu.org/licenses/                        |
// +-----------------------------------------------------------------+
//  Path: /modules/setup/language/fr_fr/modules/currency.php
//

define('SETUP_TITLE_CURRENCIES', 'Devises');
define('SETUP_CURRENCY_NAME', 'Devise');
define('SETUP_CURRENCY_CODES', 'Code');
define('SETUP_UPDATE_EXC_RATE','Mettre à jour le taux de change');

define('SETUP_CURR_EDIT_INTRO', 'Veuillez faire les changements nécessaires');
define('SETUP_INFO_CURRENCY_TITLE', 'Intitulé:');
define('SETUP_INFO_CURRENCY_CODE', 'Code:');
define('SETUP_INFO_CURRENCY_SYMBOL_LEFT', 'Symbole de gauche:');
define('SETUP_INFO_CURRENCY_SYMBOL_RIGHT', 'Symbole de droite:');
define('SETUP_INFO_CURRENCY_DECIMAL_POINT', 'Point décimal:');
define('SETUP_INFO_CURRENCY_THOUSANDS_POINT', 'Point des milliers:');
define('SETUP_INFO_CURRENCY_DECIMAL_PLACES', 'Décimales:');
define('SETUP_INFO_CURRENCY_DECIMAL_PRECISE', 'Précision décimale: Pour usage avec les prix unitaires et les quantités à une plus grande précision que la valeur des devises. Cette valeur est généralement réglée sur le nombre de décimales:');
define('SETUP_INFO_CURRENCY_VALUE', 'Valeur:');
define('SETUP_INFO_CURRENCY_EXAMPLE', 'Exemple de sortie:');
define('SETUP_CURR_INSERT_INTRO', 'Veuillez entrer la nouvelle devise avec ses données associées');
define('SETUP_CURR_DELETE_INTRO', 'Êtes-vous sûr(e) de vouloir supprimer cette devise ?');
define('SETUP_INFO_HEADING_NEW_CURRENCY', 'Nouvelle devise');
define('SETUP_INFO_HEADING_EDIT_CURRENCY', 'Modifier devise');
define('SETUP_INFO_HEADING_DELETE_CURRENCY', 'Supprimer devise');
define('SETUP_SET_DEFAULT', 'Définir par défaut');
define('SETUP_INFO_SET_AS_DEFAULT', SETUP_SET_DEFAULT . ' (nécessite une mise à jour manuelle des valeurs des devises)');
define('SETUP_INFO_CURRENCY_UPDATED', 'Le taux de change pour %s (%s) a été mis à jour avec succès via %s.');

define('SETUP_ERROR_CANNOT_CHANGE_DEFAULT', 'La devise par défaut ne peut pas être modifiée une fois que des écritures ont été introduites dans le système !');
define('SETUP_ERROR_REMOVE_DEFAULT_CURRENCY', 'ERREUR: La devise par défaut ne peut pas être supprimée. Veuillez définir une autre monnaie par défaut, et essayez à nouveau.');
define('SETUP_ERROR_CURRENCY_INVALID', 'ERREUR: Le taux de change pour %s (%s) n&#39;a pas été mis à jour via %s. Est-ce un code de devise valide ?');
define('SETUP_WARN_PRIMARY_SERVER_FAILED', 'ATTENTION: Le serveur primaire de taux de change (%s) a échoué pour %s (%s) - Essai avec le serveur secondaire de taux de change.');
define('TEXT_DISPLAY_NUMBER_OF_CURRENCIES', TEXT_DISPLAY_NUMBER . 'devises');
define('SETUP_LOG_CURRENCY','Devises - ');

?>