<?php
/* French - FR language file */

// Window heading label
define('HEADING_TITLE','Aide Phreebooks  - Propuls� par PhreeHelp');

// Icon labels
define('ICON_HOME','Accueil');
define('ICON_BACK','Pr�c�dente');
define('ICON_FORWARD','Suivante');
define('ICON_PRINT','Imprimer');
define('ICON_SUPPORT','Support');
define('ICON_EXIT','Sortie');

// Tab Labels
define('HEADING_CONTENTS','Contenu');
define('HEADING_INDEX','Index');
define('HEADING_SEARCH','Recherche');

// General text definitions
define('TEXT_KEYWORD','Entrez le mot-cl� � rechercher:');
define('TEXT_SEARCH_RESULTS','Vos r�sultats de recherche:');
define('TEXT_EXPAND','D�velopper');
define('TEXT_COLLAPSE','R�duire');

// error messages
define('NO_CONNECT_DB','Impossible de se connecter � la base de donn�es. Check the DB_SERVER, settings in the configure.php file or see your database administrator to create the database and set privileges.');
define('TEXT_NO_VERSION','Impossible de trouver le fichier des informations de version: ');
define('TEXT_CHECK_CONFIG','V�rifiez dans votre config.php si les informations sont correctes.');
define('TEXT_FAILED_OPEN_DIR','�chec d&#39;ouverture du r�pertoire: ');
define('TEXT_NO_RESULTS','Aucun r�sultat trouv�. Le mot de recherche doit avoir au moins 4 caract�res et ne pas �tre un mot courant.');
?>